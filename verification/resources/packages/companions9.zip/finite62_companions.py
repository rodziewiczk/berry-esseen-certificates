"""Nine original62D/E companion checkers with truthful current MID captures.

Every mathematical source/candidate is unchanged. The historical run reference
namespace receives only newly observed actual argv/cwd/source/streams after the
three original MID part producers complete; no old capture is staged or relabelled.
"""
from pathlib import Path,PurePosixPath
from hashlib import file_digest
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
import argparse,json,re,shutil,subprocess,sys,time
HERE=Path(__file__).resolve().parent
def need(ok,message):
 if not ok:raise ValueError(message)
def enc(value):return(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('ascii')
def unique(pairs):
 value={}
 for k,v in pairs:need(k not in value,'Unique JSON key');value[k]=v
 return value
def invalid(_):raise ValueError('Finite JSON')
def read(path):return json.loads(Path(path).read_bytes(),object_pairs_hook=unique,parse_constant=invalid)
def same(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if type(a)is list:return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def digest(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'Whole regular source/result')
 with p.open('rb')as stream:return file_digest(stream,'sha256').hexdigest()
def verify_source():
 rows=read(HERE/'FINITE62-COMPANIONS-SOURCE-VERIFIED.json')['files']
 for name,pin in rows.items():need(digest(HERE/name)==pin,'Every complete static source/untrusted candidate: '+name)
 return rows
def terminal(raw):
 need(type(raw)is bytes and 0<len(raw)<=256*1024**2,'Bounded complete native stdout')
 text=raw.decode('utf-8');decoder=json.JSONDecoder(object_pairs_hook=unique,parse_constant=invalid)
 for start in reversed([m.start()for m in re.finditer(r'(?m)^\{',text)]):
  try:value,end=decoder.raw_decode(text,start)
  except ValueError:continue
  if not text[end:].strip():need(type(value)is dict,'Whole final native object');return value
 raise ValueError('Whole native final JSON absent')
def write_capture(root,step,report,logs):
 """Actual new aliases, built only from a directly observed complete producer."""
 target=root/step['capture_alias'];need(not target.exists(),'Exclusive current capture reference namespace');target.mkdir(parents=True)
 pins={PurePosixPath(name).relative_to(PurePosixPath(step['cwd'])).as_posix():pin for name,pin in report['input_sha256'].items()}
 need(step['entry']in pins and report['returncode']==0,'Actually executed source driver and complete current input graph')
 for channel in('stdout','stderr'):shutil.copyfile(logs/(channel+'.txt'),target/(channel+'.txt'))
 metadata=dict(schema='NEW_FINITE62_CURRENT_NATIVE_EXECUTION_AT_ORIGINAL_REFERENCE_PATH_V1',command=report['argv'],cwd=report['cwd'],
  returncode=report['returncode'],input_sha256=pins,stdout_sha256=report['stdout_sha256'],stderr_sha256=report['stderr_sha256'],
  elapsed_seconds=report['seconds'],started_unix=report['started_unix'],finished_unix=report['finished_unix'],
  original_source_program_sha256=step['whole_original_source_sha256'],new_current_execution=True,historical_execution_claimed_current=False,
  original_action_reference=step['original_action_id'],owned_current_outputs=report['owned_outputs'],mathematical_acceptance=False)
 (target/'metadata.json').write_bytes(enc(metadata));return digest(target/'metadata.json')
def execute_stage(task,step,deadline):
 root=task/'capsule';cwd=root/step['cwd'];before={name:digest(root/name)for name in step['input_pins']}
 need(before==step['input_pins']and time.time()<deadline,'Whole original input graph before genuine execution')
 need(all(not(root/name).exists()for name in step['owned_outputs']),'Fresh numerical outputs only')
 logs=task/'executions'/step['id'];logs.mkdir(parents=True);argv=[sys.executable,'-B','-S',step['entry'],*step['arguments']]
 (logs/'ARGV.json').write_bytes(enc(dict(argv=argv,cwd=str(cwd),deadline=deadline)));started=time.time()
 remaining=deadline-time.time();need(remaining>1,'Native checker entry before the absolute horizon')
 with(logs/'stdout.txt').open('xb')as stdout,(logs/'stderr.txt').open('xb')as stderr:
  result=subprocess.run(argv,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=remaining,check=False)
 finished=time.time();need(type(result.returncode)is int and result.returncode==0 and(logs/'stderr.txt').stat().st_size==0,'Actual original full checker completed, empty stderr')
 actual=terminal((logs/'stdout.txt').read_bytes())
 if step['id']=='left_mid_bind':
  current={p:digest(root/('runs/toward40_20261007/local/actual_left40_mid_part_'+p+'01/metadata.json'))for p in'abc'}
  need(same(actual['arithmetic_metadata_sha256'],current),'All three exact genuine current producer metadata identities')
  numeric={k:v for k,v in actual.items()if k!='arithmetic_metadata_sha256'}
 else:numeric=actual
 need(same(numeric,step['expected_mathematical_terminal']),'Entire original numerical result, full domain, controls and source pins')
 need(before=={name:digest(root/name)for name in step['input_pins']},'Whole mathematical inputs unchanged after original native execution')
 outputs={name:digest(root/name)for name in step['owned_outputs']}
 report=dict(schema='NEW_FINITE62_COMPANION_ACTUAL_ORIGINAL_NATIVE_OBSERVATION_V1',id=step['id'],original_action_id=step['original_action_id'],argv=argv,cwd=str(cwd),
  returncode=0,started_unix=started,finished_unix=finished,seconds=finished-started,input_sha256=before,original_full_terminal=actual,
  stdout_sha256=digest(logs/'stdout.txt'),stderr_sha256=digest(logs/'stderr.txt'),owned_outputs=outputs,
  mathematical_program_modified=False,current_analytical_and_resource_licenses_still_required=True,mathematical_acceptance=False,full_proof_pass=False)
 if step['capture_alias']:report['new_current_reference_capture_sha256']=write_capture(root,step,report,logs)
 (logs/'OBSERVATION.json').write_bytes(enc(report));return report
def graph(task,steps,deadline,jobs):
 pending={s['id']:s for s in steps};completed={};failed={};active={}
 with ThreadPoolExecutor(max_workers=jobs)as pool:
  while pending or active:
   for key,step in list(pending.items()):
    if any(dep in failed for dep in step['depends']):failed[key]=dict(native_started=False,reason='DEPENDENCY_FAILED');del pending[key]
   for key,step in list(pending.items()):
    if len(active)>=jobs:break
    if all(dep in completed for dep in step['depends']):active[pool.submit(execute_stage,task,step,deadline)]=key;del pending[key]
   if not active:need(not pending,'Complete finite acyclic dependency graph');break
   done,_=wait(active,return_when=FIRST_COMPLETED)
   for future in done:
    key=active.pop(future)
    try:completed[key]=future.result()
    except Exception as error:failed[key]=dict(native_started=True,reason=type(error).__name__,message=str(error))
 return completed,failed
def main():
 p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('mode',choices=['run']);p.add_argument('--task',type=Path,required=True);p.add_argument('--deadline',type=int,required=True);p.add_argument('--jobs',type=int,choices=range(1,10),default=6);args=p.parse_args()
 need(__debug__ and not sys.flags.optimize and sys.dont_write_bytecode,'Ordinary exact no-bytecode execution')
 before=verify_source();d=read(HERE/'FINITE62-COMPANIONS-DESCRIPTION.json');task=args.task.absolute();need(not task.exists()and not task.is_relative_to(HERE)and time.time()<args.deadline,'Exclusive admitted new task')
 task.mkdir(parents=True);shutil.copytree(HERE/'payload',task/'capsule');completed,failed=graph(task,d['actions'],args.deadline,args.jobs)
 need(verify_source()==before,'Whole complete static source unchanged after every checker')
 report=dict(schema='NEW_FINITE62_NINE_ORIGINAL_COMPANIONS_OBSERVATION_V1',status='FINITE62_NINE_ORIGINAL_COMPANIONS_COMPLETED_CONDITIONAL'if not failed else'FINITE62_COMPANIONS_PARTIAL',
  native_actions=9,completed=completed,failed=failed,source_before=before,source_after=before,
  historical_capture_relabelled=False,additional_serial_left_full_mid_claimed_executed=False,
  original_current_resource_acquisition_and_low152_licenses_still_required=True,extra_indexed_initial_support_still_separate=True,mathematical_acceptance=False,full_proof_pass=False)
 (task/'RESULT.json').write_bytes(enc(report));print(json.dumps(dict(status=report['status'],completed=len(completed),failed=len(failed),result_sha256=digest(task/'RESULT.json'))),flush=True)
 return 0 if not failed else 1
if __name__=='__main__':raise SystemExit(main())
