"""Fixed signed MID domain on actual LEFT40 targets, finite n40..42."""
from fractions import Fraction as F
from central42_contract import read,profile
from normalization import generate_checked,rootup
from gap_table import epsilon
REGIONS=tuple((F(i,400),F(i+1,400))for i in range(20,54))
def contexts():
 for row in read():
  lm=F(row['lambda_max'])
  if lm<=F('.05'):continue
  for hs in(-1,1):
   base=dict(N=40,pl=F(row['p'][0]),pu=F(row['p'][1]),theta=F(row['theta']),H=F(row['H_minus'if hs<0 else'H_plus']),d0=F(row['d0']),amplitude=min(F('.45'),F(row['amplitude'])),maxnoise=lm,Ccap=F('.4247'))
   c=generate_checked(base);vmax=F(row['p'][1])*(1-F(row['p'][1]))
   c.update(epsilon=epsilon(row),rhoB_lower=(1-2*vmax)/rootup(vmax))
   for bi,(lo,end)in enumerate(REGIONS):
    hi=min(end,lm)
    if hi<=lo:continue
    start=F(0)if lo<F('.0925')else F('.16')if lo<F('.10')else F('.25')if lo<F('.12')else F('.27')
    band=0 if lo<F('.08')else 1 if lo<F('.10')else 2 if lo<F('.12')else 3 if lo<F('.125')else 4
    A=profile(row,hs,band);d=F(row['d0'])*(1-lo/lm)
    if not 0<d<=c['d0']:raise ValueError('Joint resource domain')
    steps=int((F('.5')-start)*1000)
    if start+F(steps,1000)!=F('.5'):raise ValueError('Closed phase cover')
    for sign in((-1,1)if lo<F('.12')else(-1,)):
     yield row['index'],hs,bi,lo,hi,start,A,d,steps,sign,c
