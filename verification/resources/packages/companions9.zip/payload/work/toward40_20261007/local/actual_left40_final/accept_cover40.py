"""Exact closed probability/noise/phase cover and malformed-cover controls."""
from fractions import Fraction as F
import json,copy,sys
from central42_contract import read,selected
from mid42_contract import contexts
from gap_table import epsilon
def need(x,s):
 if not x:raise ValueError(s)
def construct():
 rows=read();rects=[]
 for i,r in enumerate(rows):
  need(type(r['index'])is int and r['index']==i and list(map(F,r['p']))==[F('.282')+F(i,500),F('.282')+F(i+1,500)],'Complete p cover')
  need(epsilon(r)>0,'Zero-noise Bernoulli gap')
  for hs in(-1,1):
   rects.append(dict(index=i,Hsign=hs,kind='TINY',noise=[F(0),min(F('.05'),F(r['lambda_max']))],phase=[-F('.5'),F('.5')]))
   if F(r['lambda_max'])>F('.0925'):
    c=selected(r,hs)
    for (l,h,_),(a,b)in zip(c['noise_intervals'],c['phase_domains']):rects.append(dict(index=i,Hsign=hs,kind='LOW',noise=[l,h],phase=[-a,b]))
 for i,hs,bi,l,h,start,A,d,steps,sign,c in contexts():
  rects.append(dict(index=i,Hsign=hs,kind='MID',noise=[l,h],phase=[-F('.5'),-start]if sign<0 else[start,F('.5')]))
 return rects
def check(rects):
 rows=read();count=0
 for i,r in enumerate(rows):
  for hs in(-1,1):
   group=[x for x in rects if x['index']==i and x['Hsign']==hs]
   need(group,'Missing signed row')
   for x in group:
    need(type(x['index'])is int and type(x['Hsign'])is int,'Integer labels')
    l,h=x['noise'];a,b=x['phase'];need(F(0)<=l<h<=F(r['lambda_max'])and-F('.5')<=a<b<=F('.5'),'Rectangle domain')
   pts=sorted(set([F(0),F(r['lambda_max'])]+[y for x in group for y in x['noise']]))
   probes=pts+[(l+h)/2 for l,h in zip(pts,pts[1:])]
   for t in probes:
    phases=sorted(x['phase']for x in group if x['noise'][0]<=t<=x['noise'][1])
    right=-F('.5')
    for a,b in phases:
     need(a<=right,'Missing phase seam');right=max(right,b)
    need(right==F('.5'),'Missing phase endpoint');count+=1
 return dict(probability_cells=49,H_signs=2,closed_noise_probes=count,rectangles=len(rects))
def controls(rects):
 tests=[]
 def reject(name,r):
  try:check(r)
  except ValueError:tests.append(name)
  else:raise ValueError('Malformed cover accepted '+name)
 reject('missing_H_sign',[r for r in rects if not(r['index']==0 and r['Hsign']==-1)])
 reject('missing_TINY_noise',[r for r in rects if not(r['index']==0 and r['kind']=='TINY')])
 b=copy.deepcopy(rects)
 for r in b:
  if r['index']==0:r['phase'][1]=min(r['phase'][1],F('.49'))
 reject('missing_phase_endpoint',b)
 b=copy.deepcopy(rects)
 for r in b:
  if r['index']==48 and r['noise'][1]>F('.13'):r['noise'][1]=max(r['noise'][0],F('.13'))
 reject('missing_high_noise',b)
 b=copy.deepcopy(rects);b[0]['Hsign']=False;reject('boolean_sign',b)
 return tests
if __name__=='__main__':
 need(not sys.flags.optimize and __debug__ and len(sys.argv)==1,'Fixed unoptimized scope')
 r=construct();out=check(r);out.update(status='PASS_CLOSED_FINITE_LEFT40_42_COMPARISON_COVER',negative_controls=controls(r));print(json.dumps(out,indent=2))
