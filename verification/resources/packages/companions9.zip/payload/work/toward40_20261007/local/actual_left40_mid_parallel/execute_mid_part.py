"""Fixed partition of an unchanged exact MID arithmetic core."""
from pathlib import Path
from hashlib import sha256
import json,sys
import accept_mid40 as a
HERE=Path(__file__).parent
PARTS={'a':(0,1709),'b':(1709,3418),'c':(3418,5126)}
def run(part):
 a.need(part in PARTS and not sys.flags.optimize and __debug__,'Fixed unoptimized part')
 raw=(HERE/'mid40_witnesses.json').read_bytes();obj=json.loads(raw,object_pairs_hook=a.unique)
 ctx=list(a.contexts());a.need(len(ctx)==len(obj['rows'])==5126,'Whole fixed MID sequence')
 lo,hi=PARTS[part];selected=ctx[lo:hi];a.contexts=lambda:iter(selected)
 witness={'schema':obj['schema'],'rows':obj['rows'][lo:hi]}
 out=a.run(witness,True);out.update(status='PASS_EXACT_FINITE_LEFT40_42_MID_PART',part=part,block_range=[lo,hi],negative_controls=a.controls(witness),whole_proof_sha256=sha256(raw).hexdigest())
 dest=HERE/('mid_part_'+part+'.json')
 if dest.exists():raise FileExistsError(dest)
 dest.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(dict(status='PASS_EXACT_MID_PART_FILE',part=part,output_sha256=sha256(dest.read_bytes()).hexdigest())),flush=True)
