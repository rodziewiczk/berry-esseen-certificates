"""Bind three source-preserving exact MID partitions and their complete union."""
from pathlib import Path
from hashlib import sha256
import json,copy,sys
from execute_mid_part import PARTS
from accept_mid40 import need,unique,run,controls
from mid42_contract import contexts
HERE=Path(__file__).parent;ROOT=HERE.parents[3]
def main():
 need(len(sys.argv)==1 and not sys.flags.optimize and __debug__,'Fixed unoptimized binding')
 raw=(HERE/'mid40_witnesses.json').read_bytes();obj=json.loads(raw,object_pairs_hook=unique);run(obj,shape_only=True)
 ctx=list(contexts());need(len(ctx)==len(obj['rows'])==5126,'Complete contexts')
 next_index=0;blocks=0;cells=0;minimum=None;outputs={};metas={}
 for part,(lo,hi)in PARTS.items():
  need(lo==next_index and hi>lo,'Disjoint exhaustive block partition');next_index=hi
  path=ROOT/('runs/toward40_20261007/local/actual_left40_mid_part_'+part+'01/metadata.json');meta=json.loads(path.read_text())
  need(meta['returncode']==0 and meta['command'][-1]=='execute_mid_'+part+'.py','Fresh named exact part')
  for name,h in meta['input_sha256'].items():need(sha256((HERE/name).read_bytes()).hexdigest()==h,'Unchanged exact source/input '+name)
  need('execute_mid_'+part+'.py'in meta['input_sha256'],'Driver captured')
  for ch in('stdout','stderr'):need(sha256((path.parent/(ch+'.txt')).read_bytes()).hexdigest()==meta[ch+'_sha256'],'Captured output hash')
  b=(HERE/('mid_part_'+part+'.json')).read_bytes();out=json.loads(b,object_pairs_hook=unique)
  last=json.loads((path.parent/'stdout.txt').read_text().splitlines()[-1])
  need(last==dict(status='PASS_EXACT_MID_PART_FILE',part=part,output_sha256=sha256(b).hexdigest()),'Accepted file bound to exact stdout')
  need(out['status']=='PASS_EXACT_FINITE_LEFT40_42_MID_PART'and out['part']==part and out['block_range']==[lo,hi],'Exact part scope')
  need(out['whole_proof_sha256']==sha256(raw).hexdigest(),'Same whole witness file')
  need(type(out['blocks'])is int and out['blocks']==hi-lo,'Exact block count')
  expected_cells=sum(x[8]for x in ctx[lo:hi]);need(type(out['phase_cells'])is int and out['phase_cells']==expected_cells,'Complete phase cells')
  from fractions import Fraction as F
  v=F(out['minimum']);need(v>0,'Strict finite-gap reserve');minimum=v if minimum is None else min(minimum,v)
  blocks+=out['blocks'];cells+=out['phase_cells'];outputs[part]=sha256(b).hexdigest();metas[part]=sha256(path.read_bytes()).hexdigest()
 need(next_index==5126,'No missing final block')
 print(json.dumps(dict(status='PASS_BINDING_OF_FRESH_EXACT_FINITE_LEFT40_42_MID',blocks=blocks,phase_cells=cells,minimum=str(minimum),negative_controls=controls(obj),part_output_sha256=outputs,arithmetic_metadata_sha256=metas),indent=2))
if __name__=='__main__':main()
