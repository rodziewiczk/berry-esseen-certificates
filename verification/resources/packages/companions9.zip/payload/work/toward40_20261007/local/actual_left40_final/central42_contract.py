"""Fixed finite n40..42 comparison resources; actual acquisition is separately bound."""
from pathlib import Path
from fractions import Fraction as F
import json
from normalization import generate_checked
from gap_table import epsilon
FLOOR=40
CAP=F('.4247')
def read():return json.loads(Path(__file__).with_name('targets.json').read_text())['rows']
def profile(row,sign,bi):
 return min(F(row['amplitude']),(F('.45'),F('.40'),F('.35'),F('.3125'),F('.30'))[bi])
def selected(row,sign,hcells=8,ocells=8):
 amp=F(row['amplitude']);lm=F(row['lambda_max'])
 base=dict(N=FLOOR,pl=F(row['p'][0]),pu=F(row['p'][1]),theta=F(row['theta']),H=F(row['H_minus'if sign<0 else'H_plus']),d0=F(row['d0']),amplitude=min(amp,F('.4')),maxnoise=lm,Ccap=CAP)
 c=generate_checked(base)
 c.update(epsilon=epsilon(row),T=F(row['T']),D=F(row['D']),phase_sign=sign,rebate=F(0),repair_normal=c['repair_pos'],raw_quads=[(F(q['A']),F(q['Fminus'if sign<0 else'Fplus']),F(q['Qbudget']))for q in row['quadratics']],joint_d0=F(row['d0']),joint_lambda=lm)
 # New full-phase MID on first two bands for both regions. Existing central
 # targets have stronger amplitudes, so retaining the weaker left schedule is safe.
 pts=sorted(set([F('.0925'),lm]+[F(j,400)for j in range(38,int(lm*400)+1)]));bands=[];amps=[];rates=[];phase_domains=[]
 for lo,hi in zip(pts,pts[1:]):
  phase=F('.16')if lo<F('.10')else F('.25')if lo<F('.12')else F('.5')
  schedule=('.35','.3','.275')if row['region']=='left'else('.325','.275','.25')
  aa=min(amp,profile(row,sign,1 if lo<F('.10')else 2 if lo<F('.12')else 3 if lo<F('.125')else 4))
  if lo>=F('.125'):aa=min(aa,F('.30'))
  elif lo>=F('.12'):aa=min(aa,F('.3125'))
  phase_domains.append((phase,phase) if lo<F('.12') or lo>=F('.135') else (F('.27'),F('.5')))
  span=aa+c['d0'];x=F('3.14159')*span;sine=x-x**3/6+x**5/120-x**7/5040
  bands.append((lo,hi,phase));amps.append(aa);rates.append(2*sine*sine/span**2)
 c.update(p_cells=1,H_cells=hcells,outer_phase_cells=ocells,bands=len(bands),noise_intervals=bands,amplitude_profile=amps,rate_profile=rates,phase_domains=phase_domains)
 return c
