"""Signed MID contracts on the same proposed actual-law resource cells."""
from fractions import Fraction as F
from central42_contract import read,profile
from normalization import generate_checked
REGIONS=((F('.05'),F('.06'),F(0),F('.4')),(F('.06'),F('.08'),F(0),F('.4')),(F('.08'),F('.10'),F('.19'),F('.35')),(F('.10'),F('.12'),F('.27'),F('.3')))
def contexts():
 for row in read():
  lm=min(F('.12'),F(row['lambda_max']))
  if lm<=F('.05'):continue
  for hs in(-1,1):
   base=dict(N=40,pl=F(row['p'][0]),pu=F(row['p'][1]),theta=F(row['theta']),H=F(row['H_minus'if hs<0 else'H_plus']),d0=F(row['d0']),amplitude=F('.425'),maxnoise=lm,Ccap=F('.4247'))
   c=generate_checked(base)
   for bi,(lo,end,start,amp)in enumerate(REGIONS):
    hi=min(end,lm)
    amp=profile(row,hs,0 if bi<2 else bi-1)
    if hi<=lo:continue
    A=min(amp,F(row['amplitude']));d=F(row['d0'])*(1-lo/F(row['lambda_max']))
    if not 0<d<=c['d0']:raise ValueError('Band joint-gap premise')
    steps=int((F('.5')-start)*1000)
    if start+F(steps,1000)!=F('.5'):raise ValueError('Full closed phase cover')
    for sign in(-1,1):yield row['index'],hs,bi,lo,hi,start,A,d,steps,sign,c
