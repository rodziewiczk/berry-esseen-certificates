"""Fixed arithmetic-only conditional TINY40 replay; no resource acquisition.

Every hypothesis is in targets.json. The theorem is conditional at this stage.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys,copy,functools
import tiny42_kernel as k
from signed_normalization import generate
H=Path(__file__).resolve().parent
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
for name in('poisson_cubic','bennett','log_upper'):setattr(k,name,functools.lru_cache(None)(getattr(k,name)))
def need(ok,msg):
 if not ok:raise ValueError(msg)
def unique(pairs):
 d={}
 for key,value in pairs:need(key not in d,'duplicate JSON key');d[key]=value
 return d
def equal(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
 return a==b
def read():
 manifest=json.loads((H/'fixed_inputs.json').read_text(),object_pairs_hook=unique)
 for name,sha in manifest.items():need(hashlib.sha256((H/name).read_bytes()).hexdigest()==sha,'fixed input '+name)
 t=json.loads((H/'targets.json').read_text(),object_pairs_hook=unique);w=json.loads((H/'witnesses.json').read_text(),object_pairs_hook=unique)
 need(type(t['N'])is int and t['N']==40 and type(w['N'])is int and w['N']==40,'N40 scope')
 need(len(t['rows'])==len(w['rows'])==48,'complete p cover')
 for i,(r,q)in enumerate(zip(t['rows'],w['rows'])):
  need(type(r['index'])is int and type(q['index'])is int and r['index']==q['index']==i,'strict indices')
  need(list(map(F,r['p']))==[F('.38')+F(i,500),F('.38')+F(i+1,500)],'ordered closed p cover')
  need(F(r['amplitude'])<=F('.43'),'artificial support upper bound')
 return t,w

def reconstruct():
 targets,ws=read();rows=[]
 for r,w in zip(targets['rows'],ws['rows']):
  base=dict(N=40,pl=F(r['p'][0]),pu=F(r['p'][1]),theta=F(r['theta']),H=max(F(r['H_minus']),F(r['H_plus'])),d0=F(r['d0']),amplitude=F('.43'),maxnoise=min(F('.05'),F(r['lambda_max'])),Ccap=F('.4247'))
  c,g=generate(base,F(r['H_plus']))
  need(F(w['neg'])>0 and F(w['positive'])>0,'positive own-count constants')
  z=k.evaluate(c,g,F(w['neg']),F(w['positive']),anchor_neg=F(w['anchor']),quartic_a=F(w['a']),split_neg=F(w['split_neg']))
  need(not z['bad'] and all(F(v)>0 for v in z['gates'].values()),'strict TINY arithmetic')
  rows.append(z)
 return {'schema':'CONDITIONAL_TINY40_GLOBAL_SIGNED_GAUSSIAN_V1','scope':{'N':40,'p':['19/50','119/250'],'Cmin':'2/5','Ccap':'4247/10000','amplitude':'43/100','noise':'0<lambda<=min(1/20,Lambda_panel)','phase':'[-1/2,1/2]','H_sign':'both','score':'rho_B(C-C_B)<-lambda/1000','status':'Conditional only; these N40 resources are NOT acquired.'},'source_sha256':json.loads((H/'fixed_inputs.json').read_text()),'rows':rows}
def validate(a,w):need(equal(a,w),'complete fixed proof mismatch')
def controls(w):
 tests=[('missing_row',lambda a:a['rows'].pop()),('reorder',lambda a:a['rows'].reverse()),('duplicate',lambda a:a['rows'].__setitem__(1,a['rows'][0])),('N',lambda a:a['scope'].update(N=39)),('booleanN',lambda a:a['scope'].update(N=True)),('Ccap',lambda a:a['scope'].update(Ccap='1/2')),('missing_gate',lambda a:a['rows'][0]['gates'].pop('signed_variance')),('negative_gate',lambda a:a['rows'][0]['gates'].update(signed_variance='-1')),('false_upper',lambda a:a['rows'][0]['contract'].update(derivative_hi='1')),('false_lower',lambda a:a['rows'][0]['contract'].update(derivative_lo='2')),('extra_field',lambda a:a.update(extra=True))]
 for name,fn in tests:
  a=copy.deepcopy(w);fn(a)
  try:validate(a,w)
  except ValueError:pass
  else:raise ValueError('mutation accepted '+name)
 try:json.loads('{"x":1,"x":2}',object_pairs_hook=unique)
 except ValueError:pass
 else:raise ValueError('duplicate key accepted')
 return [name for name,_ in tests]+['duplicate_JSON_key']
if __name__=='__main__':
 need(sys.argv[1:]==[],'fixed acceptor no flags');proof=reconstruct();raw=(H/'tiny40_proof.json').read_bytes();validate(json.loads(raw,object_pairs_hook=unique),proof)
 print(json.dumps(dict(status='PASS_EXACT_CENTRAL_TINY40',scope=proof['scope'],rows=48,phase_cases=288,gates=sum(len(r['gates'])for r in proof['rows']),minimum_reserve=str(min(F(s['reserve'])for r in proof['rows']for s in r['rows'])),negative_controls=controls(proof),proof_sha256=hashlib.sha256(raw).hexdigest(),acceptor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2))
