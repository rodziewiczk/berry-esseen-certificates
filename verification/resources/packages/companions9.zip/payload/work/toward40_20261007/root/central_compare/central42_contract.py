"""Exact selected CENTRAL40 comparison targets. Acquisition/interface is a separate bound dependency."""
from pathlib import Path
from fractions import Fraction as F
import json
from normalization import generate_checked
FLOOR=40
CAP=F('.4247')
GAPS={}
for n in (40,41,42):
 for r in json.loads(Path(__file__).with_name(f'binomial{n}.json').read_text())['rows']:
  i=r['index'];GAPS[i]=min(GAPS.get(i,F(1)),F(r['epsilon']))
def read():return json.loads(Path(__file__).with_name('targets.json').read_text())['rows']
def profile(row,sign,bi):
 rows=json.loads(Path(__file__).with_name('profiles.json').read_text())['rows']
 matches=[a for a in rows if a['index']==190+row['index'] and a['sign']==sign and a['band']==bi]
 if not matches:return F(row['amplitude'])
 if len(matches)!=1:raise ValueError('Ambiguous profile cell')
 return F(matches[0]['amplitude'])
def selected(row,sign,hcells=8,ocells=4):
 amp=F(row['amplitude']);lm=F(row['lambda_max'])
 base=dict(N=FLOOR,pl=F(row['p'][0]),pu=F(row['p'][1]),theta=F(row['theta']),H=F(row['H_minus'if sign<0 else'H_plus']),d0=F(row['d0']),amplitude=amp,maxnoise=lm,Ccap=CAP)
 c=generate_checked(base)
 c.update(T=F(row['T']),D=F(row['D']),phase_sign=sign,rebate=F(0),repair_normal=c['repair_pos'],raw_quads=[(F(q['A']),F(q['Fminus'if sign<0 else'Fplus']),F(q['Qbudget']))for q in row['quadratics']],joint_d0=F(row['d0']),joint_lambda=lm)
 # New full-phase MID on first two bands for both regions. Existing central
 # targets have stronger amplitudes, so retaining the weaker left schedule is safe.
 pts=sorted(set([F('.08'),lm]+[F(j,400)for j in range(33,int(lm*400)+1)]));bands=[];amps=[];rates=[]
 for lo,hi in zip(pts,pts[1:]):
  phase=F('.19')if lo<F('.10')else F('.27')if lo<F('.12')else F('.5')
  schedule=('.35','.3','.275')if row['region']=='left'else('.325','.275','.25')
  aa=min(amp,profile(row,sign,1 if lo<F('.10')else 2 if lo<F('.12')else 3))
  span=aa+c['d0'];x=F('3.14159')*span;sine=x-x**3/6+x**5/120-x**7/5040
  bands.append((lo,hi,phase));amps.append(aa);rates.append(2*sine*sine/span**2)
 c.update(binomial_gap=GAPS[int(F(row['p'][0])*500)],finite_upper_index=42,p_cells=1,H_cells=hcells,outer_phase_cells=ocells,bands=len(bands),noise_intervals=bands,amplitude_profile=amps,rate_profile=rates)
 return c
