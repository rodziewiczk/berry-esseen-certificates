"""Fixed complete exact Bernoulli slack table for n40,41,42 and p in[.28,.48]."""
from pathlib import Path
from fractions import Fraction as F
import copy,json,sys,hashlib
import finite_binomial_core as c
H=Path(__file__).resolve().parent

def need(v,s):
 if not v:raise ValueError(s)
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def shape(o,n):
 need(type(o)is dict and set(o)=={'format','n','indices','subdivisions','rows'},'fixed schema')
 need(o['format']=='FINITE_BINOMIAL_GAP_V1'and type(o['n'])is int and o['n']==n,'fixed n')
 need(o['indices']==[140,240]and o['subdivisions']==128,'fixed complete p cover')
 need(type(o['rows'])is list and len(o['rows'])==100,'complete table')
 for j,r in enumerate(o['rows'],140):
  need(type(r['index'])is int and r['index']==j and type(r['n'])is int and r['n']==n,'ordered row indices')
  need(r['p']==[str(F(j,500)),str(F(j+1,500))],'closed p intervals')
  need(type(r['subdivisions'])is int and r['subdivisions']==128 and r['closed_boxes']==256*(n+1),'both signs all counts and subcells')
  for k in('score_cap','epsilon'):need(type(r[k])is str and str(F(r[k]))==r[k]and F(r[k])>0,'canonical positive rational')
  need(F(r['score_cap'])+F(r['epsilon'])<=c.CE_LO,'conjectured constant gap')
def equal(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
 return a==b
def reject(fn):
 try:fn()
 except (ValueError,AssertionError,TypeError,KeyError):return
 raise ValueError('negative control accepted')
need(__debug__ and not sys.flags.optimize and not sys.argv[1:],'fixed unoptimized invocation')
outputs=[];controls=0;hashes={}
for n in (40,41,42):
 p=H/f'binomial{n}_140_240_candidate.json';blob=p.read_bytes();o=json.loads(blob,object_pairs_hook=unique);shape(o,n)
 for r in o['rows']:
  actual=c.panel(n,r['index'],128);need(equal(r,actual),'exact complete row replay')
 outputs.append(o);hashes[p.name]=hashlib.sha256(blob).hexdigest()
 print('PASS_FINITE_BINOMIAL_N',n,'minimum_epsilon',str(min(F(r['epsilon'])for r in o['rows'])),flush=True)
 for mut in (lambda a:a['rows'].pop(),lambda a:a['rows'].reverse(),lambda a:a['rows'].__setitem__(1,a['rows'][0]),lambda a:a.__setitem__('n',True),lambda a:a['rows'][0].__setitem__('p',['0','1']),lambda a:a['rows'][0].__setitem__('epsilon','1')):
  bad=copy.deepcopy(o);mut(bad);need(not equal(bad,o),'active mutation');reject(lambda:shape(bad,n));controls+=1
 wrong=copy.deepcopy(o['rows'][0]);wrong['score_cap']='1/100';reject(lambda:need(equal(wrong,c.panel(n,140,128)),'actual false arithmetic cap'));controls+=1
reject(lambda:json.loads('{"n":40,"n":41}',object_pairs_hook=unique));controls+=1
# Exact probability and CDF edge identities. No float library is trusted.
for n in (1,2,3,40,41,42):
 a=c.endpoint(n,1,2)
 for j in range(n+1):
  exact=F(sum(__import__('math').comb(n,k)for k in range(j+1)),2**n)
  need(F(a[j][2],c.S)<=exact<=F(a[j][3],c.S),'symmetric Bernoulli binomial probabilities')
  lo,hi=c.cdf_at(n,j,1,2);rl,rh=c.cdf_at(n,n-j,1,2)
  need(lo==c.S-rh and hi==c.S-rl,'reflected exact Gaussian enclosures')
for name in('finite_binomial_core.py','accept_binomial_gap.py'):hashes[name]=hashlib.sha256((H/name).read_bytes()).hexdigest()
joined=[dict(p=rows[0]['p'],epsilon=str(min(F(z['epsilon'])for z in rows)),by_n={str(n):r['epsilon']for n,r in zip((40,41,42),rows)})for rows in zip(*(o['rows']for o in outputs))]
print(json.dumps(dict(status='PASS_FINITE_BINOMIAL_SLACK_40_42',scope='For n in{40,41,42}, p ineachcloseddeclaredcell, normalizedbinomialKolmogorovscore<=CE−epsilon_panel.',p=['7/25','12/25'],n=[40,41,42],probability_panels=100,closed_signed_count_cells=3225600,negative_controls=controls,source_sha256=hashes,rows=joined),indent=2),flush=True)
