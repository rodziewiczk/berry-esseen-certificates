"""Exact MID probability bounds, copied algebra from reviewed local theorem."""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial
from tiny42_kernel import bennett,ceiling,need
SCALES=tuple(F(i,100)for i in range(10,121,2))
@lru_cache(None)
def poisson_numerator(mu,anchor):
 need(mu>0 and anchor>=0,'Poisson parameters');last=32;need(last>anchor+2,'Tail start')
 finite=sum(mu**k/F(factorial(k))*max(F(0),F(k)-anchor)**3 for k in range(last+1))
 first=mu**33/F(factorial(33))*(33-anchor)**3
 ratio=mu/F(34)*((34-anchor)/(33-anchor))**3;need(0<ratio<1,'Geometric tail')
 return (finite+first/(1-ratio))/sum(mu**k/F(factorial(k))for k in range(25))
def poisson(mu,b):
 x=b+mu;fl=x.numerator//x.denominator
 anchors=sorted(set(max(F(0),F(fl)-d)for d in(F(0),F('.25'),F('.5'),F('.75'),F(1))))
 vals=[(ceiling(poisson_numerator(mu,a)/(x-a)**3),a)for a in anchors if a<x]
 need(vals,'No legal Poisson anchor');return min(vals)
def own(choice,sign,l,h,tl,th,A,c):
 need(type(choice)is int and 0<=choice<=57,'Invalid quartic witness')
 if choice==56:
  need(sign==-1,'Cantelli sign');return l*l/(th+l*l)-c['derivative_hi']*h
 if choice==57:
  need(sign==1,'Normal sign');return c['derivative_lo']*l
 a=SCALES[choice];den=F(9)/(4*F('.4641'))*a**4;vals=[];sigma=1 if sign<0 else -1;deriv=-c['derivative_hi']if sign<0 else c['derivative_lo']
 for t in(tl,th):
  co=((3*a*a*t-A*A*t-3*t*t)/den,(2*sigma*a**3-4*A*t)/den+deriv,(3*a*a-6*t)/den,F(0),-1/den)
  vals.append(sum(v*(l if v>=0 else h)**i for i,v in enumerate(co)))
 return min(vals)

@lru_cache(None)
def log_lower_series(y):return 2*sum(y**(2*j+1)/(2*j+1)for j in range(20))
@lru_cache(None)
def tail_bennett(a,V,b):
 need(a>0 and V>0 and b>0,'Bennett parameters')
 x=1+a*b/V;power=0
 while x>=2:x/=2;power+=1
 lo=power*log_lower_series(F(1,3))+log_lower_series((x-1)/(x+1))
 exponent=(b/a+V/(a*a))*lo-b/a;need(0<exponent<16,'Bennett exponent')
 small=F(exponent.numerator*10**12//exponent.denominator,10**12);need(0<=small<=exponent,'Directed exponent floor')
 return ceiling(1/(sum((small/16)**j/F(factorial(j))for j in range(17))**16))
