"""Five independent full original INITIAL replays and four fixed support checks.

Untrusted complete archived candidates are compared against freshly recomputed
exact stages and all original controls. No historical constructor metadata or
precomputation wrapper is used. Each underlying acceptor is byte-identical.
This numerical slice leaves actual own-cap, support35, resource and final
all-law licensing explicit, and does not rerun any selected COUNT forest.
"""
from pathlib import Path
from hashlib import file_digest
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import json
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent


def need(ok, message):
    if not ok:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode('ascii')


def digest(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'Complete ordinary immutable file')
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, 'No duplicate JSON field')
            result[key] = value
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Finite JSON')))


def verify_source():
    files = read(HERE / 'INITIAL3539-SOURCE-VERIFIED.json')['files']
    for name, expected in files.items():
        need(digest(HERE / name) == expected, 'Whole unchanged source/input: ' + name)
    return files


def verify_initial(case, root, receipt):
    n = case['n']
    proof = read(root / case['candidate'])
    need(proof['profile'] == case['profile'] and receipt['profile'] == case['profile']
         and receipt['initial_sha256'] == digest(root / case['candidate']), 'Whole exact candidate/profile binding')
    need(receipt['schema'] == 'FIXED_INITIAL' + str(n) + '_ACCEPTANCE_V1'
         and receipt['status'] == case['initial_status'] and receipt['stages'] == case['passes']
         and receipt['export_stages'] == 1 and receipt['probability_panels'] == 100
         and receipt['resource_cells'] == (case['passes'] + 1) * 18432
         and receipt['negative_controls'] == case['initial_controls'], 'All original INITIAL stages, export and controls')
    need(type(proof['stages']) is list and len(proof['stages']) == case['passes']
         and len(proof['export']['panels']) == 100, 'Whole untrusted candidate including all probability panels')
    return receipt


def run_case(task, case, deadline):
    directory = task / ('n' + str(case['n']))
    root = directory / 'capsule'
    shutil.copytree(HERE / 'cases' / ('n' + str(case['n'])), root)
    original = {name: digest(root / name) for name in case['input_pins']}
    steps = []
    for step in case['steps']:
        remaining = deadline - time.time()
        need(remaining > 1, 'Actual stage before absolute native cutoff')
        need(not (root / step['output']).exists(), 'No historical acceptance staged as fresh output')
        execution = directory / 'executions' / step['id']
        execution.mkdir(parents=True)
        argv = [sys.executable, '-B', '-S', step['entry']]
        (execution / 'ARGV.json').write_bytes(encoded(dict(argv=argv, cwd=str(root), deadline=deadline)))
        started = time.monotonic()
        with (execution / 'stdout.txt').open('xb') as stdout, (execution / 'stderr.txt').open('xb') as stderr:
            result = subprocess.run(argv, cwd=root, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                    timeout=remaining, check=False)
        need(type(result.returncode) is int and result.returncode == 0
             and (execution / 'stderr.txt').stat().st_size == 0, 'Whole successful original direct native stage')
        receipt = read(root / step['output'])
        if step['id'] == 'initial':
            verify_initial(case, root, receipt)
        else:
            from fractions import Fraction as F
            proof = receipt['proof']
            need(receipt['status'] == step['status'] and receipt['negative_controls'] == step['controls']
                 and type(proof['n']) is int and proof['n'] == case['n']
                 and proof['q'] == proof['K'] == '0' and proof['radius'] == '19/5'
                 and [r['sign'] for r in proof['ray_rows']] == [-1, 1]
                 and all(F(r['contact_upper']) < 0 for r in proof['ray_rows']), 'Complete original fixed actual support')
            need(receipt['source_sha256'] == {p.name: digest(p) for p in root.glob('*.py')},
                 'Whole original support source census')
        need(original == {name: digest(root / name) for name in case['input_pins']}, 'All case mathematical input bytes unchanged')
        record = dict(id=step['id'], argv=argv, returncode=0, seconds=time.monotonic()-started,
            receipt_sha256=digest(root / step['output']), whole_original_controls=step['controls'],
            stdout_sha256=digest(execution / 'stdout.txt'), stderr_sha256=digest(execution / 'stderr.txt'))
        (execution / 'OBSERVATION.json').write_bytes(encoded(record))
        steps.append(record)
    report = dict(schema='be.actual3539-original-initial-support-case/1', n=case['n'],
        status='ORIGINAL_INITIAL_AND_DECLARED_SUPPORT_COMPLETED_CONDITIONAL', profile=case['profile'],
        steps=steps, original_precompute_wait_wrapper_executed=False,
        historical_constructor_metadata_fabricated=False, parent_owncap_and_analytic_licenses_still_required=True,
        support35_separate_license_still_required=case['n'] == 35,
        resource_and_COUNT_and_final_composition_still_required=True, mathematical_acceptance=False, full_proof_pass=False)
    (directory / 'CASE-OBSERVATION.json').write_bytes(encoded(report))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('mode', choices=['run'])
    parser.add_argument('--task', required=True)
    parser.add_argument('--deadline', type=int, required=True)
    parser.add_argument('--jobs', type=int, choices=range(1, 6), default=5)
    args = parser.parse_args()
    before = verify_source()
    descriptor = read(HERE / 'INITIAL3539-DESCRIPTION.json')
    task = Path(args.task).absolute()
    need(not task.exists() and not task.is_relative_to(HERE) and time.time() < args.deadline,
         'Fresh output outside static sources before absolute cutoff')
    task.mkdir(parents=True)
    cases, failures = [], []
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = {pool.submit(run_case, task, case, args.deadline): case['n'] for case in descriptor['cases']}
        for future in as_completed(futures):
            try:
                cases.append(future.result())
            except Exception as error:
                failures.append(dict(n=futures[future], kind=type(error).__name__, message=str(error)))
    need(verify_source() == before, 'Whole source closure unchanged after original native programs')
    report = dict(schema='be.actual3539-original-initial-support-batch/1',
        status='COMPLETE_CONDITIONAL_NUMERICAL_SLICE' if not failures else 'INCOMPLETE_CONDITIONAL_NUMERICAL_SLICE',
        completed=sorted(cases, key=lambda row: row['n']), failures=failures,
        source_before=before, source_after=before, full_original_INITIAL_indices=[35, 36, 37, 38, 39],
        expected_native_actions=9, COUNT_calls=0, resource_and_parent_and_analytic_licenses_still_required=True,
        mathematical_acceptance=False, full_proof_pass=False)
    (task / 'RESULT.json').write_bytes(encoded(report))
    print(json.dumps(dict(status=report['status'], completed_indices=[r['n'] for r in cases],
                         result_sha256=digest(task / 'RESULT.json')), sort_keys=True))
    need(not failures, 'One or more original independent cases did not complete; completed cases preserved')


if __name__ == '__main__':
    main()
