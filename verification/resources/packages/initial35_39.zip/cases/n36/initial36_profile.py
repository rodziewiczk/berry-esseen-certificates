"""Fixed exact global36 INITIAL; least-failure scalar/support edge separate."""
from fractions import Fraction as F
P=dict(n=36,nmax=36,radius=F(19,5),cap=F(1699,4000),barrier=F(0),grid=[24,24,8,4])
PASSES=16
def enc(x):
    if type(x)is F:return str(x)
    if isinstance(x,dict):return{k:enc(v)for k,v in x.items()}
    if isinstance(x,(tuple,list)):return[enc(v)for v in x]
    return x
def up(x):return F(-((-x.numerator*100000)//x.denominator),100000)
