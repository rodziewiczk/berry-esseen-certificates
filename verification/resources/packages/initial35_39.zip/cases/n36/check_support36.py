"""Fixed exact support check at n36, K0, delta0, radius19/5."""
from fractions import Fraction as F
from pathlib import Path
import copy,json,hashlib,sys
import direct_gaussian_support as d

def need(x,s):
 if not x:raise ValueError(s)
def equal(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
 return a==b
def validate(x,reference):
 need(type(x)is dict and equal(x,reference),'fixed typed complete support certificate')
def main():
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed nonoptimized invocation')
 path=Path('SUPPORT36_ACCEPTED.json');need(not path.exists(),'fresh result destination')
 proof=d.target(36,F(0),F(19,5),F(0),mesh=10)
 need(proof['n']==36 and proof['K']=='0'and proof['q']=='0'and proof['radius']=='19/5','fixed scope')
 need([r['sign']for r in proof['ray_rows']]==[-1,1],'both support rays')
 controls=[]
 def mutation(name,f):
  obj=copy.deepcopy(proof);f(obj)
  try:validate(obj,proof)
  except(ValueError,AssertionError,TypeError,KeyError):controls.append(name);return
  raise ValueError('accepted corruption: '+name)
 mutation('wrong index',lambda o:o.update(n=35))
 mutation('boolean index',lambda o:o.update(n=True))
 mutation('wrong decrement',lambda o:o.update(q='19/100'))
 mutation('wrong barrier',lambda o:o.update(K='1/100'))
 mutation('wrong radius',lambda o:o.update(radius='37/10'))
 mutation('missing ray',lambda o:o['ray_rows'].pop())
 mutation('reordered rays',lambda o:o['ray_rows'].reverse())
 mutation('false contact bound',lambda o:o['ray_rows'][0].update(contact_upper='0'))
 mutation('false threshold cover',lambda o:o['gaussian'].update(cells=0))
 mutation('corrupt line digest',lambda o:o['gaussian'].update(line_sha256='0'*64))
 mutation('extra field',lambda o:o.update(accepted=True))
 result=dict(status='PASS_INITIAL_SUPPORT36_K0_Q0_R38',mathematical_status='Conditional on attained positive closed n36 maximizing witness, C36>=CE and delta36=0; published moment and contact theorem inputs explicit retained dependencies.',execution_status='Fresh exact computation PASS',proof=proof,negative_controls=controls,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('.').glob('*.py')})
 path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
