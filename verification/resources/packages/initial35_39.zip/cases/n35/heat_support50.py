"""Exact polynomial reduction for a new all-H support theorem at n>=36.

This is a new theorem using e_n < .384/n, not a relaxed execution of the
cutoff99 theorem. The finite heat expansion is unchanged and valid for n>1
when its explicit coupling condition holds. See support50_proof.tex.
"""
from fractions import Fraction as F
from math import comb, isqrt
from hashlib import sha256
import json, sys
assert __debug__ and not sys.flags.optimize

def trim(a):
    a=list(map(F,a))
    while len(a)>1 and not a[-1]: a.pop()
    return a
def add(*aa):
    z=[F(0)]*max(map(len,aa))
    for a in aa:
        for k,x in enumerate(a): z[k]+=x
    return trim(z)
def scale(a,c): return trim([x*c for x in a])
def mul(a,b):
    z=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):z[i+j]+=x*y
    return trim(z)
def val(a,x):
    z=F(0)
    for c in reversed(a):z=z*x+c
    return z
def deriv(a):return trim([j*x for j,x in enumerate(a)][1:] or [0])
def bern(a,l,h):
    d=len(a)-1
    t=[sum(a[j]*comb(j,k)*l**(j-k)*(h-l)**k for j in range(k,d+1))for k in range(d+1)]
    return [sum(t[k]*F(comb(i,k),comb(d,k))for k in range(i+1))for i in range(d+1)]
def root(x):
    assert x>=0
    den=10**12;k=isqrt(x.numerator*den*den//x.denominator)
    lo=F(k,den);hi=F(k+1,den)
    assert lo*lo<=x<hi*hi
    return lo,hi

A=trim([0,F(-1,2),0,F(1,6)])
H4=trim([3,0,-6,0,1])
EC=F(48,125)

def scale_gate(N):
    assert type(N)is int and N>=36
    x=F(1,N)
    gate=(2*EC-F(3,4))-(EC+F(1,4))*x+(EC*EC-EC)*x*x-EC*EC*x*x*x
    assert gate>0
    return gate

def constants(N,last,K):
    scale_gate(N)
    assert type(last)is int and N<=last and K>=0
    c=F('.4095')+K/last
    r=min(F('.3031')*F('.646')/(c-F('.3031')),
          F('.3322')*F('.429')/(c-F('.3322')))
    assert r>=1
    _,disc=root((2+r*r)**2-4*(1-r*r))
    _,b=root((disc-2-r*r)/2)
    assert 0<b<1 and (1+b*b)**2>r*r*(1-b*b)
    ell,_=root(F(N-1));_,S=root(F(N,N-1))
    return c,r,b,ell,S

def polynomial_data(N,last,K):
    c,r,b,ell,S=constants(N,last,K);v=N-1
    E=add([0,F(3,20*v),0,0,0,F(1,100*v)],
          scale([-2,0,3],F(51,960*v)/ell),[0,F(1,8*v*v)])
    Q=[r*EC/N,3*b,F(3,2)*r,-1]
    PA0=add(scale(add(mul(A,A),scale(mul(H4,H4),F(1,256*v))),F(2,5)*S**3),
            scale(mul(E,A),S**3),mul(scale(Q,c),A))
    PAq=scale(A,r*S)
    quarter=add(scale(A,6*ell),scale(H4,-1))
    ray0=add([F(1,2),F(1,5),0,F(1,15)],scale(Q,c))
    return dict(c=c,r=r,b=b,ell=ell,S=S,Q=Q,PA0=PA0,PAq=PAq,quarter=quarter,ray0=ray0)

def target(N,last,K,R,q):
    assert F('2.5')<=R<F('4.5') and q>=0
    p=polynomial_data(N,last,K)
    PA=add(p['PA0'],scale(p['PAq'],q))
    rows=[];gates=[];l=R
    while l<F('4.5'):
        h=min(F('4.5'),l+F(1,20))
        for name,a in [('A',A),('H4',H4),('quarter',p['quarter']),('negative_C',scale(p['Q'],-1)),('contact',scale(PA,-1))]:
            bs=bern(a,l,h)
            if min(bs)<=0:raise ValueError((name,N,last,str(K),str(R),str(q),str(l),str(min(bs))))
            gates.extend((name,str(z))for z in bs)
        rows.append([str(l),str(h)]);l=h
    for name,a in [('coefficient_ray',p['Q']),('contact_ray',add(p['ray0'],[p['r']*p['S']*q]))]:
        for j in range(4):
            z=-val(a,F('4.5'))
            if z<=0:raise ValueError((name,j,str(z)))
            gates.append((name+str(j),str(z)));a=deriv(a)
    return dict(n_band=[N,last] if K else [N,None],barrier=str(K),radius=str(R),slow=str(q),
                current_score_lower=str(p['c']),rho_upper=str(p['r']),beta_absolute_upper=str(p['b']),
                scale_coefficient=str(EC),scale_positive_gate=str(scale_gate(N)),closed_cells=rows,
                gates=len(gates),minimum_contact=str(min(F(x)for name,x in gates if name=='contact')),
                gate_sha256=sha256(json.dumps(gates,separators=(',',':')).encode()).hexdigest())

def discovered_slow_ceiling(N,last,K,R):
    """Diagnostic exact coefficient ceiling; not a fixed acceptance target."""
    p=polynomial_data(N,last,K);bounds=[];l=R
    while l<F('4.5'):
        h=min(F('4.5'),l+F(1,20))
        for name,a in [('A',A),('H4',H4),('quarter',p['quarter']),('negative_C',scale(p['Q'],-1))]:
            if min(bern(a,l,h))<=0:raise ValueError((name,str(l)))
        aa=bern(p['PA0'],l,h)
        # Elevate PAq to the same degree before comparing its coefficients.
        bb=bern(p['PAq']+[F(0)]*(len(p['PA0'])-len(p['PAq'])),l,h)
        assert all(x>0 for x in bb)
        bounds.extend(-a/b for a,b in zip(aa,bb));l=h
    for a in [p['Q'],deriv(p['ray0'])]:
        while True:
            assert val(a,F('4.5'))<0
            if len(a)==1:break
            a=deriv(a)
    bounds.append(-val(p['ray0'],F('4.5'))/(p['r']*p['S']))
    return min(bounds)
