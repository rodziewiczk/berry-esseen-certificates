"""New PHASE_SIGN_CORRECTED callback; legacy sources stay unchanged.

q(rho)=C*rho+min(phi_low*g0,.4*g0)/2, g0=3.16*rho-3-d.
This q is positive on each selected call and concave in rho; its reciprocal
is convex, preserving the existing four-corner envelope reduction.
"""
from fractions import Fraction as F

def install(k):
 original=k.late_envelope
 def corrected(n,d,previous,p,cap):
  rows=original(n,d,previous,p,cap)
  k.need(type(rows)in(list,tuple)and len(rows)==4,"complete four-corner paired return")
  k.need(all(type(row)in(list,tuple)and len(row)==5 for row in rows),"five fields in each paired corner")
  phi=F(0)if previous is None else k.PHI*(1-F(5,2)*previous/n)
  k.need(0<=phi<=F('.4'),'corrected density interval')
  rmin=k.paired(n,p,d)[3]
  answer=[]
  for (A,b,q,_,_),C,rho in zip(rows,[F('.4095')]*2+[cap]*2,[rmin,p['Rho']]*2):
   g0=F('3.16')*rho-3-d
   k.need(q==C*rho+phi*g0/2,'original paired phase formula')
   qc=q+(F('.4')-phi)*min(F(0),g0)/2
   k.need(qc>0 and qc<=q,'positive corrected phase curvature')
   value=A+b*b/(4*qc)
   answer.append((A,b,qc,value,value/rmin))
  return answer
 k.late_envelope=corrected
 return corrected
