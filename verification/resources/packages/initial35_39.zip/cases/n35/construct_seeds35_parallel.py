"""Construct the fixed twelve-cover short CENTRAL35 seed candidate."""
from pathlib import Path
import json,hashlib,sys
import seeds35_core as c
from concurrent.futures import ProcessPoolExecutor
import multiprocessing
def worker(args):
    initial,spec=args
    assert __debug__ and not sys.flags.optimize
    return c.band(initial,spec,False)
def main():
    assert __debug__ and not sys.flags.optimize
    source=Path('initial35_proof.json');initial=json.loads(source.read_bytes())
    path=Path('seeds35_proof.json');assert not path.exists()
    out=dict(schema='SHORT_CENTRAL35_SEEDS_V1',initial_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),bands=[])
    with ProcessPoolExecutor(max_workers=2,mp_context=multiprocessing.get_context('spawn'))as pool:
        for result in pool.map(worker,[(initial,spec)for spec in c.SPECS]):
            out['bands'].append(result);path.write_text(json.dumps(out,indent=2)+'\n')
            print('CONSTRUCT_SEED35_BAND',result['interval'],len(result['stages']),flush=True)
    print('CONSTRUCT_SEEDS35_COMPLETE',sum(len(b['stages'])for b in out['bands']),flush=True)

if __name__=='__main__':main()
