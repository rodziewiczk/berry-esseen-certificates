"""Portable fixed binding for the three short CENTRAL35 acquisition suites.
No heavy arithmetic is repeated. The complementary probability cover and
finite-count comparison remain explicitly separate obligations.
"""
from pathlib import Path,PurePosixPath
from fractions import Fraction as F
import json,hashlib,sys,copy

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
CAPTURED=Path('/Users/bkolodziejek/Downloads/BE_Codex_Handoff')
RUNBASE=ROOT/'runs/below40_20261007/support'
PRIOR34_SHA='e514ff05b8e99ef6fe543ac507a2f3d6236f9c5bf995f2be28e27eeed732ddc1'
CONTRACT_SHA='1545ebcc548cf4f9a33eff6aa673fd105c11a392afafd99eb9989df30d8556e6'
PROFILE={'n':35,'nmax':35,'radius':'39/10','cap':'53539/125000','barrier':'0','grid':[24,24,8,4]}
SOURCES={
'initial':{'accept_initial35_parallel.py','initial_global35.py','initial35_profile.py','kernel.py','high_window_core.py','initial35_proof.json'},
'seeds':{'accept_seeds35_parallel.py','seeds35_core.py','initial_local35.py','initial35_profile.py','accept_initial35.py','initial_global35.py','direct_gaussian_support.py','finite_binomial_core.py','small_index_support.py','heat_support50.py','kernel.py','high_window_core.py','initial35_proof.json','seeds35_proof.json'},
'central':{'accept_central35_v2.py','route35_core.py','candidate_charged_score35.py','product_endpoint34.py','initial_global35.py','initial35_profile.py','accept_initial35.py','contracted_kernel.py','corrected_phase_callback_extended.py','paired_extended.py','signed_variance_resource.py','geometric_moment_resource.py','high_window_core.py','kernel.py','direct_gaussian_support.py','finite_binomial_core.py','small_index_support.py','heat_support50.py','initial35_proof.json','seeds35_proof.json','central35_proof.json','contract.json'}}
SPECS=[('initial','positive35_initial_accept01','accept_initial35_parallel.py','INITIAL35_ACCEPTED.json','PASS_INITIAL35_K0_D6',16),('seeds','positive35_seeds_accept01','accept_seeds35_parallel.py','SEEDS35_ACCEPTED.json','PASS_SHORT_CENTRAL35_SEEDS',16),('central','positive35_central_accept01','accept_central35_v2.py','CENTRAL35_ACCEPTED.json','PASS_SHORT_CENTRAL35_RESOURCE',23)]

def need(x,s):
    if not x:raise ValueError(s)
def unique(items):
    d={}
    for k,v in items:need(k not in d,'duplicate JSON key');d[k]=v
    return d
def parse(blob):return json.loads(blob,object_pairs_hook=unique)
def read(p):return parse(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def equal(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
    return a==b
def safe(base,name):
    need(type(name)is str and name and '\\'not in name,'relative source path')
    need(all(p not in('','.','..')for p in name.split('/')),'canonical relative source path')
    rel=PurePosixPath(name);need(not rel.is_absolute(),'contained source path')
    p=base.joinpath(*rel.parts);need(p.is_file()and not p.is_symlink()and p.resolve().is_relative_to(base.resolve()),'regular contained source')
    return p

def evidence(spec,m,report,out,err,bind=True):
    kind,run,driver,name,status,nc=spec
    need(type(m['returncode'])is int and m['returncode']==0,'successful integer return code')
    need(m['cwd']==str(CAPTURED/'work/below40_20261007/support/positive35_acq'),'fixed captured cwd')
    argv=m['command'];need(type(argv)is list and len(argv)==3 and all(type(x)is str for x in argv),'fixed argv shape')
    need(argv[1:]==['-B',driver]and '-O'not in argv and '-OO'not in argv,'known ordinary Python entrypoint')
    need(type(m['input_sha256'])is dict and SOURCES[kind]<=set(m['input_sha256']),'complete executed dependency closure')
    need(hashlib.sha256(out).hexdigest()==m['stdout_sha256']and hashlib.sha256(err).hexdigest()==m['stderr_sha256']and err==b'','recorded output integrity')
    need(equal(parse(out.strip().splitlines()[-1]),report),'saved report equals actual stdout report')
    need(report['status']==status,'fixed named resource theorem')
    controls=report['negative_controls'];need(type(controls)is list and len(controls)==len(set(controls))==nc,'complete distinct arithmetic controls')
    if kind=='initial':
        need(equal(report['profile'],PROFILE),'fixed global mathematical profile')
        need(all(type(report[k])is int for k in('stages','export_stages','resource_cells','probability_panels','parallel_workers')),'strict initial incidence')
        need((report['stages'],report['export_stages'],report['resource_cells'],report['probability_panels'],report['parallel_workers'])==(10,1,202752,100,2),'complete global cover')
        need(0<F(report['D'])<=F('1.621'),'complete final gap export domain')
    elif kind=='seeds':
        need(all(type(report[k])is int for k in('seed_bands','seed_stages','resource_cells','parallel_workers')),'strict seed incidence')
        need((report['seed_bands'],report['seed_stages'],report['resource_cells'],report['parallel_workers'])==(4,12,221184,2),'complete fixed short seed schedule')
        need(report['covered_probability']==['29/100','57/100'],'closed local seed interval union')
    else:
        need(type(report['probability_panels'])is int and report['probability_panels']==18 and equal(report['surviving_panels'],list(range(31,49))),'complete central probability cover')
        need(report['contract_sha256']==CONTRACT_SHA,'fixed comparison contract')
        need(type(report['refinement_stages'])is int and 18<=report['refinement_stages']<=720,'bounded exact refinement schedule')
    bindings={}
    if bind:
        for name,h in m['input_sha256'].items():
            p=safe(HERE,name);need(type(h)is str and sha(p)==h,'executed input byte integrity');bindings[str(p.relative_to(ROOT))]=h
        need(report['initial_sha256']==sha(HERE/'initial35_proof.json'),'same accepted global INITIAL')
        if kind!='initial':need(report['seeds_sha256']==sha(HERE/'seeds35_proof.json'),'same accepted short seeds')
        if kind=='central':need(report['acquisition_sha256']==sha(HERE/'central35_proof.json'),'same accepted central proof')
    return bindings

def prior34():
    folder=ROOT/'work/below40_20261007/root/positive34_join';path=folder/'POSITIVE34_COMPLETE.json';o=read(path)
    need(sha(path)==PRIOR34_SHA,'fixed accepted predecessor report bytes')
    need(o['schema']=='POSITIVE34_COMPLETE_DAG_V1'and o['status']=='PASS_C34_LT_CE_PLUS_9_OVER_1700','completed independent predecessor theorem')
    need(o['theorem']=='C_34 < C_E + 9/1700'and o['consequence_C35_upper']=='423493/1000000','exact predecessor and smoothing cap')
    bindings={}
    for name,h in o['bound_sha256'].items():
        p=safe(ROOT,name);need(sha(p)==h,'retained predecessor dependency integrity');bindings[name]=h
    run=ROOT/'runs/below40_20261007/root/positive34_join01';m=read(run/'metadata.json');out=(run/'stdout.txt').read_bytes();err=(run/'stderr.txt').read_bytes()
    need(type(m['returncode'])is int and m['returncode']==0 and m['command'][1:]==['-B','check_positive34.py'],'actual ordinary-Python predecessor completion')
    need(m['cwd']==str(CAPTURED/'work/below40_20261007/root/positive34_join'),'captured predecessor location')
    need(hashlib.sha256(out).hexdigest()==m['stdout_sha256']and hashlib.sha256(err).hexdigest()==m['stderr_sha256']and err==b'','predecessor output integrity')
    need(len(o['bound_sha256'])==486 and len(o['negative_controls'])==6,'complete fixed predecessor report incidence')
    need(out==b'PASS_POSITIVE34_COMPLETE 486 6\n','actual predecessor completion marker')
    for name,h in m['input_sha256'].items():
        p=safe(folder,name);need(sha(p)==h,'executed predecessor driver integrity');bindings[str(p.relative_to(ROOT))]=h
    for p in(path,run/'metadata.json',run/'stdout.txt',run/'stderr.txt'):bindings[str(p.relative_to(ROOT))]=sha(p)
    return bindings

def check():
    sys.set_int_max_str_digits(0)
    need(sha(HERE/'contract.json')==CONTRACT_SHA,'unchanged eighteen-row target')
    import route35_core as r
    need(r.N==35 and r.K==0 and r.Q==F(63,340)and r.CAP==F(423493,10**6)and r.R==F(39,10),'exact central mathematical scope')
    need(35*F(9,1700)==F(63,340),'strict predecessor decrement consequence under C35>=CE')
    need(F('.40974')+F(13,20*35)<F(53539,125000),'independent old own cap used by global INITIAL')
    bindings=prior34();items=[]
    for spec in SPECS:
        run=RUNBASE/spec[1];m,report=read(run/'metadata.json'),read(HERE/spec[3]);out,err=(run/'stdout.txt').read_bytes(),(run/'stderr.txt').read_bytes()
        bindings.update(evidence(spec,m,report,out,err))
        for p in(run/'metadata.json',run/'stdout.txt',run/'stderr.txt',HERE/spec[3]):bindings[str(p.relative_to(ROOT))]=sha(p)
        items.append((spec,m,report,out,err))
    contract=read(HERE/'contract.json');proof=read(HERE/'central35_proof.json')
    need(equal([g['index']for g in contract['rows']],list(range(31,49))),'complete fixed target incidence')
    for g,record in zip(contract['rows'],proof['rows']):
        i=g['index'];need(g['p']==[str(F(i,100)),str(F(i+1,100))],'closed rational probability seams')
        z=record['interface'];need(equal(z['guard'],g),'same acquired and consumed target')
        need(z['joint']=='d/d0+lambda/Lambda<=1'and z['simultaneous_defect']=='D>=binary_charge+gap_charge*d+noise_charge*lambda','one-law simultaneous resource statements')
        need(0<F(z['inward_cap'])<=F(g['d0'])and 0<F(z['lambda_intercept'])<=F(g['Lambda'])and F(z['D'])<=F(g['D']),'primary upper scalar guards')
        for key in('outer0','outer1','radius_minus','radius_plus','Hminus','Hplus'):need(0<F(z[key])<=F(g[key]),'same-law upper guard '+key)
        for key in('binary_charge','gap_charge','noise_charge'):need(F(z['charges'][key])>=F(g[key])>=0,'simultaneous lower coefficient '+key)
        maps=z['quadratic_mapping'];need(type(maps)is list and len(maps)==12,'all six corners and both signed phases')
        for j,v in enumerate(maps):need(v['sign']==('plus'if j<6 else'minus')and type(v['target_corner'])is int and 0<=v['target_corner']<6 and F(v['margin'])>=0,'exact closed-H quadratic domination')
    for p in(HERE/'resource35_proof.tex',HERE.parent/'endpoint_product_bootstrap.tex',HERE.parent/'positive33_acq/resource33_proof.tex'):bindings[str(p.relative_to(ROOT))]=sha(p)
    return items,bindings,contract

def main():
    need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary Python invocation')
    items,bindings,contract=check();controls=[];spec,m,report,out,err=items[0]
    def reject(name,fn):
        try:fn()
        except(ValueError,KeyError,TypeError,IndexError):controls.append(name);return
        raise ValueError('malformed binding accepted: '+name)
    for name,key,value in [('boolean return','returncode',False),('failed return','returncode',1),('wrong cwd','cwd','/tmp/other'),('optimized command','command',['python','-O',spec[2]]),('unknown entrypoint','command',['python','-B','unknown.py'])]:
        z=copy.deepcopy(m);z[key]=value;reject(name,lambda z=z:evidence(spec,z,report,out,err,False))
    z=copy.deepcopy(m);z['input_sha256'].pop('initial_global35.py');reject('missing executed dependency',lambda:evidence(spec,z,report,out,err,False))
    reject('changed stdout',lambda:evidence(spec,m,report,out+b'changed',err,False))
    reject('source escape',lambda:safe(HERE,'../outside.py'))
    reject('duplicate JSON key',lambda:parse('{"n":1,"n":2}'))
    result=dict(schema='SHORT_CENTRAL35_RESOURCE_JOIN_V1',status='PASS_SHORT_CENTRAL35_RESOURCE_BINDING',mathematical_status='Conditional CENTRAL35 resource acquisition on p[.31,.49], with the independently completed34 theorem supplying decrement and stronger own cap. Complementary probabilities and the count comparison are separate.',execution_status='Three selected exact suites separately fresh PASS; this fresh join verifies sources, runs, scalars and interfaces only.',contract=contract,selected_runs=[x[0][1]for x in items],negative_controls=controls,bound_sha256=bindings)
    (HERE/'RESOURCE35_BOUND.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
