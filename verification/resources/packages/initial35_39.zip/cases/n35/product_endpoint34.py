"""New actual-gap endpoint product consequence, independent of INITIAL cells.

J<=rho+2mAB gives D>=(sqrt10-1)-6mAB. Conditional Cauchy gives
mAB<=q*A and <=p*B. Therefore both floors below are valid for the
same actual central gap, with p in [l,u] and D<=d<sqrt10-1.
Full proof: ../endpoint_product_bootstrap.tex. No target is relaxed.
"""
from fractions import Fraction as F
SIGMA_LO=F(158113883,50000000)
def seed(row):
    if not(0<SIGMA_LO and SIGMA_LO*SIGMA_LO<10):raise ValueError('exact square-root lower bound')
    l,u,d=row['pl'],row['pu'],row['D']
    if not(0<l<u<1 and 0<d<SIGMA_LO-1):raise ValueError('actual central-gap product domain')
    out=dict(row);price=SIGMA_LO-1-d
    out['A']=max(row['A'],price/(6*(1-l)))
    out['B']=max(row['B'],price/(6*u))
    return out
