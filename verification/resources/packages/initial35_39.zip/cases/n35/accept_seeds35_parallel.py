"""Fixed exact short-seed replay. Global INITIAL acceptance is a separate edge."""
from pathlib import Path
import json,hashlib,sys,copy
from concurrent.futures import ProcessPoolExecutor
import multiprocessing
from fractions import Fraction as F
import seeds35_core as c
from accept_initial35 import need,equal,fields,read,unique

BAND_RESULTS={}
def worker_band(args):
    initial,spec=args
    need(__debug__ and not sys.flags.optimize,'ordinary Python seed worker')
    return c.band(initial,spec,False)
def prepare_bands(o):
    shape(o);initial=read('initial35_proof.json')
    with ProcessPoolExecutor(max_workers=2,mp_context=multiprocessing.get_context('spawn'))as pool:
        results=list(pool.map(worker_band,[(initial,spec)for spec in c.SPECS]))
    need(len(results)==4,'complete parallel seed incidence')
    BAND_RESULTS.update((tuple(spec),result)for spec,result in zip(c.SPECS,results))

def shape(o):
    fields(o,('schema','initial_sha256','bands'))
    need(o['schema']=='SHORT_CENTRAL35_SEEDS_V1','fixed short-seed theorem')
    need(o['initial_sha256']==hashlib.sha256(Path('initial35_proof.json').read_bytes()).hexdigest(),'same global INITIAL input')
    need(type(o['bands'])is list and len(o['bands'])==4,'four fixed closed seed intervals')
    for b,spec in zip(o['bands'],c.SPECS):
        fields(b,('interval','stages'));need(equal(b['interval'],list(spec[:2])),'ordered exact interval')
        need(type(b['stages'])is list and len(b['stages'])==spec[2],'fixed short seed schedule')
        for stage in b['stages']:
            fields(stage,('profile','incoming','support','output','raw','D'))
            for key in('raw','D'):
                value=stage[key];need(type(value)is str and str(F(value))==value,'canonical outgoing bound')
            need(type(stage['output'])is dict and type(stage['output'].get('active'))is int,'strict integer coverage incidence')

def verify(o,emit=False):
    shape(o);initial=read('initial35_proof.json');cells=hc=rays=0
    for got,spec in zip(o['bands'],c.SPECS):
        expected=BAND_RESULTS[tuple(spec)]if tuple(spec)in BAND_RESULTS else c.band(initial,spec,emit);need(equal(got,expected),'complete exact local INITIAL/support replay')
        cells+=len(got['stages'])*18432
        for stage in got['stages']:
            for s in stage['support']:
                hc+=s['gaussian']['cells'];rays+=len(s['ray_rows'])
    return dict(seed_bands=4,seed_stages=12,resource_cells=cells,support_H_cells=hc,support_rays=rays,covered_probability=['29/100','57/100'])

def main():
    need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary Python invocation')
    path=Path('seeds35_proof.json');o=read(path);prepare_bands(o);result=verify(o,True);controls=[]
    def change(name,fn,deep=False):
        bad=copy.deepcopy(o);fn(bad)
        try:verify(bad)if deep else shape(bad)
        except(ValueError,AssertionError,TypeError,KeyError,ZeroDivisionError):controls.append(name);return
        raise ValueError('malformed seed accepted: '+name)
    change('wrong theorem',lambda z:z.update(schema='wrong'))
    change('wrong global binding',lambda z:z.update(initial_sha256='0'*64))
    change('missing interval',lambda z:z['bands'].pop())
    change('duplicate interval',lambda z:z['bands'].append(z['bands'][0]))
    change('reordered intervals',lambda z:z['bands'].reverse())
    change('boolean interval endpoint',lambda z:z['bands'][0]['interval'].__setitem__(0,True))
    change('missing seed stage',lambda z:z['bands'][0]['stages'].pop())
    change('boolean incidence',lambda z:z['bands'][0]['stages'][0]['output'].update(active=True))
    change('noncanonical bound',lambda z:z['bands'][0]['stages'][0].update(raw='01'))
    change('false outgoing D',lambda z:z['bands'][0]['stages'][0].update(D='1/2'),True)
    change('unacquired support',lambda z:z['bands'][0]['stages'][1]['profile'].update(radius_minus='1'),True)
    change('omitted support ray',lambda z:z['bands'][0]['stages'][1]['support'].pop(),True)
    change('false inherited mean floor',lambda z:z['bands'][0]['stages'][1]['profile']['invariants'].update(mean_lo='1/2'),True)
    change('false exported moment',lambda z:z['bands'][0]['stages'][-1]['output']['panels'][31].update(M='1'),True)
    change('extra success flag',lambda z:z.update(accepted=True))
    try:json.loads('{"a":1,"a":2}',object_pairs_hook=unique)
    except ValueError:controls.append('duplicate JSON key')
    else:raise ValueError('duplicate keys accepted')
    result.update(schema='SHORT_CENTRAL35_SEEDS_ACCEPTANCE_V1',status='PASS_SHORT_CENTRAL35_SEEDS',mathematical_status='Conditional p-local same-law INITIAL35 seeds, requiring the separately accepted global INITIAL and actual decrement<=63/340.',execution_status='Fresh exact complete twelve-cover and support replay PASS',initial_sha256=o['initial_sha256'],seeds_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),negative_controls=controls,parallel_workers=2)
    Path('SEEDS35_ACCEPTED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
