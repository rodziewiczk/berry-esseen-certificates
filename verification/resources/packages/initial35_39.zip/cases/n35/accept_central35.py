"""Fixed exact CENTRAL35 resource replay; no discovery target is accepted.
This proves only the conditional p[.31,.49] resource interface. Global
INITIAL, short-seed arithmetic, all-p comparison and final scalar composition
are separate dependencies of the eventual theorem.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys,copy
import route35_core as r
from product_endpoint34 import seed
from initial35_profile import enc
from accept_initial35 import need,equal,read,fields,rat,unique

CONTRACT_SHA='1545ebcc548cf4f9a33eff6aa673fd105c11a392afafd99eb9989df30d8556e6'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def shape(o):
    fields(o,('schema','initial_sha256','seeds_sha256','contract_sha256','global_support','rows'))
    need(o['schema']=='SHORT_CENTRAL35_RESOURCE_V1','fixed central35 resource theorem')
    need(o['initial_sha256']==sha('initial35_proof.json'),'same global INITIAL')
    need(o['seeds_sha256']==sha('seeds35_proof.json'),'same short seed proof')
    need(o['contract_sha256']==CONTRACT_SHA==sha('contract.json'),'fixed eighteen-row comparison target')
    need(type(o['rows'])is list and len(o['rows'])==18,'eighteen complete closed central panels')
    for i,row in zip(range(31,49),o['rows']):
        fields(row,('index','seed_band','product_A','product_B','base','refinements','interface'))
        need(type(row['index'])is int and row['index']==i,'ordered strict-integer probability index')
        need(type(row['seed_band'])is list and all(type(v)is int for v in row['seed_band']),'strict seed incidence')
        rat(row['product_A']);rat(row['product_B'])
        need(type(row['refinements'])is list and 1<=len(row['refinements'])<=40,'bounded nonempty refinement schedule')
        for z in row['refinements']:
            need(type(z)is dict and 'radius_minus'in z and 'radius_plus'in z,'two radius witnesses')
            rat(z['radius_minus']);rat(z['radius_plus'])

def verify(o,emit=False):
    shape(o);seeds=read('seeds35_proof.json');contract=read('contract.json');guards={g['index']:g for g in contract['rows']}
    support=r.ds.target(r.N,r.K,r.R,r.Q);need(equal(o['global_support'],support),'fixed global support acquired independently')
    hc=support['gaussian']['cells'];rays=len(support['ray_rows']);steps=0
    for record in o['rows']:
        i=record['index'];guard=guards[i]
        band=next(b for b in seeds['bands']if b['interval'][0]<=i<b['interval'][1]);last=band['stages'][-1]
        need(equal(record['seed_band'],band['interval']),'exact seed-to-probability incidence')
        row=seed(r.decode_row(last['output']['panels'][i]));rm=F(last['profile']['radius_minus']);rp=F(last['profile']['radius_plus'])
        need(record['product_A']==str(row['A'])and record['product_B']==str(row['B']),'actual endpoint product floors')
        z=r.base_cell(json.dumps(enc(row),sort_keys=True),rm,rp);need(equal(record['base'],enc(z)),'exact eighty-pass charged probability base')
        need(not z.get('excluded'),'nonempty selected central target')
        for claimed in record['refinements']:
            nrm,nrp=rat(claimed['radius_minus']),rat(claimed['radius_plus'])
            got=r.refine(json.dumps(enc(z),sort_keys=True),rm,rp,nrm,nrp)
            need(equal(claimed,enc(got)),'exact acquired support, moment and variance-geometry refinement')
            for s in got['support']:hc+=s['gaussian']['cells'];rays+=len(s['ray_rows'])
            z=got['result'];rm,rp=nrm,nrp;steps+=1;need(not z.get('excluded'),'nonempty selected refined target')
        need(equal(record['interface'],enc(r.interface(z,rm,rp,guard))),'all exact same-law scalar, direct-charge and quadratic guards')
        if emit:print('ACCEPTED_CENTRAL35',i,len(record['refinements']),flush=True)
    return dict(probability_panels=18,surviving_panels=list(range(31,49)),refinement_stages=steps,support_H_cells=hc,support_rays=rays)

def main():
    need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary Python invocation')
    sys.set_int_max_str_digits(0)
    path=Path('central35_proof.json');o=read(path);result=verify(o,True);controls=[]
    def change(name,fn,deep=False):
        z=copy.deepcopy(o);fn(z)
        try:verify(z)if deep else shape(z)
        except(ValueError,AssertionError,TypeError,KeyError,IndexError,ZeroDivisionError):controls.append(name);return
        raise ValueError('malformed central proof accepted: '+name)
    change('wrong theorem',lambda z:z.update(schema='wrong'))
    change('wrong initial binding',lambda z:z.update(initial_sha256='0'*64))
    change('wrong seed binding',lambda z:z.update(seeds_sha256='0'*64))
    change('changed target',lambda z:z.update(contract_sha256='0'*64))
    change('missing probability panel',lambda z:z['rows'].pop())
    change('duplicated probability panel',lambda z:z['rows'].append(z['rows'][0]))
    change('reordered probability cover',lambda z:z['rows'].reverse())
    change('boolean index',lambda z:z['rows'][0].update(index=True))
    change('wrong seed interval',lambda z:z['rows'][0].update(seed_band=[0,100]),True)
    change('wrong support decrement',lambda z:z['global_support'].update(q='0'),True)
    change('omitted initial ray',lambda z:z['global_support']['ray_rows'].pop(),True)
    change('false endpoint product floor',lambda z:z['rows'][0].update(product_A='1'),True)
    change('false base defect',lambda z:z['rows'][0]['base'].update(D='1/100'),True)
    change('missing route step',lambda z:z['rows'][0]['refinements'].pop(),True)
    change('noncanonical radius',lambda z:z['rows'][0]['refinements'][0].update(radius_minus='01'))
    change('unacquired radius',lambda z:z['rows'][0]['refinements'][0].update(radius_minus='1'),True)
    change('omitted acquired ray',lambda z:z['rows'][0]['refinements'][0]['support'].pop(),True)
    change('false harmonic cap',lambda z:z['rows'][0]['refinements'][0].update(lambda_geometry_cap='0'),True)
    change('false simultaneous charge',lambda z:z['rows'][0]['interface']['charges'].update(gap_charge='100'),True)
    change('false quadratic dominance',lambda z:z['rows'][0]['interface']['quadratic_mapping'][0].update(margin='1'),True)
    change('omitted quadratic branch',lambda z:z['rows'][0]['interface']['quadratic_mapping'].pop(),True)
    change('extra success flag',lambda z:z.update(accepted=True))
    try:json.loads('{"a":1,"a":2}',object_pairs_hook=unique)
    except ValueError:controls.append('duplicate JSON key')
    else:raise ValueError('duplicate keys accepted')
    result.update(schema='SHORT_CENTRAL35_RESOURCE_ACCEPTANCE_V1',status='PASS_SHORT_CENTRAL35_RESOURCE',mathematical_status='Conditional same-law CENTRAL35 resources on p[.31,.49], K0, decrement<=63/340, current cap.423493. Global INITIAL, short seeds, other p ranges and final comparison remain separate dependencies.',execution_status='Fresh complete exact resource replay PASS',initial_sha256=o['initial_sha256'],seeds_sha256=o['seeds_sha256'],contract_sha256=CONTRACT_SHA,acquisition_sha256=sha(path),negative_controls=controls)
    Path('CENTRAL35_ACCEPTED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
