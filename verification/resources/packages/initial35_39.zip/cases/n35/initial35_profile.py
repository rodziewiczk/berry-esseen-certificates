"""Fixed global INITIAL35; later localized seeds have separately acquired data."""
from fractions import Fraction as F
P=dict(n=35,nmax=35,radius=F(39,10),cap=F(53539,125000),barrier=F(0),grid=[24,24,8,4])
PASSES=10
def enc(x):
    if type(x)is F:return str(x)
    if isinstance(x,dict):return{k:enc(v)for k,v in x.items()}
    if isinstance(x,(tuple,list)):return[enc(v)for v in x]
    return x
def up(x):return F(-((-x.numerator*100000)//x.denominator),100000)
