"""New fixed-index support criterion for n>=2, with an exact scale enclosure.

Uses the proved finite fifth-order Gaussian identity and its explicit
coupling gates; it does not extend the old n>=36 scale constant.
No arithmetic result alone supplies the attained-contact hypothesis.
"""
from fractions import Fraction as F
from hashlib import sha256
import json
import heat_support50 as P

def constants(n,K):
 assert type(n)is int and n>=2 and F(0)<=K and F('.4095')+K/n<F('.469')
 c=F('.4095')+K/n;r=min(F('.3031')*F('.646')/(c-F('.3031')),F('.3322')*F('.429')/(c-F('.3322')))
 assert r>=1
 _,disc=P.root((2+r*r)**2-4*(1-r*r));_,b=P.root((disc-2-r*r)/2)
 assert 0<b<1 and (1+b*b)**2>r*r*(1-b*b)
 ell,_=P.root(F(n-1));slo,S=P.root(F(n,n-1));e=n*(S-1)-F(1,2)
 assert slo*slo<=F(n,n-1)<S*S and 0<e and ell>0
 return c,r,b,ell,S,e

def data(n,K):
 c,r,b,ell,S,e=constants(n,K);v=n-1;A=P.A;J=P.trim([0,-15,0,0,0,1]);D=P.scale(J,F(1,120*v));W=P.add(A,P.scale(D,F(-15,2)))
 E=P.add(P.scale([0,0,0,0,0,0,1],F(51,14400*v)/ell),P.scale([-2,0,3],F(51,960*v)/ell),[0,F(1,8*v*v)])
 B2=P.scale(P.mul(P.H4,P.H4),F(1,256*v));Numer=P.add(P.mul(P.add(A,P.scale(D,-3)),W),B2)
 Dom=P.add(P.mul(P.add(P.scale(A,F(1,2)),P.scale(D,-6),P.scale(P.H4,F(-1,12)/ell)),W),B2)
 Q=[r*e,3*b,F(3,2)*r,-1]
 PA0=P.add(P.scale(Numer,F(2,5)*S**3),P.scale(P.mul(E,W),S**3),P.mul(P.scale(Q,c),W))
 return dict(c=c,r=r,b=b,S=S,e=e,J=J,W=W,Dom=Dom,Q=Q,PA0=PA0,PAq=P.scale(W,r*S),ray0=P.add([F(1,2),F(1,5),0,F(1,15)],P.scale(Q,c)))

def target(n,K,R,q):
 assert type(n)is int and n>=2 and F('2.5')<=R<F('4.5') and q>=0
 d=data(n,K);poly=P.add(d['PA0'],P.scale(d['PAq'],q));rows=[];gates=[];lo=R
 while lo<F('4.5'):
  hi=min(F('4.5'),lo+F(1,20))
  for name,a in [('A',P.A),('H4',P.H4),('J',d['J']),('W',d['W']),('outer_domination',d['Dom']),('negative_C',P.scale(d['Q'],-1)),('contact',P.scale(poly,-1))]:
   bs=P.bern(a,lo,hi)
   if min(bs)<=0:raise ValueError((name,n,str(K),str(R),str(q),str(lo),str(min(bs))))
   gates.extend((name,str(x))for x in bs)
  rows.append([str(lo),str(hi)]);lo=hi
 for name,a in [('coefficient_ray',d['Q']),('contact_ray',P.add(d['ray0'],[d['r']*d['S']*q]))]:
  for j in range(4):
   x=-P.val(a,F('4.5'))
   if x<=0:raise ValueError((name,j,str(x)))
   gates.append((name+str(j),str(x)));a=P.deriv(a)
 return dict(schema='FIXED_INDEX_EXACT_SCALE_SUPPORT_V1',n=n,K=str(K),q=str(q),radius=str(R),score_lower=str(d['c']),rho_upper=str(d['r']),beta_absolute_upper=str(d['b']),scale_upper=str(d['S']),e_upper=str(d['e']),closed_radius_cells=rows,gates=len(gates),minimum_contact=str(min(F(x)for name,x in gates if name=='contact')),gate_sha256=sha256(json.dumps(gates,separators=(',',':')).encode()).hexdigest())
