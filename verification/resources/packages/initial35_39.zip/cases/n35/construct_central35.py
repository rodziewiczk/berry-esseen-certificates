"""Exact CENTRAL35 discovery from the fixed short seed schedule.
The separately invoked fixed acceptance, scalar composition and other
probability ranges are not established by this constructor.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys
import route35_core as r
from product_endpoint34 import seed
from initial35_profile import enc
assert __debug__ and not sys.flags.optimize
sys.set_int_max_str_digits(0)
initialpath=Path('initial35_proof.json');seedpath=Path('seeds35_proof.json');targetpath=Path('contract.json')
seeds=json.loads(seedpath.read_bytes());target=json.loads(targetpath.read_bytes())
assert len(target['rows'])==18
out=dict(schema='SHORT_CENTRAL35_RESOURCE_V1',initial_sha256=hashlib.sha256(initialpath.read_bytes()).hexdigest(),seeds_sha256=hashlib.sha256(seedpath.read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(targetpath.read_bytes()).hexdigest(),global_support=r.ds.target(r.N,r.K,r.R,r.Q),rows=[])
path=Path('central35_proof.json');assert not path.exists()
for guard in target['rows']:
    index=guard['index'];band=next(b for b in seeds['bands']if b['interval'][0]<=index<b['interval'][1]);last=band['stages'][-1]
    row=seed(r.decode_row(last['output']['panels'][index]));rm=F(last['profile']['radius_minus']);rp=F(last['profile']['radius_plus'])
    z=r.base_cell(json.dumps(enc(row),sort_keys=True),rm,rp)
    record=dict(index=index,seed_band=band['interval'],product_A=str(row['A']),product_B=str(row['B']),base=enc(z),refinements=[])
    assert not z.get('excluded'),(index,'unexpectedly empty central target')
    for j in range(40):
        radii=[]
        for sign,prior in[(-1,rm),(1,rp)]:
            radius=prior
            for k in range(14,40):
                candidate=F(k,10)
                if candidate>=prior:break
                try:r.ds.target(r.N,r.K,candidate,r.Q,sign=sign,rho=z['rho'],beta_lower=z['beta_lo'],beta_upper=z['beta'])
                except ValueError:continue
                radius=candidate;break
            radii.append(radius)
        result=r.refine(json.dumps(enc(z),sort_keys=True),rm,rp,*radii)
        rm,rp=radii;z=result['result'];record['refinements'].append(enc(result))
        print('CONSTRUCT_CENTRAL35',index,j+1,'excluded'if z.get('excluded')else str(z['D']),flush=True)
        assert not z.get('excluded'),(index,'unexpectedly empty refined central target')
        if r.guarded(z,rm,rp,guard):record['interface']=enc(r.interface(z,rm,rp,guard));break
    assert 'interface'in record,(index,'all fixed central guards not reached')
    out['rows'].append(record);path.write_text(json.dumps(out,indent=2)+'\n')
print('CONSTRUCT_CENTRAL35_COMPLETE',len(out['rows']),flush=True)
