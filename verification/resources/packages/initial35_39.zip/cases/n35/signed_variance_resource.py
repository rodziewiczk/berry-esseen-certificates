#!/usr/bin/env python3
"""Candidate sign-specific moment/outer-gap budgets; acceptance separate."""
def install(k):
 old=k.general_cell
 def general_cell(d,l,u,glob,steps=8):
  z=old(d,l,u,glob,steps)
  if z is None:return None
  F=k.F;lo=lambda x:k.roots(x)[0];hi=lambda x:k.roots(x)[1]
  t=z['theta'];R=k.RADIUS
  if not 0<l<u<F(1,2):return z
  pqmax=u*(1-u);pqmin=l*(1-l)
  dist=max(F(0),(4-k.SU)/2-u,l-(4-k.SL)/2)
  binary=(6+2*k.SL)*lo((1-t)**3)/hi(pqmax)*dist**2
  residual=d-binary
  if residual<0:return None
  kp=3*(k.SL+1)*z['bl'];km=3*(k.SL+3)*z['al']
  k.need(kp>0 and km>0,'signed variance charge divisors')
  vp=hi((1-l)/l);vm=hi(u/(1-u))
  bj={3:hi((1-2*pqmin)**2/pqmin),4:1/pqmin-3,5:(1-4*pqmin+2*pqmin*pqmin)/(pqmin*lo(pqmin))}
  def L(j,v):
   if j==3:return R+2*v
   if j==4:return R*R+2*R*v+3*v*v
   return R**3+2*R*R*v+3*R*v*v+4*v**3
  improved={}
  for j in (3,4,5):
   slope=F(j,2) if t==0 else ((2-t) if j==4 else max(F(0),(1-hi((1-t)**j))/t))
   improved[j]=k.up(bj[j]+residual*max(F(0),(L(j,vp)-slope*bj[j])/kp,(L(j,vm)-slope*bj[j])/km))
  oldM,oldouter=z['M'],z['douter']
  z['Rho']=min(z['Rho'],improved[3])
  z['M']=min(z['M'],improved[4],k.up(1+k.K4*(z['Rho']-1)))
  z['eta']=min(z['eta'],improved[5],R*z['M'])
  z['g']=min(z['g'],hi(z['M']-1))
  gap=z['al']+z['bl']
  charge=max((k.SU-1)*vp/(3*gap),(k.SU+1)*vm/(3*gap),(k.SU-1)*L(3,vp)/kp,(k.SU+1)*L(3,vm)/km)
  z['douter']=min(oldouter,k.up(residual*charge))
  z['ulo']+=R/(2*(k.SL+1))*(oldouter-z['douter'])
  z['uhi']=min(z['uhi'],z['j0']+R*z['douter']/4+(z['M']-3)/6)
  k.need(1<=z['M'] and z['ulo']<=z['uhi'],'signed budget moment rectangle')
  z['signed_resource']=dict(residual=residual,kp=kp,km=km,improved=improved,outer=z['douter'])
  return z
 k.general_cell=general_cell
 return general_cell
