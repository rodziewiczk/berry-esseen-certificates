"""Construct a fixed twelve-pass INITIAL39 candidate, not an acceptance claim."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
import initial_global39 as c
from initial39_profile import P,PASSES,enc,up
assert __debug__ and not sys.flags.optimize
path=Path('initial39_proof.json');assert not path.exists()
out=dict(schema='BRIDGE39_INITIAL_V1',profile=enc(P),stages=[])
raw=d=None
for j in range(PASSES):
    z=c.stage(P,raw,d);r=up(z['R'])+F(1,100000);e=up(z['D'])+F(1,100000)
    if raw is not None:r,e=min(raw,r),min(d,e)
    out['stages'].append(dict(raw=str(r),D=str(e),active=z['active'],excluded=z['excluded'],reasons=z['reasons']))
    raw,d=r,e;path.write_text(json.dumps(out,indent=2)+'\n')
    print('CONSTRUCT_INITIAL39',j+1,str(raw),str(d),flush=True)
assert 0<d<F('1.014') and d<c.k.SL-1
out['export']=enc(c.stage(P,raw,d));path.write_text(json.dumps(out,indent=2)+'\n')
print('CONSTRUCT_INITIAL39_COMPLETE',len(out['stages']),out['export']['active'],flush=True)
