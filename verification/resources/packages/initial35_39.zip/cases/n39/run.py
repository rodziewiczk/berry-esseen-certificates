"""Isolated exact39 execution logger; no optimization and no inherited PASS reuse."""
from pathlib import Path
import sys,subprocess,json,hashlib,time,platform
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
assert __debug__ and not sys.flags.optimize and len(sys.argv)==2
kind=sys.argv[1];mapping={'support':'check_support39.py','construct':'construct_initial39.py','accept':'accept_initial39.py'};assert kind in mapping
run=ROOT/'runs/below40_20261007/relative'/('bridge39_'+kind+'01');run.mkdir(exist_ok=False)
files=list(HERE.glob('*.py'))+[HERE/'COPIED_SOURCES.json']
if kind=='accept':files.append(HERE/'initial39_proof.json')
h={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files};cmd=[sys.executable,'-B',mapping[kind]];start=time.monotonic()
with(run/'stdout.txt').open('w')as o,(run/'stderr.txt').open('w')as e:r=subprocess.run(cmd,cwd=HERE,stdout=o,stderr=e)
result=dict(command=cmd,cwd=str(HERE),python=sys.version,platform=platform.platform(),optimized=sys.flags.optimize,returncode=r.returncode,elapsed_seconds=time.monotonic()-start,input_sha256=h,output_sha256={name:hashlib.sha256((run/name).read_bytes()).hexdigest()for name in('stdout.txt','stderr.txt')})
(run/'metadata.json').write_text(json.dumps(result,indent=2)+'\n');print(kind,r.returncode,flush=True);print((run/'stdout.txt').read_text()[-2500:]);print((run/'stderr.txt').read_text());raise SystemExit(r.returncode)
