"""Fixed complete INITIAL38 exact replay, separately from probability acquisition."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json,hashlib,copy,sys
import initial_global38 as initial

from initial38_profile import P

def need(x,s):
    if not x:raise ValueError(s)
def enc(x):
    if type(x)is F:return str(x)
    if isinstance(x,dict):return{k:enc(v)for k,v in x.items()}
    if isinstance(x,(list,tuple)):return[enc(v)for v in x]
    return x
def equal(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
    return a==b
def unique(rows):
    d={}
    for k,v in rows:need(k not in d,'duplicate JSON key');d[k]=v
    return d
def read(p):return json.loads(Path(p).read_bytes(),object_pairs_hook=unique)
def fields(x,names):need(type(x)is dict and set(x)==set(names),'exact object schema')
def rat(x):
    need(type(x)is str and len(x)<100,'short rational string')
    v=F(x);need(str(v)==x,'canonical rational');return v
def up(x):return F(-((-x.numerator*100000)//x.denominator),100000)
@lru_cache(None)
def stage(raw,d):return initial.stage(P,raw,d)

def shape(o):
    fields(o,('schema','profile','stages','export'))
    need(o['schema']=='BRIDGE38_INITIAL_V1'and equal(o['profile'],enc(P)),'fixed mathematical profile')
    need(type(o['stages'])is list and len(o['stages'])==15,'fixed fifteen-stage schedule')
    raw=d=None
    for z in o['stages']:
        fields(z,('raw','D','active','excluded','reasons'))
        r,e=rat(z['raw']),rat(z['D'])
        need(0<r<F(2,5)*38 and 0<e<4,'original signed feedback domain')
        if raw is not None:need(r<=raw and e<=d,'ordered valid invariants')
        for key in ('active','excluded'):need(type(z[key])is int and z[key]>=0,'strict integer incidence')
        need(z['active']+z['excluded']==18432,'complete signed cover')
        raw,d=r,e
    need(d<=F('1.127'),'fixed final D<=1.127 acquisition target')
    need(type(o['export'])is dict and type(o['export'].get('panels'))is list and len(o['export']['panels'])==100,'complete final p table')

def verify(o,emit=False):
    shape(o);raw=d=None
    for j,z in enumerate(o['stages']):
        got=stage(raw,d);r=up(got['R'])+F(1,100000);e=up(got['D'])+F(1,100000)
        if raw is not None:r,e=min(r,raw),min(e,d)
        expected=dict(raw=str(r),D=str(e),active=got['active'],excluded=got['excluded'],reasons=got['reasons'])
        need(equal(z,expected),'exact complete INITIAL stage replay')
        raw,d=r,e
        if emit:print('ACCEPTED_INITIAL38',j+1,str(raw),str(d),flush=True)
    need(d<initial.k.SL-1,'all final active cells satisfy gap condition')
    need(equal(o['export'],enc(stage(raw,d))),'exact full final panel export')
    return dict(stages=15,export_stages=1,resource_cells=16*18432,
                raw=str(raw),D=str(d),probability_panels=100,
                nonempty_panels=[j for j,z in enumerate(o['export']['panels'])if z['cells']])

def main():
    need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed nonoptimized invocation')
    path=Path('initial38_proof.json');o=read(path);result=verify(o,True);controls=[]
    def reject(name,fn):
        try:fn()
        except(ValueError,AssertionError,TypeError,KeyError,ZeroDivisionError):controls.append(name);return
        raise ValueError('corrupted proof accepted: '+name)
    def change(name,fn,deep=False):
        z=copy.deepcopy(o);fn(z);reject(name,lambda:verify(z)if deep else shape(z))
    change('wrong index',lambda z:z['profile'].update(n=33))
    change('wrong cap',lambda z:z['profile'].update(cap='469/1000'))
    change('wrong excess',lambda z:z['profile'].update(barrier='9/25'))
    change('wrong support radius',lambda z:z['profile'].update(radius='96/25'))
    change('missing stage',lambda z:z['stages'].pop())
    change('duplicate stage',lambda z:z['stages'].append(z['stages'][-1]))
    change('reordered stage',lambda z:z['stages'].reverse())
    change('boolean incidence',lambda z:z['stages'][0].update(active=True))
    change('noncanonical rational',lambda z:z['stages'][0].update(raw='01'))
    change('false raw arithmetic',lambda z:z['stages'][0].update(raw='5'),True)
    change('false final bound',lambda z:z['stages'][-1].update(D='1/2'),True)
    change('missing probability panel',lambda z:z['export']['panels'].pop())
    change('false exported theta',lambda z:z['export']['panels'][33].update(theta='0'),True)
    change('false exported endpoint',lambda z:z['export']['panels'][33].update(A='2'),True)
    change('extra field',lambda z:z.update(accepted=True))
    reject('duplicate JSON key',lambda:json.loads('{"schema":1,"schema":2}',object_pairs_hook=unique))
    result.update(schema='FIXED_INITIAL38_ACCEPTANCE_V1',status='PASS_INITIAL38_K0',
                  mathematical_status='Conditional signed INITIAL for an attained positive closed n38 witness with K=0, actual supportR3.8 and prior own cap0.422898; scalar/support and subsequent acquisition edges are separate.',
                  execution_status='Fresh exact complete replay PASS',
                  initial_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  negative_controls=controls,profile=enc(P))
    Path('INITIAL38_ACCEPTED.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
