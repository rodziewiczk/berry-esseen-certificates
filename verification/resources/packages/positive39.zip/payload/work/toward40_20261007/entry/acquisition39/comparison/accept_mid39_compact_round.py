"""Fixed exact signed-MID comparison on explicit conditional central42 resources."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from mid39_compact_contract import contexts
from contract39 import K
CONTEXTS=tuple(contexts())
from mid39_bounds import own,poisson,tail_bennett
HERE=Path(__file__).parent
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
def need(v,s):
 if not v:raise ValueError(s)
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'Duplicate key');d[k]=v
 return d
def run(o,emit=False,shape_only=False):
 need(type(o)is dict and set(o)=={'schema','rows'}and o['schema']=='SINGLE39_COMPACT_MID_WITNESSES_V1','Fixed schema')
 blocks=o['rows'];count=0;worst=F(10);digest=sha256();k=0
 for index,hs,bi,lo,hi,start,A,d,steps,sign,c in CONTEXTS:
  need(k<len(blocks),'Missing proof block');b=blocks[k];k+=1
  need(type(b)is dict and set(b)=={'index','Hsign','band','sign','witnesses'},'Exact block fields')
  need(all(type(b[x])is int for x in('index','Hsign','band','sign')),'Strict integer block labels')
  need([b[x]for x in('index','Hsign','band','sign')]==[index,hs,bi,sign],'Complete ordered signed block cover')
  need(type(b['witnesses'])is list and len(b['witnesses'])==steps,'Full closed phase cover')
  need(all(type(q)is int and 0<=q<=57 and (q!=56 or sign==-1)and(q!=57 or sign==1)for q in b['witnesses']),'Legal integer witness list')
  if shape_only:continue
  tl=c['ownlo']*lo;th=c['ownhi']*hi;V=c['incoming']*hi;mu=V/A**2
  raw=6*c['pl']-3*c['pl']**2-F('1.5')-d-3*(1-2*c['v'])*c['lmax']/(8*c['v']*39)
  rowmin=F(10)
  for j,choice in enumerate(b['witnesses']):
   need(type(choice)is int,'Integer witness')
   l=start+F(j,1000);h=l+F(1,1000)
   cc=c
   if sign>0:
    hcap=c['H']/c['elo']if hs>0 else F(0)
    dd=max(h,hcap-l)if hs>0 else c['H']/c['elo']+h
    vertex=max(l,min(h,hcap))
    phase_loss=max(F(0),2*hcap*vertex-vertex*vertex)
    zeta=c['logder']*dd/2+c['remainder']+c['entropy']*dd**3/(6*39)
    lower_derivative=1-((hi+phase_loss)/(2*c['v'])+zeta)/39
    need(dd<=c['delta'] and lower_derivative>0,'Signed positive-phase derivative domain')
    cc={**c,'derivative_lo':max(c['derivative_lo'],lower_derivative)}
   if sign<0:
    hcap=c['H']/c['elo']if hs>0 else F(0)
    dd=c['H']/c['elo']+h if hs>0 else max(h,c['H']/c['elo']-l)
    zeta=c['logder']*dd/2+c['remainder']+c['entropy']*dd**3/(6*39)
    eta=(h*h+2*max(F(0),hcap)*h)/(2*c['v'])+zeta
    need(dd<=c['delta'] and dd*dd<39*c['v'] and 0<=eta<39,'Signed negative derivative domain')
    cc={**c,'derivative_hi':min(c['derivative_hi'],1/(1-eta/39))}
   exactlo=(1-c['cv']*dd/39)*lo;exacthi=(1+c['cv']*dd/39)*hi;exactV=(1+c['cv']*(dd+1)/39)*hi
   tl=F(exactlo.numerator*10000//exactlo.denominator,10000)
   th=F(-((-exacthi.numerator*10000)//exacthi.denominator),10000)
   V=F(-((-exactV.numerator*10000)//exactV.denominator),10000);mu=V/A**2
   need(0<tl<=exactlo and th>=exacthi and V>=exactV,'outward phase-local conditional variances')
   lower=own(choice,sign,l,h,tl,th,A,cc)
   distance=1+l if sign<0 else 1-h;outerdist=F(1)if sign<0 else 1-h/2
   pc,anchor=poisson(mu,distance/A);first=min(pc,V/(V+distance**2),tail_bennett(A,V,distance));outer=tail_bennett(A,V,outerdist)
   need(0<outer<1,'Geometric probability domain')
   dpositive=max(F(0),(c['H']/c['elo']if hs>0 else F(0))+(h if sign<0 else-l))
   repair=max(F(0),c['repair_pos']*dpositive-min(c['repair_multiplier']*raw,c['repair_multiplier_upper']*raw))
   bracket=lower-c['ratio']*(first+outer*outer/(1-outer));reserve=min(c['mass']*bracket,bracket)-repair*hi/39+K/39
   need(reserve>0,('Score failure',index,hs,bi,sign,j,str(bracket),str(reserve)))
   rowmin=min(rowmin,reserve);worst=min(worst,reserve);count+=1;digest.update(('|'.join(map(str,(index,hs,bi,sign,j,choice,bracket,reserve)))+'\n').encode())
  if emit:print(json.dumps(dict(index=index,Hsign=hs,band=bi,sign=sign,status='PASS',minimum=float(rowmin))),flush=True)
 need(k==len(blocks),'Extra proof blocks')
 return dict(status='PASS_SINGLE39_POSITIVE_EXCESS_COMPACT_ROUNDED_MID',blocks=k,phase_cells=count,minimum=str(worst),gate_sha256=digest.hexdigest(),scope='n=39,39*a39>=741/4000, fixed common-law resources and joint-gap constraint; acquisition is separate')
def controls(obj):
 import copy
 tests=[]
 def reject(name,change):
  bad=copy.deepcopy(obj);change(bad)
  try:run(bad,shape_only=True)
  except ValueError:tests.append(name)
  else:raise ValueError('Bad proof accepted: '+name)
 reject('missing_row',lambda o:o['rows'].pop())
 reject('duplicate_row',lambda o:o['rows'].__setitem__(1,o['rows'][0]))
 reject('reordered_rows',lambda o:o['rows'].reverse())
 reject('boolean_index',lambda o:o['rows'][0].update(index=False))
 reject('boolean_Hsign',lambda o:o['rows'][1].update(Hsign=True))
 reject('boolean_band',lambda o:o['rows'][0].update(band=False))
 reject('boolean_phase_sign',lambda o:o['rows'][1].update(sign=True))
 reject('missing_phase',lambda o:o['rows'][0]['witnesses'].pop())
 reject('boolean_witness',lambda o:o['rows'][0]['witnesses'].__setitem__(0,False))
 reject('out_of_range_witness',lambda o:o['rows'][0]['witnesses'].__setitem__(0,58))
 reject('extra_scope',lambda o:o.update(N=41))
 bad=copy.deepcopy(obj);bad['rows'][0]['witnesses'][0]=0
 need(bad!=obj,'active legal-witness mutation')
 try:run(bad)
 except ValueError:tests.append('false_legal_quartic_witness')
 else:raise ValueError('False legal witness accepted')
 try:json.loads('{"rows":[],"rows":[]}',object_pairs_hook=unique)
 except ValueError:tests.append('duplicate_JSON_key')
 else:raise ValueError('Duplicate key accepted')
 return tests
if __name__=='__main__':
 need(len(sys.argv)==1,'Fixed target no overrides');raw=(HERE/'mid39_compact_witnesses.json').read_bytes();obj=json.loads(raw,object_pairs_hook=unique);out=run(obj,True);out['negative_controls']=controls(obj);out['proof_sha256']=sha256(raw).hexdigest();print(json.dumps(out),flush=True)
