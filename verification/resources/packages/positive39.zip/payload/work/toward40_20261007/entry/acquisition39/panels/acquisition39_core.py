"""Single-index39 acquired resources under39*a39>=741/4000 anddelta39<=.33.
Actual support[-3.84,3.84], C39<.4226, a39<.50/39 and INITIAL39 are inputs.
The plan fixes every support radius; this module does not optimize targets.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,sys
import candidate_panel40 as c
import corrected_phase_callback_extended as correction
import panel_exterior39 as ext
import heat_support50 as heat,fifth_heat50 as fifth
correction.install(c.k)
N=39;K=F(741,4000);Q=F(33,100);CAP=F('.4226');SCALE=10**6
BASE=heat.constants
if sys.flags.optimize or not __debug__:raise RuntimeError('ordinary Python required')
def need(x,s):
 if not x:raise ValueError(s)
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,(tuple,list)):return[enc(v)for v in x]
 if isinstance(x,dict):return{k:enc(v)for k,v in x.items()}
 return x
def dec(x):
 if isinstance(x,str):
  try:return F(x)
  except(ValueError,ZeroDivisionError):return x
 if isinstance(x,list):return[dec(v)for v in x]
 if isinstance(x,dict):return{k:dec(v)for k,v in x.items()}
 return x
def up(x):return c.k.up(x,SCALE)+F(1,SCALE)
def down(x):return c.k.down(x,SCALE)-F(1,SCALE)
def bounded(z):
 if z.get('excluded'):return dict(excluded=True,reason=z['reason'],stage=z['stage'])
 o={k:z[k]for k in('pl','pu')}
 for k in('raw','D','theta','rho','beta','lambda_max','inward_d_max','Hplus','Hminus'):o[k]=up(z[k])
 for k in('A','B','beta_lo'):o[k]=down(z[k])
 o['quadratics']=[{k:(down(v)if k in('Qraw','Qbudget')else up(v))for k,v in r.items()if k in('A','Fplus','Fminus','Qraw','Qbudget')}for r in z['quadratics']]
 o['joint_inward_noise']=True
 return o
def cell(row,R):return bounded(c.cell(N,R,CAP,row,steps=64,barrier=K))
def support(z,R):
 def constants(n,last,K0):
  C,_,_,ell,S=BASE(n,last,K0);return C,z['rho'],z['beta'],ell,S
 heat.constants=constants
 try:return fifth.target(N,N,K,R,Q)
 finally:heat.constants=BASE

def contact_summary(vals):
 need(vals and max(vals)<0,'strict complete contact cover')
 return dict(cells=len(vals),maximum=max(vals),sha256=hashlib.sha256(json.dumps(enc(vals),separators=(',',':')).encode()).hexdigest())
def central_radius(z):
 h=max(z['Hplus'],z['Hminus']);need(0<=z['beta_lo']<=z['beta']<1 and 0<h<2,'central contact domain')
 v=[]
 for j in range(54):
  a=F('2.5')+F(j,40);b=a+F(1,40)
  v.extend([ext.support_cell(h,z['rho'],z['beta_lo'],z['beta'],a,b),ext.support_cell(h,z['rho'],z['beta_lo'],z['beta'],-b,-a)])
 return contact_summary(v)
def strip(z,R,width):
 hyp=dict(p=[str(z['pl']),str(z['pu'])],theta=str(z['theta']),rho=str(z['rho']),beta_upper=str(z['beta']),H=str(max(z['Hplus'],z['Hminus'])),radius=str(R))
 o=ext.from_hypotheses(hyp,width);return contact_summary([F(r['upper'])for r in o['rows']])
def build(emit=False):
 initial_blob=Path('../initial/initial39_candidate.json').read_bytes();initial=dec(json.loads(initial_blob));plan_blob=Path('acquisition39_plan.json').read_bytes();plan=dec(json.loads(plan_blob))
 need(initial['format']=='INITIAL39_K741_4000_FULL_P_V1'and initial['name']=='INITIAL39_K741_4000_R384'and len(initial['panels'])==100,'fixed complete initial source')
 need(plan['schema']=='SINGLE39_ACQUISITION_PLAN_V1'and plan['first_radius']==F('2.95'),'fixed route plan')
 coarse=[];fine=[]
 for j,p in enumerate(initial['panels']):
  need(p['pl']==F(j,100)and p['pu']==F(j+1,100),'ordered full initial p cover')
  if p['cells']==0:z=dict(excluded=True,reason='initial empty')
  else:z=cell(p,F('3.84'))
  z.update(index=j,pl=p['pl'],pu=p['pu']);coarse.append(z)
  if emit:print('DISCOVERY_EXACT39_COARSE',j,z.get('excluded',False),flush=True)
 parents=[r for r in coarse if not r.get('excluded')]
 need([r['index']for r in parents]==list(range(28,46)),'fixed coarse survivor interval')
 left=[r for r in parents if r['index']<38]
 first=support(dict(rho=max(r['rho']for r in left),beta=max(r['beta']for r in left)),plan['first_radius'])
 for parent in parents:
  if parent['index']>=38:parent['radius_proof']=central_radius(parent)
  for i in range(5):
   ix=5*parent['index']+i;row={k:parent[k]for k in('raw','D','theta','rho','beta')};row.update(pl=F(ix,500),pu=F(ix+1,500))
   route=plan['rows'][ix-140];need(route['index']==ix and route['p']==[row['pl'],row['pu']],'fixed ordered fine replacement')
   radii=route['radii'];need(radii and (radii[0]==plan['first_radius']if ix<190 else radii==[F('2.5')]),'licensed initial contracted radius')
   need(all(b<a for a,b in zip(radii,radii[1:])),'strict radius refinement')
   history=[]
   for j,R in enumerate(radii):
    need(F('2.5')<=R<F('3.84'),'contracted radius range')
    proof=support(row,R)if j else None
    z=cell(row,R);history.append(dict(radius=R,support=proof))
    if z.get('excluded'):break
    row=z
   z.update(index=ix,pl=F(ix,500),pu=F(ix+1,500),radius=R,history=history)
   if not z.get('excluded'):
    width=route['strip'];need(width in(F('.55'),F('.575')),'fixed two strip widths');z['strip_width']=width;z['strip_proof']=strip(z,R,width)
   fine.append(z)
   if emit:
    print('DISCOVERY_EXACT39_FINE',ix,'EXCLUDED'if z.get('excluded')else enc({k:z[k]for k in('D','lambda_max','inward_d_max','strip_width')}),flush=True)
    Path('acquisition39_progress.json').write_text(json.dumps(enc(dict(coarse=coarse,fine=fine)),indent=2)+'\n')
 need(len(fine)==90 and [r['index']for r in fine]==list(range(140,230)),'complete90-cell fine replacement')
 return dict(schema='SINGLE39_K741_4000_Q033_ACQUISITION_V1',N=N,barrier=K,decrement=Q,cap=CAP,excess_upper=F('.50'),source_sha256=hashlib.sha256(initial_blob).hexdigest(),plan_sha256=hashlib.sha256(plan_blob).hexdigest(),coarse=coarse,first_left_support=first,fine=fine)
