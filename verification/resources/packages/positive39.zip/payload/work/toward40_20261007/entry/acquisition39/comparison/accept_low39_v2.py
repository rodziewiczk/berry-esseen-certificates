"""Fixed exact LOW39 executor. Every declared closed endpoint and gate is checked."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys,copy
import contract39 as ct
import low39_kernel as k
H=Path(__file__).resolve().parent
TARGET_SHA='50fe9de2fe3027d2877d3ea12342b48f4777dd00b7954f1f9e2b8ab004d7e8b3'
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,(tuple,list)):return[enc(v)for v in x]
 if isinstance(x,dict):return{k:enc(v)for k,v in x.items()}
 return x
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[x],b[x])for x in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def check_plan(plan,expected):ct.need(same(plan,expected),'typed full fixed LOW plan')
ct.need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed unoptimized invocation')
ct.need(hashlib.sha256((H/'targets39_candidate.json').read_bytes()).hexdigest()==TARGET_SHA,'fixed resource target bytes')
rows=ct.read();plan=[dict(index=r['index'],sign=s,N=39,Hcells=8,phase_cells=4)for r in rows if F(r['lambda_max'])>F('.08')for s in(-1,1)]
ct.need(len(plan)==90,'complete90-row fixed LOW cover');out=[]
for t in plan:
 r=rows[t['index']];cfg=ct.selected(r,t['sign'],t['Hcells'],t['phase_cells']);proof,report=k.evaluate(cfg)
 ct.need(report['status']=='PASS_SINGLE39_POSITIVE_EXCESS_LOW_ROW'and report['gates']>0 and not report['failed_gates'],'strict exact row gates')
 out.append(dict(index=t['index'],sign=t['sign'],proof=proof,report=report))
 print('PASS_EXACT_LOW39_ROW',t['index'],t['sign'],report['gates'],report['worst_score_decimal'],flush=True)
 Path('low39_progress.json').write_text(json.dumps(enc(dict(rows=out)),indent=2)+'\n')
controls=[]
for label,fn in [('missing row',lambda a:a.pop()),('duplicate row',lambda a:a.__setitem__(1,a[0])),('reordered rows',lambda a:a.reverse()),('boolean index',lambda a:a[0].update(index=False)),('boolean sign',lambda a:a[0].update(sign=True)),('wrong n',lambda a:a[0].update(N=40)),('boolean n',lambda a:a[0].update(N=True)),('wrong mesh',lambda a:a[0].update(Hcells=4)),('extra field',lambda a:a[0].update(extra=True))]:
 bad=copy.deepcopy(plan);fn(bad)
 try:check_plan(bad,plan)
 except ValueError:controls.append(label)
 else:raise ValueError('invalid plan accepted '+label)
try:json.loads('{"rows":[],"rows":[]}',object_pairs_hook=ct.unique)
except ValueError:controls.append('duplicate JSON key')
else:raise ValueError('duplicate JSON key accepted')
proof=dict(schema='SINGLE39_POSITIVE_EXCESS_LOW_FULL_V1',plan=plan,rows=out)
blob=json.dumps(enc(proof),indent=2)+'\n';Path('low39_proof.json').write_text(blob)
print(json.dumps(dict(status='PASS_SINGLE39_POSITIVE_EXCESS_LOW_FULL',scope='Fixedn39 on explicit common-law targets,K=741/4000,closed LOW noise/phase cells; acquisition and TINY/MID are separate.',rows=len(out),gates=sum(z['report']['gates']for z in out),worst_score=str(max(F(z['report']['worst_score'])for z in out if z['report']['worst_score']not in(None,'None'))),negative_controls=controls,proof_sha256=hashlib.sha256(blob.encode()).hexdigest(),target_sha256=TARGET_SHA),indent=2),flush=True)
