"""Single39 MID contexts on the fixed proposed common-law resources."""
from fractions import Fraction as F
from contract39 import read,profile,N,CAP
from normalization import generate_checked
REGIONS=((F('.05'),F('.06'),F(0)),(F('.06'),F('.08'),F(0)),(F('.08'),F('.10'),F('.19')),(F('.10'),F('.12'),F('.27')))
def contexts():
 for row in read():
  lm=min(F('.12'),F(row['lambda_max']))
  if lm<=F('.05'):continue
  for hs in(-1,1):
   c=generate_checked(dict(N=N,pl=F(row['p'][0]),pu=F(row['p'][1]),theta=F(row['theta']),H=F(row['H_minus'if hs<0 else'H_plus']),d0=F(row['d0']),amplitude=F('.44'),maxnoise=lm,Ccap=CAP))
   for bi,(lo,end,start)in enumerate(REGIONS):
    hi=min(end,lm)
    if hi<=lo:continue
    A=profile(row,0 if lo<F('.08')else 1 if lo<F('.10')else 2);d=F(row['d0'])*(1-lo/F(row['lambda_max']))
    if not 0<d<=c['d0']:raise ValueError('same-law joint gap on closed noise band')
    steps=int((F('.5')-start)*1000)
    if start+F(steps,1000)!=F('.5'):raise ValueError('complete phase cover')
    for sign in(-1,1):yield row['index'],hs,bi,lo,hi,start,A,d,steps,sign,c
