"""Fixed conditional LOCAL39 initial support with inherited positive excess and q=.33."""
from fractions import Fraction as F
import sys,json
import fifth_heat50 as h
assert __debug__ and not sys.flags.optimize and len(sys.argv)==1
K=F(741,4000);q=F(33,100)
assert K==39*F(19,100)/40
row=h.target(39,39,K,F('3.84'),q)
assert row['n_band']==[39,39] and row['closed_cells'][0][0]=='96/25'
assert row['closed_cells'][-1][-1]=='9/2'
assert all(a[1]==b[0]for a,b in zip(row['closed_cells'],row['closed_cells'][1:]))
rejected=[]
for label,args in [('false radius',(39,39,K,F(3),q)),('false decrement',(39,39,K,F('3.84'),F(10)))]:
 try:h.target(*args)
 except (AssertionError,ValueError):rejected.append(label)
 else:raise ValueError('false support accepted: '+label)
print(json.dumps(dict(status='PASS_CONDITIONAL_LOCAL39_K741_4000_Q033_SUPPORT',mathematical_status='Conditional initial support for attained contact at n39, 39*a39>=741/4000, delta39<=.33. No acquisition or local comparison conclusion is asserted.',row=row,negative_controls=rejected),indent=2))
