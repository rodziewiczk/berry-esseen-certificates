"""Closed coherent noise profiles for the single39 acquired resources."""
from fractions import Fraction as F
from pathlib import Path
import json,hashlib
import confinement39_core as c
need=c.need;enc=c.enc;dec=c.dec
BANDS=[(F('.05'),F('.08')),(F('.08'),F('.10')),(F('.10'),F('.12')),(F('.12'),None)]
def build(emit=False):
 blob=Path('confinement39_candidate.json').read_bytes();src=dec(json.loads(blob));need(src['schema']=='SINGLE39_CONFINED_RESOURCES_V1'and src['N']==39,'fixed39 confined source')
 out=[]
 for z in src['rows']:
  amps=[F('.425'),F('.375'),F('.325'),F('.30')]if z['pl']<F('.38')else[F('.375'),F('.325'),F('.275'),F('.25')]
  for sign in(-1,1):
   for bi,((lo,top),amp)in enumerate(zip(BANDS,amps)):
    hi=z['lambda_max']if top is None else min(top,z['lambda_max']);row=dict(index=z['index'],sign=sign,band=bi,requested=[lo,top],noise=[lo,hi],target_amplitude=min(amp,z['amplitude']))
    if hi<=lo:row['kind']='empty band above noise ceiling'
    elif z['amplitude']<=amp:row['kind']='inherited unconditional amplitude'
    else:
     row['kind']='new coherent joint profile';proof=[]
     for j in range(32):
      l=lo+(hi-lo)*F(j,32);u=lo+(hi-lo)*F(j+1,32)
      proof.append(c.evaluate(c.cfg(z,sign,amp,z['amplitude'],l,u,joint=True,hc=32,lc=1,coherent_theta=True)))
     row['proofs']=proof
    out.append(row)
    if emit:print('DISCOVERY_EXACT39_PROFILE',z['index'],sign,bi,row['kind'],flush=True)
  if emit:Path('profiles39_progress.json').write_text(json.dumps(enc(dict(rows=out)),indent=2)+'\n')
 need(len(out)==78*8,'all signed cells and all four noise bands')
 return dict(schema='SINGLE39_JOINT_PROFILES_V1',N=39,source_sha256=hashlib.sha256(blob).hexdigest(),rows=out)
