"""Fixed-index39 comparison on explicit, initially unacquired resource targets."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
from normalization import generate_checked
N=39;K=F(741,4000);CAP=F('.4226')
def need(v,s):
 if not v:raise ValueError(s)
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read():
 o=json.loads(Path(__file__).with_name('targets39_candidate.json').read_text(),object_pairs_hook=unique)
 need(type(o['N'])is int and o['N']==N and F(o['K'])==K and F(o['Ccap'])==CAP,'fixed39 target scope')
 rows=o['rows'];need(len(rows)==78,'78 surviving cells')
 for i,r in enumerate(rows):
  need(type(r['index'])is int and r['index']==i and type(r['source_index'])is int and r['source_index']==151+i,'typed ordered indices')
  need(list(map(F,r['p']))==[F(151+i,500),F(152+i,500)],'closed complete source interval')
  need(r['region']==('left'if i<39 else'central'),'region boundary')
  need(0<F(r['amplitude'])<=F('.43'),'global amplitude ceiling')
 return rows
def profile(row,band):
 amps=('.425','.375','.325','.30')if row['region']=='left'else('.375','.325','.275','.25')
 return min(F(row['amplitude']),F(amps[band]))
def selected(row,sign,hcells=8,ocells=4):
 lm=F(row['lambda_max']);need(sign in(-1,1)and lm>F('.08'),'nonempty LOW source')
 c=generate_checked(dict(N=N,pl=F(row['p'][0]),pu=F(row['p'][1]),theta=F(row['theta']),H=F(row['H_minus'if sign<0 else'H_plus']),d0=F(row['d0']),amplitude=F(row['amplitude']),maxnoise=lm,Ccap=CAP))
 c.update(T=F(row['T']),D=F(row['D']),phase_sign=sign,rebate=F(0),repair_normal=c['repair_pos'],raw_quads=[(F(q['A']),F(q['Fminus'if sign<0 else'Fplus']),F(q['Qbudget']))for q in row['quadratics']],joint_d0=F(row['d0']),joint_lambda=lm)
 pts=sorted(set([F('.08'),lm]+[F(j,400)for j in range(33,int(lm*400)+1)]));bands=[];amps=[];rates=[]
 for lo,hi in zip(pts,pts[1:]):
  phase=F('.19')if lo<F('.10')else F('.27')if lo<F('.12')else F('.5');bi=1 if lo<F('.10')else 2 if lo<F('.12')else 3;aa=profile(row,bi)
  span=aa+c['d0'];x=F('3.14159')*span;sine=x-x**3/6+x**5/120-x**7/5040
  bands.append((lo,hi,phase));amps.append(aa);rates.append(2*sine*sine/span**2)
 c.update(p_cells=1,H_cells=hcells,outer_phase_cells=ocells,bands=len(bands),noise_intervals=bands,amplitude_profile=amps,rate_profile=rates)
 return c
