"""Fixed single-index39 first confinement and coherent actual-radius feedback."""
from fractions import Fraction as F
from pathlib import Path
import json,hashlib
import acquisition39_core as a
import sperner_kernel as sp
N=39;need=a.need;enc=a.enc;dec=a.dec

def cfg(z,sign,amp,strip,lo=F(0),hi=None,joint=False,hc=32,lc=32,buffer=F(5,12),coherent_theta=False):
 lam=z['lambda_max'];hi=lam if hi is None else hi
 need(sign in(-1,1)and 0<=lo<hi<=lam,'closed sign/noise cell')
 d0=z['inward_d_max'];theta=z['theta']
 if joint:
  need(z['joint_inward_noise']is True,'same-law joint resource source');d0*=1-lo/lam
 if coherent_theta:theta=min(theta,hi/(N*z['pl']*(1-z['pl'])+hi))
 return dict(N=N,T=z['raw'],D=z['D'],theta=theta,d0=d0,H=z['Hminus'if sign<0 else'Hplus'],C=F('.4253'),rho=z['rho'],beta_lo=z['beta_lo'],beta_hi=z['beta'],amplitude=amp,maxnoise=hi,lower_buffer=amp*buffer,upper_buffer=amp*F(7,15),eta=F('.00001'),phase_sign=sign,noise_min=lo,strip=strip,rebate=F(0),fd=sp.rootup(max(F(N,N-1)**3,F(N,N-2))),third=F(30)if z['pl']<F('.38')else F(24),pc=1,hc=hc,lc=lc,pl=z['pl'],pu=z['pu'],raw_quads=[(q['A'],q['Fminus'if sign<0 else'Fplus'],q['Qbudget'])for q in z['quadratics']])
def evaluate(config):
 r=sp.evaluate(config);need(all(v>0 for v in r['gates'].values()),('nonpositive confinement gates',[(k,str(v))for k,v in r['gates'].items()if v<=0][:3]))
 expected={f'{p}:{h}:{l}'for p in range(config['pc'])for h in range(config['hc'])for l in range(config['lc'])};keys=[z[0]for z in r['empty']]+r['feasible']
 need(len(keys)==len(set(keys))and set(keys)==expected,'closed phase/noise cover')
 return dict(gates=len(r['gates']),excluded=len(r['empty']),feasible=len(r['feasible']),minimum_confinement=min((v for k,v in r['gates'].items()if k.startswith('confinement_')),default=None),arithmetic_sha256=hashlib.sha256(json.dumps(enc(r),sort_keys=True,separators=(',',':')).encode()).hexdigest())
def build(emit=False):
 blob=Path('acquisition39_candidate.json').read_bytes();src=dec(json.loads(blob));pb=Path('confinement39_plan.json').read_bytes();plan=dec(json.loads(pb))
 need(src['schema']=='SINGLE39_K741_4000_Q033_ACQUISITION_V1'and src['N']==N,'fixed39 acquisition source')
 need(plan['schema']=='SINGLE39_FIRST_CONFINEMENT_PLAN_V1','fixed confinement plan')
 active=[r for r in src['fine']if not r.get('excluded')];need(len(active)==78 and [r['index']for r in active]==list(range(151,229)),'complete78 surviving cells')
 need(len(plan['rows'])==78,'fixed plan length');out=[]
 for z,p in zip(active,plan['rows']):
  need(z['index']==p['index']and p['p']==[z['pl'],z['pu']],'same p cell')
  strip=z['strip_width'];history=[]
  for amp in p['amplitudes']:
   need(0<amp<strip and amp<=F('.425'),'strict selected actual support improvement')
   proofs=[evaluate(cfg(z,sign,amp,strip))for sign in(-1,1)]
   R=a.c.k.up(max(z['pu']+amp,1-z['pl']+amp)/a.c.k.roots(z['pl']*(1-z['pl']))[0],10000)+F(1,10000)
   if z['pl']<F('.38'):R=max(R,F('2.3'))
   q=a.cell(z,R);need(not q.get('excluded'),'selected feedback survivor');q.update(index=z['index'],amplitude=amp,radius=R)
   history.append(dict(amplitude=amp,radius=R,proofs=proofs));z=q;strip=amp
  need(history,'at least one confinement step');z['confinement_proof']=history;out.append(z)
  if emit:
   print('DISCOVERY_EXACT39_CONFINEMENT',z['index'],enc({k:z[k]for k in('amplitude','D','lambda_max','inward_d_max')}),flush=True)
   Path('confinement39_progress.json').write_text(json.dumps(enc(dict(rows=out)),indent=2)+'\n')
 return dict(schema='SINGLE39_CONFINED_RESOURCES_V1',N=N,source_sha256=hashlib.sha256(blob).hexdigest(),plan_sha256=hashlib.sha256(pb).hexdigest(),rows=out)
