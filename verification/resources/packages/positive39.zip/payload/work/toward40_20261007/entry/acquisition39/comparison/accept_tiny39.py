"""Fixed exact single39 TINY comparison with inherited positive excess."""
from pathlib import Path
from fractions import Fraction as F
import json,copy,hashlib,functools,sys
import contract39 as ct
from signed_normalization import generate
import tiny39_kernel as k
H=Path(__file__).resolve().parent
for name in('poisson_cubic','bennett','log_upper'):setattr(k,name,functools.lru_cache(None)(getattr(k,name)))
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def validate(a,b):ct.need(same(a,b),'complete typed tiny proof')
def build(o):
 ct.need(type(o)is dict and set(o)=={'schema','N','K','rows','bad'}and o['schema']=='SINGLE39_POSITIVE_EXCESS_TINY_CANDIDATE_V3','fixed proof shape')
 ct.need(type(o['N'])is int and o['N']==39 and F(o['K'])==ct.K and o['bad']==[] and len(o['rows'])==78,'fixed scope and full rows')
 rows=[]
 for r,s in zip(ct.read(),o['rows']):
  ct.need(type(s['index'])is int and s['index']==r['index']and type(s['source_index'])is int and s['source_index']==r['source_index'],'ordered exact panel indices')
  w=s['witness'];ct.need(type(w)is dict and set(w)=={'neg','positive','a','split_neg','anchor'},'fixed witness fields')
  for x in w.values():ct.need(type(x)is str and str(F(x))==x and F(x)>0,'positive canonical witness rational')
  base=dict(N=39,pl=F(r['p'][0]),pu=F(r['p'][1]),theta=F(r['theta']),H=max(F(r['H_minus']),F(r['H_plus'])),d0=F(r['d0']),amplitude=F('.44'),maxnoise=F('.05'),Ccap=ct.CAP)
  c,g=generate(base,F(r['H_plus']));c['barrier_allowance']=ct.K/(39*max(F('.05'),F(r['lambda_max'])))
  z=k.evaluate(c,g,F(w['neg']),F(w['positive']),anchor_neg=F(w['anchor']),quartic_a=F(w['a']),split_neg=F(w['split_neg']))
  ct.need(not z['bad']and all(F(v)>0 for v in z['gates'].values()),'all exact normalized TINY gates')
  rows.append(dict(index=r['index'],source_index=r['source_index'],witness=w,proof=z))
 return dict(schema=o['schema'],N=39,K=str(ct.K),rows=rows,bad=[])
if __name__=='__main__':
 ct.need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary Python invocation')
 path=H/'tiny39_v3_candidate.json';o=json.loads(path.read_text(),object_pairs_hook=ct.unique);actual=build(o);validate(o,actual)
 controls=[]
 for label,mut in [('missing row',lambda z:z['rows'].pop()),('duplicate row',lambda z:z['rows'].__setitem__(1,z['rows'][0])),('reorder',lambda z:z['rows'].reverse()),('wrong n',lambda z:z.update(N=40)),('boolean n',lambda z:z.update(N=True)),('wrong excess',lambda z:z.update(K='1')),('missing gate',lambda z:z['rows'][0]['proof']['gates'].pop('signed_variance')),('false upper multiplier',lambda z:z['rows'][0]['proof']['contract'].update(repair_multiplier_upper='-1')),('extra field',lambda z:z.update(extra=True))]:
  bad=copy.deepcopy(o);mut(bad)
  try:validate(bad,actual)
  except ValueError:controls.append(label)
  else:raise ValueError('malformed proof accepted '+label)
 bad=copy.deepcopy(o);bad['rows'][0]['witness']['neg']='10'
 try:build(bad)
 except ValueError:controls.append('false positive own-count witness')
 else:raise ValueError('false arithmetic witness accepted')
 try:json.loads('{"N":39,"N":40}',object_pairs_hook=ct.unique)
 except ValueError:controls.append('duplicate JSON key')
 else:raise ValueError('duplicate JSON key accepted')
 print(json.dumps(dict(status='PASS_SINGLE39_POSITIVE_EXCESS_TINY',scope='Single39,C>=CE+(741/4000)/39,0<lambda<=min(.05,Lambda),all phases and H signs,on declared common-law targets. Resource acquisition is separate.',rows=78,cases=468,gates=sum(len(r['proof']['gates'])for r in actual['rows']),minimum_reserve=str(min(F(v)for r in actual['rows']for q,v in r['proof']['gates'].items()if q.startswith('strict_comparison:'))),negative_controls=controls,proof_sha256=hashlib.sha256(path.read_bytes()).hexdigest()),indent=2))
