"""Exact common-law target/interface checks. Source arithmetic is a separate edge."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,copy,sys
import contract39 as c
H=Path(__file__).resolve().parent;P=H.parent/'panels'
def read(p):return json.loads(p.read_text(),object_pairs_hook=c.unique)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(t,s,p):
 c.need(type(t['N'])is int and t['N']==39 and F(t['K'])==c.K and F(t['Ccap'])==c.CAP,'target39 scope')
 c.need(type(s['N'])is int and s['N']==39 and s['schema']=='SINGLE39_CONFINED_RESOURCES_V1','confined source39 scope')
 c.need(type(p['N'])is int and p['N']==39 and p['schema']=='SINGLE39_JOINT_PROFILES_V1'and p['source_sha256']==sha(P/'confinement39_candidate.json'),'profile source digest')
 c.need(len(t['rows'])==len(s['rows'])==78 and len(p['rows'])==624,'complete interface domain')
 labels=[]
 for i,(a,b)in enumerate(zip(t['rows'],s['rows'])):
  ix=151+i;c.need(type(a['index'])is int and a['index']==i and type(a['source_index'])is int and type(b['index'])is int and a['source_index']==b['index']==ix,'typed ordered source cell')
  pl,pu=F(ix,500),F(ix+1,500);c.need(list(map(F,a['p']))==[pl,pu]and F(b['pl'])==pl and F(b['pu'])==pu,'same closed probability cell')
  c.need(a['region']==('left'if ix<190 else'central'),'profile region boundary')
  c.need(b['joint_inward_noise']is True,'explicit shared resource source')
  for x,y in [('T','raw'),('D','D'),('theta','theta'),('rho','rho'),('beta_hi','beta'),('d0','inward_d_max'),('lambda_max','lambda_max'),('H_plus','Hplus'),('H_minus','Hminus'),('amplitude','amplitude')]:c.need(F(a[x])>=F(b[y])>0,'outward resource '+x)
  c.need(F(a['beta_lo'])<=F(b['beta_lo']),'signed beta lower bound')
  c.need(len(a['quadratics'])==len(b['quadratics'])==4,'four coherent corners')
  for aq,bq in zip(a['quadratics'],b['quadratics']):
   for signname,Hfield in [('plus','Hplus'),('minus','Hminus')]:
    Hmax=F(b[Hfield]);da=F(aq['A'])-F(bq['A']);df=F(aq['F'+signname])-F(bq['F'+signname])
    for key in('Qraw','Qbudget'):
     c.need(F(aq[key])>0 and F(bq[key])>0,'positive source and target curvatures')
     dq=F(bq[key])-F(aq[key]);points=[F(0),Hmax]
     if dq>0:points.append(max(F(0),min(Hmax,-df/(2*dq))))
     c.need(min(da+df*h+dq*h*h for h in points)>=0,'full same-corner signed quadratic domination')
  for sign in(-1,1):
   for band,(lo,hi)in enumerate([(F('.05'),F('.08')),(F('.08'),F('.10')),(F('.10'),F('.12')),(F('.12'),None)]):
    r=p['rows'][len(labels)];label=(ix,sign,band);labels.append(label)
    c.need(all(type(r[k])is int for k in('index','sign','band'))and(r['index'],r['sign'],r['band'])==label,'full ordered signed profile')
    top=F(b['lambda_max'])if hi is None else min(hi,F(b['lambda_max']));c.need(list(map(F,r['noise']))==[lo,top],'actual closed profile noise cell')
    if top<=lo:c.need(r['kind']=='empty band above noise ceiling','empty interval license');continue
    c.need(r['kind']in('inherited unconditional amplitude','new coherent joint profile'),'active profile justification')
    c.need(F(r['target_amplitude'])<=c.profile(a,band),'actual profile dominates comparator')
 return labels
c.need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed invocation')
t=read(H/'targets39_candidate.json');s=read(P/'confinement39_candidate.json');p=read(P/'profiles39_candidate.json');labels=check(t,s,p);controls=[]
for label,which,fn in [('wrong target n',0,lambda x:x.update(N=40)),('boolean source n',1,lambda x:x.update(N=True)),('missing target row',0,lambda x:x['rows'].pop()),('duplicate target row',0,lambda x:x['rows'].__setitem__(1,x['rows'][0])),('changed p seam',0,lambda x:x['rows'][0].update(p=['3/10','151/500'])),('false raw cap',0,lambda x:x['rows'][0].update(T='0')),('false joint gap intercept',0,lambda x:x['rows'][0].update(d0='0')),('false joint noise intercept',0,lambda x:x['rows'][0].update(lambda_max='0')),('false corner constant',0,lambda x:x['rows'][0]['quadratics'][0].update(A='0')),('false curvature',0,lambda x:x['rows'][0]['quadratics'][0].update(Qbudget='100')),('missing profile row',2,lambda x:x['rows'].pop()),('reordered profile',2,lambda x:x['rows'].reverse()),('wrong source digest',2,lambda x:x.update(source_sha256='0'*64))]:
 z=copy.deepcopy([t,s,p]);fn(z[which])
 try:check(*z)
 except(ValueError,KeyError,TypeError):controls.append(label)
 else:raise ValueError('false interface accepted '+label)
try:json.loads('{"N":39,"N":40}',object_pairs_hook=c.unique)
except ValueError:controls.append('duplicate JSON key')
else:raise ValueError('duplicate keys accepted')
print(json.dumps(dict(status='PASS_CONDITIONAL_SINGLE39_ACTUAL_RESOURCE_QUADRATIC_INTERFACE',scope='Exact scalar/corner/joint/profile domination from named confined39 and profile39 outputs to comparison targets; each source arithmetic acceptance is a separate dependency.',cells=78,signed_noise_profiles=len(labels),source_sha256={str(q.relative_to(H.parent)):sha(q)for q in(H/'targets39_candidate.json',P/'confinement39_candidate.json',P/'profiles39_candidate.json')},negative_controls=controls),indent=2))
