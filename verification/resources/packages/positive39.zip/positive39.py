"""Nine byte-identical62B programs, complete fresh conditional positive39 slice.

TINY/MID/LOW arithmetic may run on fixed conditional target data in parallel.
Final completion still requires their entire actual source-interface pipeline.
Every analytical own-cap, predecessor, contact, same-law and zero-noise premise
is explicit and remains outside this numerical execution-only observation.
"""
from pathlib import Path
from hashlib import file_digest
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
import argparse
import json
import re
import shutil
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent


def need(ok,message):
    if not ok:raise ValueError(message)


def encoded(value):return(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('ascii')


def unique(pairs):
    value={}
    for key,item in pairs:need(key not in value,'No duplicate JSON key');value[key]=item
    return value


def invalid(_):raise ValueError('Finite JSON required')


def read(path):return json.loads(Path(path).read_bytes(),object_pairs_hook=unique,parse_constant=invalid)


def same(left,right):
    if type(left)is not type(right):return False
    if type(left)is dict:return left.keys()==right.keys()and all(same(left[k],right[k])for k in left)
    if type(left)is list:return len(left)==len(right)and all(same(a,b)for a,b in zip(left,right))
    return left==right


def digest(path):
    path=Path(path);need(path.is_file()and not path.is_symlink(),'Whole ordinary file')
    with path.open('rb')as stream:return file_digest(stream,'sha256').hexdigest()


def verify_source():
    files=read(HERE/'POSITIVE39-SOURCE-VERIFIED.json')['files']
    for name,pin in files.items():need(digest(HERE/name)==pin,'Complete unchanged source/input: '+name)
    return files


def terminal_json(raw):
    need(type(raw)is bytes and 0<len(raw)<=256*1024**2,'Bounded entire actual stdout')
    text=raw.decode('utf-8');decoder=json.JSONDecoder(object_pairs_hook=unique,parse_constant=invalid)
    for start in reversed([m.start()for m in re.finditer(r'(?m)^\{',text)]):
        try:value,end=decoder.raw_decode(text,start)
        except ValueError:continue
        if not text[end:].strip():
            need(type(value)is dict,'One whole final original JSON object');return value
    raise ValueError('Complete final original JSON observation absent')


def execute_stage(task,step,deadline):
    root=task/'capsule';cwd=root/step['cwd']
    before={name:digest(root/name)for name in step['input_pins']}
    need(before==step['input_pins']and time.time()<deadline,'All exact original inputs before genuine native execution')
    logs=task/'executions'/step['id'];logs.mkdir(parents=True)
    argv=[sys.executable,'-B','-S',step['entry'],*step['arguments']]
    (logs/'ARGV.json').write_bytes(encoded(dict(argv=argv,cwd=str(cwd),deadline=deadline)))
    began=time.monotonic()
    with(logs/'stdout.txt').open('xb')as stdout,(logs/'stderr.txt').open('xb')as stderr:
        observed=subprocess.run(argv,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,
            timeout=max(1,deadline-time.time()),check=False)
    need(type(observed.returncode)is int and observed.returncode==0 and(logs/'stderr.txt').stat().st_size==0,
         'Original full program completed with actual zero exit and empty stderr')
    actual=terminal_json((logs/'stdout.txt').read_bytes())
    need(same(actual,step['expected_whole_terminal_json']),
         'Entire original typed mathematical output, source pins, full domain, gates and controls match')
    need(before=={name:digest(root/name)for name in step['input_pins']},'Every mathematical input unchanged through native replay')
    for name in step['owned_outputs']:
        need((root/name).is_file(),'Complete original newly generated numerical output')
    report=dict(schema='be.positive39-original-full-native-action/1',id=step['id'],original_action_id=step['original_action_id'],
        argv=argv,cwd=str(cwd),returncode=0,seconds=time.monotonic()-began,
        original_whole_output=actual,input_sha256=before,stdout_sha256=digest(logs/'stdout.txt'),
        stderr_sha256=digest(logs/'stderr.txt'),owned_outputs={name:digest(root/name)for name in step['owned_outputs']},
        parent_scalar_support_and_analytic_licenses_still_required=True,mathematical_acceptance=False,full_proof_pass=False)
    (logs/'OBSERVATION.json').write_bytes(encoded(report));return report


def execute_graph(task,actions,deadline,jobs):
    pending={s['id']:s for s in actions};completed={};failed={};active={}
    with ThreadPoolExecutor(max_workers=jobs)as pool:
        while pending or active:
            for key,step in list(pending.items()):
                if any(dep in failed for dep in step['depends']):
                    failed[key]=dict(id=key,native_started=False,kind='DEPENDENCY_FAILED');del pending[key]
            for key,step in list(pending.items()):
                if len(active)>=jobs:break
                if all(dep in completed for dep in step['depends']):
                    active[pool.submit(execute_stage,task,step,deadline)]=key;del pending[key]
            if not active:
                need(not pending,'Complete acyclic ready-task graph');break
            done,_=wait(active,return_when=FIRST_COMPLETED)
            for future in done:
                key=active.pop(future)
                try:completed[key]=future.result()
                except Exception as error:failed[key]=dict(id=key,native_started=True,kind=type(error).__name__,message=str(error))
    return completed,failed


def main():
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('mode',choices=['run']);parser.add_argument('--task',required=True)
    parser.add_argument('--deadline',type=int,required=True);parser.add_argument('--jobs',type=int,choices=range(1,10),default=5)
    args=parser.parse_args();before=verify_source();description=read(HERE/'POSITIVE39-DESCRIPTION.json')
    task=Path(args.task).absolute()
    need(not task.exists()and not task.is_relative_to(HERE)and time.time()<args.deadline,'Exclusive new conditional arithmetic task')
    task.mkdir(parents=True);shutil.copytree(HERE/'payload',task/'capsule')
    completed,failed=execute_graph(task,description['actions'],args.deadline,args.jobs)
    need(verify_source()==before,'Whole source closure unchanged after every original numerical program')
    report=dict(schema='be.positive39-complete-nine-original-program-observation/1',
        status='ALL_NINE_ORIGINAL_POSITIVE39_ACTIONS_COMPLETED_CONDITIONAL'if not failed else'INCOMPLETE_POSITIVE39_NUMERICAL_SLICE',
        n=39,K='741/4000',q='33/100',cap='2113/5000',completed=completed,failed=failed,
        source_before=before,source_after=before,original_native_calls=9,
        cached_sharp35_to39_COUNT_repeated=False,numerical_definitions_or_hypotheses_weakened=False,
        new_scalar_projection_from_current37_38_and_all_analytic_licenses_still_required=True,
        published_exact_Bernoulli_zero_noise_theorem_still_required=True,
        mathematical_acceptance=False,all_law_positive39_granted=False,full_proof_pass=False)
    (task/'RESULT.json').write_bytes(encoded(report))
    print(json.dumps(dict(status=report['status'],completed=len(completed),failed=len(failed),
                         result_sha256=digest(task/'RESULT.json')),sort_keys=True))
    need(not failed,'Original full numerical pipeline incomplete; genuine successful steps preserved')


if __name__=='__main__':main()
