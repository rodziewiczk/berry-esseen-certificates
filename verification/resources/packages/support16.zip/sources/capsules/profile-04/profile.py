"""Fixed same-law sharp31 ladder branch4; scalar predecessor conditional."""
from fractions import Fraction as F
import finite_binomial_core as g
BRANCH=4;N=31;K=F(0);Q=F('31/100');R=F('13/4');RHO_LO=F('7/5');RHO_HI=F('3/2');CAP=F('432313/1000000')
OWNCAP_RETAINED=F(432313,1000000)
def universal(r):
 return min(F(469,1000),F(1661,5000)*(1+F(429,1000)/r),F(3031,10000)*(1+F(323,500)/r))
T_FLOOR=universal(RHO_LO)
disc=g.root((2+RHO_HI*RHO_HI)**2-4*(1-RHO_HI*RHO_HI))[1]
BETA=g.root((disc-2-RHO_HI*RHO_HI)/2)[1]
PROFILE=dict(branch=BRANCH,n=N,K='0',allowance_kind='SAME_LAW_PREDECESSOR_SCORE_MIN_POSITIVE30_UNIVERSAL',scalar_premise='C30 < CE + 1/100',predecessor_universal_upper=str(T_FLOOR),predecessor_universal_formula='min(469/1000,(1661/5000)*(1+(429/1000)/rho),(3031/10000)*(1+(323/500)/rho))',rho_branch=[str(RHO_LO),str(RHO_HI)],contact_allowance=str(Q),R=str(R),rho_upper=str(RHO_HI),beta_interval=[str(-BETA),str(BETA)],own_cap_upper=str(CAP),retained_owncap_strict=str(OWNCAP_RETAINED))
SCOPE='Conditional support-ray theorem for the same actual attained positive-closed sharp31 witness in the literal rho branch. The contact allowance bounds31(C30(P)-C31)_+ from the smaller of the conditional global positive30 ceiling and the published universal predecessor bound at the same rho floor. Both full support rays and all thresholds; not a class-delta statement or a score exclusion.'
def check_profile():
 assert 1<=RHO_LO<RHO_HI and R>0
 assert Q==min(F(31,100),31*(T_FLOOR-F(819,2000)))and Q>0
 assert CAP==min(OWNCAP_RETAINED,T_FLOOR)
 assert 0<BETA<1 and (1+BETA*BETA)**2>RHO_HI*RHO_HI*(1-BETA*BETA)
 assert (3+g.root(F(10))[1])*g.PHI_HI/6+F(7,310)<OWNCAP_RETAINED
 # The numeric implication does not prove the retained a31<7/310 theorem.
 # T bounds the same marginal at index30 and index31; it is not inferred
 # from the sharp31 witness's own score cap. Each rational term decreases
 # in rho, hence T(rho)<=T(RHO_LO) on the literal branch.
