from fractions import Fraction as F
from hashlib import sha256
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
import finite_binomial_core as g
from independent_support34 import need,mul,add,divroot_interval,cdf,density,ray_gates
from profile import PROFILE,check_profile
PROFILES=[PROFILE]
assert __debug__ and not sys.flags.optimize and len(sys.argv)==1
check_profile()
def constants(n,K):
 c=F('.4095')+K/n;r=min(F('.3031')*F('.646')/(c-F('.3031')),F('.3322')*F('.429')/(c-F('.3322')))
 need(c<F('.469')and r>=1,'published moment domain')
 disc=g.root((2+r*r)**2-4*(1-r*r))[1];b=g.root((disc-2-r*r)/2)[1]
 need(0<b<1 and (1+b*b)**2>r*r*(1-b*b),'signed moment cap')
 S=g.root(F(n,n-1))[1];e=n*(S-1)-F(1,2)
 return c,r,b,S,e
def enclosure(n,a,b,R):
 z=divroot_interval(a,b,n);v=divroot_interval(a-R,b-R,n-1);ph=cdf(z);pv=cdf(v);nr=g.root(F(n))
 first=mul((n*nr[0],n*nr[1]),(pv[0]-ph[1],pv[1]-ph[0]))
 return add(first,mul((n*R+a*(R*R-1)/2,n*R+b*(R*R-1)/2),density(z)))
rows=[]
for prof in PROFILES:
 n=31;K=F(0);q=F(prof['contact_allowance']);R=F(prof['R'])
 c=F('.4095');r=F(prof['rho_upper']);disc=g.root((2+r*r)**2-4*(1-r*r))[1];b=g.root((disc-2-r*r)/2)[1]
 need(0<b<1 and (1+b*b)**2>r*r*(1-b*b),'independent same-law signed moment bound')
 S=g.root(F(n,n-1))[1];e=n*(S-1)-F(1,2);nr=g.root(F(n));vr=g.root(F(n-1));H0=F(35)
 need(H0>=5*nr[1]and H0-R>=5*vr[1],'full threshold tails')
 tail=n*nr[1]*g.TAIL+(n*R+H0*(R*R-1)/2)*density(divroot_interval(H0,H0,n))[1]
 # Check both complete rays and tails before any finite interval subdivision.
 ray_gates(R,q,c,r,b,S,e,tail,tail)
 Q=-R**3+F(3,2)*r*R*R+3*b*R+r*e;budget=-(c*Q+r*S*q)
 stack=[(-H0+F(j,4),-H0+F(j+1,4),0)for j in range(8*int(H0))]
 gp=gm=tail;leaves=0;depth=0;digest=sha256();length=F(0)
 while stack:
  a,z,dep=stack.pop();lo,hi=enclosure(n,a,z,R)
  if max(hi,-lo)<budget:
   gp=max(gp,hi);gm=max(gm,-lo);leaves+=1;depth=max(depth,dep);length+=z-a
   digest.update(('|'.join(map(str,(a,z,lo,hi)))+'\n').encode())
  else:
   need(dep<18,'unresolved natural interval cell');mid=(a+z)/2
   stack.append((a,mid,dep+1));stack.append((mid,z,dep+1))
 need(length==2*H0,'full measure from complete binary subdivision of every closed root')
 gates=ray_gates(R,q,c,r,b,S,e,gp,gm)
 row=dict(profile=prof,n=n,K=str(K),contact_allowance=str(q),R=str(R),H0=str(H0),closed_root_cells=8*int(H0),closed_leaves=leaves,maxdepth=depth,threshold_tails=2,support_rays=2,cell_sha256=digest.hexdigest(),ray_gates=gates)
 rows.append(row);print(json.dumps(dict(profile_pass=row)),flush=True)
controls=[]
for name,fn in [('false positive ray bound',lambda:ray_gates(R,q,c,r,b,S,e,F(100),gm)),('false negative ray bound',lambda:ray_gates(R,q,c,r,b,S,e,gp,F(100))),('negative decrement',lambda:ray_gates(R,-q,c,r,b,S,e,gp,gm))]:
 try:fn()
 except ValueError:controls.append(name)
 else:raise ValueError('negative control accepted '+name)
record=dict(schema='CONDITIONAL_SHARP31_LADDER_B4_INDEPENDENT_SUPPORT_V1',status='PASS_INDEPENDENT_SAME_LAW_SUPPORT',mathematical_status='Same-law conditional support implications only, not class delta bounds; this checker derives constants and uses direct natural H intervals, not Gaussian derivative/Hessian interpolation. Rational normal/root primitives are shared.',execution_status='Fresh exact adaptive complete binary covers plus both threshold/support tails',rows=rows,negative_controls=controls,runtime=dict(python=sys.version,implementation=sys.implementation.name,optimize=sys.flags.optimize),source_sha256={name:sha256((HERE/name).read_bytes()).hexdigest()for name in('independent.py','profile.py','finite_binomial_core.py','independent_support34.py')})
output=HERE/'INDEPENDENT_ACCEPTED.json';need(not output.exists(),'fresh independent support output');output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
