from pathlib import Path
from hashlib import sha256
import copy,json,sys
import direct_gaussian_support as d
from profile import N,K,Q,R,RHO_HI,BETA,PROFILE,check_profile,SCOPE
HERE=Path(__file__).resolve().parent
def need(value,message):
 if not value:raise ValueError(message)
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def unique(pairs):
 out={}
 for key,value in pairs:need(key not in out,'duplicate JSON key');out[key]=value
 return out
def digest(path):return sha256(path.read_bytes()).hexdigest()
def main():
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'ordinary exact acceptance')
 check_profile()
 proof=d.target(N,K,R,Q,rho=RHO_HI,beta_lower=-BETA,beta_upper=BETA)
 proof['scope']=SCOPE
 expected=dict(schema='CONDITIONAL_SHARP31_LADDER_B2_SUPPORT_V1',profile=PROFILE,proof=proof)
 path=HERE/'candidate.json';obj=json.loads(path.read_text(),object_pairs_hook=unique)
 def verify(x):need(same(x,expected),'fixed typed branch, same-law allowance and complete support proof')
 verify(obj);controls=[]
 def reject(name,change):
  x=copy.deepcopy(obj);change(x)
  try:verify(x)
  except ValueError:controls.append(name);return
  raise ValueError('accepted mutation '+name)
 reject('missing profile',lambda x:x.pop('profile'))
 reject('class delta relabeling',lambda x:x['profile'].update(allowance_kind='CLASS_DELTA'))
 reject('wrong predecessor',lambda x:x['profile'].update(scalar_premise='C29 < CE + 1/100'))
 reject('wrong rho floor',lambda x:x['profile']['rho_branch'].__setitem__(0,'0'))
 reject('wrong rho upper',lambda x:x['profile'].update(rho_upper='1'))
 reject('wrong contact allowance',lambda x:x['profile'].update(contact_allowance='0'))
 reject('wrong score cap',lambda x:x['profile'].update(own_cap_upper='2/5'))
 reject('wrong beta sign',lambda x:x['profile']['beta_interval'].__setitem__(0,'0'))
 reject('wrong radius',lambda x:x['profile'].update(R='1'))
 reject('boolean index',lambda x:x['profile'].update(n=True))
 reject('one support ray omitted',lambda x:x['proof']['ray_rows'].pop())
 reject('reordered rays',lambda x:x['proof']['ray_rows'].reverse())
 reject('threshold tail omitted',lambda x:x['proof']['gaussian'].update(H0='1'))
 reject('false cell cardinality',lambda x:x['proof']['gaussian'].update(cells=False))
 reject('false contact upper',lambda x:x['proof']['ray_rows'][0].update(contact_upper='0'))
 reject('extra field',lambda x:x.update(verified=True))
 try:json.loads('{"n":31,"n":30}',object_pairs_hook=unique)
 except ValueError:controls.append('duplicate JSON key')
 else:raise ValueError('duplicate key accepted')
 sources=('accept.py','profile.py','direct_gaussian_support.py','finite_binomial_core.py','small_index_support.py','heat_support50.py')
 record=dict(schema='CONDITIONAL_SHARP31_LADDER_B2_FIXED_SUPPORT_ACCEPTANCE_V1',status='PASS_FIXED_CONDITIONAL_SAME_LAW_SUPPORT',mathematical_status='Conditional full support exclusion under the literal rho branch, predecessor ceiling, own cap and retained contact/support analytic inputs. No sharp31 conclusion.',execution_status='Fresh rational all-threshold and both-full-ray replay plus17 negative controls',profile=PROFILE,candidate_sha256=digest(path),source_sha256={name:digest(HERE/name)for name in sources},threshold_cells=proof['gaussian']['cells'],negative_controls=controls,runtime=dict(python=sys.version,implementation=sys.implementation.name,optimize=sys.flags.optimize))
 output=HERE/'FIXED_ACCEPTED.json';need(not output.exists(),'fresh fixed acceptance output');output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
if __name__=='__main__':main()
