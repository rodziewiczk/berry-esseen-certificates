"""Fresh floor31 support:16 actual native processes,22 exact-input roles.

The three duplicate B5/B6/B7 directory pairs share identical complete inputs.
Aliases share one actual proof and never pretend another execution occurred.
Historical macOS capture joins and all402 cached COUNTs are outside this run.
"""
from pathlib import Path
from fractions import Fraction as F
from concurrent.futures import ThreadPoolExecutor, as_completed
from hashlib import sha256, file_digest
import argparse
import json
import re
import shutil
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent


def need(ok,message):
    if not ok:
        raise ValueError(message)


def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode('ascii')


def same(a,b):
    if type(a)is not type(b):return False
    if type(a)is dict:return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
    if type(a)is list:return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
    return a==b


def read(path):
    def unique(pairs):
        value={}
        for key,child in pairs:
            need(key not in value,'No duplicate JSON key');value[key]=child
        return value
    return json.loads(path.read_bytes(),object_pairs_hook=unique,
        parse_constant=lambda text:(_ for _ in()).throw(ValueError('Finite JSON')))


def digest(path):
    need(path.is_file()and not path.is_symlink(),'Ordinary complete source/evidence file')
    with path.open('rb')as stream:return file_digest(stream,'sha256').hexdigest()


def describe():
    d=read(HERE/'FLOOR31-SUPPORT-DESCRIPTION.json')
    need(d['schema']=='be.current3139-floor-support-slice/1'and len(d['cases'])==8
        and len(d['tasks'])==d['actual_native_calls']==16 and d['selected_roles']==22
        and d['COUNT_calls']==0 and d['historical_join_calls']==0,'Exact first support-only slice')
    roles=[r for t in d['tasks']for r in t['selected_roles']]
    need(len(roles)==len(set(roles))==22,'Each selected role appears exactly once')
    return d


def case_check(root,case):
    directory=root/case['relocated_cwd']
    pins={name:digest(directory/name)for name in case['input_pins']}
    need(same(pins,case['input_pins'])and sha256(encoded(pins)).hexdigest()==case['input_fingerprint'],
        'All eight source files and complete comparison candidate are immutable')
    candidate=read(directory/'candidate.json')
    profile=candidate['profile']
    need(same(profile,case['profile'])and type(profile['n'])is int and profile['n']==31
        and profile['K']=='0'and profile['scalar_premise']=='C30 < CE + 1/100',
        'Literal conditional scalar, actual index and whole rho/support profile')
    return directory,candidate


def readback(root,case,task):
    directory,candidate=case_check(root,case)
    receipt=read(directory/task['output'])
    need(set(receipt)==set(task['receipt_fields'])and receipt['schema']==task['receipt_schema']
        and receipt['status']==task['receipt_status']
        and receipt['mathematical_status']==task['mathematical_status']
        and receipt['execution_status']==task['execution_status']
        and same(receipt['negative_controls'],task['negative_controls']),
        'Whole exact native receipt schema, mathematical scope and all source controls')
    expected_sources={name:case['input_pins'][name]for name in task['source_roles']}
    need(same(receipt['source_sha256'],expected_sources),'Complete native checker/kernel/profile source binding')
    runtime=receipt['runtime']
    need(type(runtime)is dict and set(runtime)=={'python','implementation','optimize'}
        and runtime['python']==sys.version and runtime['implementation']=='cpython'
        and type(runtime['optimize'])is int and runtime['optimize']==0,
        'Actual current unoptimized interpreter, never an old runtime receipt')
    if task['kind']=='fixed':
        need(same(receipt['profile'],case['profile'])
            and receipt['candidate_sha256']==case['input_pins']['candidate.json']
            and type(receipt['threshold_cells'])is int
            and receipt['threshold_cells']==candidate['proof']['gaussian']['cells'],
            'Whole freshly recomputed fixed comparison candidate and threshold cover')
        rays=candidate['proof']['ray_rows']
        need(type(rays)is list and [r['sign']for r in rays]==[-1,1]
            and all(F(r['contact_upper'])<0 for r in rays),'Both complete fixed support rays')
    else:
        rows=receipt['rows'];need(type(rows)is list and len(rows)==1,'One complete independent profile')
        row=rows[0]
        need(same(row['profile'],case['profile'])and type(row['n'])is int and row['n']==31
            and row['K']=='0'and row['R']==case['profile']['R']
            and row['contact_allowance']==case['profile']['contact_allowance']
            and row['H0']=='35'and type(row['closed_root_cells'])is int and row['closed_root_cells']==280
            and type(row['closed_leaves'])is int and row['closed_leaves']>=280
            and type(row['maxdepth'])is int and 0<=row['maxdepth']<=18
            and type(row['threshold_tails'])is int and row['threshold_tails']==2
            and type(row['support_rays'])is int and row['support_rays']==2
            and type(row['cell_sha256'])is str and re.fullmatch('[0-9a-f]{64}',row['cell_sha256'])is not None,
            'Complete independent closed H cover, both threshold tails and both support rays')
        gates=row['ray_gates']
        need(set(gates)=={'Q','Q1','Q2','L','L1','negative_support_ray_upper','positive_support_ray_upper'}
            and all(type(v)is str and F(v)<0 for v in gates.values()),'All signed full-ray eligibility and contact gates')
    return receipt


def run_native(root,case,task,deadline):
    directory,candidate=case_check(root,case)
    output=directory/task['output'];need(not output.exists(),'Fresh native receipt; old PASS is not an input')
    stdout=directory/(task['id']+'.stdout');stderr=directory/(task['id']+'.stderr')
    need(not stdout.exists()and not stderr.exists()and time.time()<deadline,'Fresh bounded native output')
    argv=[sys.executable,'-E','-B','-S',str(directory/task['script'])]
    started=time.time();process=None
    try:
        with stdout.open('xb')as out,stderr.open('xb')as err:
            process=subprocess.Popen(argv,cwd=directory,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
            while process.poll()is None:
                need(time.time()<deadline,'Immutable native cutoff')
                need(stdout.stat().st_size+stderr.stat().st_size<=8*1024**2,'Finite native capture')
                time.sleep(.1)
            code=process.wait()
        need(code==0,'Original full support checker did not complete')
    finally:
        if process is not None and process.poll()is None:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
    receipt=readback(root,case,task)
    capture=stdout.read_text(encoding='utf-8')
    if task['kind']=='fixed':
        observed=json.loads(capture)
    else:
        lines=[line for line in capture.splitlines()if line.strip()]
        need(len(lines)==2,'Independent profile trace and full receipt capture')
        need(same(json.loads(lines[0]),dict(profile_pass=receipt['rows'][0])),'Entire independent profile in captured stdout')
        observed=json.loads(lines[-1])
    need(same(observed,receipt),'Whole native accepted object equals actual capture')
    result=dict(actual_executed_task=task['id'],selected_roles=task['selected_roles'],case_id=case['case_id'],
        input_fingerprint=case['input_fingerprint'],source_sha256=receipt['source_sha256'],
        receipt_sha256=digest(output),stdout_sha256=digest(stdout),stderr_sha256=digest(stderr),
        profile=case['profile'],negative_controls=receipt['negative_controls'],
        command=argv,actual_native_exit_code=code,seconds=time.time()-started,
        execution_shared=len(task['selected_roles'])>1,extra_execution_claimed=False,
        analytic_licenses_granted=False,all_index_full_pass=False)
    with (directory/(task['id']+'-CURRENT-COMPLETED.json')).open('xb')as stream:stream.write(encoded(result))
    return result


def prepare(source,task,d):
    need(not task.exists(),'Exclusive current support computation')
    root=task/'work';root.mkdir(parents=True)
    for case in d['cases']:
        case_check(source,case)
        dest=root/case['relocated_cwd'];dest.mkdir(parents=True)
        for name in case['input_pins']:shutil.copyfile(source/case['relocated_cwd']/name,dest/name)
        need(not(dest/'FIXED_ACCEPTED.json').exists()and not(dest/'INDEPENDENT_ACCEPTED.json').exists(),
            'No old mathematical receipts copied')
    return root


def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('action',choices=('qualify','run'))
    p.add_argument('--task',type=Path);p.add_argument('--deadline',type=float);p.add_argument('--jobs',type=int,default=8)
    a=p.parse_args();d=describe();source=HERE/'sources'
    if a.action=='qualify':
        for case in d['cases']:case_check(source,case)
        print(json.dumps(dict(status='FLOOR31_SUPPORT_SOURCE_QUALIFIED',unique_profiles=8,
            actual_native_calls=16,selected_roles=22,COUNT_calls=0,native_executions=0,full_proof_pass=False)),flush=True)
        return 0
    need(a.task is not None and a.deadline is not None and time.time()<a.deadline
        and type(a.jobs)is int and 1<=a.jobs<=16,'New task, fixed native cutoff and bounded concurrency')
    need(sys.platform=='linux'and sys.version_info[:2]==(3,12)and sys.dont_write_bytecode
        and not sys.flags.optimize,'Qualified unoptimized Linux CPython3.12 -B')
    root=prepare(source,a.task.resolve(),d);cases={c['case_id']:c for c in d['cases']}
    results=[];errors=[]
    with ThreadPoolExecutor(max_workers=a.jobs)as pool:
        futures={pool.submit(run_native,root,cases[t['case_id']],t,a.deadline):t for t in d['tasks']}
        for future in as_completed(futures):
            task=futures[future]
            try:results.append(future.result())
            except Exception as error:errors.append(dict(task_id=task['id'],selected_roles=task['selected_roles'],error=repr(error)))
    roles={role:dict(actual_executed_task=r['actual_executed_task'],receipt_sha256=r['receipt_sha256'],
        input_fingerprint=r['input_fingerprint'],explicit_same_input_alias=role!=r['actual_executed_task'])
        for r in results for role in r['selected_roles']}
    report=dict(schema='be.current-floor31-support-slice/1',
        status='CONDITIONAL_FLOOR31_SUPPORT_COMPLETE'if len(results)==16 and not errors else'FLOOR31_SUPPORT_INCOMPLETE',
        actual_native_accepts=len(results),selected_roles_completed=len(roles),roles=roles,results=results,errors=errors,
        COUNT_calls=0,legacy_capture_joins_run=0,analytic_licenses_granted=False,
        all_law_C31_granted=False,all_index_full_pass=False)
    with (a.task/'CURRENT-FLOOR31-SUPPORT-REPORT.json').open('xb')as stream:stream.write(encoded(report))
    print(json.dumps(report),flush=True)
    return 0 if len(results)==16 and not errors else 2


if __name__=='__main__':
    raise SystemExit(main())
