"""Only the two original62C interface calls missing their static manifests.

The eight successful acquisition calls are NOT repeated and are NOT inferred
from these interfaces. Their genuine old partial execution must be separately
interpreted in full before an aggregate ten-component mathematical claim.
Every original Python body and complete expected numerical output is unchanged.
"""
from pathlib import Path
from hashlib import file_digest
from concurrent.futures import ThreadPoolExecutor
import argparse, json, shutil, sys, time
import acquisition4042 as original

HERE = Path(__file__).resolve().parent


def source():
    rows = original.read(HERE / 'INTERFACE-RECOVERY-SOURCE-VERIFIED.json')['files']
    for name, pin in rows.items():
        original.need(original.digest(HERE / name) == pin, 'Every whole original source and both missing manifests: ' + name)
    return rows


def description():
    d = original.read(HERE / 'INTERFACE-RECOVERY-DESCRIPTION.json')
    original.need([s['id'] for s in d['actions']] == ['left-interface', 'central-interface'], 'Exactly the two original interface components')
    original.need(d['original_eight_acquisition_calls_repeated'] is False and len(d['original_eight_required_separately']) == 8,
                  'Eight original acquisition predicates remain separate actual inputs')
    return d


def qualify():
    before = source()
    d = description()
    # The original whole static source closure remains a component of this new
    # larger closure. This validates bytes only, never an old execution label.
    original.verify_source()
    for action in d['actions']:
        for name, pin in action['input_pins'].items():
            original.need(original.digest(HERE / 'payload' / name) == pin, 'Every original input, including the previously omitted manifest')
    original.need(source() == before, 'Whole qualification is read-only')
    return before, d


def run(task, deadline):
    before, d = qualify()
    task = Path(task).absolute()
    original.need(not task.exists() and not task.is_relative_to(HERE) and time.time() < deadline, 'Exclusive new two-component task before admitted horizon')
    task.mkdir(parents=True)
    shutil.copytree(HERE / 'payload', task / 'capsule')
    complete, failed = {}, {}
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [(s['id'], pool.submit(original.execute_stage, task, s, deadline)) for s in d['actions']]
        for key, future in futures:
            try:
                complete[key] = future.result()
            except Exception as error:
                failed[key] = dict(kind=type(error).__name__, message=str(error))
    original.need(source() == before, 'Original mathematical sources and whole source closure unchanged')
    report = dict(schema='be.current62c-two-original-interface-recovery/1',
        status='BOTH_ORIGINAL_INTERFACES_COMPLETED_CONDITIONAL' if not failed else 'INTERFACE_RECOVERY_INCOMPLETE',
        completed=complete, failed=failed, actual_native_calls=2, original_eight_acquisition_calls_repeated=False,
        original_eight_required_separately=d['original_eight_required_separately'],
        old_partial_run_is_not_relabelled_success=True, original_whole_programs_changed=False,
        source_before=before, source_after=before, full_ten_component_numerical_claim_granted=False,
        analytic_or_actual_law_claim_granted=False, mathematical_acceptance=False, full_proof_pass=False)
    (task / 'RESULT.json').write_bytes(original.encoded(report))
    return report


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('mode', choices=('qualify', 'run'))
    p.add_argument('--task', type=Path)
    p.add_argument('--deadline', type=int)
    a = p.parse_args()
    original.need(__debug__ and not sys.flags.optimize and sys.dont_write_bytecode, 'Ordinary exact no-bytecode interpreter')
    if a.mode == 'qualify':
        qualify()
        print(json.dumps(dict(source_qualified=True, native_calls=0, mathematical_acceptance=False)))
        return 0
    original.need(a.task is not None and type(a.deadline) is int, 'An exact exclusive task and absolute deadline')
    result = run(a.task, a.deadline)
    print(json.dumps(dict(status=result['status'], completed=len(result['completed']), failed=len(result['failed']),
                          result_sha256=original.digest(a.task / 'RESULT.json'))))
    return 0 if not result['failed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
