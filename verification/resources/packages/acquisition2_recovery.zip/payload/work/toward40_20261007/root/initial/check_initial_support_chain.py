"""Exact support implications for three NEW single-index candidate local contracts.
This does not assert that their acquisition or local comparisons are proved.
"""
from fractions import Fraction as F
import json,sys
import fifth_heat50 as h
assert __debug__ and not sys.flags.optimize and len(sys.argv)==1
contracts=[(40,F(0),F('.19')),(39,F(741,4000),F('.31')),(38,F(37639,78000),F('.4'))]
rows=[h.target(n,n,K,F('3.84'),q) for n,K,q in contracts]
for row,(n,K,q)in zip(rows,contracts):
 assert row['n_band']==[n,n] and F(row['barrier'])==K and F(row['slow'])==q
 assert row['closed_cells'][0][0]=='96/25' and row['closed_cells'][-1][1]=='9/2'
 assert all(a[1]==b[0] for a,b in zip(row['closed_cells'],row['closed_cells'][1:]))
for n,K,q in contracts:
 try:h.target(n,n,K,F('2.5'),q)
 except (AssertionError,ValueError):pass
 else:raise ValueError('false small support accepted')
print(json.dumps(dict(status='PASS_SINGLE_INDEX_40_39_38_SUPPORT_ONLY',rows=rows,negative_controls=3,mathematical_scope='Actual attained positive contact laws with n*a_n>=K and delta_n<=q have support in(-3.84,3.84); no full local comparison asserted.'),indent=2))
