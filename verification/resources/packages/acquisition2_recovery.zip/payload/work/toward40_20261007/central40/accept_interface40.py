"""Exact same-law source-to-comparison adapter for CENTRAL40; no arithmetic replay."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys,copy
import fixed_acceptance as fixed
ROOT=Path(__file__).resolve().parent
if not __debug__ or sys.flags.optimize:raise RuntimeError('Unoptimized Python required')
need=fixed.need
FILES=['confinement_candidate.json','profile_candidate.json','comparison_targets.json','comparison_profiles.json','COMPARISON_SOURCE.json','acquisition_manifest.json','confinement_manifest.json','profile_manifest.json','accept_interface40.py']
def hashes():return {f:sha256((ROOT/f).read_bytes()).hexdigest()for f in FILES}
def load(name):return json.loads((ROOT/name).read_text())
def check(src,prf,targets,profiles):
 need(src['schema']=='SINGLE40_CENTRAL_CONFINEMENT_V1'and src['N']==40,'single40 source scope')
 need(prf['schema']=='SINGLE40_CENTRAL_JOINT_PROFILES_V1'and prf['N']==40,'single40 profile scope')
 need(targets['N']==40 and profiles['N']==40,'comparison target index')
 need(len(src['rows'])==len(targets['rows'])==48,'48 closed probability cells')
 prof={(r['index'],r['sign'],r['band']):r for r in prf['rows']};tp={(r['index'],r['sign'],r['band']):r for r in profiles['rows']}
 need(len(prof)==len(prf['rows'])and len(tp)==len(profiles['rows']),'no duplicate sign/band cases')
 mp={'raw':'T','D':'D','theta':'theta','rho':'rho','beta':'beta_hi','inward_d_max':'d0','lambda_max':'lambda_max','Hminus':'H_minus','Hplus':'H_plus','amplitude':'amplitude'}
 expected=[];quadcount=0
 for i,(s,t)in enumerate(zip(src['rows'],targets['rows'])):
  p=[F(190+i,500),F(191+i,500)]
  need(s['index']==190+i and t['index']==i and [F(s['pl']),F(s['pu'])]==p and list(map(F,t['p']))==p,'same ordered actual probability cell')
  need(s['joint_inward_noise']is True,'same-law joint source')
  for a,b in mp.items():need(F(s[a])<=F(t[b]),f'upper resource dominance {i}:{a}')
  need(F(s['beta_lo'])>=F(t['beta_lo']),'lower beta dominance')
  need(F(s['lambda_max'])>0 and F(s['inward_d_max'])>0,'positive joint intercepts')
  need(len(s['quadratics'])==len(t['quadratics'])==4,'all coherent corners')
  for a,b in zip(s['quadratics'],t['quadratics']):
   for key in('A','Fminus','Fplus'):need(F(a[key])<=F(b[key]),'upper phase coefficient dominance');quadcount+=1
   need(F(a['Qbudget'])>=F(b['Qbudget'])>0,'lower phase curvature dominance');quadcount+=1
  for sign in(-1,1):
   for bi,(lo,hi)in enumerate([(F('.05'),F('.08')),(F('.08'),F('.10')),(F('.10'),F('.12')),(F('.12'),None)]):
    lam=F(s['lambda_max'])
    if lam<=lo:continue
    key=(s['index'],sign,bi);expected.append(key);need(key in prof,'entire actual noise cover')
    a=prof[key];high=lam if hi is None else min(lam,hi)
    need(list(map(F,a['noise']))==[lo,high],'closed actual noise endpoints')
    # This matches the selected comparison reader: the schedule is on the1/80 grid.
    amp=F(round(tp[key]['amplitude']*80),80)if key in tp else F(t['amplitude'])
    need(F(a['amplitude'])<=amp,'profile support dominance')
 need(expected==list(prof),'no extraneous or reordered profile rows')
 return dict(probability_cells=48,probability_domain=['19/50','119/250'],joint_profiles=len(expected),quadratic_coefficients=quadcount)
def main():
 frozen=load('interface_manifest.json');need(frozen==hashes(),'fixed interface input/source bytes')
 for c in('acquisition','confinement','profile'):fixed.verify_manifest(load(c+'_manifest.json'),c)
 for filename,b in load('COMPARISON_SOURCE.json').items():need(sha256((ROOT/filename).read_bytes()).hexdigest()==b['sha256'],'frozen comparison-copy integrity')
 src=load('confinement_candidate.json');prf=load('profile_candidate.json');tar=load('comparison_targets.json');pro=load('comparison_profiles.json');result=check(src,prf,tar,pro)
 controls=0
 def reject(s,p,t,q):
  nonlocal controls
  try:check(s,p,t,q)
  except(ValueError,AssertionError,KeyError,TypeError):controls+=1;return
  raise ValueError('mutated interface accepted')
 for mode in('N','missing','duplicate','reordered','theta','beta','Q','joint','noise','amplitude'):
  s,p,t,q=map(copy.deepcopy,(src,prf,tar,pro))
  if mode=='N':s['N']=41
  elif mode=='missing':s['rows'].pop()
  elif mode=='duplicate':p['rows'].append(p['rows'][0])
  elif mode=='reordered':s['rows'][0],s['rows'][1]=s['rows'][1],s['rows'][0]
  elif mode=='theta':s['rows'][0]['theta']='1'
  elif mode=='beta':s['rows'][0]['beta_lo']='-1'
  elif mode=='Q':s['rows'][0]['quadratics'][0]['Qbudget']='0'
  elif mode=='joint':s['rows'][0]['joint_inward_noise']=False
  elif mode=='noise':p['rows'][0]['noise'][0]='51/1000'
  else:p['rows'][0]['amplitude']='1'
  reject(s,p,t,q)
 need(frozen==hashes(),'unchanged bytes after controls')
 print(json.dumps(dict(status='PASS_SINGLE40_CENTRAL_LOCAL_INTERFACE',**result,negative_controls=controls,arithmetic_replay='separate source-bound component runs required')),flush=True)
if __name__=='__main__':main()
