"""Exact polynomial algebra for the finite Gaussian contact theorem."""
from fractions import Fraction as F
from math import comb, factorial
import json

def add(p,q):
    out=dict(p)
    for a,c in q.items(): out[a]=out.get(a,F(0))+c
    return {a:c for a,c in out.items() if c}

def scale(p,c): return {a:v*c for a,v in p.items() if v*c}

def coefficient(j):
    """Coefficient P_j in H_n/phi(0)=sum z^j P_j(H,t)."""
    p={}
    for k in range(j+2):
        v=F((-1)**k,2**k*factorial(k)*(2*k+1))
        for i in range(j+1-k): v*=F(2*k+1+2*i,2*(i+1))
        m=2*k+1
        p=add(p,{(m-b,b):v*comb(m,b)*(-1)**b for b in range(m+1)})
    p=add(p,{(2*j+3,0):-F((-1)**(j+1),2**(j+1)*factorial(j+1)*(2*j+3)),
             (2*j+2,1):F((-1)**(j+1),2**(j+1)*factorial(j+1)),
             (2*j+1,2):F((-1)**j,2**(j+1)*factorial(j)),
             (2*j+1,0):-F((-1)**j,2**(j+1)*factorial(j))})
    return p

def bernstein(p,x,y):
    dx=max((a for a,b in p),default=0);dy=max((b for a,b in p),default=0)
    lx,hx=x;ly,hy=y;wx=hx-lx;wy=hy-ly
    q={}
    for (a,b),c in p.items():
        for i in range(a+1):
            for j in range(b+1):
                q[i,j]=q.get((i,j),F(0))+c*comb(a,i)*comb(b,j)*lx**(a-i)*ly**(b-j)*wx**i*wy**j
    return [sum(c*F(comb(k,i),comb(dx,i))*F(comb(l,j),comb(dy,j))
                for (i,j),c in q.items() if i<=k and j<=l)
            for k in range(dx+1) for l in range(dy+1)]

