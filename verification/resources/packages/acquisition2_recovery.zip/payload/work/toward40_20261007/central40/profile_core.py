"""Exact N40 conditional amplitude profiles using one joint moment resource."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
import confinement_core as conf
need=conf.need;enc=conf.enc;decode=conf.decode
BANDS=[(F('.05'),F('.08')),(F('.08'),F('.10')),(F('.10'),F('.12')),(F('.12'),None)]
def build(emit=False):
 blob=Path('confinement_candidate.json').read_bytes();src=decode(json.loads(blob));pb=Path('profile_plan.json').read_bytes();plan=decode(json.loads(pb))
 need(src['schema']=='SINGLE40_CENTRAL_CONFINEMENT_V1'and src['N']==40 and len(src['rows'])==48,'full central source')
 need(plan['schema']=='SINGLE40_SELECTED_PROFILE_PLAN_V1','named profile plan')
 expected=[];result=[];lookup={(p['index'],p['sign'],p['band']):p for p in plan['rows']}
 need(len(lookup)==len(plan['rows']),'unique plan rows')
 for z in src['rows']:
  for sign in(-1,1):
   for bi,(lo,hi)in enumerate(BANDS):
    lam=z['lambda_max']
    if lam<=lo:continue
    key=(z['index'],sign,bi);expected.append(key);need(key in lookup,'every nonempty noise band planned');p=lookup[key]
    high=lam if hi is None else min(lam,hi);amp=p['amplitude']
    row=dict(index=z['index'],sign=sign,band=bi,noise=[lo,high],amplitude=amp)
    if p.get('inherited'):
     need(z['amplitude']<=amp,'inherited support dominance');row['proof']=dict(inherited=True,amplitude=z['amplitude'])
    else:
     need(0<amp<z['amplitude'],'strict profile support improvement')
     config=conf.cfg(z,sign,amp,z['amplitude'],lo,high,joint=True,hc=p['hc'],lc=p['lc'],buffer=p['buffer'])
     row['proof']=conf.evaluate(config)
    result.append(row)
    if emit:print('EXACT_CENTRAL40_PROFILE',z['index'],sign,bi,'INHERITED'if p.get('inherited')else'PASS',flush=True)
  if emit:Path('profile_progress.json').write_text(json.dumps(enc(dict(rows=result)),indent=2)+'\n')
 need(expected==list(lookup),'exact ordered phase/noise plan cover')
 return dict(schema='SINGLE40_CENTRAL_JOINT_PROFILES_V1',N=40,source_sha256=sha256(blob).hexdigest(),plan_sha256=sha256(pb).hexdigest(),schedule=[[lo,hi]for lo,hi in BANDS],rows=result)
