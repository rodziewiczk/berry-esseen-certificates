"""N40 closed Sperner boxes, followed by actual-radius coupled feedback."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
import acquisition_core as acq
import sperner_kernel as sp
need=acq.need;enc=acq.enc;decode=acq.decode
N=40
def cfg(z,sign,amp,strip,lo=F(0),hi=None,joint=False,hc=32,lc=32,buffer=F(5,12)):
 need(sign in(-1,1),'signed phase')
 lam=z['lambda_max'];hi=lam if hi is None else hi
 need(0<=lo<hi<=lam,'closed nonempty noise band')
 d0=z['inward_d_max']
 if joint:
  need(z['joint_inward_noise']is True,'same-law joint intercept source');d0*=1-lo/lam
 return dict(N=N,T=z['raw'],D=z['D'],theta=z['theta'],d0=d0,H=z['Hminus'if sign<0 else'Hplus'],C=F('.4253'),rho=z['rho'],beta_lo=z['beta_lo'],beta_hi=z['beta'],amplitude=amp,maxnoise=hi,lower_buffer=amp*buffer,upper_buffer=amp*F(7,15),eta=F('.00001'),phase_sign=sign,noise_min=lo,strip=strip,rebate=F(0),fd=sp.rootup(max(F(N,N-1)**3,F(N,N-2))),third=F(24),pc=1,hc=hc,lc=lc,pl=z['pl'],pu=z['pu'],raw_quads=[(q['A'],q['Fminus'if sign<0 else'Fplus'],q['Qbudget'])for q in z['quadratics']])
def evaluate(config):
 r=sp.evaluate(config)
 need(all(v>0 for v in r['gates'].values()),('strict confinement gates',[(k,str(v))for k,v in r['gates'].items()if v<=0][:3]))
 expected={f'{p}:{h}:{l}'for p in range(config['pc'])for h in range(config['hc'])for l in range(config['lc'])}
 keys=[q[0]for q in r['empty']]+r['feasible']
 need(len(keys)==len(set(keys))and set(keys)==expected,'complete closed phase/noise boxes')
 raw=json.dumps(enc(r),sort_keys=True,separators=(',',':')).encode()
 return dict(gates=len(r['gates']),excluded=len(r['empty']),feasible=len(r['feasible']),minimum_confinement=min((v for k,v in r['gates'].items()if k.startswith('confinement_')),default=None),entire_domain_excluded=not r['feasible'],arithmetic_sha256=sha256(raw).hexdigest())
def build(emit=False):
 blob=Path('acquisition_candidate.json').read_bytes();src=decode(json.loads(blob));pb=Path('confinement_plan.json').read_bytes();plan=decode(json.loads(pb))
 need(src['schema']=='SINGLE40_CENTRAL_UPPER_ACQUISITION_V1'and src['N']==40 and len(src['fine'])==50,'full source acquisition')
 need(plan['schema']=='SINGLE40_SELECTED_CONFINEMENT_PLAN_V1'and len(plan['rows'])==48,'selected ordered first48 rows')
 rows=[]
 for i,z in enumerate(src['fine']):
  if z.get('excluded'):
   need(i>=48,'selected fine exclusion only at upper two cells');continue
  p=plan['rows'][i];need(p['index']==z['index']and p['p']==[z['pl'],z['pu']],'same source probability cell')
  strip=F('.55');steps=[]
  for amp in p['amplitudes']:
   need(0<amp<=F('.425')and amp<strip,'strict selected support improvement')
   proof=[evaluate(cfg(z,s,amp,strip,hc=plan['hc'],lc=plan['lc']))for s in(-1,1)]
   R=acq.c.k.up(max(z['pu']+amp,1-z['pl']+amp)/acq.c.k.roots(z['pl']*(1-z['pl']))[0],10000)+F(1,10000)
   q=acq.bounded(acq.c.cell(40,R,F('.4226'),z,steps=64));need(not q.get('excluded'),'selected feedback survivor')
   q.update(index=z['index'],amplitude=amp,radius=R)
   steps.append(dict(amplitude=amp,radius=R,proof=proof));z=q;strip=amp
  # The final acquired support remains valid for further coupled iterations.
  q=acq.bounded(acq.c.cell(40,z['radius'],F('.4226'),z,steps=64));need(not q.get('excluded'),'selected final feedback survivor')
  q.update(index=z['index'],amplitude=z['amplitude'],radius=z['radius'],confinement_proof=steps);rows.append(q)
  if emit:
   print('EXACT_CENTRAL40_CONFINEMENT',q['index'],enc({k:q[k]for k in('amplitude','raw','D','theta','lambda_max','inward_d_max')}),flush=True)
   Path('confinement_progress.json').write_text(json.dumps(enc(dict(rows=rows)),indent=2)+'\n')
 need(len(rows)==48 and [z['index']for z in rows]==list(range(190,238)),'complete central48 cover')
 return dict(schema='SINGLE40_CENTRAL_CONFINEMENT_V1',N=40,source_sha256=sha256(blob).hexdigest(),plan_sha256=sha256(pb).hexdigest(),rows=rows)
