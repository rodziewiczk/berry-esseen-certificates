import sys
from fixed_acceptance import run
if len(sys.argv)!=2:raise ValueError('component required')
run(sys.argv[1])
