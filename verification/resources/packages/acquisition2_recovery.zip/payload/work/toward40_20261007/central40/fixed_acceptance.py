"""Source-bound fixed replay and fail-closed malformed-proof controls."""
from pathlib import Path
from hashlib import sha256
import importlib,json,sys,copy
ROOT=Path(__file__).resolve().parent
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
SOURCES=['acquisition_core.py','candidate_panel40.py','contracted_kernel.py','kernel.py','corrected_phase_callback_extended.py','high_window_core.py','paired_extended.py','paired_conditional_gamma47.py','signed_variance_resource.py','panel_exterior40.py','gaussian_core.py','sperner_kernel.py','confinement_core.py','profile_core.py','fixed_acceptance.py','accept40.py']
COMPONENTS={'acquisition':('acquisition_core','acquisition_candidate.json',['initial40_candidate.json']),'confinement':('confinement_core','confinement_candidate.json',['acquisition_candidate.json','confinement_plan.json']),'profile':('profile_core','profile_candidate.json',['confinement_candidate.json','profile_plan.json'])}
def need(v,s):
 if not v:raise ValueError(s)
def digest(name):return sha256((ROOT/name).read_bytes()).hexdigest()
def manifest(component):
 mod,proof,inputs=COMPONENTS[component]
 return dict(schema='SINGLE40_CENTRAL_FIXED_MANIFEST_V1',component=component,sources={n:digest(n)for n in SOURCES},proof={proof:digest(proof)},inputs={n:digest(n)for n in inputs})
def verify_manifest(m,component):
 need(m==manifest(component),'exact source/object/input binding')
def check_object(candidate,expected):
 need(type(candidate)is dict and candidate==expected,'complete fixed route exact equality')
def run(component):
 module,proof,_=COMPONENTS[component]
 frozen=json.loads((ROOT/(component+'_manifest.json')).read_text());verify_manifest(frozen,component)
 mod=importlib.import_module(module);candidate=json.loads((ROOT/proof).read_text());expected=mod.enc(mod.build(True));check_object(candidate,expected)
 controls=0
 def rejects(fn):
  nonlocal controls
  try:fn()
  except(ValueError,AssertionError,TypeError,KeyError):controls+=1;return
  raise ValueError('negative control accepted')
 for mut in [None,[],{},dict(candidate,N=41),dict(candidate,schema='OTHER'),dict(candidate,source_sha256='0'*64)]:
  rejects(lambda mut=mut:check_object(mut,expected))
 key='fine'if component=='acquisition'else'rows'
 for mode in('missing','duplicate','reordered','corrupt'):
  v=copy.deepcopy(candidate)
  if mode=='missing':v[key]=v[key][:-1]
  elif mode=='duplicate':v[key].append(v[key][0])
  elif mode=='reordered':v[key][0],v[key][1]=v[key][1],v[key][0]
  else:v[key][0]['index']=-1
  rejects(lambda v=v:check_object(v,expected))
 for group in('sources','proof','inputs'):
  v=copy.deepcopy(frozen);v[group][next(iter(v[group]))]='0'*64
  rejects(lambda v=v:verify_manifest(v,component))
 verify_manifest(frozen,component)
 print(json.dumps(dict(status='PASS_SINGLE40_CENTRAL_'+component.upper(),proof_sha256=digest(proof),source_manifest_sha256=digest(component+'_manifest.json'),negative_controls=controls,retained_dependency='INITIAL40 and mathematical reductions require separate acceptance/review')),flush=True)
