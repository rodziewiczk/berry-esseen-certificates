"""New signed fifth-order heat bound; discovery/acceptance kernel.

The favorable fifth derivative uses the upper index endpoint, so no
unproved all-n monotonicity is invoked. Infinity is represented by last=0.
"""
from fractions import Fraction as F
from hashlib import sha256
import json
import heat_support50 as H

def data(N,last,K):
    if K:assert last>=N
    elif last:assert last>=N
    c,r,b,ell,S=H.constants(N,last or N,K)
    v=N-1;A=H.A;J=H.trim([0,-15,0,0,0,1]);H4=H.H4
    DU=H.scale(J,F(1,120*v))
    DL=H.scale(J,F(1,120*(last-1))) if last else [F(0)]
    W=H.add(A,H.scale(DU,F(-15,2)))
    E=H.add(H.scale([0,0,0,0,0,0,1],F(51,14400*v)/ell),
            H.scale([-2,0,3],F(51,960*v)/ell),[0,F(1,8*v*v)])
    B2=H.scale(H.mul(H4,H4),F(1,256*v))
    Numer=H.add(H.mul(H.add(A,H.scale(DL,-3)),W),B2)
    Dom=H.add(H.mul(H.add(H.scale(A,F(1,2)),H.scale(DL,-3),H.scale(DU,-3),H.scale(H4,F(-1,12)/ell)),W),B2)
    Q=[r*H.EC/N,3*b,F(3,2)*r,-1]
    PA0=H.add(H.scale(Numer,F(2,5)*S**3),H.scale(H.mul(E,W),S**3),H.mul(H.scale(Q,c),W))
    PAq=H.scale(W,r*S)
    ray0=H.add([F(1,2),F(1,5),0,F(1,15)],H.scale(Q,c))
    return dict(c=c,r=r,b=b,S=S,J=J,W=W,Dom=Dom,Q=Q,PA0=PA0,PAq=PAq,ray0=ray0)

def target(N,last,K,R,q):
    assert F('2.5')<=R<F('4.5') and q>=0
    p=data(N,last,K);PA=H.add(p['PA0'],H.scale(p['PAq'],q));rows=[];gates=[];l=R
    while l<F('4.5'):
        h=min(F('4.5'),l+F(1,20))
        for name,a in [('A',H.A),('H4',H.H4),('J',p['J']),('W',p['W']),('outer_domination',p['Dom']),('negative_C',H.scale(p['Q'],-1)),('contact',H.scale(PA,-1))]:
            bs=H.bern(a,l,h)
            if min(bs)<=0:raise ValueError((name,N,last,str(K),str(R),str(q),str(l),str(min(bs))))
            gates.extend((name,str(z))for z in bs)
        rows.append([str(l),str(h)]);l=h
    for name,a in [('coefficient_ray',p['Q']),('contact_ray',H.add(p['ray0'],[p['r']*p['S']*q]))]:
        for j in range(4):
            z=-H.val(a,F('4.5'))
            if z<=0:raise ValueError((name,j,str(z)))
            gates.append((name+str(j),str(z)));a=H.deriv(a)
    return dict(n_band=[N,last or None],barrier=str(K),radius=str(R),slow=str(q),
                current_score_lower=str(p['c']),rho_upper=str(p['r']),beta_absolute_upper=str(p['b']),
                scale_coefficient=str(H.EC),scale_positive_gate=str(H.scale_gate(N)),closed_cells=rows,
                gates=len(gates),minimum_contact=str(min(F(x)for name,x in gates if name=='contact')),
                gate_sha256=sha256(json.dumps(gates,separators=(',',':')).encode()).hexdigest())

def discovered_slow_ceiling(N,last,K,R):
    p=data(N,last,K);bounds=[];l=R
    while l<F('4.5'):
        h=min(F('4.5'),l+F(1,20))
        for name,a in [('A',H.A),('H4',H.H4),('J',p['J']),('W',p['W']),('outer_domination',p['Dom']),('negative_C',H.scale(p['Q'],-1))]:
            if min(H.bern(a,l,h))<=0:raise ValueError((name,str(l)))
        aa=H.bern(p['PA0'],l,h);bb=H.bern(p['PAq']+[F(0)]*(len(p['PA0'])-len(p['PAq'])),l,h)
        assert all(x>0 for x in bb)
        bounds.extend(-a/b for a,b in zip(aa,bb));l=h
    for a in [p['Q'],H.deriv(p['ray0'])]:
        while True:
            assert H.val(a,F('4.5'))<0
            if len(a)==1:break
            a=H.deriv(a)
    bounds.append(-H.val(p['ray0'],F('4.5'))/(p['r']*p['S']))
    return min(bounds)
