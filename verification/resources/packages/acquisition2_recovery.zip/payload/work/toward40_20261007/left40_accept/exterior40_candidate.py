"""New single-index40 conditional exterior candidate; unchanged generic finite heat formula.

Panel hypotheses are rounded from discovery, not proved by this program.
Every output is conditional until a separate entry acceptance acquires them.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import hashlib, json, sys
from gaussian_core import coefficient, bernstein

assert __debug__ and not sys.flags.optimize
POLYS = [coefficient(j) for j in range(6)]
N = 40
QDEC = F('.19')


def down(x, scale=10**6):
    x = F(str(x)); return F(x.numerator*scale//x.denominator, scale)


def up(x, scale=10**6):
    return -down(-F(str(x)), scale)


def root(x, upper=False):
    scale = 10**8
    a = isqrt(x.numerator*scale*scale//x.denominator)
    return F(a+int(upper), scale)


def tail(h,r):
    e = F(193,71)
    ceil = lambda x: -((-x.numerator)//x.denominator)
    return 4**7*((h+r)*F(7,6)*e**ceil((h+r)**2/6)
           +(h+r+h*(r*r+1)/8)*e**ceil(h*h/8))


def support_cell(h,rho,bl,bu,l,r):
    """Upper bound on the full contact expression for a standardized x-cell."""
    radius = max(abs(l),abs(r))
    ms = [max(F(0), max(max(bernstein(POLYS[j],(F(a)*h,F(a+1)*h),(l,r))) for a in (-1,0)))
          for j in range(1,4)]
    ms += [sum(abs(c)*h**a*radius**b for (a,b),c in POLYS[j].items())
           for j in (4,5)]
    error = F('.4')*(sum(ms[j-1]/N**j for j in range(1,6))
                      +tail(h,radius)/N**6)
    if l >= 0:
        lp = {(0,3):F(1,15)-F('.4095'),
              (0,2):F('1.5')*F('.40974')*rho,
              (0,1):3*F('.40974')*bu-F('.3988')/2}
        q = {(0,3):F(-1),(0,2):F('1.5')*rho,(0,1):3*bu}
        ll,rr = l,r
    else:
        lp = {(0,3):-F('.3988')/6-F('.4095'),
              (0,2):F('1.5')*F('.40974')*rho,
              (0,1):F('.2')-3*F('.4095')*bl}
        q = {(0,3):F(-1),(0,2):F('1.5')*rho,(0,1):-3*bl}
        ll,rr = -r,-l
    lpu = max(bernstein(lp,(F(0),F(0)),(ll,rr)))
    qu = max(F(0),max(bernstein(q,(F(0),F(0)),(ll,rr))))
    return lpu+F('.54')*qu/N+error+rho*(root(F(N,N-1),True)*QDEC
                                          +F('.384')*F('.4226')/N)


def from_hypotheses(hyp,strip=F('.55')):
    pl,pu=map(F,hyp['p'])
    th,rho=F(hyp['theta']),F(hyp['rho'])
    bu=F(hyp['beta_upper']);h=F(hyp['H'])
    assert 0<pl<=pu<F('.5') and 0<=th<1 and 1<=rho<=F('1.85')
    assert 0<h<=2 and 0<strip<1
    # beta=(1-theta)(1-2p)+kappa, |kappa|<=theta.
    bl=(1-th)*(1-2*pu)-th
    assert 0<=bl<=bu<1
    ell=root((1-th)/(pu*(1-pu)))
    starts=[(-1,ell*(strip+pl)),(1,ell*(1+strip-pu))]
    rows=[]
    for sign,start in starts:
        finish=F(hyp['radius'])
        if start>finish:
            continue
        count=max(1,int((finish-start)*80)+1)
        for j in range(count):
            a=start+(finish-start)*F(j,count)
            b=start+(finish-start)*F(j+1,count)
            l,r=(a,b)if sign>0 else(-b,-a)
            value=support_cell(h,rho,bl,bu,l,r)
            rows.append(dict(sign=sign,interval=[str(l),str(r)],upper=str(value)))
    assert rows
    return dict(hypotheses=dict(p=[str(pl),str(pu)],theta=str(th),rho=str(rho),
            beta=[str(bl),str(bu)],H=str(h),prior_support='[-'+hyp['radius']+','+hyp['radius']+']',
            decrement='19/100',excess_ceiling='0 <= a_n <= .54/n',n_floor=N,n_ceiling=48,
            contact='actual attained positive closed contact inequality'),
            conclusion='support(Y) subset (-'+str(strip)+',1+'+str(strip)+')',
            worst=max(rows,key=lambda q:F(q['upper'])),rows=rows)


def panel(z,strip=F('.55')):
    inp=z['input'];last=z['trace'][-1]
    corners=z['raw_quadratics']
    return from_hypotheses(dict(p=[str(down(inp['pl'])),str(up(inp['pu']))],
         theta=str(up(last['theta'])),rho=str(up(last['rho'])),
         beta_upper=str(up(last['beta'])),
         H=str(up(max(max(q['Hplus'],q['Hminus'])for q in corners)))),strip)


if __name__=='__main__':
    source=Path(sys.argv[1]);outpath=Path(sys.argv[2])
    assert not outpath.exists()
    data=json.loads(source.read_text())
    results=[panel(z)for z in data['panels'] if not z['trace'][-1].get('excluded')]
    bad=[i for i,z in enumerate(results)if F(z['worst']['upper'])>=0]
    obj=dict(status='EXACT_CONDITIONAL_DISCOVERY',
       entry_status='Floating discovery only: these hypotheses are NOT acquired.',
       source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
       source=str(source),results=results,bad=bad,
       cells=sum(len(z['rows'])for z in results))
    outpath.write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps(dict(status=obj['status'],panels=len(results),bad=bad,
         cells=obj['cells'],worst=float(max(F(z['worst']['upper'])for z in results)))))
