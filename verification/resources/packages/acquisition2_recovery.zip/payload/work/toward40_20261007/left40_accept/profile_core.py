"""Exact coherent-noise indexed LEFT profiles, with conditional theta."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
import confinement_core as c
need=c.need;enc=c.enc;dec=c.dec
SCHEDULE=[(F('.05'),F('.08'),F('.45')),(F('.08'),F('.10'),F('.40')),(F('.10'),F('.12'),F('.35')),(F('.12'),F('.125'),F('.3125')),(F('.125'),None,F('.30'))]
def build(emit=False):
 blob=Path('indexed_confinement_candidate.json').read_bytes();src=dec(json.loads(blob));pb=Path('profile_plan.json').read_bytes();plan=dec(json.loads(pb))
 need(src['schema']=='INDEXED40_42_LEFT_CONFINEMENT_V1'and len(src['rows'])==49,'complete indexed source')
 need(plan['schema']=='INDEXED40_42_LEFT_PROFILE_PLAN_V1'and plan['schedule']==[list(v)for v in SCHEDULE]and len(plan['rows'])==245,'complete fixed amplitude schedule')
 need(plan['subcells']==32 and plan['hc']==32,'fixed coherent partition')
 rows=[]
 for i,z in enumerate(src['rows']):
  need(z['index']==141+i,'ordered source probability cells')
  for bi,(lo,end,advertised)in enumerate(SCHEDULE):
   p=plan['rows'][5*i+bi];need(p['index']==z['index']and p['band']==bi,'ordered profile plan')
   lam=z['lambda_max'];amp=p['amplitude'];need(amp<=advertised and amp<=z['amplitude'],'selected support target')
   rec=dict(index=z['index'],band=bi,amplitude=amp,source_noise_ceiling=lam)
   if lam<=lo:
    need(p.get('expected_empty')is True,'explicit empty band status');rec.update(empty=True,noise=None)
   else:
    need(not p.get('expected_empty'),'selected nonempty band');high=lam if end is None else min(end,lam);rec['noise']=[lo,high]
    if p.get('inherited'):
     need(z['amplitude']<=amp,'inherited amplitude');rec['proof']=dict(inherited=True,amplitude=z['amplitude'])
    else:
     need(0<amp<z['amplitude'],'strict profile improvement');proofs=[]
     for sign in(-1,1):
      for si in range(32):
       a=lo+(high-lo)*F(si,32);b=lo+(high-lo)*F(si+1,32)
       cfg=c.cfg(z,sign,amp,z['amplitude'],a,b,joint=True,coherent_theta=True,hc=32,lc=1,buffer=p['buffer'])
       proof=c.evaluate(cfg);proofs.append(dict(sign=sign,subcell=si,noise=[a,b],theta=cfg['theta'],d0=cfg['d0'],proof=proof))
     need(len(proofs)==64,'both signs and32 closed noise cells');rec['proof']=dict(coherent_noise=True,subcells=proofs)
   rows.append(rec)
   if emit:print('EXACT_INDEXED40_PROFILE',z['index'],bi,'EMPTY'if rec.get('empty')else'INHERITED'if rec['proof'].get('inherited')else'PASS',flush=True)
  if emit:Path('indexed_profile_progress.json').write_text(json.dumps(enc(dict(rows=rows)),indent=2)+'\n')
 return dict(schema='INDEXED40_42_LEFT_PROFILES_V1',N=40,indexed_premise=src['indexed_premise'],source_sha256=sha256(blob).hexdigest(),plan_sha256=sha256(pb).hexdigest(),schedule=[list(v)for v in SCHEDULE],rows=rows)
