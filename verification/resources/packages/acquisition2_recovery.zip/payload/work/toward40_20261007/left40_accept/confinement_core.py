"""Exact indexed40..42 LEFT Sperner confinement and same-law feedback."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
import acquisition_core as acq
import sperner40_kernel as sp
need=acq.need;enc=acq.enc;dec=acq.dec
N=40
def cfg(z,sign,amp,strip,lo=F(0),hi=None,joint=False,coherent_theta=False,hc=24,lc=24,buffer=F(5,12)):
 lam=z['lambda_max'];hi=lam if hi is None else hi
 need(sign in(-1,1)and 0<=lo<hi<=lam,'closed signed phase/noise cell')
 theta=z['theta'];d0=z['inward_d_max']
 if joint:
  need(z['joint_inward_noise']is True,'same-law joint source');d0*=1-lo/lam
 if coherent_theta:
  vmin=min(z['pl']*(1-z['pl']),z['pu']*(1-z['pu']));need(vmin>0,'probability variance divisor')
  theta=min(theta,hi/(40*vmin+hi))
 return dict(N=40,T=z['raw'],D=z['D'],theta=theta,d0=d0,H=z['Hminus'if sign<0 else'Hplus'],C=F('.4253'),rho=z['rho'],beta_lo=z['beta_lo'],beta_hi=z['beta'],amplitude=amp,maxnoise=hi,lower_buffer=amp*buffer,upper_buffer=amp*F(7,15),eta=F('.00001'),phase_sign=sign,noise_min=lo,strip=strip,rebate=F(0),fd=sp.rootup(max(F(40,39)**3,F(40,38))),third=F(30),pc=1,hc=hc,lc=lc,pl=z['pl'],pu=z['pu'],raw_quads=[(q['A'],q['Fminus'if sign<0 else'Fplus'],q['Qbudget'])for q in z['quadratics']])
def evaluate(config):
 z=sp.evaluate(config);need(all(v>0 for v in z['gates'].values()),('strict Sperner gate',[(k,str(v))for k,v in z['gates'].items()if v<=0][:3]))
 expected={f'{p}:{h}:{l}'for p in range(config['pc'])for h in range(config['hc'])for l in range(config['lc'])};keys=[v[0]for v in z['empty']]+z['feasible']
 need(len(keys)==len(set(keys))and set(keys)==expected,'complete closed H/noise partition')
 raw=json.dumps(enc(z),sort_keys=True,separators=(',',':')).encode()
 return dict(gates=len(z['gates']),excluded=len(z['empty']),feasible=len(z['feasible']),minimum_confinement=min((v for k,v in z['gates'].items()if k.startswith('confinement_')),default=None),entire_domain_excluded=not z['feasible'],arithmetic_sha256=sha256(raw).hexdigest())
def build(emit=False):
 blob=Path('indexed_acquisition_candidate.json').read_bytes();src=dec(json.loads(blob));pb=Path('confinement_plan.json').read_bytes();plan=dec(json.loads(pb))
 need(src['schema']=='INDEXED40_42_LEFT_ACQUISITION_V1'and src['N']==40 and len(src['rows'])==49,'complete indexed source')
 need(plan['schema']=='INDEXED40_42_LEFT_CONFINEMENT_PLAN_V1'and len(plan['rows'])==49,'fixed49 plans')
 rows=[]
 for i,original in enumerate(src['rows']):
  z=original;p=plan['rows'][i];need(z['index']==p['index']==141+i and [z['pl'],z['pu']]==p['p'],'same source probability cell')
  strip=z['strip'];steps=[]
  for amp in p['amplitudes']:
   need(0<amp<strip and amp<=F('.6'),'strict support contraction')
   proof=[evaluate(cfg(z,sign,amp,strip,hc=plan['hc'],lc=plan['lc']))for sign in(-1,1)]
   vmin=min(z['pl']*(1-z['pl']),z['pu']*(1-z['pu']));r=max(z['pu']+amp,1-z['pl']+amp)/acq.c.k.roots(vmin)[0]
   radius=max(F('2.3'),acq.c.k.up(r,10**6)+F(1,10**6))
   q=acq.c.cell(40,radius,F('.4226'),z,steps=48);need(not q.get('excluded'),'selected feedback survivor')
   q=acq.bounded(q);q.update(index=z['index'],amplitude=amp,radius=radius)
   steps.append(dict(amplitude=amp,radius=radius,proof=proof));z=q;strip=amp
  need(z['amplitude']<=F('.475'),'selected final amplitude')
  z['confinement_proof']=steps;rows.append(z)
  if emit:
   print('EXACT_INDEXED40_CONFINEMENT',z['index'],enc({k:z[k]for k in('amplitude','raw','theta','lambda_max','inward_d_max')}),flush=True)
   Path('indexed_confinement_progress.json').write_text(json.dumps(enc(dict(rows=rows)),indent=2)+'\n')
 return dict(schema='INDEXED40_42_LEFT_CONFINEMENT_V1',N=40,indexed_premise=src['indexed_premise'],weighted_invariant=src['weighted_invariant'],source_sha256=sha256(blob).hexdigest(),plan_sha256=sha256(pb).hexdigest(),rows=rows)
