"""Exact indexed LEFT acquisition-to-local-target bridge, with complete profile domains."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import copy,json,sys
import fixed_acceptance as fixed
ROOT=Path(__file__).resolve().parent;need=fixed.need
if not __debug__ or sys.flags.optimize:raise RuntimeError('Unoptimized Python required')
FILES=['indexed_confinement_candidate.json','indexed_profile_candidate.json','comparison_targets.json','COMPARISON_SOURCE.json','acquisition_manifest.json','confinement_manifest.json','profile_manifest.json','accept_interface.py','FLOOR40_SCOPE_AND_JOINT_THETA.md']
SCHEDULE=[(F('.05'),F('.08'),F('.45')),(F('.08'),F('.10'),F('.40')),(F('.10'),F('.12'),F('.35')),(F('.12'),F('.125'),F('.3125')),(F('.125'),None,F('.30'))]
def H(name):return sha256((ROOT/name).read_bytes()).hexdigest()
def read(name):return json.loads((ROOT/name).read_text())
def hashes():return{n:H(n)for n in FILES}
def check(src,pro,targets):
 need(src['schema']=='INDEXED40_42_LEFT_CONFINEMENT_V1'and pro['schema']=='INDEXED40_42_LEFT_PROFILES_V1','selected indexed schemas')
 need(src['N']==pro['N']==targets['N']==40,'floor40 scope')
 need(src['indexed_premise']==pro['indexed_premise']=='n=40,delta<=.19 OR n in{41,42},delta=0','exact indexed premise')
 need(src['weighted_invariant']=='nD<=40*D_row','weighted actual-law invariant')
 need(len(src['rows'])==len(targets['rows'])==49 and len(pro['rows'])==245,'complete closed target/profile cover')
 need(pro['schedule']==[[str(a),str(b)if b is not None else None,str(c)]for a,b,c in SCHEDULE],'same five noise bands')
 mp={'raw':'T','D':'D','theta':'theta','rho':'rho','beta':'beta_hi','inward_d_max':'d0','lambda_max':'lambda_max','Hminus':'H_minus','Hplus':'H_plus','amplitude':'amplitude'}
 empty=inherited=nonempty=boxes=0
 for i,(s,t)in enumerate(zip(src['rows'],targets['rows'])):
  domain=[F(141+i,500),F(142+i,500)]
  need(s['index']==141+i and t['index']==i and [F(s['pl']),F(s['pu'])]==list(map(F,t['p']))==domain,'same ordered closed actual probability cell')
  need(s['joint_inward_noise']is True,'same-law joint intercept source')
  for a,b in mp.items():need(F(s[a])<=F(t[b]),'upper scalar dominance '+a)
  need(F(s['beta_lo'])>=F(t['beta_lo']),'lower beta dominance')
  need(len(s['quadratics'])==len(t['quadratics'])==4,'all coherent corners')
  for a,b in zip(s['quadratics'],t['quadratics']):
   for k in('A','Fplus','Fminus'):need(F(a[k])<=F(b[k]),'upper signed coefficient dominance')
   need(F(a['Qbudget'])>=F(b['Qbudget'])>0,'lower positive curvature dominance')
  lam=F(s['lambda_max']);need(lam>0 and F(s['inward_d_max'])>0,'positive joint intercepts')
  for bi,(lo,end,amp)in enumerate(SCHEDULE):
   p=pro['rows'][5*i+bi];need(p['index']==s['index']and p['band']==bi and F(p['source_noise_ceiling'])==lam,'same-law ordered profile source')
   need(F(p['amplitude'])<=min(amp,F(t['amplitude'])),'advertised amplitude dominance')
   if lam<=lo:
    need(p.get('empty')is True and p['noise']is None,'explicit empty noise band');empty+=1;continue
   need(not p.get('empty'),'nonempty actual profile');hi=lam if end is None else min(end,lam)
   need(list(map(F,p['noise']))==[lo,hi],'exact actual noise ceiling');nonempty+=1
   proof=p['proof']
   if proof.get('inherited'):
    need(F(proof['amplitude'])==F(s['amplitude'])<=F(p['amplitude']),'inherited global support');inherited+=1;continue
   need(proof['coherent_noise']is True and len(proof['subcells'])==64,'both signs times32 coherent noise cells')
   for j,q in enumerate(proof['subcells']):
    sign=-1 if j<32 else 1;cell=j%32;a=lo+(hi-lo)*F(cell,32);b=lo+(hi-lo)*F(cell+1,32)
    need(q['sign']==sign and q['subcell']==cell and list(map(F,q['noise']))==[a,b],'complete signed subinterval tile')
    vmin=min(v*(1-v)for v in domain)
    need(F(q['theta'])==min(F(s['theta']),b/(40*vmin+b)),'exact conditional theta')
    need(F(q['d0'])==F(s['inward_d_max'])*(1-a/lam),'exact joint inward bound')
    boxes+=q['proof']['excluded']+q['proof']['feasible']
 return dict(probability_cells=49,probability_domain=['141/500','19/50'],quadratic_coefficients=784,profile_entries=245,nonempty_profiles=nonempty,empty_profiles=empty,inherited_profiles=inherited,profile_phase_noise_boxes=boxes)
def main():
 frozen=read('interface_manifest.json');need(frozen==hashes(),'fixed interface files')
 for c in('acquisition','confinement','profile'):fixed.verify_manifest(read(c+'_manifest.json'),c)
 need(read('COMPARISON_SOURCE.json')['sha256']==H('comparison_targets.json'),'frozen local target bytes')
 s=read('indexed_confinement_candidate.json');p=read('indexed_profile_candidate.json');t=read('comparison_targets.json');result=check(s,p,t);controls=0
 for mode in('scope','weight','missing','duplicate','order','theta','beta','Q','joint','empty','noise','amplitude','conditional_theta','conditional_d0'):
  a,b,c=map(copy.deepcopy,(s,p,t))
  if mode=='scope':a['indexed_premise']='n>=40'
  elif mode=='weight':a['weighted_invariant']='D<=D_row'
  elif mode=='missing':a['rows'].pop()
  elif mode=='duplicate':b['rows'][1]=b['rows'][0]
  elif mode=='order':a['rows'].reverse()
  elif mode=='theta':a['rows'][0]['theta']='1'
  elif mode=='beta':a['rows'][0]['beta_lo']='-1'
  elif mode=='Q':a['rows'][0]['quadratics'][0]['Qbudget']='0'
  elif mode=='joint':a['rows'][0]['joint_inward_noise']=False
  elif mode=='empty':b['rows'][0]['empty']=False
  else:
   q=next(r for r in b['rows']if not r.get('empty')and not r['proof'].get('inherited'))
   if mode=='noise':q['noise'][0]='0'
   elif mode=='amplitude':q['amplitude']='1'
   elif mode=='conditional_theta':q['proof']['subcells'][0]['theta']='1'
   else:q['proof']['subcells'][0]['d0']='1'
  try:check(a,b,c)
  except(ValueError,AssertionError,KeyError,TypeError):controls+=1
  else:raise ValueError('mutation accepted '+mode)
 need(frozen==hashes(),'unchanged interface files')
 print(json.dumps(dict(status='PASS_INDEXED40_42_LEFT_LOCAL_INTERFACE',**result,negative_controls=controls,analytic_scope_proof='FLOOR40_SCOPE_AND_JOINT_THETA.md',arithmetic_replay='separate fixed component logs required')),flush=True)
if __name__=='__main__':main()
