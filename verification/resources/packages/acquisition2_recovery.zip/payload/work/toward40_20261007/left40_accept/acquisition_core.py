"""Fixed indexed LEFT40 acquisition: n40/delta<=.19 or n41..42/delta=0.

The original single40 object is independently replayed in full. Every actual
radius contraction also receives a finite40..42, zero-decrement heat proof.
All moment rows have the weighted interpretation nD<=40*d, per scope note.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
import candidate_panel40 as c
import corrected_phase_callback_extended as correction
import heat_support50 as heat,fifth_heat50 as fifth,exterior40_candidate as ext
correction.install(c.k);base=heat.constants;ext.QDEC=F('.19')
N=40
if not __debug__ or sys.flags.optimize:raise RuntimeError('Unoptimized Python required')
def need(v,s):
 if not v:raise ValueError(s)
def enc(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,(tuple,list)):return[enc(x)for x in v]
 if isinstance(v,dict):return{k:enc(x)for k,x in v.items()}
 return v
def dec(v):
 if isinstance(v,str):
  try:return F(v)
  except(ValueError,ZeroDivisionError):return v
 if isinstance(v,list):return[dec(x)for x in v]
 if isinstance(v,dict):return{k:dec(x)for k,x in v.items()}
 return v
def inp(z):return{k:z[k]for k in('pl','pu','raw','D','theta','rho','beta')}
def support(z,R,last,q):
 def constants(n,L,K):
  C,_,_,ell,S=base(n,L,K);return C,z['rho'],z['beta'],ell,S
 heat.constants=constants
 try:return fifth.target(40,last,F(0),R,q)
 finally:heat.constants=base

def bounded(z):
 up=lambda x:c.k.up(x,10**6)+F(1,10**6)
 down=lambda x:c.k.down(x,10**6)-F(1,10**6)
 out={k:z[k]for k in('pl','pu')}
 for key in('raw','D','theta','rho','beta','lambda_max','inward_d_max','Hplus','Hminus'):out[key]=up(z[key])
 for key in('A','B','beta_lo'):out[key]=down(z[key])
 out['quadratics']=[{k:(down(q[k])if k=='Qbudget'else up(q[k]))for k in('A','Fplus','Fminus','Qbudget')}for q in z['quadratics']]
 out['joint_inward_noise']=True
 return out

def build(emit=False):
 ib=Path('initial40_candidate.json').read_bytes();initial=dec(json.loads(ib))
 rb=Path('acquisition40_candidate.json').read_bytes();reference=dec(json.loads(rb))
 need(initial['name']=='INITIAL40_R384'and initial['format']=='INITIAL40_FULL_P_V1'and len(initial['panels'])==100,'complete bound INITIAL40')
 need(reference['N']==40 and reference['q']==F('.19')and reference['cap']==F('.4226'),'original single40 scope')
 need(len(reference['coarse'])==38 and len(reference['fine'])==60,'complete original left object')
 coarse=[];fine=[];rows=[];heat_proofs=[]
 for j in range(38):
  p=initial['panels'][j];need(p['pl']==F(j,100)and p['pu']==F(j+1,100),'closed source probability cells')
  if p['cells']==0:z=dict(index=j,p=[F(j,100),F(j+1,100)],excluded=True,source='initial_empty')
  else:z=c.cell(40,F('3.84'),F('.4226'),inp(p),steps=64);z.update(index=j,p=[F(j,100),F(j+1,100)])
  need(z==reference['coarse'][j],'fixed coarse replay');coarse.append(z)
  if emit:print('EXACT_INDEXED40_COARSE',j,z.get('excluded',False),flush=True)
 parents=[z for z in coarse if not z.get('excluded')];need([z['index']for z in parents]==list(range(26,38)),'all coarse survivors26..37')
 mom=dict(rho=max(z['rho']for z in parents),beta=max(z['beta']for z in parents));R1=F('3.2')
 first=support(mom,R1,40,F('.19'));need(dec(first)==reference['first_support']and reference['first_radius']==R1,'original first contraction')
 firstband=support(mom,R1,42,F(0));need(firstband['n_band']==[40,42],'first finite-band zero-decrement support')
 for parent in parents:
  for j in range(5):
   idx=5*parent['index']+j;old=reference['fine'][idx-130]
   need(old['index']==idx and old['p']==[F(idx,500),F(idx+1,500)],'ordered closed fine cover')
   row=inp(parent);row.update(pl=F(idx,500),pu=F(idx+1,500));previous=R1;proofs=[]
   need(old['trace']and old['trace'][0]==R1,'first contracted radius')
   for step,R in enumerate(old['trace']):
    need(F('2.5')<=R<=previous,'fixed nonincreasing support route')
    if step:
     proofs.append(dict(radius=R,single=support(row,R,40,F('.19')),finite_zero=support(row,R,42,F(0))))
    z=c.cell(40,R,F('.4226'),row,steps=64);previous=R
    if z.get('excluded'):
     need(step==len(old['trace'])-1,'exclusion closes fixed route');break
    row=inp(z)
   need(z==old['final'],'fixed final coupled resource replay')
   rec=dict(index=idx,p=old['p'],trace=old['trace'],support_proofs=proofs,excluded=bool(z.get('excluded')))
   if not z.get('excluded'):
    st=old['strip'];w=st['width'];need(w in(F('.55'),F('.575'),F('.6')),'selected strict transformed strip')
    hyp=dict(p=list(map(str,old['p'])),theta=str(z['theta']),rho=str(z['rho']),beta_upper=str(z['beta']),H=str(max(z['Hplus'],z['Hminus'])),radius=str(R))
    e=ext.from_hypotheses(hyp,w);need(F(e['worst']['upper'])==F(st['maximum'])and len(e['rows'])==st['cells']and F(st['maximum'])<0,'full actual transformed exterior replay')
    q=bounded(z);q.update(index=idx,strip=w,radius=R);rows.append(q)
    rec['strip']=dict(width=w,cells=st['cells'],maximum=F(st['maximum']),sha256=sha256(json.dumps(e['rows'],sort_keys=True,separators=(',',':')).encode()).hexdigest())
   fine.append(rec)
   if emit:
    print('EXACT_INDEXED40_FINE',idx,rec['excluded'],str(rec.get('strip',{}).get('width','')),flush=True)
    Path('indexed_acquisition_progress.json').write_text(json.dumps(enc(dict(rows=rows,fine=fine)),indent=2)+'\n')
 need(len(fine)==60 and [z['index']for z in rows]==list(range(141,190)),'complete49 local rows [.282,.38]')
 return dict(schema='INDEXED40_42_LEFT_ACQUISITION_V1',N=40,indexed_premise='n=40,delta<=.19 OR n in{41,42},delta=0',weighted_invariant='nD<=40*D_row',initial_sha256=sha256(ib).hexdigest(),source_single40_sha256=sha256(rb).hexdigest(),current_cap=F('.4226'),first_support=first,first_support_finite_zero=firstband,coarse=[dict(index=z['index'],excluded=bool(z.get('excluded')))for z in coarse],fine=fine,rows=rows)
