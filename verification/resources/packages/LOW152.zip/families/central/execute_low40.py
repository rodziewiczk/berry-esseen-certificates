"""Construct every fixed LOW conditional proof row; acquisition remains separate."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
from central42_contract import read,selected
from central42_kernel import evaluate
HERE=Path(__file__).parent;out=HERE/'low_rows';out.mkdir(exist_ok=True);rows=[]
for r in read():
 if F(r['lambda_max'])<=F('.08'):continue
 for sign in(-1,1):
  hc,oc=16,8
  dest=out/('row_%02d_%s.json'%(r['index'],'minus'if sign<0 else'plus'))
  if dest.exists():raise FileExistsError(dest)
  p,report=evaluate(selected(r,sign,hc,oc));obj=dict(index=r['index'],sign=sign,proof=p,report=report)
  dest.write_text(json.dumps(obj,default=str,indent=2)+'\n');rows.append(dict(index=r['index'],sign=sign,file=dest.name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
  print(json.dumps(dict(index=r['index'],sign=sign,status='PASS_EXACT_CONDITIONAL_ROW',worst=report['worst_score_decimal'],gates=report['gates'])),flush=True)
(HERE/'low40_index.json').write_text(json.dumps(dict(schema='CONDITIONAL_N40_LOW_COVER_V1',rows=rows),indent=2)+'\n')
