"""Bind the complete fresh exact LOW run; --replay independently reruns arithmetic.

The default is an integrity/coverage check, not a second arithmetic acceptance.
The original fixed-input executor evaluates every exact gate, with no discovery
witness or success marker among its inputs. Its source-bound fresh run is retained.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys,copy
from central42_contract import read,selected
HERE=Path(__file__).parent
INDEX_SHA='0f6bd2b660b8c1bfd08ceb4abb21846347ac62da96361a5643f41542b0fed569'
def need(x,s):
 if not x:raise ValueError(s)
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'Duplicate JSON key');d[k]=v
 return d
def check(obj,replay=False,load=True):
 need(type(obj)is dict and set(obj)=={'schema','rows'}and obj['schema']=='CONDITIONAL_N40_LOW_COVER_V1','Fixed schema')
 expected=[(r,sg)for r in read()if F(r['lambda_max'])>F('.08')for sg in(-1,1)]
 need(type(obj['rows'])is list and len(obj['rows'])==len(expected)==70,'Complete signed cover')
 total=0;worst=None;digest=sha256()
 for e,(row,sg)in zip(obj['rows'],expected):
  i=row['index'];name='row_%02d_%s.json'%(i,'minus'if sg<0 else'plus')
  need(type(e)is dict and set(e)=={'index','sign','file','sha256'},'Exact index fields')
  need(type(e['index'])is int and type(e['sign'])is int and (e['index'],e['sign'])==(i,sg),'Strict ordered labels')
  need(e['file']==name and type(e['sha256'])is str and len(e['sha256'])==64,'Fixed row file')
  if not load:continue
  blob=(HERE/'low_rows'/name).read_bytes();need(sha256(blob).hexdigest()==e['sha256'],'Bound row hash')
  o=json.loads(blob,object_pairs_hook=unique);need(type(o)is dict and set(o)=={'index','sign','proof','report'},'Row fields')
  need(type(o['index'])is int and type(o['sign'])is int and (o['index'],o['sign'])==(i,sg),'Row labels')
  hc,oc=16,8;cfg=selected(row,sg,hc,oc)
  p=o['proof'];r=o['report'];c=p['contract'];need(c['N']==40 and c['p']==row['p'] and c['H_cells']==hc,'Fixed row contract')
  need(c['constants']=={k:str(v)for k,v in cfg.items()if type(v)in(int,F)},'All scalar constants bound')
  need(all(type(r[k])is int and r[k]>=0 for k in('gates','endpoints','feasible_cells','empty_cells','phase_envelope_cells')),'Integer counters')
  need(p['mark_count']==r['feasible_cells'] and 2*r['feasible_cells']==r['endpoints'],'Endpoint multiplicity')
  need(r['feasible_cells']+r['empty_cells']==cfg['bands']*hc*oc,'Complete phase/noise grid')
  need(r['status']=='PASS_EXACT_CENTRAL_FINITE40_42_LOW'and r['failed_gates']=={},'Exact run status')
  need(all(F(v)>0 for v in r['minimum_reserves'].values()),'Positive retained reserves')
  score=None
  if r['feasible_cells']:
   score=F(r['worst_score']);need(F(r['minimum_reserves']['finite_binomial_margin'])>0,'Strict per-cell Bernoulli-gap score')
  else:need(r['worst_score']=='None' and r['endpoints']==0,'Empty-cell report')
  if replay:
   from central42_kernel import evaluate
   pp,rr=evaluate(cfg);need(pp==p and rr==r,'Fresh exact replay matches')
  total+=r['gates'];digest.update(blob)
  if score is not None:worst=score if worst is None else max(worst,score)
 return dict(rows=len(expected),strict_gates=total,worst_score=str(worst),row_digest=digest.hexdigest())
def controls(obj):
 tests=[]
 for name,fn in [('missing',lambda o:o['rows'].pop()),('duplicate',lambda o:o['rows'].__setitem__(1,o['rows'][0])),('reordered',lambda o:o['rows'].reverse()),('boolean_index',lambda o:o['rows'][0].update(index=False)),('boolean_sign',lambda o:o['rows'][1].update(sign=True)),('extra_scope',lambda o:o.update(N=41)),('path_traversal',lambda o:o['rows'][0].update(file='../bad.json'))]:
  bad=copy.deepcopy(obj);fn(bad)
  try:check(bad,load=False)
  except ValueError:tests.append(name)
  else:raise ValueError('Invalid cover accepted: '+name)
 try:json.loads('{"a":1,"a":2}',object_pairs_hook=unique)
 except ValueError:tests.append('duplicate_JSON_key')
 else:raise ValueError('Duplicate JSON accepted')
 bad=copy.deepcopy(obj);bad['rows'][0]['sha256']='0'*64
 try:check(bad)
 except ValueError:tests.append('corrupted_row_hash')
 else:raise ValueError('Corrupted row accepted')
 return tests
def provenance():
 meta=HERE.parents[3]/'runs/toward40_20261007/root/central_low_execute01/metadata.json'
 # Workspace is the fifth parent of the comparison folder.
 meta=HERE.parents[3]/'runs/toward40_20261007/root/central_low_execute01/metadata.json'
 data=json.loads(meta.read_text());need(data['returncode']==0,'fresh arithmetic execution succeeded')
 need(data['command'][-1]=='execute_low40.py','named fixed exact executor')
 for name,h in data['input_sha256'].items():need(sha256((HERE/name).read_bytes()).hexdigest()==h,'unchanged arithmetic input '+name)
 need('execute_low40.py'in data['input_sha256'],'executed driver hash captured')
 for channel in('stdout','stderr'):need(sha256((meta.parent/(channel+'.txt')).read_bytes()).hexdigest()==data[channel+'_sha256'],'unchanged captured '+channel)
 return sha256(meta.read_bytes()).hexdigest()
if __name__=='__main__':
 need(not sys.flags.optimize and __debug__,'Unoptimized Python');need(sys.argv[1:]in([],['--replay']),'Only fixed replay switch')
 blob=(HERE/'low40_index.json').read_bytes();need(sha256(blob).hexdigest()==INDEX_SHA,'Frozen index')
 obj=json.loads(blob,object_pairs_hook=unique);replay=bool(sys.argv[1:]);out=check(obj,replay);out['arithmetic_metadata_sha256']=provenance();out.update(status='PASS_FRESH_EXACT_REPLAY'if replay else'PASS_BINDING_OF_FRESH_EXACT_RUN',negative_controls=controls(obj),index_sha256=INDEX_SHA,arithmetic_run='runs/toward40_20261007/root/central_low_execute01',scope='Conditional40<=n<=42 same-law acquired-central target resources; indexed acquisition scope separately required')
 print(json.dumps(out,indent=2))
