"""New parallel152-row protocol, each with two independent original evaluations.

The original selected/evaluate functions, full row serialization, whole binder
check and all controls remain exact. Historical execute/capture metadata is not
an input. Completed rows are durable; resumption requires a separately qualified
parent execution, never a self-authored success JSON.
"""
from pathlib import Path
from hashlib import sha256,file_digest
from concurrent.futures import ThreadPoolExecutor,as_completed
from fractions import Fraction as F
import argparse,importlib.util,json,os,shutil,subprocess,sys,time
HERE=Path(__file__).resolve().parent
MF='LOW62-SOURCE-VERIFIED.json'
def need(ok,message):
 if not ok:raise ValueError(message)
def enc(value):return(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('ascii')
def original_row(value):return(json.dumps(value,default=str,indent=2,allow_nan=False)+'\n').encode('ascii')
def canonical(value):return json.dumps(value,default=str,sort_keys=True,separators=(',',':'),allow_nan=False).encode('ascii')
def h(raw):return sha256(raw).hexdigest()
def digest(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'Complete regular source/result')
 with p.open('rb')as stream:return file_digest(stream,'sha256').hexdigest()
def read(path):
 def unique(pairs):
  value={}
  for k,v in pairs:need(k not in value,'Unique JSON keys');value[k]=v
  return value
 return json.loads(Path(path).read_bytes(),object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in()).throw(ValueError('Finite JSON')))
def atomic(path,raw):
 path=Path(path);need(not path.exists(),'One complete new output, no overwrite')
 pending=path.with_name(path.name+'.pending');path.parent.mkdir(parents=True,exist_ok=True)
 with pending.open('xb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
 pending.rename(path)
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def source(root=HERE):
 rows=read(root/MF)['files']
 for name,pin in rows.items():need(digest(root/name)==pin,'Every frozen current source/input byte: '+name)
 return dict(manifest_sha256=digest(root/MF),files=rows)
def description(root=HERE):return read(root/'LOW62-DESCRIPTION.json')
def family(d,name):
 result=[case for case in d['families']if case['id']==name];need(len(result)==1,'One exact declared family');return result[0]
def row_spec(case,index,sign):
 need(type(index)is int and type(sign)is int and sign in(-1,1),'Strict row labels')
 rows=[r for r in case['rows']if r['index']==index and r['sign']==sign];need(len(rows)==1,'Exactly one complete original selected row');return rows[0]
def paths(task,case,row):
 base=Path(task)/'rows'/case['id']/row['id'];return base,base/'CONSTRUCTED.json',base/'REPLAY.json'
def context(task):
 value=read(Path(task)/'SOURCE-CONTEXT.json');root=Path(value['source_root'])
 need(root.is_absolute()and source(root)==value['source_identity'],'Whole owner-selected source epoch remains exact')
 return root,value
def worker(task,name,index,sign,phase):
 root,ctx=context(task);d=description(root);case=family(d,name);row=row_spec(case,index,sign);base,constructed,replayed=paths(task,case,row)
 before=source(root);native=Path(task)/'capsules'/name
 for path,pin in case['input_pins'].items():need(digest(native/path)==pin,'Whole row mathematical input and source')
 sys.path.insert(0,str(native));contract=load('current62_contract_'+phase,native/'central42_contract.py');kernel=load('current62_kernel_'+phase,native/'central42_kernel.py')
 original=[r for r in contract.read()if type(r['index'])is int and r['index']==index];need(len(original)==1,'Original exact target row')
 cfg=contract.selected(original[0],sign,case['H_cells'],case['outer_phase_cells'])
 need(h(canonical(cfg))==row['configuration_sha256']and cfg['N']==40 and cfg['Ccap']==F(4247,10000),'Every full original selected scalar/array configuration unchanged')
 if phase=='construct':need(not constructed.exists(),'Fresh construct output')
 else:need(phase=='replay'and constructed.is_file()and not replayed.exists(),'Separate fresh replay of a complete construction')
 proof,report=kernel.evaluate(cfg)
 raw=original_row(dict(index=index,sign=sign,proof=proof,report=report))
 for path,pin in case['input_pins'].items():need(digest(native/path)==pin,'Whole mathematical task inputs unchanged after exact evaluation')
 if phase=='construct':atomic(constructed,raw)
 else:
  need(constructed.read_bytes()==raw,'Whole proof/report byte equality after independent fresh exact evaluation')
  atomic(replayed,enc(dict(schema='NEW_LOW62_INDEPENDENT_FRESH_ROW_REPLAY_V1',family=name,index=index,sign=sign,
   complete_row_sha256=h(raw),configuration_sha256=row['configuration_sha256'],whole_proof_and_report_equal=True,
   original_evaluate_ran_fresh=True,source_before=before,source_after=source(root),mathematical_acceptance=False)))
 need(source(root)==before,'Whole source unchanged after original exact evaluation')
 observation=dict(schema='NEW_LOW62_NATIVE_ROW_PASS_V1',family=name,index=index,sign=sign,phase=phase,
  complete_row_sha256=h(raw),configuration_sha256=row['configuration_sha256'],source_before=before,source_after=before,
  complete_task_input_pins_before=case['input_pins'],complete_task_input_pins_after=case['input_pins'],actual_original_evaluate_calls=1,mathematical_acceptance=False)
 atomic(base/(phase.upper()+'-OBSERVATION.json'),enc(observation))
 print(json.dumps(dict(status='LOW62_ORIGINAL_ROW_PASS_COMPLETED',family=name,index=index,sign=sign,phase=phase,complete_row_sha256=h(raw))),flush=True)
def verify_completed(task,case,row):
 root,ctx=context(task);base,constructed,replayed=paths(task,case,row);record=read(base/'ROW-COMPLETED.json')
 need(record['schema']=='NEW_LOW62_TWO_INDEPENDENT_PASSES_COMPLETED_V1'and record['family']==case['id']
      and type(record['index'])is int and type(record['sign'])is int and record['index']==row['index']and record['sign']==row['sign']
      and record['configuration_sha256']==row['configuration_sha256'],'Exact full completed row identity')
 need(record['source_identity']==ctx['source_identity']and record['complete_row_sha256']==digest(constructed)
      and record['replay_sha256']==digest(replayed),'Whole original source epoch and current construct/replay bytes')
 need(set(record['passes'])=={'construct','replay'},'Both and only two separate source-bound evaluator processes')
 for phase in('construct','replay'):
  entry=record['passes'][phase];logs=base/'executions'/phase
  need(type(entry['returncode'])is int and entry['returncode']==0 and entry['actual_observed_process']is True,'Actual separately observed successful native process')
  expected=[sys.executable,'-B','-S',str(root/'low62_protocol.py'),'worker','--task',str(Path(task)),'--family',case['id'],'--index',str(row['index']),'--sign',str(row['sign']),'--phase',phase]
  need(entry['argv']==expected and read(logs/'ARGV.json')['argv']==expected,'Actual exact direct argv, no original executor impersonation')
  need(digest(logs/'stdout.txt')==entry['stdout_sha256']and digest(logs/'stderr.txt')==entry['stderr_sha256']and(logs/'stderr.txt').stat().st_size==0,'Every actual stopped row stream')
  obs=read(base/(phase.upper()+'-OBSERVATION.json'))
  need(obs['schema']=='NEW_LOW62_NATIVE_ROW_PASS_V1'and obs['family']==case['id']and type(obs['index'])is int and type(obs['sign'])is int
       and obs['index']==row['index']and obs['sign']==row['sign']and obs['phase']==phase
       and obs['configuration_sha256']==row['configuration_sha256']and obs['complete_row_sha256']==digest(constructed)
       and obs['source_before']==obs['source_after']==ctx['source_identity']and type(obs['actual_original_evaluate_calls'])is int and obs['actual_original_evaluate_calls']==1
       and obs['complete_task_input_pins_before']==obs['complete_task_input_pins_after']==case['input_pins'],'Entire real fresh evaluator observation and unchanged full source/task inputs')
  terminal=json.loads((logs/'stdout.txt').read_bytes())
  need(terminal==dict(status='LOW62_ORIGINAL_ROW_PASS_COMPLETED',family=case['id'],index=row['index'],sign=row['sign'],phase=phase,complete_row_sha256=digest(constructed)),'Whole terminal binds actual row pass')
 replay=read(replayed)
 need(replay['schema']=='NEW_LOW62_INDEPENDENT_FRESH_ROW_REPLAY_V1'and replay['family']==case['id']
      and type(replay['index'])is int and type(replay['sign'])is int and replay['index']==row['index']and replay['sign']==row['sign']
      and replay['whole_proof_and_report_equal']is True and replay['original_evaluate_ran_fresh']is True and replay['complete_row_sha256']==digest(constructed)
      and replay['configuration_sha256']==row['configuration_sha256']and replay['source_before']==replay['source_after']==ctx['source_identity'],'Complete independent fresh replay')
 native=Path(task)/'capsules'/case['id']
 for path,pin in case['input_pins'].items():need(digest(native/path)==pin,'Whole original task inputs retained at current readback')
 return record
def run_row(task,case,row,deadline):
 root,ctx=context(task);base,constructed,replayed=paths(task,case,row);base.mkdir(parents=True)
 passes={}
 for phase in('construct','replay'):
  logs=base/'executions'/phase;logs.mkdir(parents=True)
  argv=[sys.executable,'-B','-S',str(root/'low62_protocol.py'),'worker','--task',str(Path(task)),'--family',case['id'],'--index',str(row['index']),'--sign',str(row['sign']),'--phase',phase]
  atomic(logs/'ARGV.json',enc(dict(argv=argv,deadline=deadline)))
  remaining=deadline-time.time();need(remaining>1,'Before admitted absolute native horizon')
  started=time.time()
  with(logs/'stdout.txt').open('xb')as stdout,(logs/'stderr.txt').open('xb')as stderr:
   process=subprocess.run(argv,cwd=base,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=remaining,check=False)
  need(type(process.returncode)is int and process.returncode==0,'Fresh original per-row process completed')
  passes[phase]=dict(argv=argv,returncode=0,actual_observed_process=True,started_unix=started,finished_unix=time.time(),stdout_sha256=digest(logs/'stdout.txt'),stderr_sha256=digest(logs/'stderr.txt'))
 record=dict(schema='NEW_LOW62_TWO_INDEPENDENT_PASSES_COMPLETED_V1',family=case['id'],index=row['index'],sign=row['sign'],configuration_sha256=row['configuration_sha256'],
  source_identity=ctx['source_identity'],complete_row_sha256=digest(constructed),replay_sha256=digest(replayed),passes=passes,mathematical_acceptance=False)
 atomic(base/'ROW-COMPLETED.json',enc(record));verify_completed(task,case,row);return record
def current_provenance(native,name):
 """Closed replacement for historical launch transport; no math check changes."""
 native=Path(native);task=native.parents[1];root,ctx=context(task);case=family(description(root),name);rows=[];pins={}
 for row in case['rows']:
  record=verify_completed(task,case,row);base,constructed,_=paths(task,case,row)
  need(digest(native/'low_rows'/row['file'])==digest(constructed),'Whole current construct row at original mathematical binder input')
  rows.append(dict(index=row['index'],sign=row['sign'],file=row['file'],sha256=digest(constructed)));pins[row['id']]=digest(base/'ROW-COMPLETED.json')
 packet=read(task/(name+'-FAMILY-COMPLETED.json'))
 need(packet['row_execution_sha256']==pins and packet['source_identity']==ctx['source_identity'],'Entire owner-observed two-pass execution inventory')
 pin=digest(task/(name+'-FAMILY-COMPLETED.json'))
 if name=='central':
  need(read(native/'low40_index.json')==dict(schema='CONDITIONAL_N40_LOW_COVER_V1',rows=rows),'Entire current original ordered CENTRAL70 index')
  return pin
 return dict(schema='FINITE_LEFT40_42_LOW_COMPLETE_V1',rows=rows),dict(current_row_protocol_family_manifest_sha256=pin)
def bind_family(task,case,deadline):
 root,ctx=context(task);native=Path(task)/'capsules'/case['id'];rowpins={};rows=[]
 out=native/'low_rows';out.mkdir()
 for row in case['rows']:
  record=verify_completed(task,case,row);base,constructed,_=paths(task,case,row)
  shutil.copyfile(constructed,out/row['file']);rowpins[row['id']]=digest(base/'ROW-COMPLETED.json')
  rows.append(dict(index=row['index'],sign=row['sign'],file=row['file'],sha256=digest(constructed)))
 atomic(Path(task)/(case['id']+'-FAMILY-COMPLETED.json'),enc(dict(schema='NEW_LOW62_WHOLE_FAMILY_TWO_PASS_EXECUTION_V1',source_identity=ctx['source_identity'],family=case['id'],rows=len(rows),row_execution_sha256=rowpins,
  full_original_binder_check_and_controls_still_required=True,old_executor_claimed_run=False,mathematical_acceptance=False)))
 if case['id']=='central':atomic(native/'low40_index.json',original_row(dict(schema='CONDITIONAL_N40_LOW_COVER_V1',rows=rows)))
 argv=[sys.executable,'-B','-S',str(native/case['current_binder'])];logs=Path(task)/'binders'/case['id'];logs.mkdir(parents=True)
 atomic(logs/'ARGV.json',enc(dict(argv=argv,deadline=deadline)))
 remaining=deadline-time.time();need(remaining>1,'Whole binder must enter before the absolute native horizon')
 with(logs/'stdout.txt').open('xb')as stdout,(logs/'stderr.txt').open('xb')as stderr:
  process=subprocess.run(argv,cwd=native,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=remaining,check=False)
 need(process.returncode==0 and(logs/'stderr.txt').stat().st_size==0,'Original whole mathematical binder and all controls completed')
 result=json.loads((logs/'stdout.txt').read_bytes());expected=case['expected_mathematical_binder_result']
 need(all(type(result[k])is type(v)and result[k]==v for k,v in expected.items()),'Every complete original numerical binder field unchanged')
 need(result['negative_controls']==case['negative_controls'],'All original malformed controls retained')
 return dict(family=case['id'],result=result,stdout_sha256=digest(logs/'stdout.txt'),stderr_sha256=digest(logs/'stderr.txt'),current_binder_sha256=digest(native/case['current_binder']),original_check_and_controls_unchanged=True,
  original_execute_script_or_binder_replay_claimed_run=False,mathematical_acceptance=False)
def run(task,deadline,jobs):
 before=source();d=description();task=Path(task).absolute();need(not task.exists(),'Exclusive new parallel row task');task.mkdir(parents=True)
 atomic(task/'SOURCE-CONTEXT.json',enc(dict(source_root=str(HERE),source_identity=before)))
 for case in d['families']:shutil.copytree(HERE/'families'/case['id'],task/'capsules'/case['id'])
 completed=[];errors=[]
 with ThreadPoolExecutor(max_workers=jobs)as pool:
  futures={pool.submit(run_row,task,case,row,deadline):(case,row)for case in d['families']for row in case['rows']}
  for future in as_completed(futures):
   case,row=futures[future]
   try:completed.append(future.result());print(json.dumps(dict(row_completed=case['id']+'/'+row['id'],completed=len(completed),total=152)),flush=True)
   except Exception as error:errors.append(dict(family=case['id'],row=row['id'],error=repr(error)))
   # Atomic durable progress, not acceptance or permission to skip fresh replay.
   journal=task/('JOURNAL-'+str(len(completed)+len(errors)).zfill(3)+'.json');atomic(journal,enc(dict(completed=[dict(family=r['family'],index=r['index'],sign=r['sign'])for r in completed],errors=errors,source_identity=before,mathematical_acceptance=False)))
 binders=[]
 if len(completed)==152 and not errors:
  for case in d['families']:binders.append(bind_family(task,case,deadline))
 need(source()==before,'Whole source/input package remains exact after every child')
 result=dict(schema='NEW_LOW62_PARALLEL_ROW_PROTOCOL_OBSERVATION_V1',status='LOW62_ALL152_TWO_PASS_ROWS_AND_ORIGINAL_BINDERS_COMPLETED_CONDITIONAL'if len(binders)==2 and not errors else'LOW62_PARTIAL',
  completed_rows=len(completed),expected_rows=152,actual_native_row_calls=2*len(completed),binders=binders,errors=errors,source_before=before,source_after=before,
  previous_completed_rows_durable_but_external_genuine_execution_admission_required=True,original_execute_or_serial_binder_replay_claimed_run=False,
  actual_support_initial_resources_and_analytical_licenses_still_required=True,mathematical_acceptance=False,full_proof_pass=False)
 atomic(task/'RESULT.json',enc(result));return result
def main():
 p=argparse.ArgumentParser(allow_abbrev=False);sub=p.add_subparsers(dest='mode',required=True)
 r=sub.add_parser('run');r.add_argument('--task',type=Path,required=True);r.add_argument('--deadline',type=int,required=True);r.add_argument('--jobs',type=int,default=8)
 w=sub.add_parser('worker');w.add_argument('--task',type=Path,required=True);w.add_argument('--family',choices=['central','left'],required=True);w.add_argument('--index',type=int,required=True);w.add_argument('--sign',type=int,choices=[-1,1],required=True);w.add_argument('--phase',choices=['construct','replay'],required=True)
 a=p.parse_args();need(__debug__ and not sys.flags.optimize and sys.dont_write_bytecode,'Ordinary exact no-bytecode interpreter')
 if a.mode=='worker':worker(a.task,a.family,a.index,a.sign,a.phase);return 0
 need(1<=a.jobs<=96 and time.time()<a.deadline,'Dynamic bounded parallelism and admitted absolute cutoff')
 result=run(a.task,a.deadline,a.jobs);print(json.dumps(dict(status=result['status'],result_sha256=digest(a.task/'RESULT.json'))),flush=True)
 return 0 if result['completed_rows']==152 and len(result['binders'])==2 and not result['errors']else 1
if __name__=='__main__':raise SystemExit(main())
