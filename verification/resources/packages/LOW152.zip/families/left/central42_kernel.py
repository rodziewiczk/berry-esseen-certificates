"""Exact phase-resolved finite LEFT40..42 LOW arithmetic reduction.

This reconstructs a declared closed domain and checks every rational endpoint.
Acquired entry, confinement, normalization and TINY/MID remain separate inputs.
The analytic transfer is proved in low47_new_lemmas.tex and the retained whole-count proof.
"""
from fractions import Fraction as F
from math import isqrt,factorial
from functools import lru_cache
from pathlib import Path
import hashlib,json,sys
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
CONTRACT={'schema':'FINITE_LEFT40_42_GAP_LOW_V1'}
def rootlo(x):
    if x<0:raise ValueError('Negative radicand')
    return F(isqrt(x.numerator*10**16//x.denominator),10**8)
def rootup(x):return rootlo(x)+F(1,10**8)
def ceiling(x):return F(-((-x.numerator*10**12)//x.denominator),10**12)
@lru_cache(None)
def exp_inverse_upper(mu):
    if not 0<mu<10:raise ValueError('Poisson mean domain')
    return 1/sum(mu**k/F(factorial(k))for k in range(25))
@lru_cache(None)
def poisson_numerator(mu,a):
    if a<0:raise ValueError('Negative anchor')
    # Full cubic moment, with the finitely many negative terms removed.
    raw=mu**3+3*(1-a)*mu**2+(1-3*a+3*a*a)*mu-a**3
    correction=sum(mu**k/F(factorial(k))*(a-k)**3 for k in range(a.numerator//a.denominator+1))
    ans=raw+exp_inverse_upper(mu)*correction
    if ans<=0:raise ValueError('Nonpositive Poisson numerator')
    return ans
@lru_cache(None)
def poisson(mu,b):
    x=b+mu;fl=x.numerator//x.denominator
    anchors=sorted(set(max(F(0),F(fl)-d)for d in (F(0),F('.25'),F('.5'),F('.75'),F(1))))
    vals=[F(1)]
    for a in anchors:
        if a<x:vals.append(ceiling(poisson_numerator(mu,a)/(x-a)**3))
    return min(vals)

def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',',':')).encode()

def evaluate(cfg):
    pc=int(cfg.get("p_cells",16)); hc=int(cfg.get("H_cells",64)); a0=cfg.get("phase0",F(".14"))
    N=cfg["N"]; T=cfg["T"]; pl0=cfg["pl"]; pu0=cfg["pu"]
    theta=cfg['theta']; d0=cfg["d0"]; c=1-d0; amp=cfg['amplitude']
    mass=cfg["mass"]; H=cfg["H"]; maxnoise=cfg['maxnoise'];bands=int(cfg['bands'])
    failures={}
    contract={**CONTRACT,"schema":"FINITE_LEFT40_42_GAP_LOW_V1","N":N,"T":str(T),"p":[str(pl0),str(pu0)],"H":str(H),"D":str(cfg["D"]),"d0":str(d0),"p_cells":pc,"H_cells":hc,"phase_radii":[],"mass_floor":str(mass),"constants":{k:str(v) for k,v in cfg.items() if type(v) in (int,F)}}
    contract['configuration_sha256']=hashlib.sha256(json.dumps(cfg,default=str,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    choices=[]; gate_count=0; endpoint_count=0; empty_count=0
    digest=hashlib.sha256(); minima={}; maxima={}; phase_cache={}
    def gate(name,value):
        nonlocal gate_count
        value=F(value)
        if value<=0:
            raise ArithmeticError((name,str(value)))
        gate_count+=1
        group=name.split(':',1)[0]
        if group not in minima or value<minima[group]: minima[group]=value
        digest.update((name+'='+str(value)+'\n').encode())
    gate('c_domain_lower',c-F(1,2)); gate('c_domain_upper',1-c)
    gate('D_domain',cfg['D']) # D bound is an independent entry hypothesis.
    gate('midpoint_fourth_domain',F(5,2)*c-amp-F(1,2))
    gate('global_curvature_a',2-(pu0+H/cfg['elo']+F(1,2)))
    for pi in range(pc):
        pl=pl0+(pu0-pl0)*pi/pc; pu=pl0+(pu0-pl0)*(pi+1)/pc
        ell2=(1-theta)/(pu*(1-pu)); ell=rootlo(ell2)
        gate('ell_lower:'+str(pi),ell2-ell*ell)
        cv=1/pl; v=pl*(1-pl)
        mcell=rootlo((1-theta)*v)
        # NEW shared-shift identity: D >= m ell²[(6+2sqrt10)(p-pE)²
        # +6d(1-d)] + beta*theta. Both terms use one common iid marginal.
        al=6*mcell*ell**2*(1-d0)
        be=min(3*F('4.16')*ell*(1-pu-d0),3*F('6.16')*ell*(pl-d0))
        dist=max(F(0),F('.41886')-pu,pl-F('.41887'))
        pen=F('12.32455532')*mcell*ell**2*dist**2
        raw=(6*pl-3*pl*pl-F('1.5')-d0-3*(1-2*v)*maxnoise/(8*v*N))
        repair=min(cfg['repair_multiplier']*raw,cfg['repair_multiplier_upper']*raw)
        # Signed cubic gain can have either sign.
        for bi in range(bands):
            if 'noise_intervals'in cfg:low,high,a=cfg['noise_intervals'][bi]
            if 'amplitude_profile'in cfg:amp=cfg['amplitude_profile'][bi]
            if 'noise_intervals'not in cfg:
                low=cfg['noise_start']+bi*cfg['noise_step']; high=low+cfg['noise_step']
                a=next(F(r)for end,r in cfg['phases'] if low<F(end))
            # NEW explicit same-law hypothesis: d/joint_d0 + lambda/joint_lambda <= 1.
            if 'joint_d0' in cfg:
                gate('joint_intercept:'+str(pi)+':'+str(bi),cfg['joint_lambda']-low)
                d0=cfg['joint_d0']*(1-low/cfg['joint_lambda'])
                gate('joint_gap_positive:'+str(pi)+':'+str(bi),d0)
                c=1-d0
                al=6*mcell*ell**2*(1-d0)
                be=min(3*F('4.16')*ell*(1-pu-d0),3*F('6.16')*ell*(pl-d0))
                raw=(6*pl-3*pl*pl-F('1.5')-d0-3*(1-2*v)*maxnoise/(8*v*N))
                repair=min(cfg['repair_multiplier']*raw,cfg['repair_multiplier_upper']*raw)
                # Signed cubic gain can have either sign.
            for hj in range(hc):
                whole_a=a
                for oi in range(cfg["outer_phase_cells"]):
                    oc=cfg["outer_phase_cells"]
                    if 'phase_domains' in cfg:
                        neg,pos=cfg['phase_domains'][bi]
                        if oc%2:raise ArithmeticError('Even phase count required')
                        half=oc//2
                        if oi<half:outerl=-neg+neg*F(oi,half);outerh=-neg+neg*F(oi+1,half)
                        else:outerl=pos*F(oi-half,half);outerh=pos*F(oi-half+1,half)
                    else:outerl=-whole_a+2*whole_a*F(oi,oc);outerh=-whole_a+2*whole_a*F(oi+1,oc)
                    a=max(abs(outerl),abs(outerh))
                    key=f'{pi}:{bi}:{hj}:{oi}'
                    hl=H*hj/hc; hh=H*(hj+1)/hc
                    eh=rootup(1/(pl*(1-pl)))
                    gate('scale_upper:'+key,eh*eh*pl*(1-pl)-1)
                    hs=(hl,hh)if cfg['phase_sign']>0 else(-hh,-hl)
                    hqs=[h/e for h in hs for e in(ell,eh)]
                    deltas=[h-u for h in hqs for u in(outerl,outerh)]
                    dd=max(abs(d)for d in deltas);dpositive=max(F(0),max(deltas))
                    zeta=cfg['logder']*dd/2+cfg['remainder']+cfg['entropy']*dd**3/(6*N)
                    actual_mass=F('.39886')/rootup(pu*(1-pu))*(1-(dd*dd/(2*v)+zeta)/N)
                    mass=max(cfg['mass'],actual_mass)
                    gate('actual_mass_positive:'+key,mass)
                    ownlo=1-cv*dd/N; ownhi=1+cv*dd/N
                    budget=T
                    if all(k in cfg for k in ("R_A","R_F","R_Q")):
                        qa,qf,qq=(cfg[k] for k in ("R_A","R_F","R_Q"))
                        gate("phase_quadratic:"+key,qq)
                        vertex=max(hl,min(hh,qf/(2*qq)))
                        budget=min(T,qa+qf*vertex-qq*vertex*vertex)
                    if 'raw_quads' in cfg:
                        vals=[]
                        for qa,qf,qq in cfg['raw_quads']:
                            vv=max(hl,min(hh,qf/(2*qq)))
                            vals.append(qa+qf*vv-qq*vv*vv)
                        budget=min(T,max(vals))
                    cap=(15000*(budget-cfg['rebate']*hl*hl)/997-N*pen-be*ell*ell*low)/al
                    if cap<=0:
                        empty_count+=1; digest.update(('empty:'+key+'='+str(cap)+'\n').encode()); continue
                    gate('cap_monotonic:'+key,cv*N*low-cap*cap)
                    gate('variance_lower:'+key,ownlo)
                    t=ownhi*low; b1=c-amp; b2=2*c-amp
                    # Closed phase cells use independent valid Poisson/Cantelli
                    # and common-background bounds; no pair monotonicity needed.
                    finite_kernel=F(0)
                    for mark_index,b in enumerate((b1,b2),1):
                        vals=[]
                        for uj in range(16):
                            ul=outerl+(outerh-outerl)*uj/16;uh=outerl+(outerh-outerl)*(uj+1)/16
                            d1=c*mark_index-d0-uh;d2=mark_index-amp+ul
                            gate('poisson_distance:'+key+':'+str(b)+':'+str(uj),min(d1,d2))
                            independent=sum(min(1/(d*d+t),poisson(ownhi*high/(amp*amp),d/amp)/(ownhi*low))for d in(d1,d2))
                            alpha=c*mark_index-2*d0-uh
                            beta=mark_index-amp-d0+ul
                            gate('common_distances:'+key+':'+str(mark_index)+':'+str(uj),min(alpha,beta))
                            midpoint=(beta-alpha)/2
                            center=max(-t/beta,min(midpoint,t/alpha))
                            radius=min(center+alpha,beta-center)
                            gate('common_radius:'+key+':'+str(mark_index)+':'+str(uj),radius)
                            common=(1+center*center/t)/(radius*radius)
                            vals.append(min(independent,common))
                        finite_kernel+=max(vals)
                    # All indices >=3: fourth moments, then convex midpoint sum.
                    tail_kernel=(amp*amp+3*ownhi*high)*sum(1/(3*c*(F(5,2)*c-amp-u)**3) for u in (outerh,-outerl))
                    kernel=finite_kernel+tail_kernel
                    z=min(F('.849'),rootup(ownhi*kernel*cv*cap/(cv*N*low+cap*cap)))
                    gate('mark_positive:'+key,z); gate('mark_upper:'+key,F('.85')-z);gate('mark_probability:'+key,1-z*high)
                    # Closed rational phase cells; each bound dominates the whole cell.
                    cachekey=(pi,bi,hj,outerl,outerh)
                    if cachekey not in phase_cache:
                        b=pu-min(hqs); candidates=[]
                        for ui in range(64):
                            ul=outerl+(outerh-outerl)*ui/64; uh=outerl+(outerh-outerl)*(ui+1)/64
                            rising=max(F(0),b+uh-1)/(c-uh)**2
                            falling=max(F(0),b+uh)/(c+min(ul,c/3))**2
                            candidates.append(rising+falling)
                        phase_cache[cachekey]=max(candidates)
                    third=rootup(amp*amp+3*ownhi*high)
                    gate('third_root:'+key,third*third-amp*amp-3*ownhi*high)
                    curvature=ownhi/v*(phase_cache[cachekey]+third/(2*c-F(1,2))**3)
                    rate=(cfg['rate_profile'][bi]if 'rate_profile'in cfg else cfg['rate'])*ownlo
                    if 'joint_d0' in cfg:
                        span=amp+d0;xx=F('3.14159')*span
                        sine=xx-xx**3/6+xx**5/120-xx**7/5040
                        gate('joint_sine_positive:'+key,sine)
                        rate=max(rate,2*sine*sine/span**2*ownlo)
                    gate('harmonic_domain:'+key,3-rate*high)
                    gain=F(1000,4553)*(rate**3*low**2/6-rate**4*low**3/24+rate**5*low**4/120-rate**6*low**5/720)
                    gate('harmonic_gain:'+key,gain)
                    # Signed Gaussian correction u-f(u), retaining the actual delta=h-u.
                    hcap=max(hqs)
                    if outerl>=0:
                        vertex=max(outerl,min(outerh,hcap))
                        G=max(F(0),2*hcap*vertex-vertex*vertex)
                        normal_constant=a/(2*v)
                        normal_inverse=a*(G/(2*v)+zeta)
                    elif outerh<=0:
                        vertex=max(F(0),min(a,hcap+a))
                        G=2*(hcap+a)*vertex-vertex*vertex
                        eta=G/(2*v)+zeta
                        gate('negative_gaussian_variance:'+key,N*v-dd*dd)
                        gate('negative_gaussian_denominator:'+key,N-eta)
                        normal_constant=F(0)
                        normal_inverse=a*eta/(1-eta/N)
                    else:raise ArithmeticError('Phase cell crosses zero')
                    if normal_constant<0 or normal_inverse<0:raise ArithmeticError('Nonnegative signed Gaussian coefficients')
                    for lam in (low,high):
                        suffix=key+':'+str(lam)
                        harmonic=F(1000,4553)*rate-F(500,4553)*rate*rate*lam+gain
                        bracket=z+ownhi*kernel/z*cv*cap/(cv*N*lam+cap*cap)-harmonic
                        inv=curvature+normal_constant+normal_inverse/lam+cfg['repair_normal']*dpositive-repair
                        # Fixed n=N: both signs are covered by the proved upper mass bound1.
                        # No floor replacement of n is used in this finite-index variant.
                        score=max(mass*bracket,bracket)+max(inv/N,inv/42)
                        rb=(1-2*pu*(1-pu))/rootup(pu*(1-pu))
                        gate('finite_binomial_gap:'+suffix,rb*cfg['epsilon']/high-score)
                        needed=high*score/rb
                        if 'needed_gap'not in maxima or needed>maxima['needed_gap']:
                            maxima['needed_gap']=needed
                            maxima['needed_location']=dict(H=[hl,hh],phase=[outerl,outerh],noise=[low,high],endpoint=lam,bracket=bracket,inverse=inv)
                        # Record the required per-p Bernoulli gap; no positivity verdict here.
                        endpoint_count+=1
                        if 'score' not in maxima or score>maxima['score']: maxima['score']=score
                    choices.append([pi,bi,hj,oi,str(z)])
                a=whole_a
    if len(choices)*2!=endpoint_count or len(choices)+empty_count!=pc*bands*hc*cfg["outer_phase_cells"]:
        raise ArithmeticError('incomplete closed cover')
    proof={'schema':contract['schema'],'contract':contract,'mark_count':len(choices),'marks_sha256':hashlib.sha256(canonical(choices)).hexdigest()}
    report={'status':'PASS_EXACT_FINITE_LEFT40_42_LOW_ROW', 'failed_gates':failures,'gates':gate_count,
        'endpoints':endpoint_count,'feasible_cells':len(choices),'empty_cells':empty_count,
        'phase_envelope_cells':len(phase_cache)*64,'gate_sha256':digest.hexdigest(),
        'needed_location':maxima.get('needed_location'),'required_binomial_gap':str(max(F(0),maxima.get('needed_gap',F(0)))),'required_binomial_gap_decimal':float(max(F(0),maxima.get('needed_gap',F(0)))),'worst_score':str(maxima.get('score')),'worst_score_decimal':float(maxima['score'])if 'score'in maxima else None,
        'minimum_reserves':{k:str(v) for k,v in minima.items()},
        'scope':'Finite n40..42 on frozen actual-law target resources, joint gap, amplitude profiles, and accepted finite binomial gap; acquisition is a separate bound interface.'}
    return proof,report
