"""Exact fixed LEFT40 LOW execution on one declared disjoint row block."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
from central42_contract import read,selected
from central42_kernel import evaluate
HERE=Path(__file__).parent
PARTS={'a':(0,17),'b':(17,34),'c':(34,49)}
def run(part):
 if part not in PARTS:raise ValueError('Fixed part')
 lo,hi=PARTS[part];out=HERE/'low_rows';out.mkdir(exist_ok=True);rows=[]
 for r in read():
  if not lo<=r['index']<hi or F(r['lambda_max'])<=F('.0925'):continue
  for sign in(-1,1):
   dest=out/('row_%02d_%s.json'%(r['index'],'minus'if sign<0 else'plus'))
   if dest.exists():raise FileExistsError(dest)
   p,report=evaluate(selected(r,sign,8,8));obj=dict(index=r['index'],sign=sign,proof=p,report=report)
   dest.write_text(json.dumps(obj,default=str,indent=2)+'\n')
   item=dict(index=r['index'],sign=sign,file=dest.name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest());rows.append(item)
   print(json.dumps(dict(**item,status='PASS_EXACT_FINITE_GAP_ROW',worst=report['worst_score_decimal'],gates=report['gates'])),flush=True)
 index=HERE/('low40_index_'+part+'.json')
 index.write_text(json.dumps(dict(schema='FINITE_LEFT40_42_LOW_COVER_V1',part=part,rows=rows),indent=2)+'\n')
 print(json.dumps(dict(status='PASS_EXACT_LOW_PART',part=part,index_sha256=hashlib.sha256(index.read_bytes()).hexdigest())),flush=True)
