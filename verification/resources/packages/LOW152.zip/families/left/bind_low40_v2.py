"""Bind exact disjoint LOW runs, their logged sources, and complete coverage."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys,copy
from central42_contract import read,selected
from execute_low40 import PARTS
HERE=Path(__file__).parent
ROOT=HERE.parents[3]
def need(x,s):
 if not x:raise ValueError(s)
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'Duplicate JSON key');d[k]=v
 return d
def check(obj,load=True):
 need(type(obj)is dict and set(obj)=={'schema','rows'}and obj['schema']=='FINITE_LEFT40_42_LOW_COMPLETE_V1','Fixed schema')
 expected=[(r,sg)for r in read()if F(r['lambda_max'])>F('.0925')for sg in(-1,1)]
 need(type(obj['rows'])is list and len(obj['rows'])==len(expected),'Complete signed row count')
 total=0;worst=F(0);digest=sha256()
 for e,(row,sg)in zip(obj['rows'],expected):
  i=row['index'];name='row_%02d_%s.json'%(i,'minus'if sg<0 else'plus')
  need(type(e)is dict and set(e)=={'index','sign','file','sha256'},'Exact index fields')
  need(type(e['index'])is int and type(e['sign'])is int and(e['index'],e['sign'])==(i,sg),'Strict ordered labels')
  need(e['file']==name and type(e['sha256'])is str and len(e['sha256'])==64,'Fixed row file')
  if not load:continue
  blob=(HERE/'low_rows'/name).read_bytes();need(sha256(blob).hexdigest()==e['sha256'],'Bound row hash')
  o=json.loads(blob,object_pairs_hook=unique);need(type(o)is dict and set(o)=={'index','sign','proof','report'},'Row fields')
  need(type(o['index'])is int and type(o['sign'])is int and(o['index'],o['sign'])==(i,sg),'Row labels')
  cfg=selected(row,sg,8,8);p=o['proof'];r=o['report'];c=p['contract']
  need(c['configuration_sha256']==sha256(json.dumps(cfg,default=str,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'All fixed scalar and array configuration')
  need(all(type(r[k])is int and r[k]>=0 for k in('gates','endpoints','feasible_cells','empty_cells','phase_envelope_cells')),'Integer counters')
  need(p['mark_count']==r['feasible_cells'] and 2*r['feasible_cells']==r['endpoints'],'Endpoint multiplicity')
  need(r['feasible_cells']+r['empty_cells']==cfg['bands']*8*8,'Complete phase/noise grid')
  need(r['status']=='PASS_EXACT_FINITE_LEFT40_42_LOW_ROW'and r['failed_gates']=={},'Exact arithmetic status')
  need(all(F(v)>0 for v in r['minimum_reserves'].values()),'Positive exact gates')
  if r['feasible_cells']:need('finite_binomial_gap' in r['minimum_reserves'],'Actual finite-gap gate present')
  else:need(r['endpoints']==0 and r['empty_cells']==cfg['bands']*8*8,'Entire row excluded by strict moment cap')
  need(F(r['required_binomial_gap'])<cfg['epsilon'],'Strict finite-binomial gap')
  total+=r['gates'];worst=max(worst,F(r['required_binomial_gap']));digest.update(blob)
 return dict(rows=len(expected),strict_gates=total,maximum_required_gap=str(worst),row_digest=digest.hexdigest())
def provenance():
 rows=[];metas={}
 for part,(lo,hi)in PARTS.items():
  run='actual_left40_low_execute_'+part+'01';meta=ROOT/('runs/toward40_20261007/local/'+run+'/metadata.json');data=json.loads(meta.read_text())
  need(data['returncode']==0 and data['command'][-1]=='execute_low40_'+part+'.py','Named successful exact executor')
  for name,h in data['input_sha256'].items():need(sha256((HERE/name).read_bytes()).hexdigest()==h,'Unchanged arithmetic input '+name)
  need('execute_low40_'+part+'.py'in data['input_sha256'],'Executed driver hash captured')
  for ch in('stdout','stderr'):need(sha256((meta.parent/(ch+'.txt')).read_bytes()).hexdigest()==data[ch+'_sha256'],'Captured output integrity')
  outputs=[json.loads(x)for x in(meta.parent/'stdout.txt').read_text().splitlines()]
  index=HERE/('low40_index_'+part+'.json');o=json.loads(index.read_text(),object_pairs_hook=unique)
  need(outputs[-1]==dict(status='PASS_EXACT_LOW_PART',part=part,index_sha256=sha256(index.read_bytes()).hexdigest()),'Index bound to fresh exact stdout')
  need(o['schema']=='FINITE_LEFT40_42_LOW_COVER_V1'and o['part']==part,'Part schema')
  need(len(outputs)==len(o['rows'])+1,'No omitted row output')
  for e,out in zip(o['rows'],outputs):
   need(all(e[k]==out[k]for k in e),'Row hash bound to exact stdout');need(lo<=e['index']<hi,'Disjoint part')
  rows.extend(o['rows']);metas[part]=sha256(meta.read_bytes()).hexdigest()
 return dict(schema='FINITE_LEFT40_42_LOW_COMPLETE_V1',rows=rows),metas
def controls(obj):
 tests=[]
 for name,fn in [('missing',lambda o:o['rows'].pop()),('duplicate',lambda o:o['rows'].__setitem__(1,o['rows'][0])),('reordered',lambda o:o['rows'].reverse()),('boolean_index',lambda o:o['rows'][0].update(index=False)),('boolean_sign',lambda o:o['rows'][1].update(sign=True)),('extra_scope',lambda o:o.update(N=39)),('path_traversal',lambda o:o['rows'][0].update(file='../bad.json'))]:
  bad=copy.deepcopy(obj);fn(bad)
  try:check(bad,load=False)
  except ValueError:tests.append(name)
  else:raise ValueError('Invalid cover accepted '+name)
 bad=copy.deepcopy(obj);bad['rows'][0]['sha256']='0'*64
 try:check(bad)
 except ValueError:tests.append('corrupted_row_hash')
 else:raise ValueError('Corrupted row accepted')
 try:json.loads('{"a":1,"a":2}',object_pairs_hook=unique)
 except ValueError:tests.append('duplicate_JSON_key')
 else:raise ValueError('Duplicate JSON key accepted')
 return tests
if __name__=='__main__':
 need(not sys.flags.optimize and __debug__ and len(sys.argv)==1,'Fixed unoptimized binding')
 obj,metas=provenance();out=check(obj);out.update(status='PASS_BINDING_OF_FRESH_EXACT_FINITE_LEFT40_42_LOW',negative_controls=controls(obj),arithmetic_metadata_sha256=metas)
 print(json.dumps(out,indent=2))
