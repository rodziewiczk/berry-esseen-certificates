"""Fresh actual-index support for both base and selected patch schedules."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
HERE=Path(__file__).resolve().parent;BASE=HERE.parent.parent;ROOT=BASE.parent
SRC=ROOT/'threshold31_20261008/entry/sharp31_b1_exact';sys.path.insert(0,str(SRC))
import direct_gaussian_support as ds
files={}
def need(x,w):
 if not x:raise ValueError(w)
def bind(p):
 h=sha256(p.read_bytes()).hexdigest();files[str(p.relative_to(ROOT))]=h;return h
def read(p):bind(p);return json.loads(p.read_text())
def main():
 need(__debug__ and not sys.flags.optimize,'ordinary exact runtime')
 ext=read(HERE/'B12_UNIFORM_SOURCE_EXTENSION_CHECKED.json');need(ext['status']=='PASS_B12_UNIFORM_SOURCE_COMPARISON','explicit source extension')
 for name in('direct_gaussian_support.py','small_index_support.py','finite_binomial_core.py','heat_support50.py'):bind(SRC/name)
 bind(Path(__file__))
 out=dict(status='PARTIAL_ACTUAL_SUPPORT_NOT_BRIDGE',rows=[],failures=[])
 for branch in(1,2):
  records=[]
  def walk(x,path):
   if isinstance(x,dict):
    if all(k in x for k in['gaussian','ray_rows','radius','rho_upper','beta_interval']):records.append((path,x))
    for k,v in x.items():walk(v,path+'/'+k)
   elif isinstance(x,list):
    for k,v in enumerate(x):walk(v,path+'/'+str(k))
  for kind in('exact','local_patch'):walk(read(ROOT/f'threshold31_20261008/entry/sharp31_b{branch}_{kind}/resources31_proof.json'),'/'+kind)
  need(len(records)==(34 if branch==1 else 54),'all base and patch support acquisitions')
  for n in(32,33,34):
   v=n-1;cap=ds.root(F(n,v))[1]*(F('.40974')+F(1,15*v)+F(2,25*v)/ds.root(F(v))[0]);need(cap<F(432313,10**6),'actual owncap')
   row=dict(branch=branch,n=n,q='0',owncap_upper=str(cap),support=[]);out['rows'].append(row)
   for path,old in records:
    need(old['n']==31 and old['K']=='0','fixed floor support profile')
    try:z=ds.target(n,F(0),F(old['radius']),F(0),sign=old['support_sign'],rho=F(old['rho_upper']),beta_lower=F(old['beta_interval'][0]),beta_upper=F(old['beta_interval'][1]),mesh=old['gaussian']['mesh'])
    except(ValueError,AssertionError)as exc:out['failures'].append(dict(branch=branch,n=n,path=path,error=repr(exc)))
    else:row['support'].append(dict(source_path=path,source_sha256=sha256(json.dumps(old,sort_keys=True,separators=(',',':')).encode()).hexdigest(),proof=z))
   (HERE/'SUPPORT_PROGRESS.json').write_text(json.dumps(out,indent=2)+'\n');print('ACTUAL_B12_SUPPORT_ROW',branch,n,len(row['support']),len(out['failures']),flush=True)
 out['status']='PASS_264_ACTUAL_B12_SUPPORT_CALLS_CONDITIONAL'if not out['failures']else'INCOMPLETE_ACTUAL_SUPPORT_EXPLICIT_FAILURES'
 out['scope']='Conditional on each sharp predecessor C_(n-1)<CE. All actual initial/intermediate/local support calls are replayed; resource composition and actual count comparisons remain separate.'
 out['files_sha256']=files
 p=HERE/'B12_ACTUAL_SUPPORT_CHECKED.json';need(not p.exists(),'fresh output');p.write_text(json.dumps(out,indent=2)+'\n');print(out['status'],flush=True)
if __name__=='__main__':main()
