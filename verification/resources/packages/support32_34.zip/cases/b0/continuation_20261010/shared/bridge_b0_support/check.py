"""Fresh actual-index support at every B0 floor31 support call.

Conditional on an actual positive maximizer and C_(m-1)<CE for each bridge.
This is not a complete uniform-resource interpretation or a count theorem.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys,time
HERE=Path(__file__).resolve().parent;SHARED=HERE.parent;BASE=SHARED.parent
ROOT=BASE.parent
SOURCE=ROOT/'threshold31_20261008/entry/sharp31_b0_exact';sys.path.insert(0,str(SOURCE))
import direct_gaussian_support as ds
FILES={}
def bind(p):
 h=sha256(p.read_bytes()).hexdigest();FILES[str(p.relative_to(ROOT))]=h;return h
def read(p):bind(p);return json.loads(p.read_text())
def need(ok,s):
 if not ok:raise ValueError(s)
def main():
 need(__debug__ and not sys.flags.optimize,'ordinary exact runtime')
 composed=read(HERE/'B0_UNIFORM_SOURCE_EXTENSION_CHECKED.json')
 proof=read(SOURCE/'resources31_proof.json')
 records=[]
 def walk(x,path):
  if isinstance(x,dict):
   if all(k in x for k in ['gaussian','ray_rows','radius','rho_upper','beta_interval']):records.append((path,x))
   for k,v in x.items():walk(v,path+'/'+k)
  elif isinstance(x,list):
   for k,v in enumerate(x):walk(v,path+'/'+str(k))
 walk(proof,'')
 need(len(records)==31 and records[0][0]=='/initial_support','every explicit support acquisition')
 for n in ['direct_gaussian_support.py','small_index_support.py','finite_binomial_core.py','heat_support50.py']:bind(SOURCE/n)
 for n in ['INITIAL31_UNIFORM_INTERPRETATION.md','UNIFORM_DOWNSTREAM_RESOURCE_AUDIT.md']:bind(BASE/'audit35'/n)
 bind(Path(__file__))
 out=dict(status='PARTIAL_EXACT_ACTUAL_INDEX_SUPPORT_NOT_BRIDGE',source_support_calls=31,floor=31,predecessor='For each actual m, assume C_(m-1)<CE, hence same-law q=0 at an attained contrary witness.',rows=[],failures=[])
 for m in [32,33,34]:
  # Support-free smoothing against hypothetical sharp predecessor at m-1.
  v=m-1;capraw=ds.root(F(m,v))[1]*(F('.40974')+F(1,15*v)+F(2,25*v)/ds.root(F(v))[0])
  need(capraw<F(432313,10**6),'actual owncap below retained floor31 input')
  row=dict(n=m,q='0',owncap_upper=str(capraw),owncap_bound='432313/1000000',support=[])
  out['rows'].append(row)
  for j,(path,old) in enumerate(records):
   need(old['n']==31 and old['K']=='0','literal old sharp support profile')
   try:
    z=ds.target(m,F(0),F(old['radius']),F(0),sign=old['support_sign'],rho=F(old['rho_upper']),beta_lower=F(old['beta_interval'][0]),beta_upper=F(old['beta_interval'][1]),mesh=old['gaussian']['mesh'])
   except(ValueError,AssertionError)as exc:
    out['failures'].append(dict(n=m,path=path,reason=repr(exc)))
    print('FAILED_ACTUAL_SUPPORT',m,j,path,repr(exc),flush=True)
   else:
    row['support'].append(dict(source_path=path,source_sha256=sha256(json.dumps(old,sort_keys=True,separators=(',',':')).encode()).hexdigest(),proof=z))
    print('CHECKED_ACTUAL_SUPPORT',m,j,path,old['radius'],old['support_sign'],flush=True)
   (HERE/'PROGRESS.json').write_text(json.dumps(out,indent=2)+'\n')
 if out['failures']:
  out['status']='INCOMPLETE_SUPPORT_TRANSFER_EXPLICIT_FAILURES'
 else:
  out['status']='PASS_93_ACTUAL_INDEX_SUPPORT_CALLS_CONDITIONAL'
 out['scope']='Actual32–34 own-score upper and every explicit support acquisition in the floor31 B0 resource proof, under each sharp predecessor premise. Complete uniform source interpretation and actual-index finite counts remain separate; no cutoff follows.'
 out['files_sha256']=FILES
 dest=HERE/'BRIDGE_B0_SUPPORT_CHECKED.json';need(not dest.exists(),'fresh support result')
 dest.write_text(json.dumps(out,indent=2)+'\n');print(out['status'],len(out['failures']),flush=True)
if __name__=='__main__':main()
