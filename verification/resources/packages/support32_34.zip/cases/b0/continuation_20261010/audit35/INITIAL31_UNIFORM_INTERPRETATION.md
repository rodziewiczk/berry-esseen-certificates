# Conditional uniform interpretation of the exact INITIAL31 enclosure

This is a mathematical reuse route, not a claim that the fixed-index receipt already proves a bridge. The original artifacts are unchanged.

## Proposed statement

Let N=31. Assume an attained positive closed maximizing law at an actual integer m>=N satisfies C_m>=CE, the same rho branch and support radii as a selected INITIAL31 branch, and the branch's declared score cap (at most .432313). Subject to the retained analytic enclosure formulas, the eight-pass INITIAL31 computation can be interpreted as a **uniform floor-N enclosure** for that law.

The needed invariant after a pass is stronger than a plain unweighted defect bound:

    raw remainder <= raw_stored,
    m * D_actual <= N * d_stored.

Consequently D_actual<=d_stored. A later computation that exports a noise allowance proportional to N*d must use the weighted invariant, not multiply an arbitrary unweighted bound by N.

## Source map and argument

Main source: `threshold31_20261008/root/exact_initial31/initial_local33_charged.py` (I below).

1. `exact_initial_branches.py`:18–21 fixes n=nmax=31 and K=0. I:34 uses nmax only for c0=.4095+K/nmax. Thus the score lower endpoint is independent of the actual index in this sharp case.
2. Moment feasibility, sign-probability covers, support-deficit refinements, gap endpoint bounds, and moment cells in I:45–92 and I:104–136 do not use the index. They remain legitimate enclosures for the same rho branch and support. The coarse inequality D_actual<=d_stored is sufficient for their geometry.
3. I:93–103 uses low/high Fourier bounds evaluated at N. In `kernel.py`:79–83, a0=(N-1)/(2N) and b0=(45-M)(1-2/N)/96 increase with the actual index; their inverse powers and the root constant decrease. All additive constants are nonnegative. The extra L2/sqrt(N) also decreases. Therefore the floor-N triple remains valid.
4. `high_window_core.py`:17–18 checks 2*N*c>1 for every exponential term; lines 23–31 check the additional monotonicity gates. The six-term HIGH expression is explicitly designed for all indices above its input floor. Choosing the best complete window at N gives one valid uniform bound; one does not need the identity of the minimizing window to remain the same later.
5. I:137 uses phi_lo=.3988*(1-2.5*raw/N). Under the raw invariant, the actual lower density bound at m is at least this. Keeping the larger fixed interval [phi_lo,.4] is conservative. The same observation licenses I:150's extra phase curvature at N. Its coefficient .4095*rho_lo-d/15 is positive by a checked gate.
6. I:140–143 uses an own-score numerator raw/N - .3988*(1-2.5*raw/N)*D_lower/6. For fixed nonnegative raw,D_lower this increases with 1/N. It therefore bounds the actual numerator at m>=N from above; a negative floor-N numerator legitimately excludes a law at any such m.
7. I:151 subtracts max(K,N*(c-.40974))*rho_lo. With K=0, actual m*(c-CE)*rho is at least max(0,N*(c-.40974))*rho_lo. The floor subtraction is valid. The breakpoint c=.40974 is explicitly included in I:145. On each side the subtraction is affine, preserving the score-corner convexity argument.
8. I:153 multiplies the largest budget by 15000/(997*N). The underlying bound is m*D_actual <= (15000/997)*budget. Thus the stored value proves m*D_actual<=N*d_stored, exactly the required weighted invariant. Taking minima with the previous defect in I:155 preserves that invariant, as does taking maxima across every contributing moment cell in I:163.
9. The raw and phase outputs also remain valid at the floor because their coefficient enclosures were proved pointwise for all actual m>=N. No claim is needed that the rounded output of rerunning the program at m would be numerically monotone.

The induction uses the same fixed moment-cell construction with the stored invariants; it does not rely on comparing independently rerun adaptive covers at different indices.

## What must still be proved before using this as a bridge

* Acquire the branch support radii for each intended index. `direct_gaussian_support.py`:58–74 performs a Gaussian-line calculation at a fixed index. No all-index monotonicity of that entire line calculation has been proved in this note. A support check at 31 is not by itself a support check at 32–34.
* Supply the own-score cap independently at the intended index, and acquire the correct contact/predecessor allowance for the support calculation. The proposed q<=.31 premise is not consumed by INITIAL itself, but is relevant to acquiring support.
* Trace the downstream resource refinement from INITIAL to the count contract. This note covers the INITIAL enclosure, not every later branch-specific acquisition callback or changed support radius.
* Create a separately named interpretation/interface artifact binding the exact INITIAL source and proof hashes, recording the weighted invariant and intended index range. Do not relabel `SHARP31_BRANCH_INITIAL_V1` or edit its profile into an apparent historical replay.
* Complete an exact count proof at each bridge index. A floating count or resource discovery record remains discovery evidence only.

Potential value: if the subsequent resource refinement also has a verified uniform floor-N interpretation, support acquisition and bridge counts may suffice without repeating every INITIAL arithmetic pass. Potential failure point: silently treating stored `D` as an ordinary unweighted bound while importing a lambda allowance that needs mD<=ND would invalidate the reuse.
