# Conditional floor-31 interpretation of downstream resource acquisition

Date: 2026-10-10. This continues `INITIAL31_UNIFORM_INTERPRETATION.md`.
The files audited below are the copied branch-3 sources in
`continuation_20261010/shared/b3_resource_replay`; originals are unchanged.
`C` denotes `candidate_charged_score_v2.py`, `K` denotes
`contracted_kernel.py`, `R` denotes `resource31_core.py`.

**Assessment: a floor-N interpretation of the traced downstream formulas is viable, conditional on every support contraction being acquired at the actual index. However, changing only a count configuration's n while preserving all other guards is invalid: its affine noise price and phase-budget normalization must agree.** This note does not certify the numerical replay or any bridge count.

## Invariants and the physical variance

Fix floor `N=31`; let actual index `m>=N`. Retain

```
raw_actual <= raw_stored,
m * D_actual <= N * d_stored,
H_actual = sqrt(m) * z_actual.
```

The geometric variance is `s=theta*p*(1-p)/(1-theta)` and the count variance
is `lambda_m=m*s`. Moment geometry can use the weaker
`D_actual<=d_stored`. Every stored moment/endpoint bound continues to refer
to the same law.

## Source-by-source monotonicity

- C:34–46, K:196–246, `signed_variance_resource.py`:3–42 and
  `geometric_moment_both.py`:9–39 contain no actual-index factor. They use
  the weaker defect cap and the acquired support/moment/endpoint bounds.
  Their retained algebra and positivity gates remain necessary.
- C:47 uses `min(cap,.40974+raw/N)`. This is conservative for actual
  `m>=N`. The score floor in C:30 is `.4095` because `K=0`.
- K:65–85 gives nonnegative LOW coefficients, with `a0=(n-1)/(2n)` and
  `b0=(45-M)(1-2/n)/96` increasing in n. The reciprocals and square-root
  prefactors decrease. In `paired_extended.py`:27–43, the factor
  `(n/(n-1))^(3/2)`, every `1/(n-1)` term, and the remainder decrease;
  each multiplied coefficient is nonnegative by retained gates. Thus the
  values at N bound the actual-index coefficients, without claiming that
  independently rounded/adaptively rerun outputs must be monotone.
- `high_window_core.py`:17–38 explicitly gates the exponential-tail
  monotonicity. A complete window chosen at N remains valid for every
  m>=N. In its improved zero-piece (line 28), the function
  `sqrt(x)*exp(-x)*(x+2)/(x*x+4*x+2)` decreases for `x>=1/4`: its logarithmic
  derivative has numerator `4-10*x-22*x*x-13*x**3-2*x**4`, already negative
  at 1/4 and decreasing. The other gated pieces have decreasing positive
  factors. The choice of best window need not remain the best later.
- In K:265, the floor-N density interval `[phi_N,.4]` contains the actual
  one. Its linear maxima therefore remain valid. K:273's general curvature
  is nondecreasing in phi: its phi coefficient is
  `(3.16*rho-3-d+max(d-.16,0))/2 >= 0` for rho>=1. This sign is essential;
  simply saying every occurrence of phi increases would be insufficient.
- The installed paired correction also handles that sign correctly:
  `corrected_phase_callback_extended.py`:20–23 uses
  `C*rho+min(phi_N*g0,.4*g0)/2`. If g0<0 its minimum is the fixed `.4*g0`;
  if g0>=0 it increases with phi. Thus the N curvature is conservative.
- The phase rebate in C:54,69,89 has positive coefficient by its gates;
  using N and the stored d makes it no larger than the actual rebate.
  C:70 and R:91 subtract `N*max(0,C-.40974)*rho`, no more than the available
  actual charge `m*(C-CE)*rho`. Including the `.40974` breakpoint preserves
  the piecewise corner argument.
- C:74 updates d by `(15000/(997*N))*budget`. This preserves the weighted
  invariant, not merely `D<=d`. Taking minima with prior d and local INITIAL
  outputs in `local31_core.py`:60–64 preserves it as well.
- C:84–93 and R:81–100 export the same pointwise corner polynomials in
  `H_actual=sqrt(m)*z`. The correct physical interpretation is
  `D_actual <= (15000/(997*m))*max Q_N(H_actual)`.
  `charged_phase_cap.py`:17–27 uses only positivity of this normalization,
  so its root-based H caps still follow.

These checks trace the n dependence of the formulas; they do not constitute
a fresh independent derivation of every imported moment or Fourier lemma.

## Affine resource scaling: the required correction

At floor N, the exported prices in C:80–81 and R:101 satisfy

```
D_actual >= b + g*inward + h_N*(N*s),
```

where `b>=0`, `g>0`, `h_N>0` depend on the same acquired geometry. At actual
m this is a physical-D inequality with price

```
h_m = (N/m)*h_N,
D_actual >= b + g*inward + h_m*lambda_m.
```

Combining the weighted defect invariant and nonnegative b,g also gives

```
d_stored >= (m/N)*D_actual
         >= b + g*inward + h_N*lambda_m.
```

Consequently the original joint resource
`inward/d0 + lambda_m/Lambda <= 1` remains valid, with the original
`d0=(d-b)/g` and `Lambda=(d-b)/h_N`.

But those two displayed inequalities concern different defect quantities.
In the copied count kernel
`repair31/sharp31_b1_joint_exact/exact35_core.py`:16, `quadratic_cap` divides
by `cfg['n']`, hence bounds **physical D**. Its lines 216–220 then subtract
`noise_charge*lambda` from that cap. At a changed index m, keeping
`noise_charge=h_N` would overcharge the variance by m/N. This is a concrete
unsound shortcut, not merely an unreviewed formula.

Two consistent integration choices are available:

1. Keep physical D in the count kernel. Set `noise_charge=(N/m)*h_N`, retain
   b and g, and use the actual-index quadratic denominator m. The scalar D
   cap may safely improve to `(N/m)*d_stored`. The old d0 and Lambda remain
   valid joint bounds.
2. Use a separately named normalized defect `Dstar=(m/N)*D_actual`. Keep
   h_N and the quadratic denominator N. Then `D_actual<=Dstar` makes
   comparisons of physical sharp-D lower bounds against a Dstar upper cap
   conservative, albeit weaker. This normalization must be explicit; it
   cannot be obtained by changing only `cfg['n']` in the current code.

An exact rational regression of the scaling and its failure when omitted is
included in `check_uniform_resource_scaling.py`. The witness is an abstract
resource configuration, not a claimed contact-law counterexample.

## Harmonic theta refinement: valid but rename the intermediate

R:135–137 computes, at N,

```
lam_N = 1/(1/Lambda + 1/(N*B*d0)),
theta_N = lam_N/(N*vmin+lam_N),
B = max(A0,A1)*max(p_upper,1-p_lower).
```

At actual m, variance/support geometry proves
`lam_m=1/(1/Lambda+1/(m*B*d0))`, which **increases** with m. Therefore the
history field `lambda_geometry_cap=lam_N` is not by itself a uniform cap on
lambda_m. However, the only operational use here is theta, and

```
lam_m/(m*vmin+lam_m)
  = 1/(1+m*vmin/Lambda+vmin/(B*d0))
  <= theta_N.
```

So the actual theta update remains valid. Do not export the stored
`lambda_geometry_cap` as a new all-index lambda bound. Its floor-index
meaning must be explicit in a uniform receipt.

## Still required

Every call to `direct_gaussian_support.target(N,...)` in R:74,125 and
`local31_core.py`:20 is index-specific. Every initial and refined radius used
by the source path must be acquired at each bridge index, with the same
same-law moments and valid contact allowance. Checking only the final radii
after assuming intermediate moment improvements would be circular. A fixed
Gaussian-line result at N is not automatically monotone.

The uniform interpretation must also bind its own-cap/contact premises,
complete source hashes, exact source replay, all index-specific support
checks, and the corrected downstream count configuration. The existing
`resource31_core.interface`:149 deliberately restricts n=31; a new named
bridge interface is required. Nothing here licenses relabeling its receipt
or relaxing that gate in the archived source.
