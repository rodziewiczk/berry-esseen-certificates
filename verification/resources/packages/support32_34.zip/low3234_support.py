"""Two whole fresh actual32..34 support suites,195 internal exact evaluations.

Full low B0/B1 floor31 occurrences are retained. Only the explicit B2 loop arm
is omitted in one newly identified source projection. No COUNT is rerun and no
historical support output or source-extension document is mathematical authority.
"""
from pathlib import Path
from hashlib import sha256,file_digest
from fractions import Fraction as F
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,shutil,subprocess,sys,time
HERE=Path(__file__).resolve().parent
def need(ok,message):
 if not ok:raise ValueError(message)
def enc(value):return(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('ascii')
def digest(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'Complete ordinary input/result')
 with p.open('rb')as stream:return file_digest(stream,'sha256').hexdigest()
def read(path):
 def unique(pairs):
  out={}
  for k,v in pairs:need(k not in out,'Unique JSON keys');out[k]=v
  return out
 return json.loads(Path(path).read_bytes(),object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in()).throw(ValueError('Finite JSON')))
def same(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if type(a)is list:return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def verify_source():
 rows=read(HERE/'LOW3234-SOURCE-VERIFIED.json')['files']
 for name,pin in rows.items():need(digest(HERE/name)==pin,'Whole static source/input byte: '+name)
 return rows
def check_input(root,case):
 for name,pin in case['input_pins'].items():need(digest(root/name)==pin,'Every complete original mathematical input or explicit source projection')
def check_result(root,case):
 check_input(root,case);out=read(root/case['output']);rows=out['rows']
 need(out['status']==case['expected_status']and out['failures']==[],'Every native support succeeded; zero process exit alone is insufficient')
 need([r['n']for r in rows]==[32,33,34]and all(type(r['n'])is int for r in rows),'All actual indices explicitly, without monotonicity')
 if case['branch']==0:need(out['source_support_calls']==31 and out['floor']==31,'Whole B0 floor31 support suite')
 for row in rows:
  n=row['n'];need(row['q']=='0'and F(row['owncap_upper'])<F(432313,10**6),'Exact strict smoothing bound under each actual predecessor')
  if case['branch']==1:need(type(row['branch'])is int and row['branch']==1,'Only the explicit original low B1 branch')
  need(len(row['support'])==len(case['occurrences']),'Every complete signed support occurrence, including patch schedules')
  for current,source in zip(row['support'],case['occurrences']):
   need(current['source_path']==source['path']and current['source_sha256']==source['source_object_sha256'],'Whole original support object binding and ordered occurrence')
   proof=current['proof'];arg=source['parameters']
   need(proof['schema']=='DIRECT_SAME_LAW_CONTACT_SUPPORT_DISCOVERY_V1'and type(proof['n'])is int and proof['n']==n
        and proof['K']==proof['q_contact']=='0','Complete actual-index/K0/q0 support theorem scope')
   need(all(same(proof[k],arg[k])for k in('radius','support_sign','rho_upper','beta_interval')),'All original full support parameters retained')
   need(proof['gaussian']['n']==n and proof['gaussian']['mesh']==source['mesh']and proof['gaussian']['radius']==arg['radius'],'Whole Gaussian profile and original mesh')
   signs=[-1,1]if arg['support_sign']==0 else[arg['support_sign']]
   need([r['sign']for r in proof['ray_rows']]==signs and all(F(r[k])<0 for r in proof['ray_rows']for k in
     ('coefficient_at_R','contact_derivative_at_R','contact_derivative_slope_at_R','contact_upper')),'Every entire signed ray has all original strict gates')
 graph=out['files_sha256']
 need(set(graph)==set(case['input_pins'])and all(digest(root/name)==pin==case['input_pins'][name]for name,pin in graph.items()),'Complete actual native source/resource/extension/document graph')
 return out
def run_case(task,case,deadline):
 directory=task/('b'+str(case['branch']));root=directory/'capsule';shutil.copytree(HERE/case['root'],root);check_input(root,case)
 output=root/case['output'];need(not output.exists(),'A previous support PASS cannot be staged')
 logs=directory/'execution';logs.mkdir();argv=[sys.executable,'-B','-S',str(root/case['script'])]
 (logs/'ARGV.json').write_bytes(enc(dict(argv=argv,cwd=str(root/case['cwd']),deadline=deadline)))
 remaining=deadline-time.time();need(remaining>1,'Strict admitted absolute native horizon')
 with(logs/'stdout.txt').open('xb')as stdout,(logs/'stderr.txt').open('xb')as stderr:
  process=subprocess.run(argv,cwd=root/case['cwd'],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=remaining,check=False)
 need(type(process.returncode)is int and process.returncode==0 and(logs/'stderr.txt').stat().st_size==0,'Whole original native completed with no stderr')
 checked=check_result(root,case)
 result=dict(branch=case['branch'],actual_indices=[32,33,34],native_calls=1,target_evaluations=case['target_evaluations'],
  source_script_sha256=digest(root/case['script']),result_sha256=digest(output),stdout_sha256=digest(logs/'stdout.txt'),stderr_sha256=digest(logs/'stderr.txt'),
  all_original_occurrences_checked=True,negative_controls_added_or_claimed=False,mathematical_acceptance=False)
 (directory/'CURRENT-COMPLETED.json').write_bytes(enc(result));return result
def main():
 p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('action',choices=['run']);p.add_argument('--task',type=Path,required=True)
 p.add_argument('--deadline',type=int,required=True);p.add_argument('--jobs',type=int,choices=[1,2],default=2);args=p.parse_args()
 before=verify_source();description=read(HERE/'LOW3234-DESCRIPTION.json')
 need(description['native_calls']==2 and description['target_evaluations']==195 and description['COUNT_calls']==0,'Exact low support-only packet')
 task=args.task.absolute();need(not task.exists(),'Exclusive fresh support task');task.mkdir(parents=True)
 deadline=min(args.deadline,int(time.time())+900);completed=[];errors=[]
 with ThreadPoolExecutor(max_workers=args.jobs)as pool:
  futures={pool.submit(run_case,task,case,deadline):case for case in description['cases']}
  for future in as_completed(futures):
   case=futures[future]
   try:completed.append(future.result())
   except Exception as error:errors.append(dict(branch=case['branch'],error=repr(error)))
 after=verify_source();need(before==after,'Whole static source/runtime-input closure unchanged')
 report=dict(schema='be.low3234-two-support-suites-observation/1',status='LOW3234_TWO_SUPPORT_SUITES_COMPLETED_CONDITIONAL'if len(completed)==2 and not errors else'LOW3234_SUPPORT_INCOMPLETE',
  completed=completed,errors=errors,native_calls_completed=len(completed),source_before=before,source_after=after,
  each_actual_sharp_predecessor_required=True,current_floor31_initial_resource_and_patch_licenses_required=True,
  source_extension_documents_are_conditional_references_only=True,COUNT_acceptance_granted=False,mathematical_acceptance=False,full_proof_pass=False)
 (task/'RESULT.json').write_bytes(enc(report));print(json.dumps(dict(status=report['status'],result_sha256=digest(task/'RESULT.json'),native_calls_completed=len(completed))))
 return 0 if not errors and len(completed)==2 else 1
if __name__=='__main__':raise SystemExit(main())
