"""Small standalone outward rational interval and elementary-function core.

No filesystem access, external package, floating arithmetic, or proof kernels.
"""
from fractions import Fraction as F
from math import isqrt,factorial,comb

GRID=10**24
PI_LO=F(3141592653589793238462643383279,10**30)
PI_HI=F(3141592653589793238462643383280,10**30)

def rational(x):
    if type(x)not in(int,F):raise TypeError('literal integer or Fraction required')
    return F(x)

def down(x):return F(x.numerator*GRID//x.denominator,GRID)
def up(x):return -down(-x)

class I:
    def __init__(self,l,h=None):
        lo,hi=l,h
        if type(lo)is I:
            if hi is not None:raise TypeError('copy does not accept another endpoint')
            self.lo,self.hi=lo.lo,lo.hi;return
        lo=rational(lo);hi=lo if hi is None else rational(hi)
        if lo>hi:raise ValueError('reversed interval')
        self.lo,self.hi=down(lo),up(hi)
    def __add__(self,other):
        o=I(other);return I(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,other):return self+-I(other)
    def __rsub__(self,other):return I(other)+-self
    def __mul__(self,other):
        o=I(other);v=[a*b for a in(self.lo,self.hi)for b in(o.lo,o.hi)]
        return I(min(v),max(v))
    __rmul__=__mul__
    def __truediv__(self,other):
        o=I(other)
        if o.lo<=0<=o.hi:raise ValueError('denominator interval includes zero')
        return self*I(1/o.hi,1/o.lo)
    def __rtruediv__(self,other):return I(other)/self
    def sq(self):
        return I(0 if self.lo<=0<=self.hi else min(self.lo*self.lo,self.hi*self.hi),max(self.lo*self.lo,self.hi*self.hi))
    def sqrt(self):
        if self.lo<0:raise ValueError('negative radicand')
        a=isqrt(self.lo.numerator*GRID*GRID//self.lo.denominator)
        b=isqrt(self.hi.numerator*GRID*GRID//self.hi.denominator)
        return I(F(a,GRID),F(b if F(b,GRID)**2==self.hi else b+1,GRID))
    def __pow__(self,n):
        if type(n)is not int or n<0:raise ValueError('nonnegative literal integer power required')
        if n==0:return I(1)
        if n%2==0:return self.sq()**(n//2)
        # Endpoint formula is exact and narrower than repeated signed products.
        return I(self.lo**n,self.hi**n)
    def intersect(self,lo,hi):
        lo=rational(lo);hi=rational(hi)
        if lo>hi:raise ValueError('reversed intersection domain')
        return I(max(self.lo,lo),min(self.hi,hi))
    def pair(self):return[str(self.lo),str(self.hi)]
    @property
    def l(self):return self.lo
    @property
    def h(self):return self.hi
    def pow(self,k):return self**k

PI=I(PI_LO,PI_HI)

def polynomial(coefficients,x):
    if type(coefficients)not in(list,tuple)or not coefficients:raise ValueError('nonempty ascending coefficient list required')
    x=I(x);ans=I(0)
    for c in reversed(coefficients):ans=ans*x+rational(c)
    return ans

def _trig(x,odd):
    x=I(x)
    if x.lo<-7 or x.hi>7:raise ValueError('trigonometric domain is [-7,7]')
    mid=(x.lo+x.hi)/2;rad=(x.hi-x.lo)/2
    m=I(mid);y=m.sq()
    # Taylor degrees64(cos) and65(sin); both adjacent zero coefficient
    # is included, so Lagrange errors are <=7^66/66! and7^67/67!.
    term=m if odd else I(1);ans=term
    for j in range(1,33):
        term=-term*y/((2*j+int(odd)-1)*(2*j+int(odd)))
        ans=ans+term
    order=67 if odd else 66
    error=F(7**order,factorial(order))
    return (ans+I(-rad-error,rad+error)).intersect(-1,1)

def sin(x):return _trig(x,True)
def cos(x):return _trig(x,False)

def _exp_minus_point(x):
    u=I(x)/16
    # Alternating series is decreasing term by term for0<=u<=7/16.
    # Degree32 is above exp(-u), degree33 below. Directed Horner
    # arithmetic already includes all rounding. Raise the positive bracket.
    even=polynomial([F((-1)**k,factorial(k))for k in range(33)],u)
    odd=polynomial([F((-1)**k,factorial(k))for k in range(34)],u)
    bracket=I(odd.lo,even.hi).intersect(0,1)
    return bracket**16

def exp_minus(x):
    x=I(x)
    if x.lo<0 or x.hi>7:raise ValueError('exp_minus domain is [0,7]')
    a=_exp_minus_point(x.hi);b=_exp_minus_point(x.lo)
    return I(a.lo,b.hi)

expminus=exp_minus

def _atan_inverse_bounds(k,terms):
    if type(k)is not int or k<2 or type(terms)is not int or terms<1:raise ValueError('positive inverse-tangent parameters required')
    total=sum(F((-1)**j,(2*j+1)*k**(2*j+1))for j in range(terms))
    next_term=F((-1)**terms,(2*terms+1)*k**(2*terms+1))
    return min(total,total+next_term),max(total,total+next_term)

def certify_pi():
    a,b=_atan_inverse_bounds(5,32);c,d=_atan_inverse_bounds(239,10)
    lo,hi=16*a-4*d,16*b-4*c
    if not PI_LO<lo<=hi<PI_HI:raise ArithmeticError('pi enclosure failed')
    return dict(status='PASS_MACHIN_RATIONAL_PI_BRACKET',declared=[str(PI_LO),str(PI_HI)],derived=[str(lo),str(hi)])

def bernstein_on_interval(coefficients,left,right):
    if type(coefficients)not in(list,tuple)or not coefficients:raise ValueError('coefficient list required')
    c=[rational(x)for x in coefficients];a=rational(left);b=rational(right)
    if not a<b:raise ValueError('strictly ordered Bernstein interval required')
    n=len(c)-1
    power=[sum(c[k]*comb(k,j)*a**(k-j)*(b-a)**j for k in range(j,n+1))for j in range(n+1)]
    return[sum(power[j]*F(comb(i,j),comb(n,j))for j in range(i+1))for i in range(n+1)]

def certify_cosine_kappa():
    # Q=(1-x²/2+x³/10-P16(x))/x³; removable at zero.
    c=[F(0)]*14;c[0]=F(1,10)
    for k in range(2,9):c[2*k-3]=F((-1)**(k+1),factorial(2*k))
    rows=[]
    for i in range(80):
        a,b=F(i,16),F(i+1,16);bs=bernstein_on_interval(c,a,b)
        if min(bs)<=0:raise ArithmeticError('cosine kappa Bernstein certificate failed')
        rows.append(dict(interval=[str(a),str(b)],minimum=str(min(bs))))
    return dict(status='PASS_GLOBAL_COSINE_ABSOLUTE_CUBIC_KAPPA_ONE_TENTH',kappa='1/10',coefficients=[str(x)for x in c],interval=[0,5],cells=rows,all_real_form='cos(x)<=1-x^2/2+abs(x)^3/10')
