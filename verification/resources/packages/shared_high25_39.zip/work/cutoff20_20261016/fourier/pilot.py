"""One exact closed rho strip; scope deliberately fixed to all standardized laws."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
import integrate as core

H=Path(__file__).resolve().parent;R=H.parents[2]
TARGET=F(4097,10000)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,msg):
    if not ok:raise ValueError(msg)

def parse(raw):
    need(type(raw)is dict and set(raw)=={'rho','c','tau','cells','scope'},'exact pilot schema')
    need(raw['scope']=='ALL_CENTERED_VARIANCE_ONE_LAWS','unconditional scope only')
    need(type(raw['rho'])is list and len(raw['rho'])==2 and all(type(x)is str for x in raw['rho']),'two rational rho strings')
    need(type(raw['c'])is str and type(raw['tau'])is str,'rational parameter strings')
    lo,hi=map(F,raw['rho']);c,tau=F(raw['c']),F(raw['tau']);cells=raw['cells']
    core.old.validate_parameters(core.NS,lo,hi,F(1),c,tau,cells)
    return lo,hi,c,tau,cells

def main():
    need(__debug__ and sys.flags.dont_write_bytecode and not sys.flags.optimize,'ordinary no-bytecode Python')
    need(len(sys.argv)==3,'parameter and output paths required')
    parameters,output=map(Path,sys.argv[1:]);need(not output.exists(),'new output only')
    manifest=json.loads((H/'MANIFEST.json').read_text())
    for p,h in manifest['files_sha256'].items():need(sha(R/p)==h,'source unchanged: '+p)
    raw=json.loads(parameters.read_text());lo,hi,c,tau,cells=parse(raw)
    # beta is decreasing, so this one rational LOWER endpoint works for the
    # entire rho interval. No conditional eta=beta assertion is made.
    beta_lower=((core.I(hi*hi+8).sqrt()-hi)/2).l
    need(beta_lower>0 and beta_lower*beta_lower+hi*beta_lower<=2,'rational beta lower certificate')
    report=core.calculate(lo,hi,F(1),beta_lower,c,tau,cells)
    rows=report['rows'];need([row['n']for row in rows]==list(core.NS),'literal whole n scope')
    for row in rows:
        total=sum(F(v)for v in row['terms'].values())
        bound=core.I(row['n']).sqrt().h*total/lo
        need(F(row['normalized_upper'])==bound,'independent reported normalization')
        row['target']=str(TARGET);row['strict_target_pass']=bound<TARGET
    result=dict(status='EXACT_PILOT_PASS'if all(x['strict_target_pass']for x in rows)else'EXACT_PILOT_NOT_CLOSED',
                mathematical_scope='All iid centered variance-one real laws with finite absolute third moment in the specified closed rho strip; n=20,...,24 only.',
                eta_upper='1',zeta_lower=str(beta_lower),parameters=raw,parameters_sha256=sha(parameters),
                manifest_sha256=sha(H/'MANIFEST.json'),**report)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    for p,h in manifest['files_sha256'].items():need(sha(R/p)==h,'source changed during pilot: '+p)

if __name__=='__main__':main()
