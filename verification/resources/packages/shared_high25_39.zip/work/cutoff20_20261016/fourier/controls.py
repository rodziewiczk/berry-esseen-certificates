"""Exact generic-n identities and malformed-interface controls, no integration."""
from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,sys
import batch,jet,integrate,pilot
from kernel import I,certify_pi
H=Path(__file__).resolve().parent;R=H.parents[2]

def main():
    assert __debug__ and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv)==2
    output=Path(sys.argv[1]);assert not output.exists()
    identities=0;negative=0
    # Independently expand the finite power sum: no division and no distinct-
    # argument hypothesis. Include zero, equality, and reversed arguments.
    for a in (F(0),F(1,3),F(1,2),F(1)):
        for b in (F(0),F(1,3),F(1,2),F(1)):
            values=batch.geometrics(I(a),I(b),batch.NS)
            powers=batch.powers(I(a),batch.NS)
            for n in batch.NS:
                direct=sum(a**j*b**(n-1-j)for j in range(n))
                assert values[n]>=direct and values[n]-direct<F(1,10**18)
                assert powers[n].l<=a**n<=powers[n].h
                identities+=2
    # Independent chain-rule fixtures at nontrivial actual sample sizes.
    for n in batch.NS:
        a=F(2,3);x=jet.J(a,1);y=x**n
        for got,want in ((y.v,a**n),(y.d,n*a**(n-1)),(y.dd,n*(n-1)*a**(n-2))):
            assert got.l<=want<=got.h;identities+=1
    for hi in (F(1),F(6,5),F(13,10),F(3,2),F(19,10),F(3)):
        z=((I(hi*hi+8).sqrt()-hi)/2).l
        assert 0<z<=1<=hi and z*z+hi*z<=2
        identities+=1
    good=dict(rho=['3/2','1501/1000'],c='5/2',tau='3/10',cells=64,scope='ALL_CENTERED_VARIANCE_ONE_LAWS')
    pilot.parse(good)
    bad=[]
    for key,value in (('scope','ACQUIRED_SUPPORT_ASSUMED'),('cells',True),('cells',7),('rho',['3/2','7/5']),('rho',[1.5,'3/2']),('c','4'),('c','0'),('tau','31/100'),('tau','1/2048')):
        item=copy.deepcopy(good);item[key]=value;bad.append(item)
    item=copy.deepcopy(good);item['n']=19;bad.append(item)
    item=copy.deepcopy(good);del item['scope'];bad.append(item)
    for item in bad:
        try:pilot.parse(item)
        except (ValueError,TypeError):negative+=1
        else:raise AssertionError('malformed pilot accepted')
    for ns in ([20,21,22,23,24],(20,21,22,23),(20,21,22,23,25),(True,21,22,23,24),(24,23,22,21,20)):
        try:batch.validate_ns(ns)
        except ValueError:negative+=1
        else:raise AssertionError('wrong n scope accepted')
    pi=certify_pi();result=dict(status='PASS_GENERIC_N_IDENTITIES_AND_SCOPE_CONTROLS',identities=identities,negative_controls=negative,pi=pi,n=list(batch.NS))
    output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
