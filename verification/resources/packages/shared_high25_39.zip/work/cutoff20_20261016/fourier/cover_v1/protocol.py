"""Exact complete rho/H cover, with bounded mesh refinement and full replay."""
from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,sys,time
H=Path(__file__).resolve().parent;R=H.parents[3]
sys.path.insert(0,str(H.parent))
import integrate as core
TARGET=F(4097,10000)
def need(x,msg):
    if not x:raise ValueError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rat(x):
    need(type(x)is str,'literal rational string')
    q=F(x);need(str(q)==x,'canonical rational string');return q
def pair(x):
    need(type(x)is list and len(x)==2,'endpoint pair');a,b=map(rat,x);need(a<b,'positive interval width');return a,b

def validate(plan):
    need(type(plan)is dict and set(plan)=={'schema','n','target','rho','strips'},'plan schema')
    need(plan['schema']=='UNCONDITIONAL_SURROGATE_H_PLAN_V1','fixed plan version')
    need(type(plan['n'])is list and all(type(n)is int for n in plan['n'])and plan['n']==list(core.NS),'literal actual n scope')
    need(plan['target']=='4097/10000','unchanged target')
    start,end=pair(plan['rho']);need(1<=start<end<=F(19,10),'rho scope')
    need(type(plan['strips'])is list and plan['strips'],'nonempty ordered rho cover')
    cursor=start;count=0
    for strip in plan['strips']:
        need(type(strip)is dict and set(strip)=={'rho','h_panels'},'strip schema')
        lo,hi=pair(strip['rho']);need(lo==cursor and hi<=end,'closed contiguous rho cover');cursor=hi
        panels=strip['h_panels'];need(type(panels)is list and panels,'nonempty H cover')
        hcursor=None
        for cell in panels:
            need(type(cell)is dict and set(cell)=={'h','c','tau','heuristic_upper'},'H-cell schema')
            hl,hu=pair(cell['h']);need(0<hl<hu<=1,'positive H cell')
            if hcursor is None:need(hl*hl+hi*hl<=2,'H start no greater than beta(hi)')
            else:need(hl==hcursor,'closed contiguous H cover')
            hcursor=hu;c,tau=rat(cell['c']),rat(cell['tau'])
            core.old.validate_parameters(core.NS,lo,hi,hu,c,tau,128)
            # The floating discovery field is deliberately unused for proof.
            need(type(cell['heuristic_upper'])in(int,float),'discovery display only')
            Z=max(hl,F(2)/hu-hi,((core.I(hi*hi+8).sqrt()-hi)/2).l)
            need(0<Z<=hi,'nonempty admissible zeta interface')
            count+=1
        need(hcursor==1,'H cover reaches one')
    need(cursor==end,'rho cover reaches declared endpoint')
    return count

def negative_controls(plan):
    def altered(fn):
        x=copy.deepcopy(plan);fn(x);return x
    cases=[altered(lambda x:x.update(target='41/100')),
           altered(lambda x:x.update(n=[19,20,21,22,23])),
           altered(lambda x:x.update(n=[20,21,22,23,True])),
           altered(lambda x:x.update(strips=[])),
           altered(lambda x:x['strips'].append(copy.deepcopy(x['strips'][-1]))),
           altered(lambda x:x['strips'][0].update(h_panels=[])),
           altered(lambda x:x['strips'][0]['h_panels'][0].update(c='4')),
           altered(lambda x:x['strips'][0]['h_panels'][0].update(tau='31/100')),
           altered(lambda x:x['strips'][0]['h_panels'][0].update(h=['0','1'])),
           altered(lambda x:x['strips'][0]['h_panels'][-1]['h'].__setitem__(1,'999/1000'))]
    for x in cases:
        try:validate(x)
        except (ValueError,TypeError,KeyError):pass
        else:raise AssertionError('altered plan accepted')
    return len(cases)

def main():
    need(__debug__ and sys.flags.dont_write_bytecode and not sys.flags.optimize,'ordinary -B interpreter')
    need(len(sys.argv)==4,'construct/replay, plan path, output path required')
    action,planpath,outpath=sys.argv[1:];need(action in('construct','replay'),'known action')
    planpath=Path(planpath);outpath=Path(outpath);need(not outpath.exists(),'new output only')
    manifest=json.loads((H/'MANIFEST.json').read_text())
    for name,h in manifest['files_sha256'].items():need(sha(R/name)==h,'source binding '+name)
    plan=json.loads(planpath.read_text());count=validate(plan);negative=negative_controls(plan)
    # Replay deliberately recomputes the entire deterministic refinement path,
    # not just normalization of a previously reported bound.
    rows=[];attempts=[];began=time.monotonic()
    for strip_i,strip in enumerate(plan['strips']):
        lo,hi=map(F,strip['rho'])
        beta_lower=((core.I(hi*hi+8).sqrt()-hi)/2).l
        for h_i,cell in enumerate(strip['h_panels']):
            hl,hu=map(F,cell['h']);Z=max(hl,F(2)/hu-hi,beta_lower)
            for mesh in (128,256,512):
                result=core.calculate(lo,hi,hu,Z,F(cell['c']),F(cell['tau']),mesh)
                group=result['rows'];need([r['n']for r in group]==list(core.NS),'all actual n returned')
                for row in group:
                    exact=core.I(row['n']).sqrt().h*sum(F(x)for x in row['terms'].values())/lo
                    need(F(row['normalized_upper'])==exact,'exact normalization')
                    row.update(h_surrogate=cell['h'],rho_strip_index=strip_i,h_cell_index=h_i,target=str(TARGET),strict_target_pass=exact<TARGET)
                passed=all(r['strict_target_pass']for r in group)
                attempts.append(dict(rho_strip_index=strip_i,h_cell_index=h_i,mesh=mesh,passed=passed,normalized_uppers=[r['normalized_upper']for r in group]))
                if passed:break
            rows.extend(group)
            print('EXACT_H_CELL',strip_i,h_i,'MESH',mesh,'PASS',passed,'MAX',max(r['normalized_upper_float']for r in group),flush=True)
    need(len(rows)==5*count,'exact final row tally')
    result=dict(status='EXACT_UNCONDITIONAL_H_COVER_PASS'if all(r['strict_target_pass']for r in rows)else'EXACT_UNCONDITIONAL_H_COVER_NOT_CLOSED',
                scope='All iid centered unit-variance laws in the stated closed rho interval; literal n20..24. No acquired support or predecessor assumption.',
                n=list(core.NS),rho=plan['rho'],target=str(TARGET),h_cells=count,rho_strips=len(plan['strips']),rows=rows,attempts=attempts,
                negative_controls=negative,plan_sha256=sha(planpath),manifest_sha256=sha(H/'MANIFEST.json'),seconds=time.monotonic()-began)
    outpath.write_text(json.dumps(result,indent=2)+'\n')
    for name,h in manifest['files_sha256'].items():need(sha(R/name)==h,'source changed '+name)
    print(result['status'],'ROWS',len(rows),'MAX',max(r['normalized_upper_float']for r in rows),'SECONDS',result['seconds'],flush=True)
if __name__=='__main__':main()
