"""Floating parameter selection; writes a rational plan, never a certificate."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import math,json,sys,time
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H.parent/'coupled_v1'))
from floating import terms

THRESHOLD=.40902
CS=[F(12,5)+F(i,25)for i in range(19)]
TAUS=[F(6,25),F(13,50),F(7,25),F(3,10)]

@lru_cache(None)
def best(lo,hi,hl,hu):
    a,b,l,u=map(float,(lo,hi,hl,hu));beta=(math.sqrt(b*b+8)-b)/2
    z=max(l,2/u-b,beta);ans=None
    for c in CS:
        for tau in TAUS:
            val,_=terms(20,a,b,float(c),float(tau),160,u,z)
            if ans is None or val<ans[0]:ans=(val,c,tau)
    return ans

def h_cover(lo,hi):
    x=float(hi);beta=(math.sqrt(x*x+8)-x)/2
    lower=F(math.floor(beta*10**6),10**6)
    todo=[(lower,F(1),0)];out=[]
    while todo:
        hl,hu,depth=todo.pop();val,c,tau=best(lo,hi,hl,hu)
        if val<=THRESHOLD:
            # Check all literal n separately at the selected parameters.
            z=max(float(hl),2/float(hu)-x,beta)
            checks=[terms(n,float(lo),x,float(c),float(tau),320,float(hu),z)[0]for n in range(20,25)]
            if max(checks)>THRESHOLD:return None
            out.append(dict(h=[str(hl),str(hu)],c=str(c),tau=str(tau),heuristic_upper=max(checks)))
        else:
            if depth>=7:return None
            mid=(hl+hu)/2
            todo.extend(((mid,hu,depth+1),(hl,mid,depth+1)))
    return out

def main():
    assert len(sys.argv)==4
    lo,end=F(sys.argv[1]),F(sys.argv[2]);out=Path(sys.argv[3]);assert 1<=lo<end<=F(19,10) and not out.exists()
    begin=lo;strips=[];start=time.monotonic()
    while lo<end:
        accepted=None
        for width in (F(1,10),F(1,20),F(1,50),F(1,100),F(1,200),F(1,500),F(1,1000)):
            hi=min(end,lo+width)
            candidate=h_cover(lo,hi)
            if candidate is not None:
                accepted=dict(rho=[str(lo),str(hi)],h_panels=candidate);break
        if accepted is None:raise RuntimeError('no discovery plan at '+str(lo))
        strips.append(accepted);lo=hi
        print('DISCOVERY_STRIP',accepted['rho'],'H_PANELS',len(candidate),'FLOAT_MAX',max(x['heuristic_upper']for x in candidate),flush=True)
    plan=dict(schema='UNCONDITIONAL_SURROGATE_H_PLAN_V1',n=list(range(20,25)),target='4097/10000',rho=[str(begin),str(end)],strips=strips)
    out.write_text(json.dumps(plan,indent=2)+'\n')
    print('HEURISTIC_PLAN_ONLY',len(strips),'STRIPS',sum(len(x['h_panels'])for x in strips),'H_CELLS','SECONDS',time.monotonic()-start,flush=True)
if __name__=='__main__':main()
