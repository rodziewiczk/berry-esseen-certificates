"""Capture a reviewed planner or exact cover/replay in a fresh path."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,platform,subprocess,sys,time
H=Path(__file__).resolve().parent;R=H.parents[3]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert __debug__ and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv)>=4
    action,label=sys.argv[1:3];assert action in('plan','construct','replay')and label.isidentifier()
    out=R/'runs/cutoff20_20261016/fourier/cover_v1'/label;out.mkdir(parents=True,exist_ok=False)
    sources=dict(json.loads((H/'MANIFEST.json').read_text())['files_sha256'])
    sources[str((H/'MANIFEST.json').relative_to(R))]=sha(H/'MANIFEST.json')
    if action=='plan':
        assert len(sys.argv)==5
        command=[sys.executable,'-B','planner.py',*sys.argv[3:5],str(out/'PLAN.json')]
    else:
        assert len(sys.argv)==4
        p=Path(sys.argv[3]).resolve();sources[str(p.relative_to(R))]=sha(p)
        command=[sys.executable,'-B','protocol.py',action,str(p),str(out/'RESULT.json')]
    for p,h in sources.items():assert sha(R/p)==h
    data=dict(command=command,cwd=str(H),input_sha256=sources,python=sys.version,platform=platform.platform(),started_utc=datetime.now(timezone.utc).isoformat())
    start=time.monotonic();proc=subprocess.run(command,cwd=H,text=True,capture_output=True)
    (out/'stdout.txt').write_text(proc.stdout);(out/'stderr.txt').write_text(proc.stderr)
    changed=[p for p,h in sources.items()if sha(R/p)!=h]
    data.update(returncode=proc.returncode,elapsed_seconds=time.monotonic()-start,finished_utc=datetime.now(timezone.utc).isoformat(),changed_inputs=changed,stdout_sha256=sha(out/'stdout.txt'),stderr_sha256=sha(out/'stderr.txt'))
    for name in('RESULT.json','PLAN.json'):
        if(out/name).exists():data[name+'_sha256']=sha(out/name)
    (out/'metadata.json').write_text(json.dumps(data,indent=2)+'\n')
    print(proc.stdout,end='');print(proc.stderr,end='',file=sys.stderr)
    assert not changed
    raise SystemExit(proc.returncode)
if __name__=='__main__':main()
