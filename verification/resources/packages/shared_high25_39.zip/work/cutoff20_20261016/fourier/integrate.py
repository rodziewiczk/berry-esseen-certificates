"""Second-order midpoint upper integration of fixed smooth Fourier majorants.

Each selected branch is valid on the WHOLE closed cell. No derivative of a
min/max or an interval-dependent branch selector is used.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,time
from math import factorial
from jet import J,I,PI,sin,cos,expminus
U=Path(__file__).resolve().parent
sys.path.insert(0,str(U));import batch as old
NS=old.NS;KAPPA=old.KAPPA
need=old.need

def squared_choice(a,b,twice_a_plus_increment=None):
    # b=a+increment with increment>=0 is established by the caller.
    if twice_a_plus_increment is not None:
        sign=twice_a_plus_increment.v
        if sign.l>=0:return ('right',None)
        if sign.h<=0:return ('left',None)
    aa,bb=a.sq().v,b.sq().v
    if aa.l>=bb.h:return ('left',None)
    if bb.l>=aa.h:return ('right',None)
    return ('constant',max(aa.h,bb.h))
def squared(a,b,choice):
    mode,value=choice
    if mode=='left':return a.sq()
    if mode=='right':return b.sq()
    need(mode=='constant'and type(value)is F,'known fixed squared majorant')
    return J(value)
def cotdef(x):
    need(0<=x.v.l<=x.v.h<=1,'cotangent defect domain')
    return x/(3*(1-x.sq()/6))
def K(t,mode):
    r=1-t
    if mode=='upper':return r*(1+cotdef(J(PI)*r).sq()).sqrt()
    need(mode=='exact','fixed kernel norm branch')
    x=J(PI)*t;s=sin(x)
    need(s.v.l>0,'positive sine')
    k=r*cos(x)/s+J(1)/J(PI)
    return (r.sq()+k.sq()).sqrt()
def stable_difference(u,c):
    # cos(u)-exp(-u²/2), values and derivatives w.r.t. t, where u=c*t.
    need(0<=u.v.l<=u.v.h<=1,'stable difference series domain')
    coef=[F((-1)**(k+1))*(F(1,2**k*factorial(k))-F(1,factorial(2*k)))for k in range(2,11)]
    x=u.sq();P=J(coef[-1])
    for ck in reversed(coef[:-1]):P=P*x+ck
    d=u**4*P
    for j,field in enumerate(('v','d','dd')):
        factor=1 if j==0 else 22 if j==1 else 22*21
        error=2*F(factor,2**11*factorial(11))*u.v.h**(22-j)*c**j
        setattr(d,field,getattr(d,field)+I(-error,error))
    # d/u³ = u*P + residual/u³; bound latter without dividing by a tiny lower u.
    order_error=4*F(1,2**11*factorial(11))*u.v.h**19
    order=2*(u*P).v+I(-order_error,order_error)
    return d,order

def base(t,hi,eta,c,scale,low,jsquare):
    u=t*c;co=cos(u);increment=(hi-1)*u**3/6;re=co+increment
    imag=jsquare*u**6
    z=(hi+eta)*u
    out=dict(u=u,co=co,re=re,increment=increment,imag=imag,z=z,
             line=1-u.sq()+2*KAPPA*(hi+eta)*u**3)
    if z.v.l>=4 and z.v.h<=2*PI.l:
        out['curve']=1-J(2*scale)*(1-cos(z))/(hi+eta)**2
    if low:
        g=expminus(u.sq()/2);diff,order=stable_difference(u,c)
        out.update(g=g,diff=diff,shift=diff+increment,error_order=J(order)+(hi-1)/6)
    return out

def choose(full,low):
    coord=squared_choice(full['co'],full['re'],2*full['co']+full['increment'])
    candidates={'one':J(1)}
    for name in('line','curve'):
        if name in full and full[name].v.l>0:candidates[name]=full[name].sqrt()
    cr=squared(full['co'],full['re'],coord)+full['imag']
    if cr.v.l>0:candidates['coordinate']=cr.sqrt()
    mode=min(candidates,key=lambda k:candidates[k].v.h)
    spec={'modulus':mode,'coordinate':coord}
    if low:spec['error']=squared_choice(full['diff'],full['shift'],full['error_order'])
    return spec

def functions(t,hi,eta,c,scale,low,spec,jsquare):
    b=base(t,hi,eta,c,scale,low,jsquare);mode=spec['modulus']
    if mode=='one':m=J(1)
    elif mode=='coordinate':m=(squared(b['co'],b['re'],spec['coordinate'])+b['imag']).sqrt()
    else:
        need(mode in('line','curve')and mode in b,'selected whole-cell modulus remains eligible')
        m=b[mode].sqrt()
    kn=K(t,spec['kernel']);mp={n:m**n for n in NS}
    if not low:return {n:(kn*mp[n],J(0),None)for n in NS}
    g=b['g'];err=(squared(b['diff'],b['shift'],spec['error'])+b['imag']).sqrt()
    corr=(1-t)*(1+cotdef(J(PI)*t).sq()).sqrt()
    S=J(0);gp=J(1);out={}
    for n in range(1,NS[-1]+1):
        S=m*S+gp;gp=gp*g
        if n in NS:out[n]=(kn*err*S,corr*gp,kn*(mp[n]+gp))
    return out

def upper(full,mid,width):
    need(type(width)is F and width>0,'positive exact width')
    midpoint=mid.v.h+(width*width/24)*max(F(0),full.dd.h)
    return width*min(full.v.h,midpoint)

def cell(a,b,hi,eta,c,scale,low,jsquare):
    t=J(I(a,b),1);mid=J(I((a+b)/2),1)
    common=base(t,hi,eta,c,scale,low,jsquare);spec=choose(common,low)
    spec['kernel']='upper'if t.v.l>=F(3,4)else'exact'
    full=functions(t,hi,eta,c,scale,low,spec,jsquare);point=functions(mid,hi,eta,c,scale,low,spec,jsquare)
    out={}
    for n in NS:
        val,norm,triangle=full[n];pv,pnorm,ptriangle=point[n]
        vu=upper(val,pv,b-a)
        if low:vu=min(vu,upper(triangle,ptriangle,b-a))
        out[n]=(vu,upper(norm,pnorm,b-a)if low else F(0))
    return out,spec

def calculate(lo,hi,eta,zeta,c,tau,cells):
    old.validate_parameters(NS,lo,hi,eta,c,tau,cells);eps=F(1,1024)
    need(type(zeta)is F and 0<=zeta<=hi,'exact nonnegative zeta cap at most rho_upper')
    jsquare=min((hi-1)*(hi+F(5,3)),hi*hi-zeta*zeta)/36
    need(jsquare>=0,'nonnegative imaginary square coefficient')
    scale=(8-64*KAPPA)/(1-old.cos(I(4)))
    need(0<scale.l<=scale.h<=1,'compatible profile coefficient')
    start=time.monotonic();sums={n:dict(low=F(0),normal=F(0),high=F(0))for n in NS};stats={}
    for low,a,b in((True,eps,tau),(False,tau,1-eps)):
        width=(b-a)/cells
        for j in range(cells):
            left,right=a+j*width,a+(j+1)*width
            try:
                vals,spec=cell(left,right,hi,eta,c,scale,low,jsquare)
                label=spec['modulus']+('/'+spec['error'][0]if low else'')
            except ValueError:
                # Original valid upper-Darboux enclosure has no C2 obligation.
                raw=old.integrands(I(left,right),NS,hi,eta,c,scale,low)
                vals={n:(width*raw[n][0],width*raw[n][1])for n in NS};label='darboux_fallback'
            stats[label]=stats.get(label,0)+1
            for n in NS:
                if low:sums[n]['low']+=vals[n][0];sums[n]['normal']+=vals[n][1]
                else:sums[n]['high']+=vals[n][0]
        print('MIDPOINT_INTEGRATED',str(lo),str(hi),'LOW'if low else'HIGH',cells,flush=True)
    ut=c*tau;tailpow=old.powers(old.expminus(I(ut*ut/2)),NS);rows=[]
    for n in NS:
        lowhead=n*(hi*c**3/6*(eps**4/4+eps**3/(3*PI.l))+c**4/8*(eps**5/5+eps**4/(4*PI.l)))
        normalhead=eps+PI.h*eps*eps/2;hightail=eps*eps/2+PI.h*eps**3/3
        tail=(tailpow[n]/(PI*n*ut*ut)).h
        terms=dict(low=sums[n]['low']+lowhead,normal=sums[n]['normal']+normalhead,high=sums[n]['high']+hightail,tail=tail)
        total=sum(terms.values());bound=I(n).sqrt().h*total/lo
        rows.append(dict(n=n,rho=[str(lo),str(hi)],eta_upper=str(eta),zeta_lower=str(zeta),imaginary_square_coefficient=str(jsquare),kappa=str(KAPPA),c=str(c),tau=str(tau),epsilon=str(eps),cells_per_piece=cells,normalized_upper=str(bound),normalized_upper_float=float(bound),terms={k:str(v)for k,v in terms.items()}))
    return dict(rows=rows,branch_statistics=stats,shared_cells=2*cells,seconds=time.monotonic()-start)
