"""Capture a fixed reviewed discovery, control, or exact-pilot action."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,platform,subprocess,sys,time
H=Path(__file__).resolve().parent;R=H.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert __debug__ and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv)>=3
    action,label=sys.argv[1:3]
    assert action in('discovery','controls','pilot') and label.isidentifier()
    assert len(sys.argv)==(4 if action=='pilot' else 3)
    out=R/'runs/cutoff20_20261016/fourier'/label;out.mkdir(parents=True,exist_ok=False)
    sources=dict(json.loads((H/'MANIFEST.json').read_text())['files_sha256'])
    sources[str((H/'MANIFEST.json').relative_to(R))]=sha(H/'MANIFEST.json')
    command=[sys.executable,'-B',action+'.py']
    if action=='pilot':
        parameter=Path(sys.argv[3]).resolve();assert parameter.parent==H and parameter.suffix=='.json'
        sources[str(parameter.relative_to(R))]=sha(parameter)
        command+=[str(parameter),str(out/'RESULT.json')]
    else:command+=[str(out/'RESULT.json')]
    for p,h in sources.items():assert sha(R/p)==h
    metadata=dict(command=command,cwd=str(H),input_sha256=sources,python=sys.version,platform=platform.platform(),started_utc=datetime.now(timezone.utc).isoformat())
    start=time.monotonic();p=subprocess.run(command,cwd=H,text=True,capture_output=True)
    (out/'stdout.txt').write_text(p.stdout);(out/'stderr.txt').write_text(p.stderr)
    changed=[name for name,h in sources.items()if sha(R/name)!=h]
    metadata.update(returncode=p.returncode,elapsed_seconds=time.monotonic()-start,finished_utc=datetime.now(timezone.utc).isoformat(),changed_inputs=changed,stdout_sha256=sha(out/'stdout.txt'),stderr_sha256=sha(out/'stderr.txt'))
    if (out/'RESULT.json').exists():metadata['result_sha256']=sha(out/'RESULT.json')
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr)
    assert not changed
    raise SystemExit(p.returncode)
if __name__=='__main__':main()
