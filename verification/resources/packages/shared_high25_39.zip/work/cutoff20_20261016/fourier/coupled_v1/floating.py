"""Floating discovery ONLY; no quadrature output is an acceptance certificate."""
from pathlib import Path
import json, math, sys, time
from functools import lru_cache
import numpy as np
from numpy.polynomial.legendre import leggauss

NS=(20,21,22,23,24)
KAPPA=62/625
EPS=1/1024
PI=math.pi
SCALE=(8-64*KAPPA)/(1-math.cos(4))

@lru_cache(None)
def quadrature(order):return leggauss(order)

def terms(n,lo,hi,c,tau,order=160,eta=1.,zeta=None):
    # This intentionally uses the same valid (but here floating) upper
    # expressions and conservative analytic heads/tail as integrate.py.
    nodes,weights=quadrature(order)
    beta=(math.sqrt(hi*hi+8)-hi)/2
    Z=beta if zeta is None else zeta
    J=min((hi-1)*(hi+5/3),hi*hi-Z*Z)/36
    result={}
    for low,a,b in ((True,EPS,tau),(False,tau,1-EPS)):
        # Split at fixed profile and kernel seams. This still is discovery.
        seams=sorted(set([a,b]+[z for z in (.75,4/((hi+eta)*c),2*PI/((hi+eta)*c)) if a<z<b]))
        values=[]; norms=[]
        for a,b in zip(seams,seams[1:]):
            t=(a+b)/2+(b-a)*nodes/2; w=(b-a)*weights/2
            u=c*t; co=np.cos(u); inc=(hi-1)*u**3/6; re=co+inc
            ims=J*u**6; D=hi+eta; z=D*u
            line=1-u*u+2*KAPPA*D*u**3
            assert np.min(line)>0
            mod=np.minimum(1,np.sqrt(line))
            curve_mask=(z>=4)&(z<=2*PI)
            curve=1-2*SCALE*(1-np.cos(z))/D**2
            assert np.min(curve[curve_mask],initial=1)>0
            mod=np.minimum(mod,np.where(curve_mask,np.sqrt(np.maximum(curve,0)),1))
            mod=np.minimum(mod,np.sqrt(np.maximum(co*co,re*re)+ims))
            r=1-t; kn=np.sqrt(r*r+(r/np.tan(PI*t)+1/PI)**2)
            rtail=PI*r; tailkn=r*np.sqrt(1+(rtail/(3*(1-rtail*rtail/6)))**2)
            kn=np.where(t>=.75,tailkn,kn)
            if low:
                g=np.exp(-u*u/2); err=np.sqrt(np.maximum((co-g)**2,(re-g)**2)+ims)
                geo=np.zeros_like(u); gp=np.ones_like(u)
                for _ in range(n):
                    geo=mod*geo+gp; gp=gp*g
                error=np.minimum(err*geo,mod**n+gp)
                x=PI*t; correction=r*np.sqrt(1+(x/(3*(1-x*x/6)))**2)
                values.append(float(np.dot(w,kn*error))); norms.append(float(np.dot(w,correction*gp)))
            else: values.append(float(np.dot(w,kn*mod**n)))
        result['low' if low else 'high']=sum(values)
        if low:result['normal']=sum(norms)
    result['low']+=n*(hi*c**3/6*(EPS**4/4+EPS**3/(3*PI))+c**4/8*(EPS**5/5+EPS**4/(4*PI)))
    result['normal']+=EPS+PI*EPS*EPS/2
    result['high']+=EPS*EPS/2+PI*EPS**3/3
    ut=c*tau
    result['tail']=math.exp(-n*ut*ut/2)/(PI*n*ut*ut)
    return math.sqrt(n)*sum(result.values())/lo,result

def main():
    assert len(sys.argv)==2
    output=Path(sys.argv[1]); assert not output.exists()
    start=time.monotonic(); rows=[]
    for lo in (1.2,1.25,1.3,1.35,1.4,1.45,1.5,1.6,1.7,1.8):
        hi=lo+.001; best=None
        for c in np.linspace(2.4,3.12,19):
            for tau in (.26,.28,.3):
                upper,pieces=terms(20,lo,hi,float(c),tau)
                item=(upper,float(c),tau,pieces)
                if best is None or item[0]<best[0]:best=item
        value,c,tau,pieces=best
        checks={str(n):terms(n,lo,hi,c,tau,320)[0]for n in NS}
        row=dict(rho=[lo,hi],c=c,tau=tau,n20_upper160=value,n_upper320=checks,terms_n20_160=pieces)
        rows.append(row);print(json.dumps(row),flush=True)
    result=dict(status='HEURISTIC_FLOATING_DISCOVERY_ONLY',numpy_version=np.__version__,eta_upper=1,n=list(NS),kappa=KAPPA,rows=rows,seconds=time.monotonic()-start)
    output.write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
