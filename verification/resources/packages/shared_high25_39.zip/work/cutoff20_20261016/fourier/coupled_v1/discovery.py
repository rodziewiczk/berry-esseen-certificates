"""Heuristic h-surrogate panels; all float output remains non-certifying."""
from pathlib import Path
import math,json,sys,time
import numpy as np
from floating import terms,NS

def main():
    assert len(sys.argv)==2
    out=Path(sys.argv[1]);assert not out.exists()
    start=time.monotonic();rows=[]
    for lo in (1.05,1.075,1.1,1.125,1.15,1.175,1.2,1.225,1.25,1.275,1.3):
        hi=lo+.001;beta=(math.sqrt(hi*hi+8)-hi)/2
        floor=math.floor(beta*10**6)/10**6
        edges=np.linspace(floor,1.,17);bands=[]
        for hl,hu in zip(edges,edges[1:]):
            hl,hu=float(hl),float(hu);zeta=max(hl,2/hu-hi,beta);best=None
            for c in np.linspace(2.4,3.12,19):
                for tau in (.24,.26,.28,.3):
                    val,pieces=terms(20,lo,hi,float(c),tau,160,hu,zeta)
                    row=(val,float(c),tau,pieces)
                    if best is None or row[0]<best[0]:best=row
            val,c,tau,pieces=best
            checks={str(n):terms(n,lo,hi,c,tau,320,hu,zeta)[0]for n in NS}
            bands.append(dict(h=[hl,hu],zeta=zeta,c=c,tau=tau,n20_upper160=val,n_upper320=checks))
        worst=max(bands,key=lambda x:x['n_upper320']['20'])
        row=dict(rho=[lo,hi],bands=bands,worst_n20=worst['n_upper320']['20'],worst_band=worst)
        rows.append(row);print(json.dumps({k:v for k,v in row.items()if k!='bands'}),flush=True)
    result=dict(status='HEURISTIC_COUPLED_H_DISCOVERY_ONLY',n=list(NS),rho_width=.001,h_panels=16,rows=rows,numpy_version=np.__version__,seconds=time.monotonic()-start)
    out.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
