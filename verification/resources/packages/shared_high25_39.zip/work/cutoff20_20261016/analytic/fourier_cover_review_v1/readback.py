"""Independent exact coverage/capture readback; imports no proof evaluator."""
from __future__ import annotations

import copy
import json
import math
import sys
from fractions import Fraction as F
from hashlib import sha256
from math import isqrt
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
GRID = 10 ** 24
TARGET = F(4097, 10000)
NS = [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
EMPTY_SHA = sha256(b'').hexdigest()
PI_LO = F(3141592653589793238462643383279, 10 ** 30)


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'duplicate JSON key')
        out[key] = value
    return out


def load(path):
    return json.loads(path.read_text(), object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def rat(value):
    need(type(value) is str, 'literal rational string')
    out = F(value)
    need(str(out) == value, 'canonical rational')
    return out


def endpoints(value):
    need(type(value) is list and len(value) == 2, 'endpoint pair')
    lo, hi = map(rat, value)
    need(lo < hi, 'strictly ordered endpoints')
    return lo, hi


def integer(value, minimum=0):
    need(type(value) is int and value >= minimum, 'literal integer')
    return value


def down(value):
    return F(value.numerator * GRID // value.denominator, GRID)


def up(value):
    return -down(-value)


def sqrt_down(value):
    return F(isqrt(value.numerator * GRID ** 2 // value.denominator), GRID)


def sqrt_up(value):
    lower = sqrt_down(value)
    return lower if lower * lower == value else lower + F(1, GRID)


def beta_lower(hi):
    # Independently duplicate the documented outward endpoint algebra,
    # not the interval class or its elementary-function implementation.
    lower = down((sqrt_down(down(hi * hi + 8)) - up(hi)) / 2)
    need(lower > 0 and lower * lower + hi * lower <= 2, 'beta lower root')
    return lower


def safe_path(value):
    need(type(value) is str and value, 'path string')
    p = Path(value)
    need(not p.is_absolute() and '..' not in p.parts, 'workspace-relative path')
    return ROOT / p


def plan_cells(plan, expected_rho):
    need(type(plan) is dict and set(plan) == {'schema', 'n', 'target', 'rho', 'strips'}, 'plan fields')
    need(plan['schema'] == 'UNCONDITIONAL_SURROGATE_H_PLAN_V1', 'plan version')
    need(type(plan['n']) is list and all(type(n) is int for n in plan['n']) and plan['n'] == NS, 'actual n scope')
    need(plan['target'] == str(TARGET) and plan['rho'] == expected_rho, 'requested target and rho')
    start, end = endpoints(plan['rho'])
    need(F(1) <= start < end <= F(19, 10), 'rho theorem domain')
    need(type(plan['strips']) is list and plan['strips'], 'nonempty strips')
    rcursor = start
    expected = []
    for si, strip in enumerate(plan['strips']):
        need(type(strip) is dict and set(strip) == {'rho', 'h_panels'}, 'strip fields')
        lo, hi = endpoints(strip['rho'])
        need(lo == rcursor and hi <= end, 'complete ordered rho seams')
        rcursor = hi
        need(type(strip['h_panels']) is list and strip['h_panels'], 'nonempty H cells')
        hcursor = None
        for hj, cell in enumerate(strip['h_panels']):
            need(type(cell) is dict and set(cell) == {'h', 'c', 'tau', 'heuristic_upper'}, 'cell fields')
            hl, hu = endpoints(cell['h'])
            need(0 < hl < hu <= 1, 'H range')
            if hcursor is None:
                need(hl * hl + hi * hl <= 2, 'H begins no higher than beta')
            else:
                need(hl == hcursor, 'complete ordered H seams')
            hcursor = hu
            c, tau = rat(cell['c']), rat(cell['tau'])
            need(0 < c < PI_LO and F(1, 1024) < tau <= F(3, 10), 'frequency gates')
            need(type(cell['heuristic_upper']) in (int, float) and math.isfinite(cell['heuristic_upper']), 'finite discovery display')
            z = max(hl, 2 / hu - hi, beta_lower(hi))
            need(0 < z <= hi, 'zeta interface')
            expected.append(dict(si=si, hj=hj, rho=strip['rho'], h=cell['h'], lo=lo, hi=hi,
                                 eta=hu, zeta=z, c=c, tau=tau))
        need(hcursor == 1, 'H reaches one')
    need(rcursor == end, 'rho reaches endpoint')
    return expected


def normalized(terms, n, lo):
    need(type(terms) is dict and set(terms) == {'low', 'normal', 'high', 'tail'}, 'four Prawitz terms')
    values = list(map(rat, terms.values()))
    need(all(v >= 0 for v in values), 'nonnegative integral terms')
    return sqrt_up(F(n)) * sum(values) / lo


def validate_result(result, plan, expected_rho, plan_hash, manifest_hash):
    fields = {'status', 'scope', 'n', 'rho', 'target', 'h_cells', 'rho_strips', 'rows', 'attempts',
              'negative_controls', 'plan_sha256', 'manifest_sha256', 'seconds'}
    need(type(result) is dict and set(result) == fields, 'result fields')
    need(result['status'] == 'EXACT_UNCONDITIONAL_H_COVER_PASS', 'all cells must pass')
    need(result['scope'] == 'All iid centered unit-variance laws in the stated closed rho interval; literal n25..39. No acquired support or predecessor assumption.', 'unconditional scope')
    need(type(result['n']) is list and all(type(n) is int for n in result['n']) and result['n'] == NS, 'result n scope')
    need(result['rho'] == expected_rho and result['target'] == str(TARGET), 'result target domain')
    expected = plan_cells(plan, expected_rho)
    need(integer(result['h_cells'], 1) == len(expected), 'H cell count')
    need(integer(result['rho_strips'], 1) == len(plan['strips']), 'rho strip count')
    need(integer(result['negative_controls'], 10) >= 10, 'native malformed-plan controls')
    need(result['plan_sha256'] == plan_hash and result['manifest_sha256'] == manifest_hash, 'input bindings')
    need(type(result['seconds']) in (int, float) and math.isfinite(result['seconds']) and result['seconds'] >= 0, 'elapsed display')
    need(type(result['rows']) is list and len(result['rows']) == len(expected) * len(NS), 'complete final row count')
    need(type(result['attempts']) is list, 'attempt list')
    row_fields = {'n', 'rho', 'eta_upper', 'zeta_lower', 'imaginary_square_coefficient', 'kappa', 'c', 'tau',
                  'epsilon', 'cells_per_piece', 'normalized_upper', 'normalized_upper_float', 'terms',
                  'h_surrogate', 'rho_strip_index', 'h_cell_index', 'target', 'strict_target_pass'}
    cursor = 0
    for ci, cell in enumerate(expected):
        group = result['rows'][len(NS) * ci:len(NS) * (ci + 1)]
        mesh = integer(group[0]['cells_per_piece'], 1)
        need(mesh in (128, 256, 512), 'approved final mesh')
        for row, n in zip(group, NS):
            need(type(row) is dict and set(row) == row_fields, 'row fields')
            need(integer(row['n']) == n and integer(row['rho_strip_index']) == cell['si'] and integer(row['h_cell_index']) == cell['hj'], 'row identity/order')
            need(row['rho'] == cell['rho'] and row['h_surrogate'] == cell['h'], 'row actual rectangle')
            need(rat(row['eta_upper']) == cell['eta'] and rat(row['zeta_lower']) == cell['zeta'], 'shared H inputs')
            jsq = min((cell['hi'] - 1) * (cell['hi'] + F(5, 3)), cell['hi'] ** 2 - cell['zeta'] ** 2) / 36
            need(rat(row['imaginary_square_coefficient']) == jsq >= 0, 'imaginary coefficient')
            need(rat(row['c']) == cell['c'] and rat(row['tau']) == cell['tau'], 'chosen parameters')
            need(row['kappa'] == '62/625' and row['epsilon'] == '1/1024', 'fixed constants')
            need(integer(row['cells_per_piece']) == mesh and row['target'] == str(TARGET), 'mesh and target')
            upper = normalized(row['terms'], n, cell['lo'])
            need(rat(row['normalized_upper']) == upper < TARGET, 'exact normalization/strict closure')
            need(type(row['strict_target_pass']) is bool and row['strict_target_pass'], 'literal pass flag')
            need(type(row['normalized_upper_float']) in (int, float) and math.isfinite(row['normalized_upper_float']), 'finite display upper')
        for attempt_mesh in (128, 256, 512):
            need(cursor < len(result['attempts']), 'all attempted meshes recorded')
            attempt = result['attempts'][cursor]
            cursor += 1
            need(type(attempt) is dict and set(attempt) == {'rho_strip_index', 'h_cell_index', 'mesh', 'passed', 'normalized_uppers'}, 'attempt fields')
            need(integer(attempt['rho_strip_index']) == cell['si'] and integer(attempt['h_cell_index']) == cell['hj'] and integer(attempt['mesh']) == attempt_mesh, 'complete attempt order')
            need(type(attempt['normalized_uppers']) is list and len(attempt['normalized_uppers']) == len(NS), 'all-n attempt tuple')
            vals = list(map(rat, attempt['normalized_uppers']))
            need(all(x >= 0 for x in vals), 'nonnegative attempt uppers')
            passed = all(v < TARGET for v in vals)
            need(type(attempt['passed']) is bool and attempt['passed'] == passed, 'attempt pass arithmetic')
            if attempt_mesh == mesh:
                need(passed and attempt['normalized_uppers'] == [r['normalized_upper'] for r in group], 'final attempt matches all rows')
                break
            need(not passed, 'no skipped earlier passing mesh')
    need(cursor == len(result['attempts']), 'no extra/missing attempts')
    return expected


def capture(directory, action, expected_meta_sha, plan_path, manifest, graph):
    meta_path = directory / 'metadata.json'
    need(digest(meta_path) == expected_meta_sha, 'approved capture metadata identity')
    meta = load(meta_path)
    need(type(meta['returncode']) is int and meta['returncode'] == 0 and meta['changed_inputs'] == [], 'successful unchanged capture')
    need(meta['stdout_sha256'] == digest(directory / 'stdout.txt'), 'stdout binding')
    need(meta['stderr_sha256'] == EMPTY_SHA == digest(directory / 'stderr.txt'), 'empty stderr binding')
    result_path = directory / 'RESULT.json'
    need(meta['RESULT.json_sha256'] == digest(result_path), 'captured result binding')
    cwd = ROOT / 'work/cutoff20_20261016/fourier/cover_v1'
    need(meta['cwd'] == str(cwd), 'native execution cwd')
    command = meta['command']
    need(type(command) is list and len(command) == 6 and command[1:] == ['-B', 'protocol.py', action, str(plan_path), str(result_path)], 'native command actual action/input')
    need(type(command[0]) is str and Path(command[0]).name.startswith('python'), 'ordinary Python executable')
    expected_inputs = dict(manifest['files_sha256'])
    expected_inputs['work/cutoff20_20261016/fourier/cover_v1/MANIFEST.json'] = digest(cwd / 'MANIFEST.json')
    expected_inputs[str(plan_path.relative_to(ROOT))] = digest(plan_path)
    need(meta['input_sha256'] == expected_inputs, 'entire captured input graph')
    for path in (meta_path, result_path, directory / 'stdout.txt', directory / 'stderr.txt'):
        graph[str(path.relative_to(ROOT))] = digest(path)
    return load(result_path)


def normalized_result(result):
    out = copy.deepcopy(result)
    del out['seconds']
    # The display float is not arithmetic evidence; retaining it in equality
    # is harmless, but no conclusion depends on binary floating comparison.
    return out


def controls(plan, result, rho, ph, mh):
    def pchange(fn):
        p = copy.deepcopy(plan)
        fn(p)
        return p, result
    def rchange(fn):
        r = copy.deepcopy(result)
        fn(r)
        return plan, r
    bad = [
        pchange(lambda x: x.update(n=[20, 21, 22, 23, True])),
        pchange(lambda x: x.update(target='41/100')),
        pchange(lambda x: x.update(strips=[])),
        pchange(lambda x: x['strips'].append(copy.deepcopy(x['strips'][-1]))),
        pchange(lambda x: x['strips'][0]['h_panels'][0].update(h=['0', '1'])),
        pchange(lambda x: x['strips'][0]['h_panels'][0].update(c='4')),
        pchange(lambda x: x['strips'][0]['h_panels'][-1]['h'].__setitem__(1, '999/1000')),
        rchange(lambda x: x['rows'].pop()),
        rchange(lambda x: x['rows'].reverse()),
        rchange(lambda x: x['rows'][0].update(n=True)),
        rchange(lambda x: x['rows'][0].update(eta_upper='1')),
        rchange(lambda x: x['rows'][0].update(zeta_lower='2')),
        rchange(lambda x: x['rows'][0].update(normalized_upper='0')),
        rchange(lambda x: x['rows'][0]['terms'].update(tail='-1')),
        rchange(lambda x: x['rows'][0].update(cells_per_piece=1024)),
        rchange(lambda x: x['attempts'].pop()),
        rchange(lambda x: x['attempts'][0].update(passed=not x['attempts'][0]['passed'])),
        rchange(lambda x: x.update(status='EXACT_UNCONDITIONAL_H_COVER_NOT_CLOSED')),
        rchange(lambda x: x.update(plan_sha256='0' * 64)),
    ]
    # eta mutation must differ even for a one-panel strip whose upper is1.
    bad[10][1]['rows'][0]['eta_upper'] = '1/2'
    for p, r in bad:
        try:
            validate_result(r, p, rho, ph, mh)
        except (ValueError, TypeError, KeyError, IndexError):
            pass
        else:
            raise ValueError('malformed proof object accepted')
    try:
        json.loads('{"n":20,"n":21}', object_pairs_hook=unique)
    except ValueError:
        pass
    else:
        raise ValueError('duplicate JSON key accepted')
    return len(bad) + 1


def main():
    need(__debug__ and not sys.flags.optimize and sys.dont_write_bytecode, 'ordinary -B execution')
    need(len(sys.argv) == 2, 'one source-bound request required')
    request_path = Path(sys.argv[1]).resolve()
    request = load(request_path)
    need(type(request) is dict and set(request) == {'plan', 'plan_sha256', 'manifest_sha256', 'construct_capture', 'construct_metadata_sha256', 'replay_capture', 'replay_metadata_sha256', 'rho', 'output'}, 'request fields')
    plan_path = safe_path(request['plan'])
    output = safe_path(request['output'])
    need(output.parent == HERE and not output.exists(), 'fresh local output')
    manifest_path = ROOT / 'work/cutoff20_20261016/fourier/cover_v1/MANIFEST.json'
    need(digest(plan_path) == request['plan_sha256'] and digest(manifest_path) == request['manifest_sha256'], 'request input pins')
    manifest = load(manifest_path)
    graph = dict(manifest['files_sha256'])
    need(graph and all(type(v) is str and len(v) == 64 for v in graph.values()), 'nonempty source graph')
    for path, expected in graph.items():
        need(digest(safe_path(path)) == expected, 'source integrity: ' + path)
    graph[str(manifest_path.relative_to(ROOT))] = digest(manifest_path)
    graph[str(plan_path.relative_to(ROOT))] = digest(plan_path)
    graph[str(request_path.relative_to(ROOT))] = digest(request_path)
    graph[str(Path(__file__).resolve().relative_to(ROOT))] = digest(Path(__file__))
    graph[str((HERE / 'REVIEW.txt').relative_to(ROOT))] = digest(HERE / 'REVIEW.txt')
    plan = load(plan_path)
    constructed = capture(safe_path(request['construct_capture']), 'construct', request['construct_metadata_sha256'], plan_path, manifest, graph)
    replayed = capture(safe_path(request['replay_capture']), 'replay', request['replay_metadata_sha256'], plan_path, manifest, graph)
    expected = validate_result(constructed, plan, request['rho'], request['plan_sha256'], request['manifest_sha256'])
    validate_result(replayed, plan, request['rho'], request['plan_sha256'], request['manifest_sha256'])
    need(normalized_result(constructed) == normalized_result(replayed), 'complete exact construction/replay equality')
    negative = controls(plan, constructed, request['rho'], request['plan_sha256'], request['manifest_sha256'])
    tail = F(3328, 10000) * (1 + F(429, 1000) / F(19, 10))
    need(tail < TARGET, 'external Shevtsova tail scalar comparison')
    need(all(digest(safe_path(p)) == h for p, h in graph.items()), 'all inputs unchanged')
    maximum = max(rat(row['normalized_upper']) for row in constructed['rows'])
    record = dict(status='PASS_INDEPENDENT_EXACT_FOURIER_COVER_READBACK',
                  mathematical_status='Source-reviewed universal Fourier bound conditional on the stated external Prawitz theorem and exact scalar certificate; lower rho remains outside scope.',
                  execution_status='Fresh independent coverage, scalar normalization and capture/source validation; native integration reproduced by the constructor and replay, not independently recomputed here.',
                  n=NS, rho=request['rho'], target=str(TARGET), normalized_upper_max=str(maximum),
                  rho_strips=len(plan['strips']), h_cells=len(expected), exact_rows=len(constructed['rows']), attempts=len(constructed['attempts']), negative_controls=negative,
                  external_tail_from='19/10', external_tail_upper=str(tail), files_sha256=graph)
    with output.open('x') as f:
        json.dump(record, f, indent=2)
        f.write('\n')
    print(json.dumps({k: v for k, v in record.items() if k != 'files_sha256'}), flush=True)


if __name__ == '__main__':
    main()
