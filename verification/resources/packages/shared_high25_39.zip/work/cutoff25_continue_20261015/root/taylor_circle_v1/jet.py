"""Directed value/first/second derivative enclosures; no numerical differentiation."""
from pathlib import Path
import sys
U=Path(__file__).resolve().parents[3]/'cutoff25_rethink_20261015/scale_analytic/fourier_interval'
sys.path.insert(0,str(U))
from kernel import I,PI,sin as isin,cos as icos,expminus as iexpminus

class J:
    def __init__(self,v,d=0,dd=0):
        if type(v)is J:
            if d!=0 or dd!=0:raise TypeError('copy with derivatives')
            self.v,self.d,self.dd=v.v,v.d,v.dd
        else:self.v,self.d,self.dd=I(v),I(d),I(dd)
    def __add__(self,other):
        b=J(other);return J(self.v+b.v,self.d+b.d,self.dd+b.dd)
    __radd__=__add__
    def __neg__(self):return J(-self.v,-self.d,-self.dd)
    def __sub__(self,b):return self+-J(b)
    def __rsub__(self,b):return J(b)+-self
    def __mul__(self,other):
        b=J(other);return J(self.v*b.v,self.d*b.v+self.v*b.d,self.dd*b.v+2*self.d*b.d+self.v*b.dd)
    __rmul__=__mul__
    def reciprocal(self):
        v=self.v
        if v.l<=0<=v.h:raise ValueError('reciprocal crosses zero')
        return J(1/v,-self.d/v.sq(),2*self.d.sq()/(v**3)-self.dd/v.sq())
    def __truediv__(self,b):return self*J(b).reciprocal()
    def __rtruediv__(self,b):return J(b)*self.reciprocal()
    def __pow__(self,n):
        if type(n)is not int or n<0:raise ValueError('literal nonnegative integer power')
        if n==0:return J(1)
        if n==1:return J(self)
        return J(self.v**n,n*(self.v**(n-1))*self.d,n*(n-1)*(self.v**(n-2))*self.d.sq()+n*(self.v**(n-1))*self.dd)
    def sq(self):return self**2
    def sqrt(self):
        if self.v.l<=0:raise ValueError('smooth square root needs strictly positive radicand')
        y=self.v.sqrt()
        return J(y,self.d/(2*y),self.dd/(2*y)-self.d.sq()/(4*(y**3)))

def sin(x):
    x=J(x);s,c=isin(x.v),icos(x.v)
    return J(s,c*x.d,-s*x.d.sq()+c*x.dd)
def cos(x):
    x=J(x);s,c=isin(x.v),icos(x.v)
    return J(c,-s*x.d,-c*x.d.sq()-s*x.dd)
def expminus(x):
    x=J(x);e=iexpminus(x.v)
    return J(e,-e*x.d,e*(x.d.sq()-x.dd))
