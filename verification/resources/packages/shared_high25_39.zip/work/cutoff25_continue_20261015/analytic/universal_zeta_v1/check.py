"""Exact actual-law and negative controls for the universal zeta envelope."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
CIRCLE=ROOT/'work/cutoff25_rethink_20261015/repo_iid_low_v1/ZETA_CIRCLE_PROOF.txt'

def law(atoms):
    assert type(atoms)is list and atoms
    assert all(type(a)is tuple and len(a)==2 and all(type(x)is F for x in a) for a in atoms)
    assert all(p>=0 for x,p in atoms) and sum(p for x,p in atoms)==1
    mu=sum(x*p for x,p in atoms);atoms=[(x-mu,p) for x,p in atoms]
    assert sum(x*p for x,p in atoms)==0
    w=sum(p*x*x for x,p in atoms);assert w>0
    H=sum(p*abs(x) for x,p in atoms);T=sum(p*abs(x)**3 for x,p in atoms)
    A=sum(p*x*x for x,p in atoms if x>0);B=sum(p*x*x for x,p in atoms if x<0)
    assert min(H,T,A,B)>0 and A+B==w
    r=H/2;positive=sum(p for x,p in atoms if x>0);negative=sum(p for x,p in atoms if x<0)
    Tp=sum(p*x**3 for x,p in atoms if x>0);Tm=sum(p*(-x)**3 for x,p in atoms if x<0)
    assert A*A<=r*Tp and B*B<=r*Tm
    assert r*r/A<=positive and r*r/B<=negative and positive+negative<=1
    gap_h=4*A*B-H*H*w;gap_rho=H*T+4*A*B-2*w*w
    raw_z=4*A*B/H;gap=raw_z*(T+raw_z)-2*w**3
    assert gap_h>=0 and gap_rho>=0 and gap>=0
    support={x for x,p in atoms if p>0}
    assert (gap==0)==(len(support)==2)
    return {'atoms':[[str(x),str(p)] for x,p in atoms],'variance':str(w),
            'h_gap':str(gap_h),'rho_plus_zeta_gap':str(gap_rho),'final_gap':str(gap),
            'equality':gap==0}

def rejected(fn):
    try:fn()
    except (AssertionError,ValueError,TypeError,ZeroDivisionError):return 1
    raise AssertionError('malformed fixture accepted')

def main():
    assert __debug__ and sys.flags.optimize==0 and sys.dont_write_bytecode
    fixtures=[]
    for p in map(F,['1/1000000','1/100','8/25','2/5','1/2','99/100']):
        fixtures.append([(-p,1-p),(1-p,p)])
    fixtures += [
      [(F(-2),F(1,8)),(F(0),F(3,4)),(F(2),F(1,8))],
      [(F(-1),F(499999,1000000)),(F(1),F(1,2)),(F(1000),F(1,1000000))],
      [(F(-1),F(1,4)),(F(-1),F(1,4)),(F(1),F(1,2))],
      [(F(-3),F(1,10)),(F(-1),F(1,5)),(F(2),F(3,10)),(F(7),F(2,5))],
      [(F(-1000000),F(1,10**18)),(F(-1),F(1,2)-F(1,10**18)),(F(1),F(1,2))],
      [(F(-1),F(499999,1000000)),(F(0),F(1,1000000)),(F(1),F(1,2))],
    ]
    epsilon=F(1,9000000);M=F(100)
    fixtures.append([(-M,epsilon/2),(-F(1),(1-epsilon)/2),(F(1),(1-epsilon)/2),(M,epsilon/2)])
    rows=[law(a) for a in fixtures]
    w=1+epsilon*(M*M-1);T=1+epsilon*(M**3-1)
    eta_raw=1+3*epsilon*(M-1)+epsilon*epsilon*(M**3-3*M+2)
    pair=sum(px*py*abs(x-y)**3 for x,px in fixtures[-1] for y,py in fixtures[-1])/2-T
    assert pair==eta_raw>0 and F(11,10)**2<T*T/w**3<F(6,5)**2
    eta_gap=eta_raw*eta_raw+T*eta_raw-2*w**3;assert eta_gap>0
    for a,r in zip(fixtures,rows):assert law(list(reversed(a)))['final_gap']==r['final_gap']
    bad=[[],[(F(0),F(1))],[(F(1),F(1,2))],[(F(-1),F(-1)),(F(1),F(2))],[(1,F(1,2)),(F(-1),F(1,2))]]
    negatives=sum(rejected(lambda a=a:law(a)) for a in bad)
    out={'status':'FRESH_EXACT_ACTUAL_LAW_CONTROLS_FOR_UNIVERSAL_ZETA_THEOREM',
         'laws':rows,'global_eta_counterexample':{'variance':str(w),'third_raw':str(T),'eta_raw':str(eta_raw),'strict_violation_gap':str(eta_gap)},'negative_controls':negatives,'reordered_atoms':'identical','python':sys.version,
         'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),HERE/'PROOF.txt',CIRCLE]}}
    with (HERE/'CHECKED.json').open('x') as st:json.dump(out,st,indent=2);st.write('\n')
    print(json.dumps({'actual_laws':len(rows),'equality_laws':sum(r['equality'] for r in rows),'negative_controls':negatives}))

if __name__=='__main__':main()
