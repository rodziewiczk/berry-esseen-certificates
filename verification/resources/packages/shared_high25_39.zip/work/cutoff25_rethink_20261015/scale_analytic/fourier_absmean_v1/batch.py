"""Exact five-n Fourier enclosure with an absolute-mean upper and kappa=62/625."""
from pathlib import Path
from fractions import Fraction as F
import sys,time

H=Path(__file__).resolve().parent
U=H.parent/'fourier_interval';sys.path.insert(0,str(U))
from kernel import I,PI,sin,cos,expminus

NS=(26,27,28,29,30)
KAPPA=F(62,625)

def need(x,msg):
    if not x:raise ValueError(msg)

def validate_ns(ns):
    need(type(ns)is tuple and all(type(n)is int for n in ns)and ns==NS,'literal ordered n tuple26..30 required')

def powers(x,ns):
    validate_ns(ns);out={};y=I(1)
    for n in range(1,ns[-1]+1):
        y=y*x
        if n in ns:out[n]=y
    return out

def geometrics(a,b,ns):
    validate_ns(ns);a=I(a);b=I(b);S=I(0);bp=I(1);out={}
    for n in range(1,ns[-1]+1):
        S=a*S+bp;bp=bp*b
        if n in ns:out[n]=S.h
    return out

def power6(x):
    y=I(1)
    for _ in range(6):y=y*x
    return y

def cot_defect_upper(x):
    need(0<=x.l<=x.h<=1,'cotangent correction proof domain')
    return x/(3*(1-x.sq()/6))

def kernel_norm(t):
    r=1-t
    if t.l>=F(3,4):
        d=cot_defect_upper(PI*r)
        return (r*(1+d.sq()).sqrt()).h
    x=PI*t;si=sin(x)
    need(si.l>0,'positive sine denominator')
    k=r*cos(x)/si+1/PI
    return (r.sq()+k.sq()).sqrt().h

def shared_cell(t,hi,eta,c,scale,low):
    need(type(low)is bool,'literal low branch flag required')
    u=c*t;u2=u.sq();u3=u2*u;co=cos(u)
    delta=hi-1;J=delta*(hi+F(5,3))/36
    re=co+delta*u3/6
    line=1-u2+2*KAPPA*(hi+eta)*u3
    need(line.h>=0,'line radicand upper nonnegative')
    modulus=min(F(1),I(max(F(0),line.h)).sqrt().h)
    D=hi+eta;z=D*u;curved=False
    if z.l>=4 and z.h<=2*PI.l:
        rad=1-2*scale*(1-cos(z))/(D*D)
        need(rad.h>=0,'curved radicand upper nonnegative')
        modulus=min(modulus,I(max(F(0),rad.h)).sqrt().h);curved=True
    need(u.h<=PI.l,'real lower bound domain')
    imag_sq=(J*power6(u)).h
    coordinate_sq=max(co.sq().h,re.sq().h)+imag_sq
    modulus=min(modulus,I(coordinate_sq).sqrt().h)
    K=kernel_norm(t)
    row=dict(K=K,modulus=modulus,curved=curved)
    if low:
        need(u.h<F(3,2),'low-frequency domain')
        g=expminus(u2/2)
        midpoint=(u.l+u.h)/2;radius=(u.h-u.l)/2
        mid=I(midpoint)
        difference=cos(mid)-expminus(mid.sq()/2)
        error_radius=F(2,3)*u.h**3*radius
        difference=difference+I(-error_radius,error_radius)
        shifted=difference+delta*u3/6
        difference_sq=max(difference.sq().h,shifted.sq().h)+imag_sq
        error_disk=I(difference_sq).sqrt().h
        d=cot_defect_upper(PI*t)
        correction=(1-t)*(1+d.sq()).sqrt()
        row.update(g=g,error_disk=error_disk,correction=correction)
    return row

def integrands(t,ns,hi,eta,c,scale,low):
    validate_ns(ns);row=shared_cell(t,hi,eta,c,scale,low)
    mp=powers(I(row['modulus']),ns)
    if not low:return{n:(row['K']*mp[n].h,F(0),row['curved'])for n in ns}
    gp=powers(row['g'],ns);geo=geometrics(row['modulus'],row['g'].h,ns);out={}
    for n in ns:
        error=row['error_disk']*geo[n]
        error=min(error,(mp[n]+gp[n]).h)
        normal=(row['correction']*gp[n]).h
        out[n]=(row['K']*error,normal,row['curved'])
    return out

def validate_parameters(ns,lo,hi,eta,c,tau,cells):
    validate_ns(ns)
    need(all(type(x)is F for x in(lo,hi,eta,c,tau)),'exact Fraction parameters required')
    need(1<=lo<=hi and 0<eta<=1 and 0<c<PI.l and 0<tau<=F(3,10),'parameters')
    eps=F(1,1024)
    need(eps<tau<1-eps and type(cells)is int and cells>=8,'closed integration range')

def calculate(ns,lo,hi,eta,c,tau,cells):
    validate_parameters(ns,lo,hi,eta,c,tau,cells);eps=F(1,1024)
    scale=(8-64*KAPPA)/(1-cos(I(4)))
    need(0<scale.l<=scale.h<=1,'profile coefficient')
    start=time.monotonic();sums={n:dict(low=F(0),normal=F(0),high=F(0),curved=0)for n in ns}
    for low,a,b in((True,eps,tau),(False,tau,1-eps)):
        width=(b-a)/cells
        for j in range(cells):
            t=I(a+j*width,a+(j+1)*width)
            values=integrands(t,ns,hi,eta,c,scale,low)
            for n in ns:
                val,norm,curved=values[n]
                if low:sums[n]['low']+=width*val;sums[n]['normal']+=width*norm
                else:sums[n]['high']+=width*val
                sums[n]['curved']+=int(curved)
        print('BATCH_INTEGRATED',list(ns),str(lo),str(hi),'LOW'if low else'HIGH',cells,flush=True)
    ut=c*tau;tailpow=powers(expminus(I(ut*ut/2)),ns);rows=[]
    for n in ns:
        low_head=n*(hi*c**3/6*(eps**4/4+eps**3/(3*PI.l))+c**4/8*(eps**5/5+eps**4/(4*PI.l)))
        normal_head=eps+PI.h*eps*eps/2;high_tail=eps*eps/2+PI.h*eps**3/3
        tail=(tailpow[n]/(PI*n*ut*ut)).h
        terms=dict(low=sums[n]['low']+low_head,high=sums[n]['high']+high_tail,normal=sums[n]['normal']+normal_head,tail=tail)
        total=sum(terms.values());upper=I(n).sqrt().h*total/lo
        rows.append(dict(n=n,rho=[str(lo),str(hi)],absmean_upper=str(eta),kappa=str(KAPPA),c=str(c),tau=str(tau),epsilon=str(eps),cells_per_piece=cells,
                         normalized_upper=str(upper),normalized_upper_float=float(upper),target='4097/10000',strict_target_pass=upper<F(4097,10000),terms={k:str(v)for k,v in terms.items()},curved_cells=sums[n]['curved']))
    return dict(rows=rows,shared_cells=2*cells,per_n_cells=2*cells,seconds=time.monotonic()-start)
