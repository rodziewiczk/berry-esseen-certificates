"""Full support-free literal n25..39 rho/H cover with exact parallel construction and replay."""
from pathlib import Path
from hashlib import sha256,file_digest
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
import argparse,importlib.util,json,os,sys,threading,time

HERE=Path(__file__).resolve().parent
CORE=HERE/'work/cutoff20_20261016/fourier'
sys.path.insert(0,str(CORE));sys.path.insert(1,str(CORE/'cover_v1'))
import protocol
core=protocol.core
TARGET=F(4097,10000)
SCOPE='All iid centered unit-variance laws in the stated closed rho interval; literal n25..39. No acquired support or predecessor assumption.'


def need(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    with Path(path).open('rb')as stream:return file_digest(stream,'sha256').hexdigest()


def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode('ascii')


def sources():
    manifest=json.loads((HERE/'N2539-SOURCE-VERIFIED.json').read_bytes())
    for name,pin in manifest['files'].items():
        need(sha(HERE/name)==pin,'Whole static source '+name)
    need(core.NS==(25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39),'Literal actual25 arithmetic scope')
    return sha(HERE/'N2539-SOURCE-VERIFIED.json')


def one(cell):
    si,ci,strip,item=cell;lo,hi=map(F,strip['rho']);hl,hu=map(F,item['h'])
    zeta=max(hl,F(2)/hu-hi,((core.I(hi*hi+8).sqrt()-hi)/2).l);attempts=[]
    for mesh in(128,256,512):
        result=core.calculate(lo,hi,hu,zeta,F(item['c']),F(item['tau']),mesh)
        need([r['n']for r in result['rows']]==list(core.NS),'Every literal actual index')
        for row in result['rows']:
            exact=core.I(row['n']).sqrt().h*sum(F(x)for x in row['terms'].values())/lo
            need(F(row['normalized_upper'])==exact,'Whole exact normalization')
            row.update(h_surrogate=item['h'],rho_strip_index=si,h_cell_index=ci,target=str(TARGET),strict_target_pass=exact<TARGET)
        passed=all(r['strict_target_pass']for r in result['rows'])
        attempts.append(dict(rho_strip_index=si,h_cell_index=ci,mesh=mesh,passed=passed,
            normalized_uppers=[r['normalized_upper']for r in result['rows']]))
        if passed:break
    return dict(rows=result['rows'],attempts=attempts)


def episode(plan,jobs,plan_pin,manifest_pin):
    count=protocol.validate(plan);negative=protocol.negative_controls(plan)
    cells=[(si,ci,strip,item)for si,strip in enumerate(plan['strips'])for ci,item in enumerate(strip['h_panels'])]
    began=time.monotonic()
    with ProcessPoolExecutor(max_workers=min(jobs,len(cells)))as pool:parts=list(pool.map(one,cells))
    rows=[r for part in parts for r in part['rows']];attempts=[r for part in parts for r in part['attempts']]
    need(len(rows)==count*len(core.NS),'All literal25..39 rows across the entire closed cover')
    return dict(status='EXACT_UNCONDITIONAL_H_COVER_PASS'if all(r['strict_target_pass']for r in rows)else'EXACT_UNCONDITIONAL_H_COVER_NOT_CLOSED',
        scope=SCOPE,n=list(core.NS),rho=plan['rho'],target=str(TARGET),h_cells=count,rho_strips=len(plan['strips']),
        rows=rows,attempts=attempts,negative_controls=negative,plan_sha256=plan_pin,
        manifest_sha256=manifest_pin,seconds=time.monotonic()-began)


def run(task,deadline,jobs):
    need(__debug__ and sys.dont_write_bytecode and sys.flags.no_site,'Unoptimized stdlib-only -B -S runtime')
    need(type(jobs)is int and 1<=jobs<=96 and time.time()<deadline,'Finite admitted concurrency and cutoff')
    timer=threading.Timer(deadline-time.time(),lambda:os._exit(124));timer.daemon=True;timer.start()
    try:
        before=sources();task=Path(task)
        need(task.is_absolute()and not task.exists()and not task.resolve().is_relative_to(HERE),'Exclusive fresh output outside sources')
        task.mkdir(parents=True,exist_ok=False);plan_path=HERE/'PLAN2539.json';plan=json.loads(plan_path.read_bytes())
        need(plan['n']==list(core.NS)and plan['rho']==['6/5','19/10'],'Complete actual25 target rectangle')
        independent_path=HERE/'work/cutoff20_20261016/analytic/fourier_cover_review_v1/readback.py'
        spec=importlib.util.spec_from_file_location('universal25_independent_readback',independent_path)
        independent=importlib.util.module_from_spec(spec);spec.loader.exec_module(independent)
        results=[]
        for label in('construct','replay'):
            result=episode(plan,jobs,sha(plan_path),sha(CORE/'cover_v1/MANIFEST.json'))
            independent.validate_result(result,plan,plan['rho'],sha(plan_path),result['manifest_sha256'])
            controls=independent.controls(plan,result,plan['rho'],sha(plan_path),result['manifest_sha256'])
            need(controls==20,'All original20 independent negative controls')
            (task/(label+'.json')).write_bytes(encoded(result));results.append(result)
        left,right=({k:v for k,v in result.items()if k!='seconds'}for result in results)
        need(left==right,'Complete deterministic exact construct/replay equality')
        need(sources()==before,'Whole source before/after equality')
        tail=F(208,625)*(1+F(429,1000)/F(19,10));need(tail<TARGET,'Exact published infinite-rho complement endpoint')
        report=dict(schema='be.unrestricted-n2539-universal-fourier-complete-numerical-observation/1',
            status='UNRESTRICTED_N2539_FOURIER_NUMERICAL_PASS',n=list(core.NS),rho=plan['rho'],target=str(TARGET),
            rho_strips=len(plan['strips']),h_cells=results[0]['h_cells'],sample_size_rows=len(results[0]['rows']),
            per_n_upper={str(n):max((r['normalized_upper']for r in results[0]['rows']if r['n']==n),key=F)for n in core.NS},
            normalized_upper_max=max((r['normalized_upper']for r in results[0]['rows']),key=F),
            independent_negative_controls=20,native_negative_controls=10,
            construct_sha256=sha(task/'construct.json'),replay_sha256=sha(task/'replay.json'),
            source_manifest_sha256=before,external_tail_from='19/10',external_tail_upper=str(tail),
            support_used=False,predecessor_used=False,monotonicity_in_n_used=False,
            actual_source_runtime_cgroup_authentication_still_required=True,
            n_generic_analytic_Prawitz_and_kappa_licenses_still_required=True,full_proof_pass=False)
        (task/'RESULT.json').write_bytes(encoded(report));print(json.dumps(report),flush=True);return report
    finally:timer.cancel()


if __name__=='__main__':
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('mode',choices=('run',))
    p.add_argument('--task',type=Path,required=True);p.add_argument('--deadline',type=int,required=True)
    p.add_argument('--jobs',type=int,default=1);a=p.parse_args();run(a.task,a.deadline,a.jobs)
