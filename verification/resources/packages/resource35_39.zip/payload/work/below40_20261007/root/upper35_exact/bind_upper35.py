"""Bind the exact complement replay to the independently accepted INITIAL/seed pair.
This checks recorded execution, coverage and source identity; no heavy replay.
"""
from pathlib import Path
from hashlib import sha256
import ast,copy,importlib.util,json,sys
H=Path(__file__).resolve().parent;ROOT=H.parents[3]
ENTRY=ROOT/'work/below40_20261007/support/positive35_acq'
CAPTURED=Path('/Users/bkolodziejek/Downloads/BE_Codex_Handoff')
INDICES=list(range(16))+list(range(49,100))
def need(x,s):
 if not x:raise ValueError(s)
def unique(items):
 d={}
 for k,v in items:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read(p):return json.loads(p.read_bytes(),object_pairs_hook=unique)
def sha(p):return sha256(p.read_bytes()).hexdigest()
def safe(base,name):
 need(type(name)is str and name and not Path(name).is_absolute()and all(x not in('','.','..')for x in name.split('/')),'safe canonical dependency')
 p=base/name;need(p.is_file()and not p.is_symlink()and p.resolve().is_relative_to(base.resolve()),'regular contained dependency');return p
def closure(driver):
 todo=[driver];seen=set()
 while todo:
  name=todo.pop()
  if name in seen:continue
  seen.add(name)
  for node in ast.walk(ast.parse((H/name).read_text())):
   mods=[z.name for z in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)else[]
   for mod in mods:
    if mod and(H/(mod+'.py')).is_file():todo.append(mod+'.py')
 return seen

def check_record(report,m,out,err):
 need(report['schema']=='COMPLEMENT35_EXCLUSION_ACCEPTANCE_V1'and report['status']=='PASS_COMPLEMENT35_EXCLUSION','fixed complement theorem')
 need(type(report['probability_panels'])is int and report['probability_panels']==67 and report['indices']==INDICES and all(type(i)is int for i in report['indices']),'all67 closed probability panels')
 need([report[x]for x in('initially_excluded','refinement_stages','support_H_cells','support_rays')]==[43,17,22460,36],'fixed complete arithmetic scope')
 need(type(report['negative_controls'])is list and len(report['negative_controls'])==len(set(report['negative_controls']))==19,'19 distinct corruption controls')
 need(type(m['returncode'])is int and m['returncode']==0,'fresh exact returncode')
 need(m['cwd']==str(CAPTURED/'work/below40_20261007/root/upper35_exact')and type(m['command'])is list and len(m['command'])==3 and m['command'][1:]==['-B','accept_upper.py'],'fixed ordinary acceptance invocation')
 need(sha256(out).hexdigest()==m['stdout_sha256']and sha256(err).hexdigest()==m['stderr_sha256']and err==b'','fresh output integrity')
 need(json.loads(out.strip().splitlines()[-1],object_pairs_hook=unique)==report,'actual stdout report')
 needed=closure('accept_upper.py')
 need(needed<=set(report['source_sha256'])and needed|{'initial35_proof.json','seeds35_proof.json','upper35_proof.json'}<=set(m['input_sha256']),'complete executed source closure and proof inputs')
 bindings={}
 for name,h in m['input_sha256'].items():
  p=safe(H,name);need(sha(p)==h,'executed input byte integrity '+name);bindings[str(p.relative_to(ROOT))]=h
 for name,h in report['source_sha256'].items():
  p=safe(H,name);need(m['input_sha256'][name]==h==sha(p),'accepted source bytes '+name)
 for key,name in [('initial_sha256','initial35_proof.json'),('seeds_sha256','seeds35_proof.json'),('candidate_sha256','upper35_proof.json')]:need(report[key]==sha(H/name),'accepted proof/input '+key)
 return bindings

def check():
 sp=importlib.util.spec_from_file_location('central35_bound_sources',ENTRY/'check_resources35_v2.py');res=importlib.util.module_from_spec(sp);sp.loader.exec_module(res)
 bindings=res.prior34();antecedents=[]
 for spec in res.SPECS[:2]:
  run=res.RUNBASE/spec[1];meta,report=res.read(run/'metadata.json'),res.read(ENTRY/spec[3]);out,err=(run/'stdout.txt').read_bytes(),(run/'stderr.txt').read_bytes()
  bindings.update(res.evidence(spec,meta,report,out,err))
  for p in(run/'metadata.json',run/'stdout.txt',run/'stderr.txt',ENTRY/spec[3]):bindings[str(p.relative_to(ROOT))]=sha(p)
  antecedents.append(spec[1])
 for name in('initial35_proof.json','seeds35_proof.json'):need(sha(H/name)==sha(ENTRY/name),'same copied and independently accepted source pair')
 inputs=read(H/'SOURCE_INPUT_BINDINGS.json')
 need(inputs=={str((ENTRY/name).relative_to(ROOT)):sha(H/name)for name in('initial35_proof.json','seeds35_proof.json')},'exact original/copy source map')
 run=ROOT/'runs/below40_20261007/root/upper35_accept01';report=read(H/'COMPLEMENT35_ACCEPTED.json');meta=read(run/'metadata.json');out,err=(run/'stdout.txt').read_bytes(),(run/'stderr.txt').read_bytes()
 bindings.update(check_record(report,meta,out,err))
 proof=read(H/'upper35_proof.json');need([r['index']for r in proof['rows']]==INDICES,'exact proof incidence')
 for i,z in zip(INDICES,proof['rows']):need(type(z['index'])is int and z['source']==('local45_57'if 49<=i<57 else'global'),'fixed same-law source assignment')
 for p in(run/'metadata.json',run/'stdout.txt',run/'stderr.txt',H/'COMPLEMENT35_ACCEPTED.json',H/'SOURCE_INPUT_BINDINGS.json',ENTRY/'check_resources35_v2.py',Path(__file__).resolve()):bindings[str(p.relative_to(ROOT))]=sha(p)
 return bindings,antecedents,(report,meta,out,err)

def main():
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary Python invocation')
 bindings,antecedents,args=check();controls=[]
 def reject(name,bad):
  try:check_record(*bad)
  except(ValueError,KeyError,TypeError,IndexError):controls.append(name);return
  raise ValueError('bad complement binding accepted '+name)
 for field,value in [('status','FAIL'),('indices',INDICES[:-1]),('negative_controls',[]),('initial_sha256','0'*64)]:
  a=copy.deepcopy(args);a[0][field]=value;reject('changed '+field,a)
 for field,value in [('returncode',False),('returncode',1),('cwd','/tmp'),('command',['python','-O','accept_upper.py'])]:
  a=copy.deepcopy(args);a[1][field]=value;reject('changed '+field+str(value),a)
 a=copy.deepcopy(args);a[1]['input_sha256'].pop('upper_route35_core.py');reject('missing actual source',a)
 a=list(copy.deepcopy(args));a[2]+=b'changed';reject('changed captured stdout',a)
 result=dict(schema='COMPLEMENT35_BOUND_V1',status='PASS_ACTUAL_COMPLEMENT35_EXCLUSION',mathematical_status='Locally derived exact complement exclusion for an attained index35 counterexample, using complete34 and retained contact/Fourier inputs. Low16..30 and central31..48 remain separate obligations.',execution_status='Global and short-seed arithmetic plus complement arithmetic separately freshPASS; this run checks same-law inputs, recorded source integrity and full regional coverage.',n=35,decrement='63/340',own_cap='423493/1000000',indices=INDICES,source_runs=antecedents+['upper35_accept01'],negative_controls=controls,bound_sha256=bindings)
 dest=H/'COMPLEMENT35_BOUND.json';need(not dest.exists(),'fresh result');dest.write_text(json.dumps(result,indent=2)+'\n');print('ACTUAL_COMPLEMENT35_BOUND_PASS',len(bindings),len(controls),flush=True)
if __name__=='__main__':main()
