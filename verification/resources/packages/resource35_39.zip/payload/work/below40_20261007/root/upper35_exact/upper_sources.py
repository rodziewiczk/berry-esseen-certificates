"""Fixed source selection for the complement of the low/central35 rows."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from accept_initial35 import need,equal,read,fields,rat,unique
from initial35_profile import P,enc
import re
HERE=Path(__file__).resolve().parent
INDICES=tuple(range(16))+tuple(range(49,100))
def long_rat(x):
 need(type(x)is str and re.fullmatch(r'-?[0-9]+(?:/[1-9][0-9]*)?',x)is not None,'typed exact rational')
 value=F(x);need(str(value)==x,'canonical exact rational');return value
def digest(p):return sha256(Path(p).read_bytes()).hexdigest()
def inputs():
 initial=read(HERE/'initial35_proof.json');seeds=read(HERE/'seeds35_proof.json')
 need(initial['schema']=='POSITIVE35_INITIAL_V1' and equal(initial['profile'],enc(P)),'fixed global INITIAL35')
 need(len(initial['export']['panels'])==100,'all global probability panels')
 need(seeds['schema']=='SHORT_CENTRAL35_SEEDS_V1','fixed short seed theorem')
 need(seeds['initial_sha256']==digest(HERE/'initial35_proof.json'),'local seeds use this same global INITIAL')
 bands=[b for b in seeds['bands']if b['interval']==[45,57]]
 need(len(bands)==1 and len(bands[0]['stages'])==2,'exact two-cover upper local seed')
 last=bands[0]['stages'][-1];profile=last['profile']
 need(profile['p_interval']==['9/20','57/100'] and profile['radius_minus']=='33/10' and profile['radius_plus']=='37/10','fixed upper local support and probability scope')
 need(len(last['output']['panels'])==100,'complete localized panel export')
 return initial,last
def selected(initial,last,i):
 need(type(i)is int and i in INDICES,'selected complement index')
 local=49<=i<57
 row=(last['output']if local else initial['export'])['panels'][i]
 need(F(row['pl'])==F(i,100) and F(row['pu'])==F(i+1,100),'closed selected probability panel')
 if local:return row,F(33,10),F(37,10),'local45_57'
 return row,F(39,10),F(39,10),'global'
