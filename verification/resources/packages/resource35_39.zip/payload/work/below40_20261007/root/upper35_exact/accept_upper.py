"""Fixed exact complement35 replay. Initial and seed acceptance are other edges."""
from upper_sources import *
import upper_route35_core as r
from product_endpoint34 import seed
import json,copy,sys
def shape(o):
 fields(o,('schema','initial_sha256','seeds_sha256','global_support','rows'))
 need(o['schema']=='COMPLEMENT35_EXCLUSION_V1','fixed exclusion theorem')
 need(o['initial_sha256']==digest(HERE/'initial35_proof.json') and o['seeds_sha256']==digest(HERE/'seeds35_proof.json'),'same acquired global/local source bytes')
 need(type(o['rows'])is list and len(o['rows'])==len(INDICES),'complete complement incidence')
 for i,z in zip(INDICES,o['rows']):
  need(type(z['index'])is int and z['index']==i,'ordered strict index')
  need(z['source']==('local45_57'if 49<=i<57 else'global'),'fixed source incidence')
  need(z['kind']in('empty_initial','negative_initial','resource'),'fixed exclusion branch')
  names=['index','source','kind']
  if z['kind']=='resource':
   names+=['product_A','product_B','base','refinements'];long_rat(z['product_A']);long_rat(z['product_B'])
   need(type(z['refinements'])is list and len(z['refinements'])<=40,'finite refinement schedule')
   for w in z['refinements']:rat(w['radius_minus']);rat(w['radius_plus'])
  fields(z,names)
def verify(o,emit=False):
 shape(o);initial,last=inputs();support=r.ds.target(r.N,r.K,r.R,r.Q)
 need(equal(o['global_support'],support),'fixed independent support rays')
 hc=support['gaussian']['cells'];rays=len(support['ray_rows']);steps=0;empty=0
 for z in o['rows']:
  i=z['index'];source,rm,rp,origin=selected(initial,last,i)
  kind='empty_initial'if source['cells']==0 else'negative_initial'if F(source['D'])<0 else'resource'
  need(z['kind']==kind,'actual source exclusion branch')
  if kind!='resource':empty+=1;continue
  row=seed(r.decode_row(source));need(z['product_A']==str(row['A'])and z['product_B']==str(row['B']),'actual endpoint-product floors')
  current=r.base_cell(json.dumps(enc(row),sort_keys=True),rm,rp);need(equal(z['base'],enc(current)),'fresh charged probability base')
  for claimed in z['refinements']:
   need(not current.get('excluded'),'no extra step after exclusion')
   a,b=rat(claimed['radius_minus']),rat(claimed['radius_plus'])
   got=r.refine(json.dumps(enc(current),sort_keys=True),rm,rp,a,b)
   need(equal(claimed,enc(got)),'fresh exact support-before-moment refinement')
   for s in got['support']:hc+=s['gaussian']['cells'];rays+=len(s['ray_rows'])
   rm,rp=a,b;current=got['result'];steps+=1
  need(current.get('excluded')is True,'strict actual-law exclusion')
  if emit:print('ACCEPTED_UPPER35',i,len(z['refinements']),flush=True)
 return dict(probability_panels=len(INDICES),indices=list(INDICES),initially_excluded=empty,refinement_stages=steps,support_H_cells=hc,support_rays=rays)
def main():
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary invocation');sys.set_int_max_str_digits(0)
 path=HERE/'upper35_proof.json';o=read(path);result=verify(o,True);controls=[]
 def mutate(name,fn,deep=False):
  x=copy.deepcopy(o);fn(x)
  try:verify(x)if deep else shape(x)
  except(ValueError,AssertionError,TypeError,KeyError,IndexError,ZeroDivisionError):controls.append(name);return
  raise ValueError('corrupted complement accepted: '+name)
 for key in('schema','initial_sha256','seeds_sha256'):mutate('wrong '+key,lambda x,key=key:x.update({key:'wrong'}))
 mutate('missing panel',lambda x:x['rows'].pop());mutate('duplicate panel',lambda x:x['rows'].append(x['rows'][0]));mutate('reordered panels',lambda x:x['rows'].reverse())
 mutate('boolean index',lambda x:x['rows'][0].update(index=False));mutate('false source incidence',lambda x:x['rows'][16].update(source='global'))
 mutate('false empty branch',lambda x:x['rows'][0].update(kind='negative_initial'),True)
 mutate('changed decrement',lambda x:x['global_support'].update(q='0'),True);mutate('missing full support ray',lambda x:x['global_support']['ray_rows'].pop(),True)
 j=next(i for i,z in enumerate(o['rows'])if z['kind']=='resource'and z['refinements'])
 mutate('false endpoint product',lambda x:x['rows'][j].update(product_A='1'),True)
 mutate('false base exclusion',lambda x:x['rows'][j]['base'].update(excluded=True),True)
 mutate('missing refinement',lambda x:x['rows'][j]['refinements'].pop(),True)
 mutate('noncanonical radius',lambda x:x['rows'][j]['refinements'][0].update(radius_minus='01'))
 mutate('unproved support radius',lambda x:x['rows'][j]['refinements'][0].update(radius_minus='1'),True)
 mutate('false terminal exclusion',lambda x:x['rows'][j]['refinements'][-1]['result'].update(excluded=False),True)
 mutate('extra accepted flag',lambda x:x.update(accepted=True))
 try:json.loads('{"i":0,"i":0}',object_pairs_hook=unique)
 except ValueError:controls.append('duplicate JSON key')
 else:raise ValueError('duplicate keys accepted')
 result.update(schema='COMPLEMENT35_EXCLUSION_ACCEPTANCE_V1',status='PASS_COMPLEMENT35_EXCLUSION',mathematical_status='Conditional exclusions for p panels0..15 and49..99 under fixed global35 and two-cover45..57 source bounds, own cap.423493 and decrement63/340. Actual INITIAL/seed acceptance and the other33 panels remain separate edges.',initial_sha256=o['initial_sha256'],seeds_sha256=o['seeds_sha256'],candidate_sha256=digest(path),negative_controls=controls,source_sha256={p.name:digest(p)for p in HERE.glob('*.py')})
 dest=HERE/'COMPLEMENT35_ACCEPTED.json';need(not dest.exists(),'fresh acceptance');dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
