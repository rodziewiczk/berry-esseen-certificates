"""Wait for complete seed construction, snapshot inputs, then construct/replay."""
from pathlib import Path
import json,time,sys,subprocess,shutil,hashlib
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
SOURCE=HERE.parents[1]/'support/positive35_acq'
meta=ROOT/'runs/below40_20261007/support/positive35_seeds_construct01/metadata.json'
assert __debug__ and not sys.flags.optimize
while not meta.exists():time.sleep(10)
assert json.loads(meta.read_text())['returncode']==0
bindings={}
for name in('initial35_proof.json','seeds35_proof.json'):
 source=SOURCE/name;dest=HERE/name;assert not dest.exists();shutil.copyfile(source,dest)
 h=hashlib.sha256(source.read_bytes()).hexdigest();assert hashlib.sha256(dest.read_bytes()).hexdigest()==h
 bindings[str(source.relative_to(ROOT))]=h
(HERE/'SOURCE_INPUT_BINDINGS.json').write_text(json.dumps(bindings,indent=2)+'\n')
logger=ROOT/'work/optimized301_20260927/tools/log_command.py'
for kind,script in [('construct','construct_upper.py'),('accept','accept_upper.py')]:
 run=ROOT/f'runs/below40_20261007/root/upper35_{kind}01'
 subprocess.run([sys.executable,'-B',str(logger),'--output',str(run),'--cwd',str(HERE),'--',sys.executable,'-B',script],cwd=HERE,check=True)
