"""Construct exact exclusions for all67 complementary probability panels."""
from upper_sources import *
import upper_route35_core as r
from product_endpoint34 import seed
import json,sys
need(__debug__ and not sys.flags.optimize,'ordinary Python')
sys.set_int_max_str_digits(0)
initial,last=inputs();path=HERE/'upper35_proof.json';need(not path.exists(),'fresh candidate')
out=dict(schema='COMPLEMENT35_EXCLUSION_V1',initial_sha256=digest(HERE/'initial35_proof.json'),seeds_sha256=digest(HERE/'seeds35_proof.json'),global_support=r.ds.target(r.N,r.K,r.R,r.Q),rows=[])
for i in INDICES:
 source,rm,rp,origin=selected(initial,last,i)
 record=dict(index=i,source=origin)
 if source['cells']==0:record.update(kind='empty_initial')
 elif F(source['D'])<0:record.update(kind='negative_initial')
 else:
  row=seed(r.decode_row(source));z=r.base_cell(json.dumps(enc(row),sort_keys=True),rm,rp)
  record.update(kind='resource',product_A=str(row['A']),product_B=str(row['B']),base=enc(z),refinements=[])
  for step in range(40):
   if z.get('excluded'):break
   radii=[]
   for sign,prior in[(-1,rm),(1,rp)]:
    radius=prior
    for k in range(14,40):
     proposed=F(k,10)
     if proposed>=prior:break
     try:r.ds.target(r.N,r.K,proposed,r.Q,sign=sign,rho=z['rho'],beta_lower=z['beta_lo'],beta_upper=z['beta'])
     except ValueError:continue
     radius=proposed;break
    radii.append(radius)
   got=r.refine(json.dumps(enc(z),sort_keys=True),rm,rp,*radii)
   rm,rp=radii;z=got['result'];record['refinements'].append(enc(got))
  need(z.get('excluded') is True,'strict completed complementary exclusion')
 out['rows'].append(record);path.write_text(json.dumps(out,indent=2)+'\n')
 print('CONSTRUCT_UPPER35',i,record['kind'],len(record.get('refinements',[])),flush=True)
print('CONSTRUCT_COMPLEMENT35_COMPLETE',len(out['rows']),flush=True)
