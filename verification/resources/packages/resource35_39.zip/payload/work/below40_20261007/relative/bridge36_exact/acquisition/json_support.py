from pathlib import Path
from fractions import Fraction as F
import json
def need(x,s):
    if not x:raise ValueError(s)
def enc(x):
    if type(x)is F:return str(x)
    if isinstance(x,dict):return{k:enc(v)for k,v in x.items()}
    if isinstance(x,(list,tuple)):return[enc(v)for v in x]
    return x
def equal(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
    return a==b
def unique(rows):
    d={}
    for k,v in rows:need(k not in d,'duplicate JSON key');d[k]=v
    return d
def read(p):return json.loads(Path(p).read_bytes(),object_pairs_hook=unique)
def fields(x,names):need(type(x)is dict and set(x)==set(names),'exact object schema')
def rat(x):
    need(type(x)is str and len(x)<100,'short rational string')
    v=F(x);need(str(v)==x,'canonical rational');return v
