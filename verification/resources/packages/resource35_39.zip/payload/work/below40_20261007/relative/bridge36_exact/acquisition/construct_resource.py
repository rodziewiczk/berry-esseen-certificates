"""Construct fixed-index bridge product-floor resources from global and localized INITIAL.
This is discovery; the independently executed fixed replay is separate.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys
import route_core as r
from product_endpoint import seed
from source_table import sources
from initial_profile import enc
from fixed_profile import N,SURVIVORS,CONTRACT_SHA
HERE=Path(__file__).resolve().parent
assert __debug__ and not sys.flags.optimize
sys.set_int_max_str_digits(0)
initialpath=HERE.parent/f'initial{N}_proof.json';targetpath=HERE/'contract.json'
seedpath=HERE.parent/'seeds/seeds36_proof.json';seeds=json.loads(seedpath.read_text())
ini=json.loads(initialpath.read_text());table=sources(ini,seeds);target=json.loads(targetpath.read_text());guards={g['index']:g for g in target['rows']}
assert'export'in ini and list(guards)==SURVIVORS
assert hashlib.sha256(targetpath.read_bytes()).hexdigest()==CONTRACT_SHA
out=dict(schema=f'BRIDGE{N}_LOCAL_SEEDED_RESOURCE_V1',seeds_sha256=hashlib.sha256(seedpath.read_bytes()).hexdigest(),initial_sha256=hashlib.sha256(initialpath.read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(targetpath.read_bytes()).hexdigest(),global_support=r.ds.target(r.N,r.K,r.R,r.Q),rows=[])
path=Path('acquisition_proof.json');assert not path.exists()
for index in range(len(out['rows']),100):
    source,rm,rp=table[index];row=r.decode_row(source)
    if row['cells']==0:
        out['rows'].append(dict(index=index,excluded='empty global INITIAL panel'));continue
    if row['D']<0:
        out['rows'].append(dict(index=index,excluded='negative global conserved budget'));continue
    row=seed(row)
    z=r.c.cell(r.N,max(rm,rp),r.CAP,row,steps=80,barrier=r.K)
    record=dict(index=index,product_A=str(row['A']),product_B=str(row['B']),base=enc(z),refinements=[])
    if not z.get('excluded'):
        for j in range(24):
            next_radii=[]
            for sign,prior in[(-1,rm),(1,rp)]:
                radius=prior
                for k in range(14,40):
                    cand=F(k,10)
                    if cand>=prior:break
                    try:r.ds.target(r.N,r.K,cand,r.Q,sign=sign,rho=z['rho'],beta_lower=z['beta_lo'],beta_upper=z['beta'])
                    except ValueError:continue
                    radius=cand;break
                next_radii.append(radius)
            result=r.refine(json.dumps(enc(z),sort_keys=True),rm,rp,*next_radii)
            rm,rp=next_radii;z=result['result'];record['refinements'].append(enc(result))
            print('CONSTRUCT_BRIDGE'+str(N),index,j+1,'excluded'if z.get('excluded')else str(z['D']),flush=True)
            if z.get('excluded'):break
            if index in guards and r.guarded(z,rm,rp,guards[index]):
                record['interface']=enc(r.interface(z,rm,rp,guards[index]));break
        assert z.get('excluded')or'interface'in record,(index,'fixed guards not reached')
    out['rows'].append(record);path.write_text(json.dumps(out,indent=2)+'\n')
path.write_text(json.dumps(out,indent=2)+'\n')
print('CONSTRUCT_BRIDGE'+str(N)+'_COMPLETE',len(out['rows']),[z['index']for z in out['rows']if'interface'in z],flush=True)
