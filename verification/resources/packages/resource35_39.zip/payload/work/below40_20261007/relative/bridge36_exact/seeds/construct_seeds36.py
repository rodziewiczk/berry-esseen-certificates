"""Construct the fixed two-cover local36 INITIAL candidate; no acceptance claim."""
from pathlib import Path
import json,hashlib,sys
import seeds36_core as c
assert __debug__ and not sys.flags.optimize
sys.set_int_max_str_digits(0)
source=Path(__file__).resolve().parent.parent/'initial36_proof.json';initial=json.loads(source.read_bytes())
path=Path('seeds36_proof.json');assert not path.exists()
out=dict(schema='SHORT_CENTRAL36_SEEDS_V1',initial_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),bands=[])
for spec in c.SPECS:
 out['bands'].append(c.band(initial,spec,True));path.write_text(json.dumps(out,indent=2)+'\n')
print('CONSTRUCT_SEEDS36_COMPLETE',sum(len(b['stages'])for b in out['bands']),flush=True)
