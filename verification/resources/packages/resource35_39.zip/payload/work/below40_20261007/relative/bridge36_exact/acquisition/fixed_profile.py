"""Fixed actual resource-acquisition profile; final sharp comparison is separate."""
from fractions import Fraction as F
from initial_profile import P
N=36
K=F(0)
Q=F(0)
CAP=P["cap"]
R=P["radius"]
FIRST=24
LAST=48
SURVIVORS=list(range(FIRST,LAST+1))
CONTRACT_SHA="85c86f2ee65bd601bdc3ebdbeb01e8b92f5dc3ad517ca422b7279e582eb6d3e1"
