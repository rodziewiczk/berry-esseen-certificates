"""Fixed actual resource-acquisition profile; final sharp comparison is separate."""
from fractions import Fraction as F
from initial_profile import P
N=39
K=F(0)
Q=F(0)
CAP=P["cap"]
R=P["radius"]
FIRST=26
LAST=47
SURVIVORS=list(range(FIRST,LAST+1))
CONTRACT_SHA="6e3ba2cef34cc577ef966ebe5708b83bccd33698b4388f8c0f652c239661f1c4"
