"""Exact fixed-index bridge probability/support/variance-geometry refinement.

No proof-file I/O or floating-point gates. A fixed acceptor must bind the
INITIAL table, all radius witnesses, the target contract and complete cover.
"""
from fractions import Fraction as F
from functools import lru_cache
import json
import candidate_below40 as c
import corrected_phase_callback_extended as correction
import geometric_moment_resource as gm
import direct_gaussian_support as ds

correction.install(c.k)
from fixed_profile import N,K,Q,CAP,R

def need(x,s):
    if not x:raise ValueError(s)

def enc(x):
    if type(x)is F:return str(x)
    if isinstance(x,dict):return{k:enc(v)for k,v in x.items()}
    if isinstance(x,(tuple,list)):return[enc(v)for v in x]
    return x

def decode_row(row):
    return {k:F(v) if type(v)is str else v for k,v in row.items()}

@lru_cache(None)
def base_cell(serialized):
    row=decode_row(json.loads(serialized))
    if row['cells']==0:return dict(excluded=True,reason='empty INITIAL probability panel')
    if row['D']<0:return dict(excluded=True,reason='negative INITIAL conserved budget')
    return c.cell(N,R,CAP,row,steps=80,barrier=K)

def amplitude(row,rm,rp):
    l,u,t=row['pl'],row['pu'],row['theta']
    need(0<l<u<1 and 0<=t<1,'acquired full sign-probability domain')
    vmax=max(l*(1-l),u*(1-u),F(1,4)if l<=F(1,2)<=u else F(0))
    ell=ds.root((1-t)/vmax)[0]
    need(ell>0,'positive actual scale lower bound')
    A0=rm/ell-l
    A1=rp/ell-(1-u)
    need(A0>0 and A1>0,'positive outward amplitudes')
    return ell,A0,A1

def support_step(row,oldrm,oldrp,rm,rp):
    need(F(1)<=rm<=oldrm and F(1)<=rp<=oldrp,'ordered acquired support radii')
    supports=[]
    for sign,prior,radius in [(-1,oldrm,rm),(1,oldrp,rp)]:
        if radius<prior:
            supports.append(ds.target(N,K,radius,Q,sign=sign,rho=row['rho'],
                                      beta_lower=row['beta_lo'],beta_upper=row['beta']))
    return supports

@lru_cache(None)
def refine(serialized,oldrm,oldrp,rm,rp):
    row=decode_row(json.loads(serialized))
    supports=support_step(row,oldrm,oldrp,rm,rp)
    old=gm.install(c.k,rp,rm)
    try:
        result=c.cell(N,max(F(23,10),rp,rm),CAP,row,steps=64,barrier=K)
    finally:
        c.k.general_cell=old
    if result.get('excluded'):
        return dict(radius_minus=rm,radius_plus=rp,support=supports,result=result)
    ell,A0,A1=amplitude(result,rm,rp)
    A=max(A0,A1)
    d0,Lambda=result['inward_d_max'],result['lambda_max']
    l,u=result['pl'],result['pu']
    need(A>0 and d0>0 and Lambda>0,'strict variance-geometry divisors')
    # For one actual marginal, lambda <= n A max(p,q) d.
    # Both sign-probability halves use the same joint displacement budget.
    lambdabar=1/(1/Lambda+1/(N*A*max(u,1-l)*d0))
    oldtheta=result['theta']
    vmin=min(l*(1-l),u*(1-u))
    theta=min(oldtheta,lambdabar/(N*vmin+lambdabar))
    need(0<=theta<=oldtheta<1,'outward variance contraction')
    result['theta']=theta
    return dict(radius_minus=rm,radius_plus=rp,support=supports,result=result,
                ell_lower=ell,amplitude0=A0,amplitude1=A1,
                theta_before=oldtheta,lambda_geometry_cap=lambdabar)

def polynomial_minimum(a,b,c,H):
    need(H>=0,'closed signed H interval')
    values=[a,a+b*H+c*H*H]
    if c>0 and 0<-b/(2*c)<H:values.append(a-b*b/(4*c))
    return min(values)

def quadratic_interface(row,guard):
    mappings=[]
    if len(row.get('quadratics',[]))!=4:return None
    for sign in('plus','minus'):
        H=F(guard['H'+sign]);field='F'+sign
        for q in row['quadratics']:
            options=[]
            for j,t in enumerate(guard['quadratics']):
                a=F(t['A'])-(q['A']-K*q['rho'])
                b=F(t[field])-q[field]
                curvature=q['Qbudget']-F(t['Qbudget'])
                margin=polynomial_minimum(a,b,curvature,H)
                options.append((margin,j))
            margin,j=max(options)
            if margin<0:return None
            mappings.append(dict(sign=sign,target_corner=j,margin=margin))
    return mappings

def guarded(row,rm,rp,guard):
    if row.get('excluded'):return False
    l,u=row['pl'],row['pu']
    need([str(l),str(u)]==guard['p'],'fixed actual panel target')
    ell,A0,A1=amplitude(row,rm,rp)
    d0,Lambda=F(guard['d0']),F(guard['Lambda'])
    return (0<row['inward_d_max']<=d0
            and 0<row['lambda_max']<=Lambda
            and row['D']<=F(guard['D'])
            and A0<=F(guard['outer0']) and A1<=F(guard['outer1'])
            and rm<=F(guard['radius_minus'])and rp<=F(guard['radius_plus'])
            and 0<row.get('Hminus',F(100))<=F(guard['Hminus'])
            and 0<row.get('Hplus',F(100))<=F(guard['Hplus'])
            and row['D']-row['residual']>=F(guard['binary_charge'])
            and row['residual']/row['inward_d_max']>=F(guard['gap_charge'])
            and row['residual']/row['lambda_max']>=F(guard['noise_charge'])
            and quadratic_interface(row,guard)is not None)

def interface(row,rm,rp,guard):
    need(guarded(row,rm,rp,guard),'every fixed sharp-gap comparison guard is acquired')
    ell,A0,A1=amplitude(row,rm,rp)
    return dict(ell_lower=ell,outer0=A0,outer1=A1,radius_minus=rm,radius_plus=rp,
                inward_cap=row['inward_d_max'],lambda_intercept=row['lambda_max'],D=row['D'],
                Hminus=row['Hminus'],Hplus=row['Hplus'],guard=guard,
                quadratic_mapping=quadratic_interface(row,guard),
                joint='d/d0+lambda/Lambda<=1',
                binary_charge=row['D']-row['residual'],
                gap_charge=row['residual']/row['inward_d_max'],
                noise_charge=row['residual']/row['lambda_max'],
                phase_normalization=F(15000,997*N))
