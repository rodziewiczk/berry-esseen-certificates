"""Join separately acquired global and two-pass local INITIAL36 tables."""
from fractions import Fraction as F
from json_support import need,equal
from initial_profile import P,enc

def sources(initial,seeds):
 need(initial['schema']=='BRIDGE36_INITIAL_V1' and equal(initial['profile'],enc(P)),'fixed global profile')
 need(seeds['schema']=='SHORT_CENTRAL36_SEEDS_V1' and len(seeds['bands'])==1,'fixed local seed theorem')
 band=seeds['bands'][0]
 need(equal(band['interval'],[30,42]) and len(band['stages'])==2,'two closed localized INITIAL stages')
 last=band['stages'][-1];profile=last['profile'];local=last['output']['panels']
 need(profile['p_interval']==['3/10','21/50'] and profile['radius_minus']=='3' and profile['radius_plus']=='37/10','acquired local domain and radii')
 need(len(initial['export']['panels'])==len(local)==100,'full source panel incidence')
 out=[]
 for i in range(100):
  selected=30<=i<42
  row=local[i] if selected else initial['export']['panels'][i]
  need(F(row['pl'])==F(i,100) and F(row['pu'])==F(i+1,100),'source panel coordinates')
  out.append((row,F(3) if selected else P['radius'],F(37,10) if selected else P['radius']))
 return out
