"""Fixed actual resource-acquisition profile; final sharp comparison is separate."""
from fractions import Fraction as F
from initial_profile import P
N=37
K=F(0)
Q=F(0)
CAP=P["cap"]
R=P["radius"]
FIRST=24
LAST=47
SURVIVORS=list(range(FIRST,LAST+1))
CONTRACT_SHA="3d09da3ce8a7fe23df4902a0b07eef06bb5bbebcc411f77a10aa4ad33bf96570"
