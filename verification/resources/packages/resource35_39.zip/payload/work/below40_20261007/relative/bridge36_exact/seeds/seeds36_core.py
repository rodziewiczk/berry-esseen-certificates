"""Exact short p-local INITIAL36 seeds; every incoming invariant is acquired.
Fixed n36, K0, support R3.8 and score cap.42475. This is a separately
named finite theorem; its global INITIAL and local comparison are other edges.
"""
from fractions import Fraction as F
from functools import lru_cache
import json
import initial_local36 as c
import direct_gaussian_support as ds
from initial36_profile import P,enc

Q=F(0)
SPECS=((30,42,2,F(3),F(37,10)),)
def need(x,s):
    if not x:raise ValueError(s)
def up(x,grid=10**6):return F(-((-x.numerator*grid)//x.denominator),grid)
def down(x,grid=10**6):return F((x.numerator*grid)//x.denominator,grid)
def decode(o):
    if type(o)is str:return F(o)
    if type(o)is dict:return{k:decode(v)for k,v in o.items()}
    if type(o)is list:return[decode(v)for v in o]
    return o

def invariant_update(previous,old):
    active=[r for r in previous['panels']if r['cells']]
    need(active,'nonempty seed interval')
    names={'rho':('rho',max),'beta_lo':('beta_lo',min),'beta_hi':('beta',max),'M':('M',max),'eta':('eta',max),'gamma_lo':('gamma_lo',min),'gamma_hi':('gamma_hi',max),'mean_lo':('mean_lo',min),'mean_hi':('mean_hi',max)}
    inv={name:(down if name.endswith('_lo')else up)(fn(r[key]for r in active))for name,(key,fn)in names.items()}
    for key,value in old.items():inv[key]=(max if key.endswith('_lo')else min)(inv[key],value)
    need(inv['beta_lo']<=inv['beta_hi']and inv['gamma_lo']<=inv['gamma_hi']and 0<inv['mean_lo']<=inv['mean_hi'],'coherent inherited signed moment box')
    return inv

@lru_cache(None)
def evaluate(profile,raw,d):return c.stage(decode(json.loads(profile)),raw,d)

def band(initial,spec,emit=False):
    a,b,count,rm,rp=spec
    profile=dict(P,p_interval=[F(a,100),F(b,100)])
    raw,d=F(initial['stages'][-1]['raw']),F(initial['stages'][-1]['D'])
    prior=None;stages=[]
    for j in range(count):
        supports=[]
        if j:
            inv=invariant_update(prior,profile.get('invariants',{}));profile['invariants']=inv
            if j==1:
                for sign,radius in((-1,rm),(1,rp)):
                    need(0<radius<=profile['radius'],'ordered actual support radius')
                    supports.append(ds.target(36,F(0),radius,Q,sign=sign,rho=inv['rho'],beta_lower=inv['beta_lo'],beta_upper=inv['beta_hi']))
                profile.update(radius_minus=rm,radius_plus=rp,radius=max(rm,rp))
        incoming=dict(raw=str(raw),D=str(d));z=evaluate(json.dumps(enc(profile),sort_keys=True),raw,d)
        raw=min(raw,up(z['R'],10**5)+F(1,10**5));d=min(d,up(z['D'],10**5)+F(1,10**5))
        need(0<raw<F(14)and 0<d<c.k.SL-1,'complete positive-density gap seed')
        stages.append(dict(profile=enc(profile),incoming=incoming,support=supports,output=enc(z),raw=str(raw),D=str(d)))
        prior=z
        if emit:print('EXACT_SEED36',a,b,j+1,str(raw),str(d),flush=True)
    return dict(interval=[a,b],stages=stages)
