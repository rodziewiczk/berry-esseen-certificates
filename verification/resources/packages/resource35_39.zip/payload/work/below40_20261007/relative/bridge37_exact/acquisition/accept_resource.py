"""Fixed complete exact bridge acquisition replay with product endpoint floors.
Global INITIAL and the fixed count comparison are separate accepted edges.
"""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json,hashlib,copy,sys
import route_core as r
from product_endpoint import seed
from initial_profile import P,enc
from json_support import read,equal,need,fields,unique,rat
from fixed_profile import N,FIRST,LAST,SURVIVORS,CONTRACT_SHA
HERE=Path(__file__).resolve().parent


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

@lru_cache(None)
def base(serialized):
    source=r.decode_row(json.loads(serialized))
    if source['cells']==0:return dict(excluded='empty global INITIAL panel'),None
    if source['D']<0:return dict(excluded='negative global conserved budget'),None
    row=seed(source)
    z=r.c.cell(r.N,r.R,r.CAP,row,steps=80,barrier=r.K)
    return dict(product_A=str(row['A']),product_B=str(row['B']),base=enc(z),refinements=[]),z

def shape(o,initial_hash):
    fields(o,('schema','initial_sha256','contract_sha256','global_support','rows'))
    need(o['schema']==f'BRIDGE{N}_RESOURCE_V1','fixed distinct product-floor theorem')
    need(o['initial_sha256']==initial_hash and o['contract_sha256']==CONTRACT_SHA,'fixed dependency hashes')
    need(type(o['rows'])is list and len(o['rows'])==100,'complete closed probability cover')
    for i,z in enumerate(o['rows']):
        need(type(z)is dict and type(z.get('index'))is int and z['index']==i,'strict typed row order')
        if'excluded'in z:fields(z,('index','excluded'));continue
        need(type(z.get('refinements'))is list and len(z['refinements'])<=24,'bounded exact route witness')
        for step in z['refinements']:
            need(type(step)is dict,'exact step object')
            for key in('radius_minus','radius_plus'):need(1<=rat(step[key])<=r.R,'canonical support radius')

def verify(o,initial,guards,initial_hash,emit=False):
    shape(o,initial_hash);support=r.ds.target(r.N,r.K,r.R,r.Q)
    need(equal(o['global_support'],support),'exact full-ray initial support')
    panels=initial['export']['panels'];need(len(panels)==100,'complete global INITIAL panel premise')
    survivors=[];steps=0;hc=support['gaussian']['cells'];rays=2
    for i,(source,witness)in enumerate(zip(panels,o['rows'])):
        need(F(source['pl'])==F(i,100)and F(source['pu'])==F(i+1,100),'closed exact initial panel')
        record,z=base(json.dumps(source,sort_keys=True));expected=dict(index=i,**copy.deepcopy(record));rm=rp=r.R
        if z is not None and not z.get('excluded'):
            for step in witness['refinements']:
                need(not z.get('excluded'),'no use after a contradiction')
                nm,np=rat(step['radius_minus']),rat(step['radius_plus'])
                actual=r.refine(json.dumps(enc(z),sort_keys=True),rm,rp,nm,np)
                need(equal(step,enc(actual)),'exact support geometry and resource replay')
                expected['refinements'].append(enc(actual));z=actual['result'];rm,rp=nm,np;steps+=1
                for s in actual['support']:hc+=s['gaussian']['cells'];rays+=1
            if not z.get('excluded'):
                need(i in guards,'remaining actual probability domain')
                expected['interface']=enc(r.interface(z,rm,rp,guards[i]));survivors.append(i)
        need(equal(witness,expected),'complete exact row and fixed sharp-gap interface')
        if emit:print('ACCEPTED_BRIDGE'+str(N),i,'guard'if i in survivors else'excluded',flush=True)
    need(survivors==SURVIVORS,'fixed complete acquired survivor cover')
    return dict(probability_panels=100,surviving_panels=survivors,refinement_stages=steps,support_H_cells=hc,support_rays=rays)

def main():
    need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary Python invocation')
    # Serialization limit only; all arithmetic and proof gates are unchanged.
    sys.set_int_max_str_digits(0)
    need(sha('contract.json')==CONTRACT_SHA,'fixed count-comparison target bytes')
    contract=read('contract.json');guards={g['index']:g for g in contract['rows']}
    need(type(contract['n'])is int and contract['n']==N and contract['K']=='0'and list(guards)==SURVIVORS,'fixed comparator scope')
    initial_path=HERE.parent/f'initial{N}_proof.json'
    initial=read(initial_path);ih=sha(initial_path)
    need(initial['schema']==f'BRIDGE{N}_INITIAL_V1'and equal(initial['profile'],enc(P)),'fixed global INITIAL premise')
    path=Path('acquisition_proof.json');o=read(path);report=verify(o,initial,guards,ih,True);controls=[]
    def reject(name,fn):
        try:fn()
        except(ValueError,AssertionError,TypeError,KeyError,IndexError,ZeroDivisionError):controls.append(name);return
        raise ValueError('corrupt acquisition accepted: '+name)
    def change(name,mutate,deep=False):
        z=copy.deepcopy(o);mutate(z);reject(name,lambda:verify(z,initial,guards,ih)if deep else shape(z,ih))
    change('wrong theorem',lambda z:z.update(schema='other'))
    change('wrong initial binding',lambda z:z.update(initial_sha256='0'*64))
    change('changed comparison target',lambda z:z.update(contract_sha256='0'*64))
    change('missing probability panel',lambda z:z['rows'].pop())
    change('duplicated probability panel',lambda z:z['rows'].__setitem__(FIRST+1,z['rows'][FIRST]))
    change('reordered probability panels',lambda z:z['rows'].reverse())
    change('boolean panel index',lambda z:z['rows'][0].update(index=False))
    change('wrong support decrement',lambda z:z['global_support'].update(q='19/100'),True)
    change('wrong support index',lambda z:z['global_support'].update(n=33),True)
    change('omitted initial support ray',lambda z:z['global_support']['ray_rows'].pop(),True)
    change('false product endpoint floor',lambda z:z['rows'][FIRST].update(product_A='1'),True)
    change('false base defect',lambda z:z['rows'][FIRST]['base'].update(D='0'),True)
    change('missing route step',lambda z:z['rows'][FIRST+1]['refinements'].pop(),True)
    change('noncanonical support radius',lambda z:z['rows'][FIRST]['refinements'][0].update(radius_minus='08/5'))
    change('unacquired smaller radius',lambda z:z['rows'][FIRST]['refinements'][0].update(radius_minus='1'),True)
    first_ray=next((i,j)for i,w in enumerate(o['rows'])for j,s in enumerate(w.get('refinements',[]))if s['support'])
    change('missing acquired ray',lambda z:z['rows'][first_ray[0]]['refinements'][first_ray[1]]['support'].pop(),True)
    change('false harmonic cap',lambda z:z['rows'][FIRST]['refinements'][0].update(lambda_geometry_cap='0'),True)
    change('false contracted theta',lambda z:z['rows'][FIRST]['refinements'][0]['result'].update(theta='0'),True)
    change('false outward interface',lambda z:z['rows'][FIRST]['interface'].update(outer0='0'),True)
    change('false quadratic dominance',lambda z:z['rows'][FIRST]['interface']['quadratic_mapping'][0].update(margin='1'),True)
    change('omitted quadratic branch',lambda z:z['rows'][FIRST]['interface']['quadratic_mapping'].pop(),True)
    for field in('binary_charge','gap_charge','noise_charge'):
        change('false affine '+field,lambda z,field=field:z['rows'][FIRST]['interface'].update({field:'1000000000'}),True)
    change('wrong phase normalization',lambda z:z['rows'][FIRST]['interface'].update(phase_normalization='1'),True)
    change('extra success flag',lambda z:z.update(accepted=True))
    reject('duplicate JSON key',lambda:json.loads('{"rows":[],"rows":[]}',object_pairs_hook=unique))
    report.update(schema=f'BRIDGE{N}_ACQUISITION_ACCEPTANCE_V1',status=f'PASS_ACQUISITION{N}_K0_PRODUCT_GUARDED',mathematical_status=f'Conditional same-law resource theorem for an attained positive closed n{N} witness at excessK=0 and decrement0. Prior scalar ceilings, separately accepted global INITIAL and final count comparison remain explicit dependencies.',execution_status='Fresh complete exact acquisition replay PASS',initial_sha256=ih,acquisition_sha256=sha(path),contract_sha256=CONTRACT_SHA,negative_controls=controls,contract=dict(n=N,K='0',decrement='0',current_cap=str(P['cap']),p=[str(F(FIRST,100)),str(F(LAST+1,100))],guard_rows=len(SURVIVORS),phase_normalization=str(F(15000,997*N))))
    Path('ACQUISITION_ACCEPTED.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
