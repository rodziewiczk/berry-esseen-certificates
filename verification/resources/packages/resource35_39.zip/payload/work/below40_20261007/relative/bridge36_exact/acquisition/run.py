"""Source-bound logger for exact bridge resource construction or fixed replay."""
from pathlib import Path
import sys,subprocess,json,hashlib,time,platform
from fixed_profile import N
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4]
assert __debug__ and not sys.flags.optimize and len(sys.argv)==2
kind=sys.argv[1];assert kind in('construct','accept');run=ROOT/'runs/below40_20261007/relative'/f'bridge{N}_resource_{kind}01';run.mkdir(exist_ok=False)
files=list(HERE.glob('*.py'))+[HERE/'contract.json',HERE/'PREPARED_SOURCES.json',HERE.parent/f'initial{N}_proof.json',HERE.parent/'seeds/seeds36_proof.json']
if kind=='accept':files.append(HERE/'acquisition_proof.json')
h={str(p.relative_to(HERE))if p.is_relative_to(HERE)else'../'+str(p.relative_to(HERE.parent)):hashlib.sha256(p.read_bytes()).hexdigest()for p in files};cmd=[sys.executable,'-B',kind+'_resource.py'];start=time.monotonic()
with(run/'stdout.txt').open('w')as o,(run/'stderr.txt').open('w')as e:r=subprocess.run(cmd,cwd=HERE,stdout=o,stderr=e)
result=dict(command=cmd,cwd=str(HERE),python=sys.version,platform=platform.platform(),optimized=sys.flags.optimize,returncode=r.returncode,elapsed_seconds=time.monotonic()-start,input_sha256=h,output_sha256={name:hashlib.sha256((run/name).read_bytes()).hexdigest()for name in('stdout.txt','stderr.txt')})
(run/'metadata.json').write_text(json.dumps(result,indent=2)+'\n');print(N,kind,r.returncode,flush=True);print((run/'stdout.txt').read_text()[-2500:]);print((run/'stderr.txt').read_text());raise SystemExit(r.returncode)
