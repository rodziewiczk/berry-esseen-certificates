"""Fixed actual resource-acquisition profile; final sharp comparison is separate."""
from fractions import Fraction as F
from initial_profile import P
N=38
K=F(0)
Q=F(0)
CAP=P["cap"]
R=P["radius"]
FIRST=25
LAST=47
SURVIVORS=list(range(FIRST,LAST+1))
CONTRACT_SHA="18e695b61b47d25e8dca30315143ae2fcee11711efe3b61937d2935de5c680a4"
