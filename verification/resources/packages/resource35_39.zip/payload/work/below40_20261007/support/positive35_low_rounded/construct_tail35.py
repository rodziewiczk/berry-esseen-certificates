"""Exact candidate29--30 acquisition from the separately acquired central seed."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys
import low35_core as c
from initial35_profile import enc
assert __debug__ and not sys.flags.optimize
sys.set_int_max_str_digits(0)
seedpath=Path('seeds35_proof.json');targetpath=Path('contract.json')
assert hashlib.sha256(targetpath.read_bytes()).hexdigest()==c.CONTRACT_SHA
seeds=json.loads(seedpath.read_bytes());targets={r['index']:r for r in json.loads(targetpath.read_bytes())['rows']}
band=next(z for z in seeds['bands']if z['interval']==[29,34]);last=band['stages'][-1]
path=Path('tail35_proof.json');assert not path.exists()
out=dict(schema='LOW35_TAIL_FROM_CENTRAL_SEED_V1',seeds_sha256=hashlib.sha256(seedpath.read_bytes()).hexdigest(),contract_sha256=c.CONTRACT_SHA,rows=[])
for i in(29,30):
    source=c.decode(last['output']['panels'][i]);rm=F(last['profile']['radius_minus']);rp=F(last['profile']['radius_plus'])
    row,A,B=c.begin_route(source,rm,rp)
    rec=dict(index=i,product_A=enc(A),product_B=enc(B),base=enc(row),refinements=[])
    assert not row.get('excluded')
    for j in range(40):
        rmnew,rpnew=c.proposed_radii(row,rm,rp)
        got=c.r.refine(json.dumps(enc(row),sort_keys=True),rm,rp,rmnew,rpnew)
        rec['refinements'].append(enc(got));rm,rp=rmnew,rpnew;row=got['result'];assert not row.get('excluded')
        print('CONSTRUCT_LOW35_TAIL',i,j+1,str(row['D']),flush=True)
        if c.r.guarded(row,rm,rp,targets[i]):rec['interface']=enc(c.r.interface(row,rm,rp,targets[i]));break
    assert 'interface'in rec,(i,'fixed tail guard not acquired')
    out['rows'].append(rec);path.write_text(json.dumps(out,indent=2)+'\n')
print('CONSTRUCT_LOW35_TAIL_COMPLETE',len(out['rows']),flush=True)
