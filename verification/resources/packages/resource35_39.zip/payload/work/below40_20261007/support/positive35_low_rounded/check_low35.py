"""Portable source/coverage join for accepted LOW35 acquisition.
Heavy arithmetic is not repeated. The fixed finite-count comparison and
upper-probability complement remain explicit external dependencies.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys,copy

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
CENTRAL=HERE.parent/'positive35_acq'
CAPTURED=Path('/Users/bkolodziejek/Downloads/BE_Codex_Handoff')
CONTRACT_SHA='febdeb30f097785a338cc0bd72b85f1a6e4f6aaeadadec75286feeb46d02b488'
SOURCES={'accept_low35.py','verify_band35.py','verify_tail35.py','low35_core.py','route35_core.py','candidate_charged_score35.py','corrected_phase_callback_extended.py','paired_extended.py','signed_variance_resource.py','geometric_moment_resource.py','direct_gaussian_support.py','finite_binomial_core.py','small_index_support.py','heat_support50.py','kernel.py','contracted_kernel.py','high_window_core.py','initial_local35.py','initial_global35.py','initial35_profile.py','product_endpoint34.py','accept_initial35.py','initial35_proof.json','seeds35_proof.json','contract.json','band35_16_23_proof.json','band35_23_26_proof.json','band35_26_29_proof.json','tail35_proof.json'}

def need(x,s):
    if not x:raise ValueError(s)
def unique(items):
    o={}
    for k,v in items:need(k not in o,'duplicate JSON key');o[k]=v
    return o
def parse(blob):return json.loads(blob,object_pairs_hook=unique)
def read(p):return parse(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def equal(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
    return a==b
def safe(base,name):
    need(type(name)is str and name and '\\'not in name and not Path(name).is_absolute(),'relative source name')
    need(all(x not in('','.','..')for x in name.split('/')),'canonical relative source name')
    p=base/name;need(p.is_file()and not p.is_symlink()and p.resolve().is_relative_to(base.resolve()),'contained regular source')
    return p

def evidence(m,o,out,err,bind=True):
    need(type(m['returncode'])is int and m['returncode']==0,'actual successful integer return')
    need(m['cwd']==str(CAPTURED/'work/below40_20261007/support/positive35_low_rounded'),'fixed recorded acquisition location')
    argv=m['command'];need(type(argv)is list and len(argv)==3 and all(type(v)is str for v in argv)and argv[1:]==['-B','accept_low35.py'],'fixed ordinary-Python acceptance entrypoint')
    need(type(m['input_sha256'])is dict and SOURCES<=set(m['input_sha256']),'complete executed dependency closure')
    need(hashlib.sha256(out).hexdigest()==m['stdout_sha256']and hashlib.sha256(err).hexdigest()==m['stderr_sha256']and not err,'actual run output integrity')
    need(equal(parse(out.strip().splitlines()[-1]),o),'saved report is the actual final output')
    need(o['schema']=='FIXED_LOW35_RESOURCE_ACCEPTANCE_V1'and o['status']=='PASS_LOW35_ALTERNATING_RESOURCE','fixed low35 mathematical theorem')
    need(type(o['n'])is int and o['n']==35 and o['barrier']=='0'and o['decrement']=='63/340'and o['cap']=='423493/1000000','exact finite index and scalar premises')
    need(o['contract_sha256']==CONTRACT_SHA,'fixed guarded count target')
    need(o['parallel_workers']==2 and type(o['parallel_workers'])is int,'fixed execution scope')
    need(o['negative_controls']==['duplicate JSON key']and type(o['part_negative_control_count'])is int and o['part_negative_control_count']==72,'all73 mutation controls')
    expected=[([16,23],list(range(16,23)),[],19),([23,26],[],[23,24,25],19),([26,29],[],[26,27,28],19),([29,31],[],[29,30],15)]
    need(type(o['parts'])is list and len(o['parts'])==4,'complete four-part closed cover')
    for z,(interval,excluded,acquired,nc)in zip(o['parts'],expected):
        need(equal(z['interval'],interval)and equal(z['excluded'],excluded)and equal(z['acquired'],acquired),'exact closed probability coverage')
        controls=z['negative_controls'];need(type(controls)is list and len(controls)==len(set(controls))==nc,'complete distinct per-part controls')
    bindings={}
    if bind:
        for name,h in m['input_sha256'].items():
            p=safe(HERE,name);need(sha(p)==h,'executed source and proof bytes');bindings[str(p.relative_to(ROOT))]=h
        need(o['initial_sha256']==sha(HERE/'initial35_proof.json')==sha(CENTRAL/'initial35_proof.json'),'same independently accepted global INITIAL')
        need(o['seeds_sha256']==sha(HERE/'seeds35_proof.json')==sha(CENTRAL/'seeds35_proof.json'),'same separately accepted short seed')
        for z in o['parts']:need(sha(safe(HERE,z['proof']))==z['proof_sha256'],'exact replayed proof bytes')
    return bindings

def main():
    need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary Python join')
    sys.set_int_max_str_digits(0)
    # This source-bound prerequisite check does not repeat resource arithmetic.
    sys.path.insert(0,str(CENTRAL))
    import check_resources35_v2 as central
    _,bindings,_=central.check()
    run=ROOT/'runs/below40_20261007/support/low35_rounded_accept01'
    m,o=read(run/'metadata.json'),read(HERE/'LOW35_ACCEPTED.json');out,err=(run/'stdout.txt').read_bytes(),(run/'stderr.txt').read_bytes()
    bindings.update(evidence(m,o,out,err))
    for p in(run/'metadata.json',run/'stdout.txt',run/'stderr.txt',HERE/'LOW35_ACCEPTED.json',CENTRAL/'check_resources35_v2.py'):bindings[str(p.relative_to(ROOT))]=sha(p)
    need(sha(HERE/'contract.json')==CONTRACT_SHA,'same fixed low count contract')
    controls=[]
    def reject(name,fn):
        try:fn()
        except(ValueError,TypeError,KeyError,IndexError):controls.append(name);return
        raise ValueError('malformed binding accepted: '+name)
    for name,key,value in [('boolean return','returncode',False),('failed return','returncode',1),('wrong location','cwd','/tmp/elsewhere'),('optimized command','command',['python','-O','accept_low35.py']),('unknown driver','command',['python','-B','unknown.py'])]:
        z=copy.deepcopy(m);z[key]=value;reject(name,lambda z=z:evidence(z,o,out,err,False))
    z=copy.deepcopy(m);z['input_sha256'].pop('low35_core.py');reject('missing arithmetic source',lambda:evidence(z,o,out,err,False))
    reject('changed stdout',lambda:evidence(m,o,out+b'changed',err,False))
    reject('source escape',lambda:safe(HERE,'../outside.py'))
    reject('duplicate JSON key',lambda:parse('{"x":1,"x":2}'))
    result=dict(schema='LOW35_RESOURCE_BINDING_V1',status='PASS_LOW35_RESOURCE_BINDING',mathematical_status='Conditional complete acquisition/exclusion on p[.16,.31] atn35; count comparisons and upper complement are separate.',execution_status='Fresh source/coverage binding of separately accepted arithmetic; no heavy replay in this join.',selected_run='low35_rounded_accept01',contract_sha256=CONTRACT_SHA,excluded=list(range(16,23)),acquired=list(range(23,31)),negative_controls=controls,bound_sha256=bindings)
    (HERE/'LOW35_RESOURCE_BOUND.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
