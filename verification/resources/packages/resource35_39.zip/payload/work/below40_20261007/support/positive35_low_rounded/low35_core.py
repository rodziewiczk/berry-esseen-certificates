"""Exact alternating p-local INITIAL/resource feedback for LOW35.
No success record is accepted here; callers must bind INITIAL, radius history,
complete closed probability bands and the final fixed guarded comparison.
"""
from fractions import Fraction as F
from functools import lru_cache
import json
import route35_core as r
import initial_local35 as initial
from initial35_profile import P,enc
from product_endpoint34 import seed

SPECS=((16,23,4),(23,26,3),(26,29,3))
CONTRACT_SHA='febdeb30f097785a338cc0bd72b85f1a6e4f6aaeadadec75286feeb46d02b488'
need=r.need

def up(x,grid=10**6):return F(-((-x.numerator*grid)//x.denominator),grid)
def down(x,grid=10**6):return F((x.numerator*grid)//x.denominator,grid)
def decode(o):
    if type(o)is str:
        try:return F(o)
        except ValueError:return o
    if type(o)is dict:return{k:decode(v)for k,v in o.items()}
    if type(o)is list:return[decode(v)for v in o]
    return o
@lru_cache(None)
def evaluate(profile,raw,d):return initial.stage(decode(json.loads(profile)),raw,d)

def merge_source(initial_row,prior):
    row=dict(initial_row)
    if prior is not None and row['cells']:
        old=prior['result']
        for key in('D','raw','theta','rho','M','eta','beta'):row[key]=min(row[key],old[key])
        for key in('A','B','beta_lo'):row[key]=max(row[key],old[key])
    return row

def begin_route(source,rm,rp):
    if source['cells']==0:return dict(excluded=True,reason='empty p-local INITIAL panel'),None,None
    if source['D']<0:return dict(excluded=True,reason='negative p-local conserved budget'),None,None
    row=seed(source)
    return r.base_cell(json.dumps(enc(row),sort_keys=True),rm,rp),row['A'],row['B']

def proposed_radii(row,rm,rp):
    answer=[]
    for sign,prior in((-1,rm),(1,rp)):
        radius=prior
        for j in range(14,40):
            candidate=F(j,10)
            if candidate>=prior:break
            try:r.ds.target(r.N,r.K,candidate,r.Q,sign=sign,rho=row['rho'],beta_lower=row['beta_lo'],beta_upper=row['beta'])
            except ValueError:continue
            radius=candidate;break
        answer.append(radius)
    return answer

def following_profile(profile,active):
    """Every cap refers to the same law within its still-active p panel."""
    need(active,'nonempty residual closed probability set')
    caps=[]
    for item in active:
        source=item['source'];row=item['route']['result'];l,u,t=row['pl'],row['pu'],row['theta']
        need(0<l<u<F(1,2)and 0<=t<1,'fixed low-p mean/variance domain')
        # m^2=pq(1-theta), so this is a LOWER bound, rounded down.
        mean_floor=r.ds.root(l*(1-l)*(1-t))[0]
        mean_ceiling=r.ds.root(u*(1-u))[1]
        caps.append(dict(rho=row['rho'],beta_lo=max(source['beta_lo'],row['beta_lo']),beta_hi=row['beta'],M=row['M'],eta=row['eta'],gamma_lo=source['gamma_lo'],gamma_hi=min(source['gamma_hi'],row['trace'][-1]['g']),mean_lo=max(source['mean_lo'],mean_floor),mean_hi=min(source['mean_hi'],mean_ceiling)))
    inv={key:(down if key.endswith('_lo')else up)((min if key.endswith('_lo')else max)(z[key]for z in caps))for key in caps[0]}
    for key,value in profile.get('invariants',{}).items():inv[key]=(max if key.endswith('_lo')else min)(inv[key],value)
    need(inv['beta_lo']<=inv['beta_hi']and inv['gamma_lo']<=inv['gamma_hi']and 0<inv['mean_lo']<=inv['mean_hi'],'coherent inherited actual moments')
    rm=max(z['route']['radius_minus']for z in active);rp=max(z['route']['radius_plus']for z in active)
    out=dict(profile,invariants=inv,radius_minus=rm,radius_plus=rp,radius=max(rm,rp),p_interval=[min(z['route']['result']['pl']for z in active),max(z['route']['result']['pu']for z in active)])
    raw=up(max(z['route']['result']['raw']for z in active),10**5)+F(1,10**5)
    d=up(max(z['route']['result']['D']for z in active),10**5)+F(1,10**5)
    need(0<raw<14 and 0<d<initial.k.SL-1,'positive density and complete actual gap')
    return out,raw,d
