"""Exact construction only: one alternating LOW35 seed/resource band."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys
import low35_core as c
from initial35_profile import enc
assert __debug__ and not sys.flags.optimize
sys.set_int_max_str_digits(0)
a,b,count=c.SPECS[int(sys.argv[1])]
initialpath=Path('initial35_proof.json');targetpath=Path('contract.json')
assert hashlib.sha256(targetpath.read_bytes()).hexdigest()==c.CONTRACT_SHA
inp=json.loads(initialpath.read_bytes());targets={r['index']:r for r in json.loads(targetpath.read_bytes())['rows']}
profile=dict(c.P,p_interval=[F(a,100),F(b,100)],cap=c.r.CAP)
raw,d=F(inp['stages'][-1]['raw']),F(inp['stages'][-1]['D'])
path=Path('band35_'+str(a)+'_'+str(b)+'_proof.json');assert not path.exists()
out=dict(schema='ALTERNATING_LOW35_BAND_V1',interval=[a,b],initial_sha256=hashlib.sha256(initialpath.read_bytes()).hexdigest(),contract_sha256=c.CONTRACT_SHA,stages=[])
prior={};excluded=set();rm0=rp0=c.r.R
for step in range(count):
    z=c.evaluate(json.dumps(enc(profile),sort_keys=True),raw,d)
    stage=dict(profile=enc(profile),incoming=dict(raw=str(raw),D=str(d)),output=enc(z),rows=[])
    active=[]
    for i in range(a,b):
        if i in excluded:continue
        source=c.merge_source(z['panels'][i],prior.get(i))
        rm=prior[i]['radius_minus']if i in prior else rm0;rp=prior[i]['radius_plus']if i in prior else rp0
        row,A,B=c.begin_route(source,rm,rp)
        rec=dict(index=i,source=enc(source),radius_minus=str(rm),radius_plus=str(rp),product_A=enc(A),product_B=enc(B),base=enc(row),refinements=[])
        if not row.get('excluded'):
            for j in range(24):
                nrm,nrp=c.proposed_radii(row,rm,rp)
                result=c.r.refine(json.dumps(enc(row),sort_keys=True),rm,rp,nrm,nrp)
                rec['refinements'].append(enc(result));new=result['result'];rm,rp=nrm,nrp
                if new.get('excluded'):row=new;break
                passed=i in targets and c.r.guarded(new,rm,rp,targets[i])
                stable=abs(new['D']-row['D'])<F(1,10**9)and abs(new['theta']-row['theta'])<F(1,10**9)
                row=new
                if passed or stable:break
        if row.get('excluded'):
            excluded.add(i);rec['outcome']='excluded'
        else:
            passed=i in targets and c.r.guarded(row,rm,rp,targets[i])
            rec['outcome']='guarded'if passed else'retained'
            if passed:rec['interface']=enc(c.r.interface(row,rm,rp,targets[i]))
            route=dict(result=row,radius_minus=rm,radius_plus=rp)
            prior[i]=route;active.append(dict(index=i,source=source,route=route))
        stage['rows'].append(rec)
        print('CONSTRUCT_LOW35',a,b,step+1,i,rec['outcome'],len(rec['refinements']),flush=True)
    out['stages'].append(stage);path.write_text(json.dumps(out,indent=2)+'\n')
    if not active or all(i['index']in targets and c.r.guarded(i['route']['result'],i['route']['radius_minus'],i['route']['radius_plus'],targets[i['index']])for i in active):break
    assert step+1<count,(a,b,'fixed short schedule not sufficient')
    profile,raw,d=c.following_profile(profile,active);rm0=profile['radius_minus'];rp0=profile['radius_plus']
    stage['feedback']=dict(profile=enc(profile),raw=str(raw),D=str(d));path.write_text(json.dumps(out,indent=2)+'\n')
assert set(range(a,b))==excluded|set(prior)
# Any earlier retained row is either excluded later or must meet its fixed guard.
for i,route in prior.items():
    if i not in excluded:assert i in targets and c.r.guarded(route['result'],route['radius_minus'],route['radius_plus'],targets[i])
print('CONSTRUCT_LOW35_COMPLETE',a,b,len(out['stages']),sorted(excluded),flush=True)
