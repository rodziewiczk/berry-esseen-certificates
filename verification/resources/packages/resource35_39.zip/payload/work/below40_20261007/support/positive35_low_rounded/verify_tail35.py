"""Read-only exact29--30 acquisition replay from an independently accepted seed."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import low35_core as c
from initial35_profile import enc
from accept_initial35 import need,equal,fields,rat,read

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def shape(o):
    fields(o,('schema','seeds_sha256','contract_sha256','rows'))
    need(o['schema']=='LOW35_TAIL_FROM_CENTRAL_SEED_V1','fixed named two-panel tail')
    need(o['seeds_sha256']==sha('seeds35_proof.json'),'same separately acquired central seed')
    need(o['contract_sha256']==c.CONTRACT_SHA==sha('contract.json'),'same fixed low count contract')
    need(type(o['rows'])is list and len(o['rows'])==2,'complete29--30 incidence')
    for i,r in zip((29,30),o['rows']):
        fields(r,('index','product_A','product_B','base','refinements','interface'))
        need(type(r['index'])is int and r['index']==i,'ordered strict integer incidence')
        need(type(r['refinements'])is list and 1<=len(r['refinements'])<=40,'bounded tail refinement witness')

def verify(o,emit=False):
    shape(o);seeds=read('seeds35_proof.json');targets={r['index']:r for r in read('contract.json')['rows']}
    band=next(z for z in seeds['bands']if z['interval']==[29,34]);last=band['stages'][-1]
    hc=rays=count=0
    for rec in o['rows']:
        i=rec['index'];source=c.decode(last['output']['panels'][i]);rm=F(last['profile']['radius_minus']);rp=F(last['profile']['radius_plus'])
        row,A,B=c.begin_route(source,rm,rp)
        need(equal(rec['product_A'],enc(A))and equal(rec['product_B'],enc(B))and equal(rec['base'],enc(row)),'exact acquired endpoint and charged base')
        need(not row.get('excluded'),'nonempty selected target')
        for witness in rec['refinements']:
            rmnew,rpnew=rat(witness['radius_minus']),rat(witness['radius_plus'])
            got=c.r.refine(json.dumps(enc(row),sort_keys=True),rm,rp,rmnew,rpnew)
            need(equal(witness,enc(got)),'exact complete tail support/moment/variance step')
            for s in got['support']:hc+=s['gaussian']['cells'];rays+=len(s['ray_rows'])
            count+=1;rm,rp=rmnew,rpnew;row=got['result'];need(not row.get('excluded'),'nonempty selected refined target')
        need(equal(rec['interface'],enc(c.r.interface(row,rm,rp,targets[i]))),'all fixed sharp-gap target guards')
        if emit:print('ACCEPTED_LOW35_TAIL',i,len(rec['refinements']),flush=True)
    return dict(interval=[29,31],initial_covers=0,initial_cells=0,refinements=count,support_H_cells=hc,support_rays=rays,excluded=[],acquired=[29,30])
