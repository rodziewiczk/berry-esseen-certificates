"""Fixed exact LOW35 acquisition on16..30, using2 ordinary-Python workers.
Global INITIAL and CENTRAL35 seed acceptance are separately bound premises.
The finite-count comparison and all-p composition remain separate obligations.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import multiprocessing
import json,hashlib,sys,copy
from fractions import Fraction as F
import low35_core as c
import verify_band35 as vb
import verify_tail35 as vt
from accept_initial35 import need,read,unique

JOBS=[('band','band35_16_23_proof.json'),('band','band35_23_26_proof.json'),('band','band35_26_29_proof.json'),('tail','tail35_proof.json')]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def worker_job(job):
    need(__debug__ and not sys.flags.optimize,'ordinary Python acquisition worker')
    sys.set_int_max_str_digits(0)
    kind,path=job;o=read(path);module=vb if kind=='band'else vt
    result=module.verify(o,True);controls=[]
    def change(name,fn,deep=True):
        z=copy.deepcopy(o);fn(z)
        try:module.verify(z)if deep else module.shape(z)
        except(ValueError,AssertionError,TypeError,KeyError,IndexError,ZeroDivisionError):controls.append(name);return
        raise ValueError('malformed acquisition accepted: '+name)
    change('wrong theorem',lambda z:z.update(schema='wrong'),False)
    change('changed contract',lambda z:z.update(contract_sha256='0'*64),False)
    change('extra field',lambda z:z.update(accepted=True),False)
    if kind=='band':
        change('wrong global INITIAL',lambda z:z.update(initial_sha256='0'*64),False)
        change('unknown band',lambda z:z.update(interval=[0,100]),False)
        change('boolean band incidence',lambda z:z['interval'].__setitem__(0,True),False)
        change('missing final stage',lambda z:z['stages'].pop())
        change('duplicated schedule',lambda z:z['stages'].append(z['stages'][-1]),False)
        change('reordered schedule',lambda z:z['stages'].reverse())
        change('false incoming D',lambda z:z['stages'][0]['incoming'].update(D='1/2'))
        change('unacquired initial radius',lambda z:z['stages'][0]['profile'].update(radius_minus='1'))
        moment_index=next(i for i,v in enumerate(o['stages'][0]['output']['panels'])if v['cells']and v['beta']!='0')
        change('false signed export',lambda z:z['stages'][0]['output']['panels'][moment_index].update(beta='0'))
        change('missing probability cell',lambda z:z['stages'][0]['rows'].pop())
        change('duplicated probability cell',lambda z:z['stages'][0]['rows'].append(z['stages'][0]['rows'][0]))
        change('reordered probability cover',lambda z:z['stages'][0]['rows'].reverse())
        change('boolean probability incidence',lambda z:z['stages'][0]['rows'][0].update(index=True))
        change('false mean feedback',lambda z:z['stages'][0]['feedback']['profile']['invariants'].update(mean_lo='1/2'))
        si,ri=next((s,i)for s,z in enumerate(o['stages'])for i,r in enumerate(z['rows'])if any(v.get('support')for v in r['refinements']))
        wi=next(i for i,v in enumerate(o['stages'][si]['rows'][ri]['refinements'])if v.get('support'))
        change('omitted acquired support ray',lambda z:z['stages'][si]['rows'][ri]['refinements'][wi]['support'].pop())
        si2,ri2,wi2=next((s,i,j)for s,z in enumerate(o['stages'])for i,r in enumerate(z['rows'])for j,v in enumerate(r['refinements'])if 'lambda_geometry_cap'in v)
        change('false harmonic variance cap',lambda z:z['stages'][si2]['rows'][ri2]['refinements'][wi2].update(lambda_geometry_cap='0'))
        need(len(controls)==19,'all alternating negative controls')
    else:
        change('wrong seed binding',lambda z:z.update(seeds_sha256='0'*64),False)
        change('missing probability cell',lambda z:z['rows'].pop(),False)
        change('duplicated probability cell',lambda z:z['rows'].append(z['rows'][0]),False)
        change('reordered probability cover',lambda z:z['rows'].reverse(),False)
        change('boolean probability incidence',lambda z:z['rows'][0].update(index=True),False)
        change('false endpoint product',lambda z:z['rows'][0].update(product_A='1'))
        change('false base budget',lambda z:z['rows'][0]['base'].update(D='1/10'))
        change('missing refinement',lambda z:z['rows'][0]['refinements'].pop())
        change('unacquired radius',lambda z:z['rows'][0]['refinements'][0].update(radius_minus='1'))
        change('false simultaneous charge',lambda z:z['rows'][0]['interface']['charges'].update(gap_charge='100'))
        change('false quadratic domination',lambda z:z['rows'][0]['interface']['quadratic_mapping'][0].update(margin='1'))
        change('missing signed quadratic',lambda z:z['rows'][0]['interface']['quadratic_mapping'].pop())
        need(len(controls)==15,'all tail negative controls')
    result.update(proof=path,proof_sha256=sha(path),negative_controls=controls)
    return result

def main():
    need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed ordinary Python entrypoint')
    sys.set_int_max_str_digits(0)
    need(sha('contract.json')==c.CONTRACT_SHA,'frozen low35 comparison target')
    support=c.r.ds.target(35,F(0),F(39,10),F(63,340))
    with ProcessPoolExecutor(max_workers=2,mp_context=multiprocessing.get_context('spawn'))as pool:
        results=list(pool.map(worker_job,JOBS))
    need([z['interval']for z in results]==[[16,23],[23,26],[26,29],[29,31]],'complete closed low probability union')
    need([i for z in results for i in z['excluded']]==list(range(16,23)),'all seven lower outer panels excluded')
    need([i for z in results for i in z['acquired']]==list(range(23,31)),'all eight count-comparison interfaces acquired')
    need(3<=sum(z['initial_covers']for z in results)<=10,'at most ten complete short local INITIAL covers')
    controls=[]
    try:json.loads('{"x":1,"x":2}',object_pairs_hook=unique)
    except ValueError:controls.append('duplicate JSON key')
    else:raise ValueError('duplicate key accepted')
    result=dict(schema='FIXED_LOW35_RESOURCE_ACCEPTANCE_V1',status='PASS_LOW35_ALTERNATING_RESOURCE',mathematical_status='Conditional n35 resource/exclusion theorem on p[.16,.31], excessK0, decrement63/340 and cap.423493, requiring separately accepted global INITIAL and29--34 seed. Count comparison and upper/complementary p coverage are separate.',execution_status='Fresh complete exact alternating INITIAL/support/moment/variance replay with mutation controls',n=35,barrier='0',decrement='63/340',cap='423493/1000000',initial_sha256=sha('initial35_proof.json'),seeds_sha256=sha('seeds35_proof.json'),contract_sha256=c.CONTRACT_SHA,global_support=support,parts=results,initial_cells=sum(z['initial_cells']for z in results),refinements=sum(z['refinements']for z in results),support_H_cells=support['gaussian']['cells']+sum(z['support_H_cells']for z in results),support_rays=len(support['ray_rows'])+sum(z['support_rays']for z in results),negative_controls=controls,part_negative_control_count=sum(len(z['negative_controls'])for z in results),parallel_workers=2)
    Path('LOW35_ACCEPTED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
