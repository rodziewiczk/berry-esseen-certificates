"""Fixed exact replay of a short LOW35 alternating acquisition band."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import low35_core as c
from initial35_profile import enc
from accept_initial35 import need,equal,fields,rat,read

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def shape(o):
    fields(o,('schema','interval','initial_sha256','contract_sha256','stages'))
    need(o['schema']=='ALTERNATING_LOW35_BAND_V1','fixed named alternating theorem')
    need(o['initial_sha256']==sha('initial35_proof.json'),'same independently acquired global INITIAL')
    need(o['contract_sha256']==c.CONTRACT_SHA==sha('contract.json'),'same fixed eight-row low contract')
    need(type(o['interval'])is list and len(o['interval'])==2 and all(type(x)is int for x in o['interval']),'strict integer band incidence')
    spec=next((s for s in c.SPECS if list(s[:2])==o['interval']),None);need(spec is not None,'known closed band')
    need(type(o['stages'])is list and 1<=len(o['stages'])<=spec[2],'bounded nonempty feedback schedule')
    return spec

def verify(o,emit=False):
    a,b,count=shape(o)
    inp=read('initial35_proof.json');targets={r['index']:r for r in read('contract.json')['rows']}
    profile=dict(c.P,p_interval=[F(a,100),F(b,100)],cap=c.r.CAP)
    raw,d=F(inp['stages'][-1]['raw']),F(inp['stages'][-1]['D'])
    excluded=set();prior={};rm0=rp0=c.r.R
    hc=rays=refinements=0
    for step,stage in enumerate(o['stages']):
        fields(stage,('profile','incoming','output','rows')+(()if step+1==len(o['stages'])else('feedback',)))
        need(equal(stage['profile'],enc(profile))and equal(stage['incoming'],dict(raw=str(raw),D=str(d))),'every incoming bound and radius is acquired')
        z=c.evaluate(json.dumps(enc(profile),sort_keys=True),raw,d)
        need(equal(stage['output'],enc(z)),'complete exact signed INITIAL cover')
        indices=[i for i in range(a,b)if i not in excluded]
        need(type(stage['rows'])is list and len(stage['rows'])==len(indices),'all nonexcluded closed panels')
        active=[]
        for i,rec in zip(indices,stage['rows']):
            extra=('interface',)if rec.get('outcome')=='guarded'else()
            fields(rec,('index','source','radius_minus','radius_plus','product_A','product_B','base','refinements','outcome')+extra)
            need(type(rec['index'])is int and rec['index']==i,'ordered exact probability incidence')
            source=c.merge_source(z['panels'][i],prior.get(i))
            rm=prior[i]['radius_minus']if i in prior else rm0;rp=prior[i]['radius_plus']if i in prior else rp0
            need(equal(rec['source'],enc(source))and rec['radius_minus']==str(rm)and rec['radius_plus']==str(rp),'common-law retained panel bounds and support')
            row,A,B=c.begin_route(source,rm,rp)
            need(equal(rec['base'],enc(row))and equal(rec['product_A'],enc(A))and equal(rec['product_B'],enc(B)),'endpoint product floors and exact charged base')
            need(type(rec['refinements'])is list and len(rec['refinements'])<=24,'bounded resource witness')
            if row.get('excluded'):need(not rec['refinements'],'no refinements of an empty event')
            else:need(rec['refinements'],'nonempty refinement witness')
            for witness in rec['refinements']:
                need(not row.get('excluded'),'no transition from excluded cell')
                rmnew,rpnew=rat(witness['radius_minus']),rat(witness['radius_plus'])
                got=c.r.refine(json.dumps(enc(row),sort_keys=True),rm,rp,rmnew,rpnew)
                need(equal(witness,enc(got)),'exact support-before-moment-before-geometry refinement')
                for s in got['support']:hc+=s['gaussian']['cells'];rays+=len(s['ray_rows'])
                row=got['result'];rm,rp=rmnew,rpnew;refinements+=1
            if row.get('excluded'):
                need(rec['outcome']=='excluded','actual proved exclusion');excluded.add(i)
            else:
                passed=i in targets and c.r.guarded(row,rm,rp,targets[i])
                need(rec['outcome']==('guarded'if passed else'retained'),'exact full guarded interface status')
                if passed:need(equal(rec['interface'],enc(c.r.interface(row,rm,rp,targets[i]))),'all upper bounds, simultaneous charges and signed quadratics')
                route=dict(result=row,radius_minus=rm,radius_plus=rp);prior[i]=route
                active.append(dict(index=i,source=source,route=route))
            if emit:print('ACCEPTED_LOW35',a,b,step+1,i,rec['outcome'],flush=True)
        if step+1<len(o['stages']):
            need(active,'feedback only for a nonempty set of possible marginals')
            profile,raw,d=c.following_profile(profile,active);rm0=profile['radius_minus'];rp0=profile['radius_plus']
            need(equal(stage['feedback'],dict(profile=enc(profile),raw=str(raw),D=str(d))),'exact one-law variance/mean feedback with outward rounding')
        else:
            need(not active or all(z['index']in targets and c.r.guarded(z['route']['result'],z['route']['radius_minus'],z['route']['radius_plus'],targets[z['index']])for z in active),'every final active panel reaches its fixed comparison target')
    need(set(range(a,b))==excluded|set(prior),'complete closed interval coverage')
    return dict(interval=[a,b],initial_covers=len(o['stages']),initial_cells=18432*len(o['stages']),refinements=refinements,support_H_cells=hc,support_rays=rays,excluded=sorted(excluded),acquired=[i for i in range(a,b)if i not in excluded])
