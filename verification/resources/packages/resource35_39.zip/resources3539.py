"""Original complete35–39 seed/resource arithmetic, with a small ready-task DAG.

Exact parent payloads remain conditional mathematical inputs. Current parent
licenses are joined separately. No old own acceptance, HMAC, invented source
epoch, COUNT evaluation or historical execution capture is used here.
"""
from pathlib import Path
from hashlib import file_digest
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import argparse
import json
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent


def need(ok, message):
    if not ok:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+'\n').encode('ascii')


def digest(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'Complete ordinary whole file')
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, 'No duplicate JSON key')
            result[key] = value
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Finite JSON')))


def verify_source():
    files = read(HERE/'RESOURCE3539-SOURCE-VERIFIED.json')['files']
    for name, expected in files.items():
        need(digest(HERE/name) == expected, 'Every whole static source/input byte: '+name)
    return files


def check_receipt(step, receipt):
    need(type(receipt) is dict and receipt['status'] == step['status']
         and receipt['schema'] == step['schema'] and receipt['negative_controls'] == step['negative_controls'],
         'Whole original receipt schema and all original top-level controls')
    for key, value in step['fixed_receipt_fields'].items():
        need(type(receipt.get(key)) is type(value) and receipt[key] == value, 'Complete original domain/census/parent binding: '+key)
    if step['id'] == 'n35-low':
        need([p['interval'] for p in receipt['parts']] == [[16,23],[23,26],[26,29],[29,31]],
             'Entire closed LOW35 probability cover')
        need([p['negative_controls'] for p in receipt['parts']] == step['part_controls'],
             'All original malformed-proof controls in every LOW subpart')


def run_step(task, step, deadline):
    root = task/'capsule'
    directory = root/step['cwd']
    output = directory/step['output']
    need(not output.exists() and time.time() < deadline, 'Fresh acceptance before absolute native cutoff')
    before = {name:digest(root/name) for name in step['input_pins']}
    need(before == step['input_pins'], 'Entire selected original source/parent input closure before native execution')
    logs = task/'executions'/step['id']
    logs.mkdir(parents=True)
    argv = [sys.executable, '-B', '-S', step['entry']]
    (logs/'ARGV.json').write_bytes(encoded(dict(argv=argv,cwd=str(directory),deadline=deadline)))
    began = time.monotonic()
    with (logs/'stdout.txt').open('xb') as stdout, (logs/'stderr.txt').open('xb') as stderr:
        observed = subprocess.run(argv,cwd=directory,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,
                                  timeout=max(1,deadline-time.time()),check=False)
    need(type(observed.returncode) is int and observed.returncode == 0
         and (logs/'stderr.txt').stat().st_size == 0, 'Actual complete original native arithmetic and empty stderr')
    receipt = read(output)
    check_receipt(step,receipt)
    need(before == {name:digest(root/name) for name in step['input_pins']}, 'All complete exact mathematical inputs unchanged')
    report = dict(schema='be.actual3539-complete-original-seed-resource-action/1',id=step['id'],
        n=step['n'],argv=argv,cwd=str(directory),returncode=0,seconds=time.monotonic()-began,
        receipt_sha256=digest(output),receipt_status=receipt['status'],original_controls=receipt['negative_controls'],
        input_sha256=before,stdout_sha256=digest(logs/'stdout.txt'),stderr_sha256=digest(logs/'stderr.txt'),
        current_parent_licenses_still_required=True,mathematical_acceptance=False,full_proof_pass=False)
    (logs/'OBSERVATION.json').write_bytes(encoded(report))
    return report


def execute_graph(task, actions, deadline, jobs):
    """At most jobs native CPU slots, respecting each original two-worker stage."""
    pending = {s['id']:s for s in actions}
    completed, failed, active = {}, {}, {}
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        while pending or active:
            blocked = [key for key,step in pending.items() if any(dep in failed for dep in step['depends'])]
            for key in blocked:
                failed[key] = dict(id=key,kind='DEPENDENCY_FAILED',native_started=False)
                del pending[key]
            used = sum(weight for _,weight in active.values())
            for key,step in list(pending.items()):
                weight = min(jobs,step['cpu_workers'])
                if all(dep in completed for dep in step['depends']) and used+weight <= jobs:
                    future = pool.submit(run_step,task,step,deadline)
                    active[future] = (key,weight)
                    del pending[key]
                    used += weight
            if not active:
                need(not pending,'Acyclic complete ready-task graph')
                break
            done,_ = wait(active,return_when=FIRST_COMPLETED)
            for future in done:
                key,_ = active.pop(future)
                try:
                    completed[key] = future.result()
                except Exception as error:
                    failed[key] = dict(id=key,kind=type(error).__name__,message=str(error),native_started=True)
    return completed,failed


def main():
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('mode',choices=['run'])
    parser.add_argument('--task',required=True)
    parser.add_argument('--deadline',required=True,type=int)
    parser.add_argument('--jobs',type=int,choices=range(1,9),default=6)
    args=parser.parse_args()
    before=verify_source()
    description=read(HERE/'RESOURCE3539-DESCRIPTION.json')
    task=Path(args.task).absolute()
    need(not task.exists() and not task.is_relative_to(HERE) and time.time()<args.deadline,
         'Exclusive new task outside immutable sources before native cutoff')
    task.mkdir(parents=True)
    shutil.copytree(HERE/'payload',task/'capsule')
    completed,failed=execute_graph(task,description['actions'],args.deadline,args.jobs)
    need(verify_source()==before,'Whole source closure unchanged through every original action')
    report=dict(schema='be.actual3539-original-nine-seed-resource-actions/1',
        status='COMPLETE_CONDITIONAL_NUMERICAL_SLICE' if not failed else 'INCOMPLETE_CONDITIONAL_NUMERICAL_SLICE',
        completed=completed,failed=failed,expected_original_native_actions=9,COUNT_calls=0,
        source_before=before,source_after=before,exact_parent_payloads_are_conditional_inputs=True,
        current_initial_scalar_support_and_resource_COUNT_licenses_still_required=True,
        mathematical_acceptance=False,full_proof_pass=False)
    (task/'RESULT.json').write_bytes(encoded(report))
    print(json.dumps(dict(status=report['status'],completed=len(completed),failed=len(failed),
                         result_sha256=digest(task/'RESULT.json')),sort_keys=True))
    need(not failed,'Original action incomplete; successful observations and outputs preserved')


if __name__=='__main__':
    main()
