"""Only the exact new initial support primitive from the indexed scope checker.

The caller must separately prove the current CENTRAL components and indexed
analytic extension. No archived CENTRAL40_ACCEPTED_STATUS is an input here.
"""
from pathlib import Path
from hashlib import sha256,file_digest
from fractions import Fraction as F
from copy import deepcopy
import argparse,importlib.util,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent
def need(ok,message):
 if not ok:raise ValueError(message)
def enc(value):return(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('ascii')
def unique(pairs):
 out={}
 for k,v in pairs:need(k not in out,'Unique JSON key');out[k]=v
 return out
def parse(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in()).throw(ValueError('Finite JSON')))
def read(path):return parse(Path(path).read_bytes())
def digest(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'Complete ordinary source/result')
 with p.open('rb')as stream:return file_digest(stream,'sha256').hexdigest()
def source():
 rows=read(HERE/'INDEXED40-SOURCE-VERIFIED.json')['files']
 for name,pin in rows.items():need(digest(HERE/name)==pin,'Every whole original primitive source and new adapter')
 return rows
def check_scope(proof):
 need(type(proof)is dict and proof['n_band']==[40,42]and all(type(n)is int for n in proof['n_band']), 'Exact finite indices40..42, no monotonicity or boolean indices')
 need(proof['barrier']==proof['slow']=='0'and proof['radius']=='96/25','Exact literal K0/q0/R3.84 input')
 expected=[];lo=F(96,25)
 while lo<F(9,2):hi=min(F(9,2),lo+F(1,20));expected.append([str(lo),str(hi)]);lo=hi
 need(proof['closed_cells']==expected,'Complete closed Bernstein cover through9/2, without endpoint gaps')
 need(type(proof['gates'])is int and proof['gates']>0 and F(proof['minimum_contact'])>0 and F(proof['scale_positive_gate'])>0,'All original strict contact and scale gates')
 pin=proof['gate_sha256'];need(type(pin)is str and len(pin)==64 and all(c in'0123456789abcdef'for c in pin),'Whole exact native gate stream identity')
def controls(proof):
 mutations=[('missing_cell',lambda p:p['closed_cells'].pop()),('gap_endpoint',lambda p:p['closed_cells'][0].__setitem__(0,'19/5')),
  ('wrong_last_index',lambda p:p.__setitem__('n_band',[40,43])),('boolean_index',lambda p:p.__setitem__('n_band',[True,42])),
  ('wrong_barrier',lambda p:p.__setitem__('barrier','1')),('wrong_decrement',lambda p:p.__setitem__('slow','1')),
  ('wrong_radius',lambda p:p.__setitem__('radius','4')),('false_gate',lambda p:p.__setitem__('minimum_contact','0'))]
 accepted=[]
 for name,mutate in mutations:
  bad=deepcopy(proof);mutate(bad)
  try:check_scope(bad)
  except(ValueError,KeyError,TypeError):accepted.append(name)
  else:raise ValueError('Malformed support admitted: '+name)
 return accepted
def evaluate():
 before=source();native=HERE/'math';sys.path.insert(0,str(native))
 import fifth_heat50 as h
 # EXACT literal call from the original check_central_indexed_scope.py.
 proof=h.target(40,42,F(0),F('3.84'),F(0));check_scope(proof)
 need(source()==before,'Every original source unchanged through complete exact gate evaluation')
 return dict(schema='NEW_INDEXED40_EXACT_INITIAL_PRIMITIVE_V1',proof=proof,negative_controls=controls(proof),source_before=before,source_after=before,
  actual_central_component_acquisition_granted=False,indexed_analytic_license_granted=False,mathematical_acceptance=False)
def run(task,deadline):
 before=source();task=Path(task).absolute();need(not task.exists(),'Exclusive new initial support task');task.mkdir(parents=True);observations=[];records=[]
 for name in('construct','replay'):
  remaining=deadline-time.time();need(remaining>1,'Primitive enters before the absolute native horizon')
  logs=task/name;logs.mkdir();argv=[sys.executable,'-B','-S',str(HERE/'indexed_support40.py'),'evaluate'];(logs/'ARGV.json').write_bytes(enc(dict(argv=argv,deadline=deadline)))
  with(logs/'stdout.txt').open('xb')as out,(logs/'stderr.txt').open('xb')as err:process=subprocess.run(argv,cwd=logs,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=remaining,check=False)
  need(type(process.returncode)is int and process.returncode==0 and(logs/'stderr.txt').stat().st_size==0,'Two actually observed independent complete exact source evaluations')
  result=parse((logs/'stdout.txt').read_bytes());check_scope(result['proof'])
  need(result['source_before']==result['source_after']==before and result['negative_controls']==controls(result['proof']),'Whole current primitive scope and all eight malformed controls')
  observations.append(result);records.append(dict(name=name,argv=argv,returncode=0,stdout_sha256=digest(logs/'stdout.txt'),stderr_sha256=digest(logs/'stderr.txt')))
 need(enc(observations[0])==enc(observations[1]),'Full independent fresh proof, gate-stream and source equality')
 need(source()==before,'Whole primitive source after both complete processes')
 report=dict(schema='NEW_INDEXED40_INITIAL_SUPPORT_TWO_PASS_OBSERVATION_V1',status='INDEXED40_LITERAL_INITIAL_SUPPORT_COMPLETED_CONDITIONAL',
  original_literal_call=dict(N=40,last=42,K='0',R='96/25',q='0'),proof=observations[1]['proof'],negative_controls=observations[1]['negative_controls'],
  actual_native_calls=2,executions=records,source_before=before,source_after=before,actual_central_components_and_indexed_analytic_license_still_required=True,
  historical_component_status_staged=False,full_original_scope_checker_claimed_run=False,mathematical_acceptance=False,full_proof_pass=False)
 (task/'RESULT.json').write_bytes(enc(report));return report
def main():
 p=argparse.ArgumentParser(allow_abbrev=False);sub=p.add_subparsers(dest='mode',required=True);sub.add_parser('evaluate')
 r=sub.add_parser('run');r.add_argument('--task',type=Path,required=True);r.add_argument('--deadline',type=int,required=True);args=p.parse_args()
 need(__debug__ and not sys.flags.optimize and sys.dont_write_bytecode,'Ordinary exact no-bytecode interpreter')
 if args.mode=='evaluate':print(enc(evaluate()).decode(),end='');return 0
 result=run(args.task,args.deadline);print(json.dumps(dict(status=result['status'],result_sha256=digest(args.task/'RESULT.json'))),flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
