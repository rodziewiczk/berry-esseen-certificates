"""One exact support35 obligation, two independent original source evaluations.

The original n35/K0/R3.84/q.19 target uses default sign0, published moment cap
and beta endpoints. No old DIRECT acceptance or complete positive chain is an
input. Refinement to R3.9 and the current weak-predecessor license are separate.
"""
from pathlib import Path
from hashlib import file_digest
from fractions import Fraction as F
from copy import deepcopy
import argparse,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent
def need(ok,message):
 if not ok:raise ValueError(message)
def enc(value):return(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('ascii')
def unique(pairs):
 out={}
 for k,v in pairs:need(k not in out,'Unique JSON key');out[k]=v
 return out
def parse(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in()).throw(ValueError('Finite JSON only')))
def read(path):return parse(Path(path).read_bytes())
def digest(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'Complete ordinary source/result')
 with p.open('rb')as stream:return file_digest(stream,'sha256').hexdigest()
def source():
 rows=read(HERE/'SUPPORT35-SOURCE-VERIFIED.json')['files']
 for name,pin in rows.items():need(digest(HERE/name)==pin,'Every whole original math source and explicit new adapter')
 return rows
def hexpin(value):return type(value)is str and len(value)==64 and all(c in'0123456789abcdef'for c in value)
def check_scope(proof):
 need(type(proof)is dict and set(proof)=={'schema','n','K','q','radius','support_sign','score_lower','rho_upper','beta_interval','e_upper','scale_upper','gaussian','ray_rows','scope'},'Whole exact original target schema')
 need(proof['schema']=='DIRECT_FIXED_INDEX_GAUSSIAN_SUPPORT_V1'and type(proof['n'])is int and proof['n']==35
      and proof['K']=='0'and proof['q']=='19/100'and proof['radius']=='96/25'and type(proof['support_sign'])is int and proof['support_sign']==0,
      'Literal actual35/K0/R3.84/q.19, both signs and no improved moment inputs')
 gaussian=proof['gaussian'];need(type(gaussian)is dict and type(gaussian['n'])is int and gaussian['n']==35
  and gaussian['radius']=='96/25'and type(gaussian['mesh'])is int and gaussian['mesh']==10,'Original actual-index Gaussian profile and full threshold mesh')
 H0=F(gaussian['H0']);need(H0.denominator==1 and H0>0 and type(gaussian['cells'])is int and gaussian['cells']==2*int(H0)*10,
  'Complete closed threshold interval at original mesh, with both threshold tails')
 need(F(gaussian['tail_upper'])>=0 and F(gaussian['gaussian_plus_upper'])>=F(gaussian['tail_upper'])
  and F(gaussian['gaussian_minus_upper'])>=F(gaussian['tail_upper'])and hexpin(gaussian['line_sha256']),'Both entire threshold tails and full line-gate identity')
 rays=proof['ray_rows'];need(type(rays)is list and len(rays)==2 and [r['sign']for r in rays]==[-1,1]
  and all(type(r['sign'])is int and all(F(r[k])<0 for k in('coefficient_at_R','contact_derivative_at_R','contact_derivative_slope_at_R','contact_upper'))for r in rays),
  'Both full infinite support rays and every original strict outward contact gate')
 need(F(proof['score_lower'])>0 and F(proof['rho_upper'])>=1 and F(proof['scale_upper'])>0 and F(proof['e_upper'])>0,'Original positive scale and score domains')
 beta=list(map(F,proof['beta_interval']));need(len(beta)==2 and -1<beta[0]<=beta[1]<1 and beta[0]==-beta[1],'Default original symmetric beta endpoints')
def controls(proof):
 mutations=[('boolean_index',lambda p:p.__setitem__('n',True)),('wrong_index',lambda p:p.__setitem__('n',36)),
  ('wrong_radius',lambda p:p.__setitem__('radius','39/10')),('wrong_decrement',lambda p:p.__setitem__('q','0')),
  ('missing_support_ray',lambda p:p['ray_rows'].pop()),('boolean_support_sign',lambda p:p['ray_rows'][1].__setitem__('sign',True)),
  ('missing_threshold_cells',lambda p:p['gaussian'].__setitem__('cells',0)),('corrupted_threshold_digest',lambda p:p['gaussian'].__setitem__('line_sha256','0'*64)),
  ('wrong_scale_correction',lambda p:p.__setitem__('e_upper','0')),('non_strict_contact',lambda p:p['ray_rows'][0].__setitem__('contact_upper','0')),
  ('improved_beta_endpoint',lambda p:p.__setitem__('beta_interval',['0','0'])),('extra_field',lambda p:p.__setitem__('accepted',True))]
 accepted=[]
 for name,mutate in mutations:
  bad=deepcopy(proof);mutate(bad)
  try:check_scope(bad);need(enc(bad)==enc(proof),'Whole freshly reconstructed original proof equality')
  except(ValueError,TypeError,KeyError):accepted.append(name)
  else:raise ValueError('Malformed support proof admitted: '+name)
 return accepted
def evaluate():
 before=source();sys.path.insert(0,str(HERE/'math'));import direct_gaussian_support as ds
 # Exact specialization of the original for n in range(2,40) source call.
 # Optional sign/rho/beta arguments are deliberately left at their originals.
 proof=ds.target(35,F(0),F('3.84'),F('.19'),mesh=10);check_scope(proof)
 need(source()==before,'Every whole original source unchanged through all exact gates')
 return dict(schema='NEW_ACTUAL35_ORIGINAL_DIRECT_SUPPORT_PRIMITIVE_V1',proof=proof,negative_controls=controls(proof),source_before=before,source_after=before,
  default_sign_rho_beta_arguments_unchanged=True,original_n2_to39_acceptor_claimed_run=False,mathematical_acceptance=False)
def run(task,deadline):
 before=source();task=Path(task).absolute();need(not task.exists(),'Exclusive current actual35 support task');task.mkdir(parents=True);objects=[];executions=[]
 for name in('construct','replay'):
  remaining=deadline-time.time();need(remaining>1,'Support primitive enters before the admitted absolute horizon')
  logs=task/name;logs.mkdir();argv=[sys.executable,'-B','-S',str(HERE/'support35.py'),'evaluate'];(logs/'ARGV.json').write_bytes(enc(dict(argv=argv,deadline=deadline)))
  with(logs/'stdout.txt').open('xb')as stdout,(logs/'stderr.txt').open('xb')as stderr:result=subprocess.run(argv,cwd=logs,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=remaining,check=False)
  need(type(result.returncode)is int and result.returncode==0 and(logs/'stderr.txt').stat().st_size==0,'Two actually observed separate complete original numerical calls')
  obj=parse((logs/'stdout.txt').read_bytes());check_scope(obj['proof'])
  need(obj['source_before']==obj['source_after']==before and obj['negative_controls']==controls(obj['proof'])
   and obj['default_sign_rho_beta_arguments_unchanged']is True,'Whole original input scope, source equality and all malformed controls')
  objects.append(obj);executions.append(dict(name=name,argv=argv,returncode=0,stdout_sha256=digest(logs/'stdout.txt'),stderr_sha256=digest(logs/'stderr.txt')))
 need(enc(objects[0])==enc(objects[1])and source()==before,'Whole proof/full threshold-line and support-ray equality under fresh independent replay')
 need(F(96,25)<F(39,10)and F(0)<=F(19,100),'Exact domain inclusion data, separate from its analytic application')
 report=dict(schema='NEW_ACTUAL35_TWO_PASS_DIRECT_SUPPORT_OBSERVATION_V1',status='ACTUAL35_DIRECT_SUPPORT_COMPLETED_CONDITIONAL',
  original_literal_call=dict(n=35,K='0',R='96/25',q='19/100',mesh=10,sign=0,rho=None,beta_lower=None,beta_upper=None),
  proof=objects[1]['proof'],negative_controls=objects[1]['negative_controls'],executions=executions,actual_native_calls=2,source_before=before,source_after=before,
  larger_initial_radius='39/10',original_fullrange_or_positive_chain_claimed_run=False,
  attained_contact_published_moment_and_current_weak_predecessor_licenses_still_required=True,mathematical_acceptance=False,full_proof_pass=False)
 (task/'RESULT.json').write_bytes(enc(report));return report
def main():
 p=argparse.ArgumentParser(allow_abbrev=False);sub=p.add_subparsers(dest='mode',required=True);sub.add_parser('evaluate');sub.add_parser('qualify')
 r=sub.add_parser('run');r.add_argument('--task',type=Path,required=True);r.add_argument('--deadline',type=int,required=True);args=p.parse_args()
 need(__debug__ and not sys.flags.optimize and sys.dont_write_bytecode,'Ordinary exact no-bytecode interpreter')
 if args.mode=='qualify':source();print(json.dumps(dict(status='ACTUAL35_SOURCE_QUALIFIED',new_native_execution=False,mathematical_acceptance=False)),flush=True);return 0
 if args.mode=='evaluate':print(enc(evaluate()).decode(),end='');return 0
 result=run(args.task,args.deadline);print(json.dumps(dict(status=result['status'],result_sha256=digest(args.task/'RESULT.json'))),flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
