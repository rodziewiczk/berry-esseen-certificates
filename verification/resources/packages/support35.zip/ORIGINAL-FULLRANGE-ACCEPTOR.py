"""Fixed exact acceptance: DIRECT_SUPPORT_N2_TO_39_R384_Q019.
Discovery is not imported. Reject ambiguous JSON and enforce a fixed theorem.
"""
from fractions import Fraction as F
from pathlib import Path
import copy,json,hashlib
from direct_gaussian_support import target,exponential,cdf_interval,gaussian_point

def need(x,msg):
 if not x:raise ValueError(msg)
def pairs(rows):
 d={}
 for k,v in rows:
  need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read(path):return json.loads(Path(path).read_text(),object_pairs_hook=pairs)
def typed_equal(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(typed_equal(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(typed_equal(x,y)for x,y in zip(a,b))
 return a==b
def validate(obj,expected):
 need(type(obj)is dict and set(obj)=={'schema','rows'},'exact root schema')
 need(obj['schema']=='DIRECT_SUPPORT_CANDIDATES_V1','schema identifier')
 need(type(obj['rows'])is list and len(obj['rows'])==38,'all fixed indices')
 need(typed_equal(obj,expected),'exact typed full certificate equality')

def main():
 p=Path('direct_support_fullrange.json');original=read(p)
 expected={'schema':'DIRECT_SUPPORT_CANDIDATES_V1','rows':[]}
 for n in range(2,40):
  r=target(n,F(0),F('3.84'),F('.19'),mesh=10)
  expected['rows'].append(r)
 validate(original,expected)
 controls=[]
 def reject(name,f):
  try:f()
  except (ValueError,AssertionError,TypeError,KeyError):controls.append(name);return
  raise ValueError('negative control accepted: '+name)
 def mutation(name,f):
  x=copy.deepcopy(original);f(x);reject(name,lambda:validate(x,expected))
 mutation('missing index',lambda x:x['rows'].pop())
 mutation('duplicate index',lambda x:x['rows'].__setitem__(1,x['rows'][0]))
 mutation('reordered indices',lambda x:x['rows'].reverse())
 mutation('boolean index',lambda x:x['rows'][0].__setitem__('n',True))
 mutation('changed radius',lambda x:x['rows'][0].__setitem__('radius','7/2'))
 mutation('omitted support sign',lambda x:x['rows'][0]['ray_rows'].pop())
 mutation('wrong exact scale correction',lambda x:x['rows'][0].__setitem__('e_upper','0'))
 mutation('missing threshold cells',lambda x:x['rows'][0]['gaussian'].__setitem__('cells',0))
 mutation('corrupted threshold digest',lambda x:x['rows'][0]['gaussian'].__setitem__('line_sha256','0'*64))
 mutation('extra field',lambda x:x.__setitem__('accepted',True))
 mutation('wrong decrement',lambda x:x['rows'][0].__setitem__('q','1/10'))
 reject('duplicate JSON key',lambda:json.loads('{"rows":[],"rows":[]}',object_pairs_hook=pairs))
 reject('false support target',lambda:target(32,F(0),F('3.5'),F('.19')))
 reject('negative decrement allowance',lambda:target(32,F(0),F('3.84'),F('-.01')))
 reject('invalid fixed index type',lambda:target(True,F(0),F('3.84'),F('.19')))
 reject('invalid sign type',lambda:target(32,F(0),F('3.84'),F('.19'),sign=True))
 reject('unlicensed improved moment cap',lambda:target(32,F(0),F('3.84'),F('.19'),rho=F(2)))
 # Exact elementary identities and monotonicity; these supplement, not replace,
 # the analytic proofs of the interval primitives.
 need(exponential(F(0))==(F(1),F(1)),'exp at zero')
 for q in [F(1,10),F(1),F(3),F(25,2),F(100)]:
  a,b=exponential(q);need(0<=a<=b<=1,'exp range')
  c,d=exponential(2*q);need(c<=b*b and a*a<=d,'exp doubling enclosure overlap')
 for a,b in [(F(-8),F(-5)),(F(-1),F(2)),(F(0),F(0)),(F(4),F(6))]:
  x=cdf_interval(a,b);y=cdf_interval(-b,-a)
  need(x==(1-y[1],1-y[0]),'exact CDF reflection')
 for n in [2,20,32,39]:
  for h in [F(-7,3),F(0),F(8,3)]:
   x,_=gaussian_point(n,h,F('3.84'));y,_=gaussian_point(n,-h,-F('3.84'))
   need(x==( -y[1],-y[0]),'exact Gaussian reflection')
 result={'schema':'DIRECT_SUPPORT_ACCEPTANCE_V1','status':'PASS_DIRECT_SUPPORT_N2_TO_39_R384_Q019','mathematical_status':'Locally derived conditional support lemma; depends on stated attained-contact and published moment inputs, not a new score cutoff.','execution_status':'fresh exact replay PASS','indices':list(range(2,40)),'closed_threshold_cells':sum(r['gaussian']['cells']for r in expected['rows']),'complete_support_rays':76,'threshold_rays':76,'negative_controls':controls,'proof_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'worst_contact_upper':str(max(F(x['contact_upper'])for r in expected['rows']for x in r['ray_rows']))}
 Path('direct_support_acceptance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
