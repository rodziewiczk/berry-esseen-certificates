"""Five fresh original floor31 low-rho stages, with explicit parent hypotheses.

Old literal support receipts are reference inputs, never new execution claims.
The original INITIAL candidate changes only support.file for its actual fresh
location. Every other candidate value/program byte remains fixed. Each fresh
INITIAL must finish before its branch's unchanged full resource acceptors run.
"""
from pathlib import Path
from hashlib import sha256,file_digest
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,os,shutil,subprocess,sys,time

HERE=Path(__file__).resolve().parent


def need(ok,message):
    if not ok:raise ValueError(message)


def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode('ascii')


def same(a,b):
    if type(a)is not type(b):return False
    if type(a)is dict:return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
    if type(a)is list:return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
    return a==b


def read(path):
    def unique(pairs):
        out={}
        for name,value in pairs:need(name not in out,'No duplicate JSON key');out[name]=value
        return out
    return json.loads(Path(path).read_bytes(),object_pairs_hook=unique,
        parse_constant=lambda value:(_ for _ in()).throw(ValueError(value)))


def sha(path):
    path=Path(path);need(path.is_file()and not path.is_symlink(),'Ordinary complete source/output')
    with path.open('rb')as stream:return file_digest(stream,'sha256').hexdigest()


def describe():
    mf=read(HERE/'FLOOR31-LOW-SOURCE-VERIFIED.json')
    for name,pin in mf['files'].items():need(sha(HERE/name)==pin,'Whole exact math/data source '+name)
    value=read(HERE/'FLOOR31-LOW-DESCRIPTION.json')
    need(value['actual_native_calls']==5 and value['COUNT_calls']==0 and len(value['cases'])==5,
        'Exactly five original finite source stages; no COUNT rerun')
    need(value['rho_closed_cover']==[['1','11/10'],['11/10','6/5']]
        and value['support16_is_separate_current_input']is True,'Complete closed low domain and explicit support premise')
    return value,sha(HERE/'FLOOR31-LOW-SOURCE-VERIFIED.json')


def mathematical_initial(value):
    value=json.loads(json.dumps(value));need(type(value.get('support'))is dict and'file'in value['support'],
        'One explicitly identified transport-only INITIAL pointer')
    value['support'].pop('file');return value


def prepare_initial(directory,case):
    path=directory/case['candidate'];old=read(path);current=json.loads(json.dumps(old))
    current['support']['file']=str(directory/'support/candidate.json')
    need(same(mathematical_initial(old),mathematical_initial(current)),
        'Every full INITIAL value unchanged outside the one declared transport pointer')
    raw=(json.dumps(current,indent=2)+'\n').encode('utf-8');path.write_bytes(raw)
    return dict(field='support.file',old_value=old['support']['file'],new_value=current['support']['file'],
        original_candidate_sha256=case['input_pins'][case['candidate']],current_candidate_sha256=sha(path),
        all_other_complete_candidate_values_identical=True,mathematical_program_changed=False)


def check_output(directory,case):
    value=read(directory/case['output']);candidate=read(directory/case['candidate'])
    need(same(value['profile'],candidate['profile']),'Exact whole current branch profile')
    if case['id'].endswith('initial'):
        branch=case['id'][1]
        need(value['status']=='FRESH_EXACT_CONDITIONAL_SHARP31_LADDER_B'+branch+'_INITIAL_PASS'
            and value['signed_rectangles']==11*18432 and type(value['signed_rectangles'])is int
            and value['probability_panels']==100 and type(value['probability_panels'])is int,
            'Every ten-update/final-export signed cell and all100 closed probability panels')
        need(same(value['fixed_expected_object_controls'],case['original_controls'])
            and value['proof_sha256']==sha(directory/case['candidate'])
            and value['checker_sha256']==sha(directory/case['entry']),
            'Every original INITIAL control and exact current candidate/program')
        runtime=value['runtime'];need(runtime['python']==sys.version and runtime['implementation']=='cpython'
            and type(runtime['optimize'])is int and runtime['optimize']==0,'Actual unchanged ordinary interpreter')
    else:
        expected='PASS_SHARP31_B0_RESOURCES'if case['id']=='b0-resource'else(
            'PASS_SHARP31_B1_RESOURCES'if case['id']=='b1-resource'else'PASS_SHARP31_B1_LOCAL_PATCH_RESOURCES')
        need(value['status']==expected and same(value['theorem'],candidate['theorem'])
            and same(value['negative_controls'],case['original_controls'])
            and value['resource_sha256']==sha(directory/case['candidate'])
            and value['acceptor_sha256']==sha(directory/case['entry']),
            'Complete original support/resource/interface replay and all original controls')
    return value


def execute_case(task,case,deadline):
    directory=task/case['relocated_cwd'];projection=None
    for name,pin in case['input_pins'].items():need(sha(directory/name)==pin,'Original entire case input BEFORE execution')
    if case['id'].endswith('initial'):projection=prepare_initial(directory,case)
    inputs={name:sha(directory/name)for name in case['input_pins']}
    need(not(directory/case['output']).exists(),'No old acceptance receipt staged as fresh')
    execution=task/'executions'/case['id'];execution.mkdir(parents=True,exist_ok=False)
    argv=[sys.executable,'-B','-S',case['entry'],*case['argv'][2:]]
    # Only original direct argv; no shell, dynamic eval, producer shortcut or
    # forged current compatibility capture is used by this source slice.
    (execution/'COMMAND.json').write_bytes(encoded(dict(argv=argv,cwd=str(directory),input_sha256=inputs,
        candidate_transport_projection=projection,whole_cgroup_authentication_still_required=True)))
    began=time.monotonic()
    with(execution/'stdout.txt').open('xb')as stdout,(execution/'stderr.txt').open('xb')as stderr:
        result=subprocess.run(argv,cwd=directory,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,
            timeout=max(1,int(deadline-time.time())))
    need(result.returncode==0 and(execution/'stderr.txt').stat().st_size==0,'Whole original native stage completed without stderr')
    receipt=check_output(directory,case)
    need(inputs=={name:sha(directory/name)for name in case['input_pins']},'Every original declared input unchanged during native replay')
    record=dict(case_id=case['id'],original_action_id=case['action_id'],argv=argv,returncode=result.returncode,
        seconds=time.monotonic()-began,input_sha256=inputs,candidate_transport_projection=projection,
        receipt_sha256=sha(directory/case['output']),receipt_status=receipt['status'],
        stdout_sha256=sha(execution/'stdout.txt'),stderr_sha256=sha(execution/'stderr.txt'),
        complete_original_controls=case['original_controls'],mathematical_acceptance=False,full_proof_pass=False)
    (execution/'OBSERVATION.json').write_bytes(encoded(record));return record


def branch(task,cases,ids,deadline):
    out=[];initial=None
    for case_id in ids:
        case=cases[case_id]
        if case_id.endswith('initial'):initial=case
        else:
            fresh=read(task/initial['relocated_cwd']/initial['candidate'])
            stored=read(task/case['relocated_cwd']/'initial31_proof.json')
            need(same(mathematical_initial(fresh),mathematical_initial(stored)),
                'All resource INITIAL math values equal the genuinely completed current INITIAL object')
        out.append(execute_case(task,case,deadline))
    return out


def run(task,deadline,jobs):
    need(__debug__ and sys.dont_write_bytecode and sys.flags.no_site,'Ordinary stdlib-only -B -S source execution')
    need(type(jobs)is int and 1<=jobs<=2 and time.time()<deadline,'Finite two-branch concurrency and cutoff')
    descriptor,before=describe();task=Path(task)
    need(task.is_absolute()and not task.exists()and not task.resolve().is_relative_to(HERE),'Fresh contained output separate from static source')
    task.mkdir(parents=True,exist_ok=False);shutil.copytree(HERE/'cases',task/'cases')
    cases={c['id']:c for c in descriptor['cases']};out=[]
    with ThreadPoolExecutor(max_workers=jobs)as pool:
        futures=[pool.submit(branch,task,cases,ids,deadline)for ids in(
            ('b0-initial','b0-resource'),('b1-initial','b1-resource','b1-patch'))]
        for future in as_completed(futures):out.extend(future.result())
    _,after=describe();need(after==before,'Whole unchanged static source BEFORE/AFTER')
    need({r['case_id']for r in out}==set(cases),'Exactly all five original numerical stages completed')
    report=dict(schema='be.floor31-closed-low-five-stage-numerical-observation/1',
        status='FLOOR31_LOW_FIVE_ORIGINAL_NUMERICAL_STAGES_COMPLETED',n=31,
        rho_closed_cover=descriptor['rho_closed_cover'],source_manifest_sha256=before,stages=out,
        COUNT_calls=0,all_probability_panels_retained=True,current_support16_licence_still_required=True,
        scalar_C30_q_and_owncap_licenses_still_required=True,charged_resource_and_COUNT_licenses_still_required=True,
        old_support_receipts_are_reference_inputs_not_new_claims=True,
        actual_execution_authentication_still_required=True,mathematical_acceptance=False,full_proof_pass=False)
    (task/'RESULT.json').write_bytes(encoded(report));print(json.dumps(report),flush=True);return report


if __name__=='__main__':
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('mode',choices=('run','qualify'))
    p.add_argument('--task',type=Path);p.add_argument('--deadline',type=int);p.add_argument('--jobs',type=int,default=2);a=p.parse_args()
    if a.mode=='qualify':print(json.dumps(dict(source_manifest_sha256=describe()[1],native_calls=0,full_proof_pass=False)))
    else:
        need(a.task is not None and a.deadline is not None,'Explicit fresh task and cutoff');run(a.task,a.deadline,a.jobs)
