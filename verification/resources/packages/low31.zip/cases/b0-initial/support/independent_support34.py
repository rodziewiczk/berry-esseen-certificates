"""Independent n34 Gaussian support reduction, natural interval H cells.
Uses only the reviewed rational root/CDF primitives; does not import the direct
support constructor, its constants, its H derivatives, or its Hessian bound.
"""
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import json,sys
import finite_binomial_core as g
S=g.S;Z=g.Z

def need(x,s):
 if not x:raise ValueError(s)
def mul(a,b):
 xs=[x*y for x in a for y in b];return min(xs),max(xs)
def scaled(a,c):return mul(a,(c,c))
def add(a,b):return a[0]+b[0],a[1]+b[1]
def divroot_interval(a,b,n):
 lo,hi=g.root(F(n));xs=[x/y for x in(a,b)for y in(lo,hi)];return min(xs),max(xs)
@lru_cache(None)
def cdf_point_grid(j):
 if j<0:
  a,b=cdf_point_grid(-j);return 1-b,1-a
 if j>=5*Z:return 1-g.TAIL,F(1)
 a,b=g.positive_cdf(j);return F(a,S),F(b,S)
def cdf(a):
 lo=a[0].numerator*Z//a[0].denominator;hi=g.ceildiv(a[1].numerator*Z,a[1].denominator)
 return cdf_point_grid(lo)[0],cdf_point_grid(hi)[1]
def exp_neg(q):
 need(q>=0,'positive exponential argument');j=0
 while q>1:q/=2;j+=1
 lo=hi=S;sl=sh=S
 for k in range(1,32):
  lo=lo*q.numerator//(q.denominator*k);hi=g.ceildiv(hi*q.numerator,q.denominator*k)
  if k%2:sl-=hi;sh-=lo
  else:sl+=lo;sh+=hi
 sh+=g.ceildiv(hi*q.numerator,q.denominator*32)
 need(0<=sl<=sh<=S,'odd31/even32 exponential enclosure')
 for _ in range(j):sl=sl*sl//S;sh=g.ceildiv(sh*sh,S)
 return F(sl,S),F(sh,S)
def density(a):
 nearest=F(0)if a[0]<=0<=a[1]else min(abs(a[0]),abs(a[1]));furthest=max(abs(a[0]),abs(a[1]))
 return g.PHI_LO*exp_neg(furthest**2/2)[0],g.PHI_HI*exp_neg(nearest**2/2)[1]
def enclosure(a,b,R):
 z=divroot_interval(a,b,34);v=divroot_interval(a-R,b-R,33)
 ph=cdf(z);pv=cdf(v);nr=g.root(F(34));first=mul((34*nr[0],34*nr[1]),(pv[0]-ph[1],pv[1]-ph[0]))
 coefficient=(34*R+a*(R*R-1)/2,34*R+b*(R*R-1)/2)
 return add(first,mul(coefficient,density(z)))
def constants():
 c=F(819,2000);r=min(F(3031,10000)*F(323,500)/(c-F(3031,10000)),F(1661,5000)*F(429,1000)/(c-F(1661,5000)))
 need(r==F(7361,4000),'published rho cap')
 # y=beta^2 obeys y^2+(2+r^2)y+1-r^2<=0.
 disc=g.root((2+r*r)**2-4*(1-r*r))[1];b=g.root((disc-2-r*r)/2)[1]
 need(0<b<1 and (1+b*b)**2>r*r*(1-b*b),'signed-beta cap from exact quadratic')
 scale=g.root(F(34,33))[1];e=34*(scale-1)-F(1,2)
 need(e>0,'exact fixed-index correction');return c,r,b,scale,e

def ray_gates(R,q,c,r,b,scale,e,Gp,Gm):
 need(R>=1 and q>=0,'ray scope');Q=-R**3+F(3,2)*r*R*R+3*b*R+r*e
 q1=-3*R*R+3*r*R+3*b;q2=-6*R+3*r
 l=F(2,5)*(R*R/2+F(1,2)+e)+c*q1;l1=F(2,5)*R+c*q2
 need(max(Q,q1,q2,l,l1,F(1,5)-3*c)<0,'negative cubic coefficient and contact derivative on full ray')
 contacts=[Gp+c*Q+r*scale*q,Gm+c*Q+r*scale*q];need(max(contacts)<0,'both support-ray endpoint contact inequalities')
 return dict(Q=str(Q),Q1=str(q1),Q2=str(q2),L=str(l),L1=str(l1),negative_support_ray_upper=str(contacts[1]),positive_support_ray_upper=str(contacts[0]))
def main():
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'ordinary fixed support check')
 R=F(39,10);q=F(102,275);mesh=200;H0=F(33);c,r,b,s,e=constants();nr=g.root(F(34));vr=g.root(F(33))
 need(H0>=5*nr[1]and H0-R>=5*vr[1],'two complete threshold tails')
 tail=34*nr[1]*g.TAIL+(34*R+H0*(R*R-1)/2)*density(divroot_interval(H0,H0,34))[1]
 gp=gm=tail;wherep=wherem='threshold tails';digest=sha256()
 for j in range(2*int(H0)*mesh):
  a=-H0+F(j,mesh);bH=a+F(1,mesh);lo,hi=enclosure(a,bH,R)
  if hi>gp:gp=hi;wherep=[str(a),str(bH)]
  if -lo>gm:gm=-lo;wherem=[str(a),str(bH)]
  digest.update(('|'.join(map(str,(a,bH,lo,hi)))+'\n').encode())
 gates=ray_gates(R,q,c,r,b,s,e,gp,gm);tests=[]
 for label,fn in [('false Gaussian support cap',lambda:ray_gates(R,q,c,r,b,s,e,F(10),gm)),('wrong narrow radius',lambda:ray_gates(F(3),q,c,r,b,s,e,gp,gm)),('negative allowance',lambda:ray_gates(R,-q,c,r,b,s,e,gp,gm))]:
  try:fn()
  except ValueError:tests.append(label)
  else:raise ValueError('negative control accepted')
 need(cdf((F(-3),F(2)))==(1-cdf((F(-2),F(3)))[1],1-cdf((F(-2),F(3)))[0]),'CDF reflection including atoms irrelevant to Gaussian')
 need(exp_neg(F(0))==(F(1),F(1)),'density at zero')
 print(json.dumps(dict(status='PASS_INDEPENDENT_N34_SUPPORT_DIRECT_INTERVALS',mathematical_status='Same conditional attained-contact support theorem, independently reduced using natural H interval enclosures rather than derivative/Hessian cell interpolation. Rational CDF/root primitives are shared and separately analytically reviewed.',execution_status='Fresh rational all-H cover and full-ray polynomial checks',n=34,K='0',q=str(q),R=str(R),threshold_cells=2*int(H0)*mesh,H0=str(H0),mesh=mesh,threshold_rays=2,support_rays=2,gaussian_plus_upper=str(gp),gaussian_minus_upper=str(gm),where_plus=wherep,where_minus=wherem,threshold_tail_upper=str(tail),cell_digest=digest.hexdigest(),ray_gates=gates,negative_controls=tests),indent=2))
if __name__=='__main__':main()
