"""Fixed same-law sharp31 ladder branch0; predecessor remains conditional."""
from fractions import Fraction as F
import finite_binomial_core as g
N=31;K=F(0);Q=F(31,100);R=F(47,20);RHO_LO=F(1);RHO_HI=F(11,10);CAP=F(432313,1000000)
disc=g.root((2+RHO_HI*RHO_HI)**2-4*(1-RHO_HI*RHO_HI))[1]
BETA=g.root((disc-2-RHO_HI*RHO_HI)/2)[1]
PROFILE=dict(n=N,K='0',allowance_kind='SAME_LAW_PREDECESSOR_SCORE_FROM_POSITIVE30',scalar_premise='C30 < CE + 1/100',rho_branch=['1','11/10'],contact_allowance='31/100',R='47/20',rho_upper='11/10',beta_interval=[str(-BETA),str(BETA)],own_cap_strict='432313/1000000')
def check_profile():
 assert 31*F(1,100)==Q
 assert 0<BETA<1 and (1+BETA*BETA)**2>RHO_HI*RHO_HI*(1-BETA*BETA)
 assert RHO_LO==1 and RHO_HI==F(11,10)and R==F(47,20)
 assert (3+g.root(F(10))[1])*g.PHI_HI/6+F(7,310)<CAP
 # The preceding numerical implication does not prove C31<CE+7/310.
 # The strict own cap is a retained outside dependency, as in the prior ladder.

