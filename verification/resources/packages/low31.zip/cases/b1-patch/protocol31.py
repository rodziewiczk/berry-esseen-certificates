"""Exact branch resource protocol, with literal frozen source and target scope."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
import resource31_core as r
import local31_core as local
import charged_phase_cap as phase
from branch_profile import BRANCH,PROFILE,THEOREM,SUPPORT_PROFILE,SUPPORT_SCOPE,SUPPORT_SHA,INITIAL_SHA,CONTRACT_SHA,CONTRACT_SCHEMA,CONTRACT_FIELDS,SURVIVORS,BETA,SELECTED_PANELS
SCHEMA='SHARP31_RHO_B1_LOCAL_PATCH_RESOURCE_V1'
SOURCES=('resource31_core.py','candidate_charged_score_v2.py','contracted_kernel.py','kernel.py','high_window_core.py','paired_extended.py','signed_variance_resource.py','geometric_moment_both.py','corrected_phase_callback_extended.py','direct_gaussian_support.py','finite_binomial_core.py','small_index_support.py','heat_support50.py','branch_profile.py','local31_core.py','initial_local31_charged.py','charged_phase_cap.py','protocol31.py')
def need(x,s):
 if not x:raise ValueError(s)
def sha(p):return sha256(Path(p).read_bytes()).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read(p):return json.loads(Path(p).read_text(),object_pairs_hook=unique)
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def fields(o,names):need(type(o)is dict and set(o)==set(names),'exact object fields')
def rat(x):
 need(type(x)is str,'rational string');v=F(x);need(str(v)==x,'canonical rational');return v
def initial_support():
 obj=read('support31.json');need(sha('support31.json')==SUPPORT_SHA,'fixed actual branch support bytes')
 fields(obj,('schema','profile','proof'))
 need(obj['schema']==f'CONDITIONAL_SHARP31_LADDER_B{BRANCH}_SUPPORT_V1'and same(obj['profile'],SUPPORT_PROFILE),'same branch support theorem')
 need(SUPPORT_PROFILE['rho_branch']==[str(r.RHO_LO),str(r.RHO_HI)]and F(SUPPORT_PROFILE['R'])==r.R and SUPPORT_PROFILE['contact_allowance']==str(r.Q),'support matches all arithmetic constants')
 actual=r.ds.target(r.N,r.K,r.R,r.Q,rho=r.RHO_HI,beta_lower=-F(BETA),beta_upper=F(BETA))
 need(obj['proof']['scope']==SUPPORT_SCOPE,'fixed supplied support scope')
 # The reviewed arithmetic copies differ only in these theorem annotations.
 need(actual['schema']=='DIRECT_SAME_LAW_CONTACT_SUPPORT_DISCOVERY_V1'and actual['q_contact']==str(r.Q),'literal replay support naming')
 need(obj['proof']['schema']=='DIRECT_FIXED_INDEX_GAUSSIAN_SUPPORT_V1'and obj['proof']['q']==str(r.Q),'literal supplied support naming')
 actual['schema']='DIRECT_FIXED_INDEX_GAUSSIAN_SUPPORT_V1';actual['q']=actual.pop('q_contact');actual['scope']=SUPPORT_SCOPE
 need(same(obj['proof'],actual),'complete initial support arithmetic equality')
 return actual
def fixed_inputs():
 need(__debug__ and not sys.flags.optimize,'ordinary assertion-enabled runtime')
 need(type(BRANCH)is int and BRANCH in(1,3,4),'literal supported branch')
 need(sha('contract31.json')==CONTRACT_SHA and sha('initial31_proof.json')==INITIAL_SHA,'fixed target and INITIAL bytes')
 target=read('contract31.json');fields(target,CONTRACT_FIELDS)
 need(target['schema']==CONTRACT_SCHEMA and target['scope']=='FIXED_UNACQUIRED_RESOURCES','named conditional count contract')
 need(type(target['n'])is int and target['n']==31 and rat(target['K'])==0 and type(target['branch'])is int and target['branch']==BRANCH,'literal count target/index/branch')
 need(target['rho_interval']==[str(r.RHO_LO),str(r.RHO_HI)],'literal count rho branch')
 need(type(target['rows'])is list and len(target['rows'])==len(SURVIVORS),'full selected count table')
 for i,z in zip(SURVIVORS,target['rows']):
  need(type(z['index'])is int and z['index']==i and type(z['n'])is int and z['n']==31,'fixed closed row order')
  need(z['p']==[str(F(i,100)),str(F(i+1,100))],'literal count probability interval')
  need(rat(z['rho_lower'])==r.RHO_LO and r.RHO_LO<=rat(z['rho_upper'])<=r.RHO_HI,'both count rho endpoints')
 initial=read('initial31_proof.json')
 need(initial['schema']==f'CONDITIONAL_SHARP31_LADDER_B{BRANCH}_INITIAL_V1'and same(initial['profile'],PROFILE),'full literal INITIAL branch')
 need(PROFILE['invariants']==dict(rho_lo=str(r.RHO_LO),rho=str(r.RHO_HI))and F(PROFILE['radius'])==r.R,'same arithmetic profile')
 need(initial['scalar_premise']=='C_30 < C_E + 1/100'and initial['contrary_premise']=='C_31 >= C_E'and initial['predecessor_allowance']=='31/100','same contrary witness and predecessor')
 need(initial['support']['sha256']==SUPPORT_SHA and same(initial['support']['profile'],SUPPORT_PROFILE),'same INITIAL support')
 need(type(initial['stages'])is list and len(initial['stages'])==10,'ten global updates')
 last=initial['final_invariants'];fields(last,('raw','D'))
 need(same(last,dict(raw=initial['stages'][-1]['next_raw'],D=initial['stages'][-1]['next_D'])),'guard/export induction')
 need(0<rat(last['D'])<r.c.k.SL-1 and 0<rat(last['raw'])<F(62,5),'uniform gap and density domains')
 panels=initial['export']['panels'];need(type(panels)is list and len(panels)==100,'full closed p cover')
 for i,z in enumerate(panels):
  need(type(z)is dict and type(z['cells'])is int and z['cells']>=0,'typed INITIAL panel incidence')
  need(rat(z['pl'])==F(i,100)and rat(z['pu'])==F(i+1,100),'closed INITIAL order')
  for key in('raw','D','theta','rho','beta','H','A','B','mean_lo','mean_hi','gamma_lo','gamma_hi','M','eta','beta_lo','rho_lo','rho_branch_upper'):rat(z[key])
  need(z['rho_lo']==str(r.RHO_LO)and z['rho_branch_upper']==str(r.RHO_HI),'literal branch labels on every panel')
  if z['cells']:
   need(r.RHO_LO<=F(z['rho'])<=r.RHO_HI,'actual nonempty panel rho interval')
  else:
   need(z['raw']=='-1'and z['D']=='-1'and z['rho']=='1','empty INITIAL sentinels; not actual moment bounds')
 return initial,{z['index']:z for z in target['rows']}
def bindings():return{p:sha(p)for p in SOURCES+('initial31_proof.json','contract31.json','support31.json')}
def radii(z,rm,rp):
 fields(z,('radius_minus','radius_plus'))
 nm,np=rat(z['radius_minus']),rat(z['radius_plus'])
 need(0<nm<=rm and 0<np<=rp,'nested actual support plan');return nm,np
def resource_plan(plan,rm,rp,limit):
 need(type(plan)is list and len(plan)<=limit,'bounded resource refinements')
 for z in plan:rm,rp=radii(z,rm,rp)
 return rm,rp
def plan_shape(plan):
 fields(plan,('base','locals'));rm,rp=resource_plan(plan['base'],r.R,r.R,5)
 need(type(plan['locals'])is list and len(plan['locals'])<=2,'at most two fixed local covers')
 for i,z in enumerate(plan['locals']):
  if set(z)=={'moment_empty'}:
   need(z['moment_empty']is True and i==len(plan['locals'])-1,'terminal moment contradiction');continue
  fields(z,('initial_support','resource'));rm,rp=radii(z['initial_support'],rm,rp)
  rm,rp=resource_plan(z['resource'],rm,rp,8)
def shape(obj):
 fields(obj,('schema','profile','theorem','input_sha256','initial_support','rows'))
 need(obj['schema']==SCHEMA and same(obj['profile'],PROFILE)and same(obj['theorem'],THEOREM),'fixed resource theorem')
 need(same(obj['input_sha256'],bindings()),'complete input bindings')
 need(type(obj['rows'])is list and len(obj['rows'])==2,'two selected local patch panels')
 for i,z in zip(SELECTED_PANELS,obj['rows']):
  fields(z,('index','plan','result','interface'))
  need(type(z['index'])is int and z['index']==i,'strict ordered probability panel')
  plan_shape(z['plan']);need(type(z['result'])is dict and type(z['interface'])is list,'typed exact result')
def one(index,source,guard,plan=None):
 result=local.route(r.dec(source),plan);actual_plan=local.selected_plan(result)
 if plan is not None:need(same(plan,actual_plan),'all selected stages consumed')
 interface=[]
 if not result.get('excluded'):
  need(index in guard,'every survivor enters fixed count target')
  result['result']=phase.complete_export(result['result'])
  interface=r.enc(r.interface(result['result'],guard[index]))
 return dict(index=index,plan=actual_plan,result=r.enc(result),interface=interface)
def verify(obj,initial,guard,emit=False):
 shape(obj);support=initial_support()
 need(same(obj['initial_support'],support),'complete initial support replay')
 totals=dict(probability_panels=2,resource_refinements=0,local_INITIAL_covers=0,
  local_INITIAL_rectangles=0,support_H_cells=support['gaussian']['cells'],signed_support_rays=2,
  signed_quadratic_interfaces=0,surviving_panels=[],excluded_panels=[])
 def count_support(proofs):
  for z in proofs:totals['support_H_cells']+=z['gaussian']['cells'];totals['signed_support_rays']+=1
 def count_resource(resource):
  for z in resource.get('history',[]):
   totals['resource_refinements']+=1;count_support(z['support'])
 for i,witness in zip(SELECTED_PANELS,obj['rows']):
  source=initial['export']['panels'][i]
  actual=one(i,source,guard,witness['plan']);need(same(witness,actual),'full exact resource/INITIAL/interface replay')
  z=actual['result'];count_resource(z['base'])
  for stage in z['locals']:
   if 'initial'in stage:
    totals['local_INITIAL_covers']+=1;totals['local_INITIAL_rectangles']+=stage['initial']['total']
    count_support(stage['support']);count_resource(stage['resource'])
  totals['excluded_panels'if z['excluded']else'surviving_panels'].append(i)
  totals['signed_quadratic_interfaces']+=len(actual['interface'])
  if emit:print('ACCEPTED_SHARP31_LOCAL_RESOURCE',BRANCH,i,z.get('reason','fixed target acquired'),flush=True)
 need(totals['surviving_panels']==SURVIVORS,'complete branch target interfaces')
 return totals
