"""Exact sharp31 literal-rho branch route: global resources, then at most two local INITIAL covers.
Every contracted support radius is proved before use; each local cover is for
one fixed actual p interval and one common law. No pooling of panels occurs.
"""
from fractions import Fraction as F
import resource31_core as r
import initial_local31_charged as initial

PROFILE=dict(n=31,nmax=31,radius=r.R,cap=r.CAP,barrier=r.K,grid=[24,24,8,4],p_interval=[F(0),F(1)],invariants=dict(rho_lo=r.RHO_LO,rho=r.RHO_HI))

def plan_of(resource):
 return [dict(radius_minus=str(z['radius_minus']),radius_plus=str(z['radius_plus']))for z in resource.get('history',[])]
def support(inv,rm,rp,plan=None):
 row=dict(rho=inv['rho'],beta_lo=inv['beta_lo'],beta=inv['beta_hi'])
 if plan is None:return r.support(row,rm,rp)
 nm,np=(F(plan[key])for key in('radius_minus','radius_plus'))
 r.need(0<nm<=rm and 0<np<=rp,'nested local INITIAL support')
 proofs=[]
 for sign,prior,new in((-1,rm,nm),(1,rp,np)):
  if new<prior:proofs.append(r.ds.target(r.N,r.K,new,r.Q,sign=sign,rho=inv['rho'],beta_lower=inv['beta_lo'],beta_upper=inv['beta_hi']))
 return nm,np,proofs
def invariants(source,row,previous):
 l,u,t=row['pl'],row['pu'],row['theta']
 vmin=min(l*(1-l),u*(1-u))
 vmax=max(l*(1-l),u*(1-u),F(1,4)if l<=F(1,2)<=u else F(0))
 inv=dict(rho=row['rho'],rho_lo=r.RHO_LO,
  beta_lo=max(source['beta_lo'],row['beta_lo']),beta_hi=min(source['beta'],row['beta']),
  M=row['M'],eta=row['eta'],gamma_lo=source['gamma_lo'],
  gamma_hi=min(source['gamma_hi'],row['trace'][-1]['g']),
  mean_lo=max(source['mean_lo'],r.c.k.roots(vmin*(1-t))[0]),
  mean_hi=min(source['mean_hi'],r.c.k.roots(vmax)[1]))
 for key,value in previous.get('invariants',{}).items():
  inv[key]=(max if key.endswith('_lo')else min)(inv[key],value)
 # Finite outward grids keep denominators bounded. They only weaken bounds.
 for key,value in list(inv.items()):
  lower=key.endswith('_lo');rounded=(r.down if lower else r.up)(value)
  r.need(rounded<=value if lower else rounded>=value,'outward local invariant')
  inv[key]=rounded
 inv['rho_lo']=max(inv['rho_lo'],r.RHO_LO);inv['rho']=min(inv['rho'],r.RHO_HI)
 return inv
def route(source,plan=None):
 source=dict(source);r.need(type(source['cells'])is int and source['cells']>=0,'literal initial panel cells')
 index=int(source['pl']*100)
 base=r.resource(source,replay_plan=None if plan is None else plan['base'])
 answer=dict(index=index,base=base,locals=[])
 if base.get('excluded'):
  answer.update(excluded=True,reason=base['reason']);return answer
 P=dict(PROFILE);item=base
 for j in range(2 if plan is None else len(plan['locals'])):
  row=item['raw_row'];l,u=row['pl'],row['pu']
  r.need(row['D']<r.c.k.SL-1,'all local INITIAL cells have actual central gap')
  inv=invariants(source,row,P)
  if inv['rho']<inv['rho_lo'] or any(inv[k+'_lo']>inv[k+'_hi']for k in('beta','gamma','mean')):
   answer['locals'].append(dict(step=j+1,excluded=True,reason='DISJOINT_SAME_LAW_MOMENT_INTERVALS',invariants=inv))
   answer.update(excluded=True,reason='DISJOINT_SAME_LAW_MOMENT_INTERVALS');return answer
  rm,rp=item['result']['radius_minus'],item['result']['radius_plus']
  selected=None if plan is None else plan['locals'][j]['initial_support']
  rm,rp,proofs=support(inv,rm,rp,selected)
  P=dict(P,invariants=inv,radius_minus=rm,radius_plus=rp,radius=max(F(23,10),rm,rp),p_interval=[l,u])
  cover=initial.stage(P,row['raw'],row['D'])
  newsource=dict(cover['panels'][index],rho_lo=r.RHO_LO,rho_branch_upper=r.RHO_HI)
  if newsource['cells']:
   for key in('D','raw','theta','rho','M','eta','beta','H'):newsource[key]=min(newsource[key],row[key])
   for key in('A','B','beta_lo'):newsource[key]=max(newsource[key],row[key])
  resource=r.resource(newsource,rm,rp,max_refinements=8,replay_plan=None if plan is None else plan['locals'][j]['resource'])
  answer['locals'].append(dict(step=j+1,profile=P,input_raw=row['raw'],input_D=row['D'],support=proofs,
   radius_minus=rm,radius_plus=rp,initial=cover,source=newsource,resource=resource))
  if resource.get('excluded'):
   answer.update(excluded=True,reason=resource['reason']);return answer
  source,item=newsource,resource
 answer.update(excluded=False,result=item['result']);return answer
def selected_plan(answer):
 locals=[]
 for z in answer['locals']:
  if z.get('excluded'):
   locals.append(dict(moment_empty=True));continue
  locals.append(dict(initial_support=dict(radius_minus=str(z['radius_minus']),radius_plus=str(z['radius_plus'])),resource=plan_of(z['resource'])))
 return dict(base=plan_of(answer['base']),locals=locals)
