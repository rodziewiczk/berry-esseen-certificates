"""Exact fixed-index sharp31, literal rho branch selected in branch_profile resource calculus, with both probability halves.
A named acceptor must bind global INITIAL, scalar/support inputs, complete
closed p coverage and all fixed count targets. No theorem is asserted here.
"""
from fractions import Fraction as F
from functools import lru_cache
import json
import candidate_charged_score_v2 as c
import corrected_phase_callback_extended as correction
import geometric_moment_both as gm
import direct_gaussian_support as ds
correction.install(c.k)
N=31;K=F(0);Q=F(31,100);CAP=F(432313,1000000);R=F('13/5')
RHO_LO=F('11/10');RHO_HI=F('6/5')

def need(x,s):
 if not x:raise ValueError(s)
def enc(x):
 if type(x)is F:return str(x)
 if isinstance(x,dict):return{str(k):enc(v)for k,v in x.items()}
 if isinstance(x,(list,tuple)):return[enc(v)for v in x]
 return x
def dec(x):
 if type(x)is str:
  try:return F(x)
  except ValueError:return x
 if isinstance(x,dict):return{k:dec(v)for k,v in x.items()}
 if isinstance(x,list):return[dec(v)for v in x]
 return x
def up(x,grid=10**8):return F(-((-x.numerator*grid)//x.denominator),grid)
def down(x,grid=10**8):return F(x.numerator*grid//x.denominator,grid)
def source_round(source):
 row=dict(source)
 need(row['rho_lo']==RHO_LO and row['rho_branch_upper']==RHO_HI,'literal same-law branch input')
 if not row['cells']or row['D']<0:return row
 for key in('D','raw','theta','rho','M','eta','beta','H','mean_hi','gamma_hi'):
  if key in row:
   v=up(row[key]);need(v>=row[key],'outward incoming upper');row[key]=v
 for key in('A','B','beta_lo','mean_lo','gamma_lo'):
  if key in row:
   v=down(row[key]);need(v<=row[key],'outward incoming lower');row[key]=v
 row['rho']=min(row['rho'],RHO_HI)
 need(RHO_LO<=row['rho']<=RHO_HI,'intersect rounded ceiling with literal branch')
 need(row['theta']<1,'rounded positive between-sign variance')
 return row

def retained_cell(radius,row,steps):
 try:z=c.cell(N,radius,CAP,row,steps=steps,barrier=K)
 except c.k.EmptyEndpointRectangle as e:
  return dict(excluded=True,reason='EMPTY_ACQUIRED_ENDPOINT_RECTANGLE',witness=e.args[0])
 except c.k.EmptyMomentBranch as e:
  return dict(excluded=True,reason='EMPTY_LITERAL_RHO_MOMENT_INTERSECTION',witness=e.args[0])
 if not z.get('excluded'):
  z['M']=min(row.get('M',z['trace'][-1]['M']),z['trace'][-1]['M'])
  z['eta']=min(row.get('eta',radius*z['M']),radius*z['M'])
  z['beta_lo']=max(row.get('beta_lo',z['beta_lo']),z['beta_lo'])
  z['H']=row['H']
  need(z['rho_lo']==RHO_LO and RHO_LO<=z['rho']<=RHO_HI,'same literal branch after coupled update')
 return z

def amplitude(row,rm,rp):
 l,u,t=row['pl'],row['pu'],row['theta'];need(0<l<u<1 and 0<=t<1,'both-half variance domain')
 vmin=min(l*(1-l),u*(1-u));vmax=max(l*(1-l),u*(1-u),F(1,4)if l<=F(1,2)<=u else F(0))
 ell=c.k.roots((1-t)/vmax)[0];need(ell>0,'positive actual scale')
 A0=rm/ell-l;A1=rp/ell-(1-u);need(A0>0 and A1>0,'positive actual outer caps')
 return ell,A0,A1,vmin,vmax

def support(row,oldrm,oldrp):
 rm,rp=oldrm,oldrp;proofs=[]
 for sign,prior in((-1,oldrm),(1,oldrp)):
  for j in range(14,40):
   radius=F(j,10)
   if radius>=prior:break
   try:z=ds.target(N,K,radius,Q,sign=sign,rho=row['rho'],beta_lower=row['beta_lo'],beta_upper=row['beta'])
   except ValueError:continue
   if sign<0:rm=radius
   else:rp=radius
   proofs.append(z);break
 return rm,rp,proofs

def charged(quads):
 need(len(quads)==4,'four simultaneous precursor corners')
 C0,C1=quads[0]['C'],quads[2]['C'];need(C1>C0,'ordered actual-score interval')
 need(quads[1]['C']==C0 and quads[3]['C']==C1,'same score corners')
 need(quads[0]['rho']==quads[2]['rho']and quads[1]['rho']==quads[3]['rho'],'same rho corners')
 split=F('.40974')+K/N;scores=sorted(set([C0,C1]+([split]if C0<split<C1 else[])));answer=[]
 for C in scores:
  weight=(C-C0)/(C1-C0)
  for j in(0,1):
   rho=quads[j]['rho'];v={key:(1-weight)*quads[j][key]+weight*quads[j+2][key]for key in('A','Fplus','Fminus','Qbudget')}
   v['A']-=max(K,N*(C-F('.40974')))*rho;v.update(C=C,rho=rho);answer.append(v)
 return answer

def export(row,rm,rp):
 ell,A0,A1,_,_=amplitude(row,rm,rp);d0,Lambda=row['inward_d_max'],row['lambda_max'];res=row['residual']
 need(res>0 and d0>0 and Lambda>0,'positive simultaneous resource divisors')
 Hm=min(row['H'],row.get('Hminus',row['H']));Hp=min(row['H'],row.get('Hplus',row['H']))
 if 'quadratics'in row:quads=charged(row['quadratics']);kind='paired signed envelope'
 else:
  H=max(Hm,Hp);eps=F(1,10000);quads=[dict(A=row['D']/F(15000,997*N)+eps*H*H,Fplus=F(0),Fminus=F(0),Qbudget=eps)];kind='scalar defect with independently acquired INITIAL H'
 out=dict(rho_lo=row.get('rho_lo',F(1)),rho_hi=row['rho'],index=int(row['pl']*100),N=N,K=K,pl=row['pl'],pu=row['pu'],D=row['D'],lambda_max=Lambda,d0=d0,radius_minus=rm,radius_plus=rp,outer0=A0,outer1=A1,H_minus=Hm,H_plus=Hp,charge_b=row['D']-res,charge_g=res/d0,charge_h=res/Lambda,paired=row['trace'][-1]['paired'],amplitude=max(A0,A1),quadratics=quads,envelope_kind=kind)
 need(out['charge_b']>=0 and out['charge_g']>0 and out['charge_h']>0,'nonnegative actual-law prices')
 return out

def resource(source,rm=R,rp=R,max_refinements=5,replay_plan=None):
 row=source_round(source)
 if not row['cells']:return dict(excluded=True,reason='empty INITIAL probability panel')
 if row['D']<0:return dict(excluded=True,reason='negative INITIAL conserved budget')
 need(0<rm<=R and 0<rp<=R,'acquired support input')
 price=c.k.SL-1-row['D'];need(price>0,'positive endpoint-product price')
 A=price/(6*(1-row['pl']));B=price/(6*row['pu'])
 row['A']=max(row['A'],down(A,10**10));row['B']=max(row['B'],down(B,10**10))
 need(row['A']>0 and row['B']>0,'strict acquired inward endpoints')
 seed=dict(row);row=retained_cell(max(F(23,10),rm,rp),row,80)
 if row.get('excluded'):return dict(excluded=True,reason=row['reason'],initial=seed,base=row)
 base=row;history=[]
 for j in range(max_refinements if replay_plan is None else len(replay_plan)):
  oldrm,oldrp=rm,rp
  if replay_plan is None:rm,rp,proofs=support(row,rm,rp)
  else:
   nm,np=(F(replay_plan[j][key])for key in ('radius_minus','radius_plus'))
   need(0<nm<=oldrm and 0<np<=oldrp,'nested actual support radii')
   proofs=[]
   for sign,prior,new in((-1,oldrm,nm),(1,oldrp,np)):
    if new<prior:proofs.append(ds.target(N,K,new,Q,sign=sign,rho=row['rho'],beta_lower=row['beta_lo'],beta_upper=row['beta']))
   rm,rp=nm,np
  old=gm.install(c.k,rp,rm)
  try:z=retained_cell(max(F(23,10),rm,rp),row,64)
  finally:c.k.general_cell=old
  step=dict(step=j+1,radius_minus=rm,radius_plus=rp,support=proofs)
  if z.get('excluded'):
   step['result']=z;history.append(step);return dict(excluded=True,reason=z['reason'],initial=seed,base=base,history=history)
  ell,A0,A1,vmin,vmax=amplitude(z,rm,rp);l,u,t=z['pl'],z['pu'],z['theta'];d0,Lambda=z['inward_d_max'],z['lambda_max']
  need(d0>0 and Lambda>0,'positive geometry divisors')
  lam=1/(1/Lambda+1/(N*max(A0,A1)*max(u,1-l)*d0))
  theta_up=up(lam/(N*vmin+lam),10**12);need(theta_up>=lam/(N*vmin+lam),'outward harmonic theta')
  z['theta']=min(t,theta_up);need(0<=z['theta']<=t<1,'same-law variance intersection')
  step.update(result=z,lambda_geometry_cap=lam,theta_before=t);history.append(step)
  stable=z['D']==row['D']and z['theta']==row['theta'];row=z
  if stable and replay_plan is None:break
 return dict(excluded=False,initial=seed,base=base,history=history,result=export(row,rm,rp),raw_row=row)

def polymin(a,b,c,H):
 need(H>=0,'closed signed threshold interval');vals=[a,a+b*H+c*H*H]
 if c>0 and 0<-b/(2*c)<H:vals.append(a-b*b/(4*c))
 return min(vals)
def interface(result,target):
 mappings=[];r=result
 need(type(target.get('n'))is int and target['n']==N,'fixed count index31')
 if 'K'in target:need(F(target['K'])==K,'fixed positive excess target')
 need([r['pl'],r['pu']]==[F(x)for x in target['p']],'same closed actual probability panel')
 need(F(1)<=F(target.get('rho_lower','1'))<=r['rho_lo'],'actual lower rho floor domination')
 need('rho_lower'in target and 'rho_upper'in target,'both count rho endpoints required')
 need(r['rho_lo']==RHO_LO and r['rho_hi']<=RHO_HI,'literal branch exported')
 need(r['rho_hi']<=F(target['rho_upper'])<=RHO_HI,'actual upper rho ceiling domination')
 for a,b in(('D','D'),('d0','d0'),('lambda_max','Lambda'),('H_minus','Hminus'),('H_plus','Hplus'),('radius_minus','radius_minus'),('radius_plus','radius_plus'),('outer0','outer0'),('outer1','outer1')):need(r[a]<=F(target[b]),'target upper '+b)
 for a,b in(('charge_b','binary_charge'),('charge_g','gap_charge'),('charge_h','noise_charge')):need(r[a]>=F(target[b]),'target lower '+b)
 for sign in('plus','minus'):
  field='F'+sign;H=F(target['H'+sign])
  for q in r['quadratics']:
   choices=[(polymin(F(t['A'])-q['A'],F(t[field])-q[field],q['Qbudget']-F(t['Qbudget']),H),j)for j,t in enumerate(target['quadratics'])]
   margin,j=max(choices);need(margin>=0,'complete quadratic-envelope domination');mappings.append(dict(sign=sign,target=j,margin=margin))
 return mappings


def acquire(source,replay_plan=None):
 """Full resource route; unrelated domain errors reject."""
 return resource(source,replay_plan=replay_plan)
