"""Literal branch-local scope; all receipts are separate obligations."""
BRANCH=1
PROFILE={'n': 31, 'nmax': 31, 'radius': '13/5', 'cap': '432313/1000000', 'barrier': '0', 'grid': [24, 24, 8, 4], 'p_interval': ['0', '1'], 'invariants': {'rho_lo': '11/10', 'rho': '6/5'}}
THEOREM={'n': 31, 'K': '0', 'rho_interval': ['11/10', '6/5'], 'contact_allowance': '31/100', 'own_cap_strict': '432313/1000000', 'initial_radius': '13/5', 'predecessor': {'n': 30, 'excess_upper': '1/100'}, 'phase_normalization': '15000/30907', 'scalar_quadratic_curvature': '1/10000', 'local_INITIAL_max_per_panel': 2}
SUPPORT_PROFILE={'branch': 1, 'n': 31, 'K': '0', 'allowance_kind': 'SAME_LAW_PREDECESSOR_SCORE_MIN_POSITIVE30_UNIVERSAL', 'scalar_premise': 'C30 < CE + 1/100', 'predecessor_universal_upper': '230879/500000', 'predecessor_universal_formula': 'min(469/1000,(1661/5000)*(1+(429/1000)/rho),(3031/10000)*(1+(323/500)/rho))', 'rho_branch': ['11/10', '6/5'], 'contact_allowance': '31/100', 'R': '13/5', 'rho_upper': '6/5', 'beta_interval': ['-87847516857502139851258773649/250000000000000000000000000000', '87847516857502139851258773649/250000000000000000000000000000'], 'own_cap_upper': '432313/1000000', 'retained_owncap_strict': '432313/1000000'}
SUPPORT_SCOPE='Conditional support-ray theorem for the same actual attained positive-closed sharp31 witness in the literal rho branch. The contact allowance bounds31(C30(P)-C31)_+ from the smaller of the conditional global positive30 ceiling and the published universal predecessor bound at the same rho floor. Both full support rays and all thresholds; not a class-delta statement or a score exclusion.'
SUPPORT_SHA='84b6c9bee72e6a1230f7058afea18270bc23f58625c7eee50f3a033e5ed1bb74'
INITIAL_SHA='760342969ad153f955c049ae1549243366956bc92bf91e5992ee3395d175404a'
CONTRACT_SHA='876454fcd98c2351241892dd0ee87aee0eac1b359e6c5da3c51d61de13643de4'
CONTRACT_SCHEMA='CONDITIONAL_SHARP31_LOCALPATCH_B1_COUNT_CONTRACT_V1'
CONTRACT_FIELDS=['schema', 'scope', 'n', 'K', 'branch', 'rho_interval', 'rows']
SURVIVORS=[35, 36]
BETA='87847516857502139851258773649/250000000000000000000000000000'
SELECTED_PANELS=[35,36]
