"""Same-law phase cap derived from the actual-C charged conserved envelope.

If D>=0 and D<=s*max_j(Aj+Fj*h-Qj*h*h), s>0,Qj>0,h>=0,
then some corner polynomial is nonnegative. Its upper root bounds h.
Negative-discriminant corners cannot do so; other corners contribute the
nonnegative part of their upper root. An outward square root is sufficient.
No corner is selected independently from the actual-law envelope.
"""
from fractions import Fraction as F
import resource31_core as r

def complete_export(source):
 out=dict(source)
 r.need(out['charge_b']>=0 and out['charge_g']>0 and out['charge_h']>0,'same-law nonnegative defect from affine charge')
 proof=dict(normalization=F(15000,997*r.N),old_H_minus=out['H_minus'],old_H_plus=out['H_plus'])
 r.need(proof['normalization']>0 and bool(out['quadratics']),'positive normalization and full corner family')
 for sign in('minus','plus'):
  roots=[]
  for q in out['quadratics']:
   A,b,Q=q['A'],q['F'+sign],q['Qbudget'];r.need(Q>0,'positive charged curvature')
   disc=b*b+4*Q*A
   if disc<0:root=F(0)
   else:
    upper=r.c.k.roots(disc)[1];r.need(upper>=0 and upper*upper>=disc,'outward charged discriminant root')
    root=max(F(0),(b+upper)/(2*Q))
   roots.append(root)
  proof['roots_'+sign]=roots;out['H_'+sign]=min(out['H_'+sign],max(roots))
 out['charged_phase_cap']=proof
 return out
