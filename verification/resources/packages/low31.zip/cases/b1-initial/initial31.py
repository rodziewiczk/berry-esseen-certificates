"""Fixed sharp31_ladder_b1 INITIAL acquisition, conditional on positive30.

Ten deterministic exact guarded updates and a complete final panel export.
Acceptance recomputes the complete object; no FLOAT input selects a bound.
This does not itself exclude the contrary C31 witness.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import copy,json,sys
import initial_local33_charged as initial

HERE=Path(__file__).resolve().parent
P=dict(n=31,nmax=31,radius=F('13/5'),cap=F('432313/1000000'),barrier=F(0),grid=[24,24,8,4],p_interval=[F(0),F(1)],invariants=dict(rho_lo=F('11/10'),rho=F('6/5')))
SOURCE_SHA={
 'initial_local33_charged.py':'4fac5690455115ade7a70389f496f2f6c25f99627366eaf6253416c71aca79a6',
 'kernel.py':'d71f58b7527c3cf6d2146d816e5d124f6f331d1b153e5aaedee5182707647f12',
 'high_window_core.py':'53e181be63852e21abc3f44191cce7237c46d9e9d7868d3b6b94fccb606c7232'}
SUPPORT=HERE/'support/candidate.json'
SUPPORT_SHA='84b6c9bee72e6a1230f7058afea18270bc23f58625c7eee50f3a033e5ed1bb74'
SUPPORT_PROFILE={'branch': 1, 'n': 31, 'K': '0', 'allowance_kind': 'SAME_LAW_PREDECESSOR_SCORE_MIN_POSITIVE30_UNIVERSAL', 'scalar_premise': 'C30 < CE + 1/100', 'predecessor_universal_upper': '230879/500000', 'predecessor_universal_formula': 'min(469/1000,(1661/5000)*(1+(429/1000)/rho),(3031/10000)*(1+(323/500)/rho))', 'rho_branch': ['11/10', '6/5'], 'contact_allowance': '31/100', 'R': '13/5', 'rho_upper': '6/5', 'beta_interval': ['-87847516857502139851258773649/250000000000000000000000000000', '87847516857502139851258773649/250000000000000000000000000000'], 'own_cap_upper': '432313/1000000', 'retained_owncap_strict': '432313/1000000'}
SUPPORT_RECEIPTS={'FIXED_ACCEPTED.json': '2acd52505b792c9c63ef115dba42cd7cb8e2c757425043f3e7ced41da2b0c6ec', 'INDEPENDENT_ACCEPTED.json': 'eff5666d2a21625d517a878d766960822ffb0ec996e6d5cc1f221dfc045ca420'}
SCHEMA='CONDITIONAL_SHARP31_LADDER_B1_INITIAL_V1'

def need(x,msg):
 if not x:raise ValueError(msg)
def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def unique(pairs):
 out={}
 for key,value in pairs:need(key not in out,'duplicate JSON key');out[key]=value
 return out
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v)for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [enc(v)for v in x]
 return x
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def guard(value):return F(-((-value.numerator*10**10)//value.denominator),10**10)+F(1,10000000)
def coverage(z):
 need(type(z['total'])is int and z['total']==18432,'complete signed cover size')
 need(type(z['active'])is int and type(z['excluded'])is int,'integer coverage counts')
 need(z['active']>=0 and z['excluded']>=0 and z['active']+z['excluded']==18432,'complete signed cover accounting')
 need(all(type(x)is int and x>0 for x in z['reasons'].values())and sum(z['reasons'].values())==z['excluded'],'necessary exclusion accounting')
def inputs():
 need({name:digest(HERE/name)for name in SOURCE_SHA}==SOURCE_SHA,'frozen exact INITIAL modules')
 need(digest(SUPPORT)==SUPPORT_SHA,'fixed exact branch support candidate')
 candidate=json.loads(SUPPORT.read_text(),object_pairs_hook=unique)
 need(candidate['schema']=='CONDITIONAL_SHARP31_LADDER_B1_SUPPORT_V1'and same(candidate['profile'],SUPPORT_PROFILE),'literal branch support profile')
 records={}
 for filename,h in SUPPORT_RECEIPTS.items():
  path=HERE/'support'/filename;need(digest(path)==h,'frozen support acceptance receipt')
  record=json.loads(path.read_text(),object_pairs_hook=unique)
  for name,source_hash in record['source_sha256'].items():need(digest(HERE/'support'/name)==source_hash,'frozen support checker closure')
  records[filename]=record
 fixed=records['FIXED_ACCEPTED.json'];ind=records['INDEPENDENT_ACCEPTED.json']
 need(fixed['status']=='PASS_FIXED_CONDITIONAL_SAME_LAW_SUPPORT'and fixed['candidate_sha256']==SUPPORT_SHA and same(fixed['profile'],SUPPORT_PROFILE),'fixed complete support replay')
 need(len(fixed['negative_controls'])==17 and fixed['threshold_cells']==600,'fixed support controls and threshold cover')
 need(ind['status']=='PASS_INDEPENDENT_SAME_LAW_SUPPORT'and len(ind['rows'])==1 and same(ind['rows'][0]['profile'],SUPPORT_PROFILE),'independent same-law support replay')
 need(len(ind['negative_controls'])==3 and ind['rows'][0]['threshold_tails']==2 and ind['rows'][0]['support_rays']==2,'independent complete tails and controls')
 lower=F('11/10');universal=min(F(469,1000),F(1661,5000)*(1+F(429,1000)/lower),F(3031,10000)*(1+F(323,500)/lower))
 need(F('31/100')==min(F(31,100),31*(universal-F(819,2000)))and F('432313/1000000')==min(F(432313,1000000),universal),'exact same-law predecessor allowance and own-cap upper')
 need(same(P['invariants'],dict(rho_lo=F('11/10'),rho=F('6/5'))),'literal actual-law rho branch retained')
 return dict(file=str(SUPPORT),sha256=SUPPORT_SHA,profile=SUPPORT_PROFILE,acceptance_sha256=SUPPORT_RECEIPTS)

def calculate(progress=False):
 support=inputs();stages=[];raw=d=None
 for j in range(10):
  z=initial.stage(P,raw,d);coverage(z)
  nr,nd=guard(z['R']),guard(z['D'])
  if raw is not None:nr,nd=min(raw,nr),min(d,nd)
  need(0<nr<F(2,5)*31 and 0<nd<6,'positive guarded INITIAL domain')
  stages.append(dict(input_raw=None if raw is None else str(raw),input_D=None if d is None else str(d),next_raw=str(nr),next_D=str(nd),cover=enc(z)))
  raw,d=nr,nd
  print('EXACT_SHARP31_LADDER_B1_STAGE',j+1,str(raw),str(d),z['active'],z['excluded'],flush=True)
  if progress:
   (HERE/'CONSTRUCTION_PROGRESS.json').write_text(json.dumps(dict(status='PARTIAL_EXACT_CONSTRUCTION_NOT_ACCEPTED',completed_stages=j+1,stages=stages),indent=2)+'\n')
 need(d<initial.k.SL-1,'every retained rho>=1 cell has a positive central gap')
 export=initial.stage(P,raw,d);coverage(export)
 need(len(export['panels'])==100 and all(row['pl']==F(j,100)and row['pu']==F(j+1,100)for j,row in enumerate(export['panels'])),'complete ordered closed probability panels')
 for row in export['panels']:
  if row['cells']>0:need(F('11/10')<=row['rho']<=F('6/5'),'actual exported nonempty rho ceiling stays within branch')
  else:need(row['cells']==0 and row['raw']==-1 and row['D']==-1,'explicit empty probability panel sentinels')
  row['rho_lo']=F('11/10');row['rho_branch_upper']=F('6/5')
 print('EXACT_SHARP31_LADDER_B1_EXPORT',str(raw),str(d),export['active'],flush=True)
 return dict(schema=SCHEMA,profile=enc(P),predecessor_allowance='31/100',scalar_premise='C_30 < C_E + 1/100',contrary_premise='C_31 >= C_E',support=support,source_sha256=SOURCE_SHA,guard_rule='ceil_to_1e-10_plus_1e-7_then_intersect_previous',stages=stages,final_invariants=dict(raw=str(raw),D=str(d)),export=enc(export),mathematical_scope='Conditional acquisition for the same attained global positive closed maximizer restricted to actual rho in[11/10,6/5], at the retained charged INITIAL enclosure scope. No sharp31 score exclusion or full-rho conclusion is established.')
def main():
 need(__debug__ and not sys.flags.optimize,'assertions enabled')
 need(len(sys.argv)==2 and sys.argv[1]in('construct','accept'),'named fixed action')
 action=sys.argv[1];path=(HERE/'SHARP31_LADDER_B1_INITIAL_PROOF.json')
 if action=='construct':
  need(not path.exists(),'fresh construction destination')
  expected=calculate(progress=True)
  path.write_text(json.dumps(expected,indent=2)+'\n');print('CONSTRUCTED_CONDITIONAL_SHARP31_LADDER_B1_INITIAL',flush=True);return
 obj=json.loads(path.read_text(),object_pairs_hook=unique)
 need(type(obj)is dict and obj.get('schema')==SCHEMA and same(obj.get('profile'),enc(P)),'fixed typed schema/profile')
 expected=calculate()
 def verify(value):need(same(value,expected),'exact complete fixed proof object')
 verify(obj);controls=[]
 def reject(name,change):
  value=copy.deepcopy(obj);change(value)
  try:verify(value)
  except ValueError:controls.append(name);return
  raise ValueError('accepted mutation '+name)
 reject('wrong sharp target',lambda x:x['profile'].update(barrier='1/100'))
 reject('wrong index',lambda x:x['profile'].update(n=32))
 reject('boolean index',lambda x:x['profile'].update(n=True))
 reject('wrong predecessor premise',lambda x:x.update(scalar_premise='C_30 < C_E'))
 reject('wrong support selection',lambda x:x['support'].update(sha256='0'*64))
 reject('discarded rho floor',lambda x:x['profile']['invariants'].pop('rho_lo'))
 reject('wrong rho ceiling',lambda x:x['profile']['invariants'].update(rho='2'))
 reject('missing panel rho branch',lambda x:x['export']['panels'][0].pop('rho_lo'))
 reject('wrong allowance',lambda x:x.update(predecessor_allowance='0'))
 reject('missing stage',lambda x:x['stages'].pop())
 reject('duplicate stage',lambda x:x['stages'].append(x['stages'][0]))
 reject('reordered stages',lambda x:x['stages'].reverse())
 reject('false next guard',lambda x:x['stages'][0].update(next_D='1/10'))
 reject('noncanonical guard',lambda x:x['stages'][0].update(next_D=x['stages'][0]['next_D']+' '))
 reject('boolean covered count',lambda x:x['stages'][0]['cover'].update(total=True))
 reject('corrupt final gap',lambda x:x['final_invariants'].update(D='3'))
 reject('missing panel',lambda x:x['export']['panels'].pop())
 reject('reordered panels',lambda x:x['export']['panels'].reverse())
 reject('extra field',lambda x:x.update(unproved=True))
 reject('missing dependency',lambda x:x['source_sha256'].pop('kernel.py'))
 try:json.loads('{"x":0,"x":1}',object_pairs_hook=unique)
 except ValueError:controls.append('duplicate JSON key')
 else:raise ValueError('duplicate JSON key accepted')
 result=dict(status='FRESH_EXACT_CONDITIONAL_SHARP31_LADDER_B1_INITIAL_PASS',mathematical_scope=expected['mathematical_scope'],scalar_premise=expected['scalar_premise'],profile=expected['profile'],support=expected['support'],source_sha256=SOURCE_SHA,proof_sha256=digest(path),checker_sha256=digest(__file__),runtime=dict(python=sys.version,implementation=sys.implementation.name,optimize=sys.flags.optimize),signed_rectangles=11*18432,probability_panels=100,final_invariants=expected['final_invariants'],fixed_expected_object_controls=controls)
 out=(HERE/'SHARP31_LADDER_B1_INITIAL_ACCEPTED.json');need(not out.exists(),'fresh acceptance destination')
 out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':main()
