"""Fixed sharp31 resource protocol for the literal rho branch[1,11/10].
The positive30 scalar theorem, retained owncap31, accepted global INITIAL,
and conditional count theorem remain explicit separate dependencies.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
import resource31_core as r

PROFILE=dict(n=31,nmax=31,radius='47/20',cap='432313/1000000',barrier='0',grid=[24,24,8,4],p_interval=['0','1'],invariants=dict(rho_lo='1',rho='11/10'))
CONTRACT_SHA='3ffb3863663992930b88a3ef7bfcea22b9bd34e3dbae8f5b272854a4f181f5ef'
SUPPORT_SHA='614d0bfe388e916ab5de8890f5c505bb4bbf1efba5b24308ebbc666103900759'
BETA='253256785899779989718153264423/1000000000000000000000000000000'
SUPPORT_PROFILE=dict(n=31,K='0',allowance_kind='SAME_LAW_PREDECESSOR_SCORE_FROM_POSITIVE30',scalar_premise='C30 < CE + 1/100',rho_branch=['1','11/10'],contact_allowance='31/100',R='47/20',rho_upper='11/10',beta_interval=['-'+BETA,BETA],own_cap_strict='432313/1000000')
SCHEMA='SHARP31_RHO_B0_RESOURCE_V3'
THEOREM=dict(n=31,K='0',rho_interval=['1','11/10'],contact_allowance='31/100',own_cap_strict='432313/1000000',initial_radius='47/20',predecessor=dict(n=30,excess_upper='1/100'),phase_normalization='15000/30907',scalar_quadratic_curvature='1/10000')
SOURCES=('resource31_core.py','candidate_charged_score_v2.py','contracted_kernel.py','kernel.py','high_window_core.py','paired_extended.py','signed_variance_resource.py','geometric_moment_both.py','corrected_phase_callback_extended.py','direct_gaussian_support.py','finite_binomial_core.py','small_index_support.py','heat_support50.py','protocol31_v3.py')

def need(x,s):
 if not x:raise ValueError(s)
def sha(p):return sha256(Path(p).read_bytes()).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read(p):return json.loads(Path(p).read_bytes(),object_pairs_hook=unique)
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def fields(o,names):need(type(o)is dict and set(o)==set(names),'exact object fields')
def rat(x):
 need(type(x)is str,'rational string');v=F(x);need(str(v)==x,'canonical rational');return v
def initial_support():
 obj=read('support31.json');need(sha('support31.json')==SUPPORT_SHA,'literal accepted branch support bytes')
 fields(obj,('schema','profile','proof'))
 need(obj['schema']=='CONDITIONAL_SHARP31_LADDER_B0_SUPPORT_V1'and same(obj['profile'],SUPPORT_PROFILE),'same branch support theorem')
 actual=r.ds.target(r.N,r.K,r.R,r.Q,rho=r.RHO_HI,beta_lower=-F(BETA),beta_upper=F(BETA))
 scope='Conditional support-ray theorem for the same actual attained positive-closed sharp31 witness with rho in[1,11/10] and predecessor-score contact allowance31/100, licensed if C30<CE+1/100. Both full support rays and all thresholds; not a class-delta statement or a score exclusion.'
 need(obj['proof']['scope']==scope,'literal supplied support scope annotation')
 # The two retained DS copies have identical arithmetic and differ only
 # in explicit class-vs-same-law metadata. The positive30 class ceiling
 # licenses both allowances here. Translate only these checked aliases;
 # every numerical proof field is still compared with strict equality.
 need(actual['schema']=='DIRECT_SAME_LAW_CONTACT_SUPPORT_DISCOVERY_V1'and actual['q_contact']=='31/100','literal replay support naming')
 need(obj['proof']['schema']=='DIRECT_FIXED_INDEX_GAUSSIAN_SUPPORT_V1'and obj['proof']['q']=='31/100','literal supplied support naming')
 actual['schema']='DIRECT_FIXED_INDEX_GAUSSIAN_SUPPORT_V1';actual['q']=actual.pop('q_contact')
 actual['scope']=scope
 need(same(obj['proof'],actual),'complete branch support arithmetic replay')
 return actual
def fixed_inputs():
 need(__debug__ and not sys.flags.optimize,'ordinary Python assertions enabled')
 need(sha('contract31.json')==CONTRACT_SHA,'fixed exact count guard bytes')
 target=read('contract31.json')
 fields(target,('schema','n','K','branch','rho_interval','contact_q','global_radius','scalar_premise','rows','premise'))
 need(target['schema']=='CONDITIONAL_SHARP31_LADDER_BRANCH0_V1','named conditional count theorem')
 need(type(target['n'])is int and target['n']==31 and rat(target['K'])==0 and type(target['branch'])is int and target['branch']==0,'literal index, target and branch')
 need(target['rho_interval']==['1','11/10']and target['contact_q']=='31/100'and target['global_radius']=='47/20'and target['scalar_premise']=='C30 < CE + 1/100','count premise join')
 need(type(target['rows'])is list and len(target['rows'])==14,'fourteen exact count panels')
 for i,z in enumerate(target['rows'],36):
  need(type(z['index'])is int and z['index']==i and type(z['n'])is int and z['n']==31,'ordered closed count panels')
  need(z['p']==[str(F(i,100)),str(F(i+1,100))],'literal count probability interval')
  need(rat(z['rho_lower'])==1 and 1<=rat(z['rho_upper'])<=r.RHO_HI,'both count rho endpoints')
 initial=read('initial31_proof.json')
 need(initial['schema']=='CONDITIONAL_SHARP31_LADDER_B0_INITIAL_V1'and same(initial['profile'],PROFILE),'literal global INITIAL scope including branch')
 need(initial['scalar_premise']=='C_30 < C_E + 1/100'and initial['contrary_premise']=='C_31 >= C_E'and initial['predecessor_allowance']=='31/100','same contrary law and predecessor')
 need(initial['support']['sha256']==SUPPORT_SHA and same(initial['support']['profile'],SUPPORT_PROFILE),'same INITIAL support object')
 need(type(initial['stages'])is list and len(initial['stages'])==10,'ten global INITIAL updates')
 last=initial['final_invariants'];fields(last,('raw','D'))
 need(same(last,dict(raw=initial['stages'][-1]['next_raw'],D=initial['stages'][-1]['next_D'])),'guard/export identity')
 need(0<rat(last['D'])<r.c.k.SL-1 and 0<rat(last['raw'])<F(62,5),'uniform gap and density domain')
 panels=initial['export']['panels'];need(type(panels)is list and len(panels)==100,'complete global p cover')
 for i,z in enumerate(panels):
  need(type(z)is dict and type(z['cells'])is int and z['cells']>=0,'typed INITIAL incidence')
  need(rat(z['pl'])==F(i,100)and rat(z['pu'])==F(i+1,100),'ordered closed INITIAL panel')
  for key in('raw','D','theta','rho','beta','H','A','B','mean_lo','mean_hi','gamma_lo','gamma_hi','M','eta','beta_lo','rho_lo','rho_branch_upper'):rat(z[key])
  need(z['rho_lo']=='1'and z['rho_branch_upper']=='11/10'and 1<=F(z['rho'])<=r.RHO_HI,'literal rho endpoints in every source panel')
 return initial,{z['index']:z for z in target['rows']}
def bindings():return {p:sha(p)for p in SOURCES+('initial31_proof.json','contract31.json','support31.json')}
def shape(obj):
 fields(obj,('schema','profile','theorem','input_sha256','initial_support','rows'))
 need(obj['schema']==SCHEMA and same(obj['profile'],PROFILE)and same(obj['theorem'],THEOREM),'fixed conditional branch theorem')
 need(same(obj['input_sha256'],bindings()),'complete source/input closure')
 need(type(obj['rows'])is list and len(obj['rows'])==100,'one hundred probability panels')
 for i,z in enumerate(obj['rows']):
  fields(z,('index','plan','result','interface'))
  need(type(z['index'])is int and z['index']==i,'strict closed panel order')
  need(type(z['plan'])is list and len(z['plan'])<=5,'at most five fixed resource refinements')
  rm=rp=r.R
  for h in z['plan']:
   fields(h,('radius_minus','radius_plus'));nm,np=rat(h['radius_minus']),rat(h['radius_plus'])
   need(0<nm<=rm and 0<np<=rp,'nested actual support');rm,rp=nm,np
  need(type(z['result'])is dict and type(z['interface'])is list,'typed exact result')
def one(i,source,guard,plan=None):
 z=r.acquire(r.dec(source),replay_plan=plan)
 chosen=[dict(radius_minus=h['radius_minus'],radius_plus=h['radius_plus'])for h in z.get('history',[])]
 chosen=r.enc(chosen)
 if plan is not None:need(same(plan,chosen),'full selected plan consumed')
 interface=[]
 if not z.get('excluded'):
  need(i in guard,'every survivor has a fixed count guard')
  interface=r.enc(r.interface(z['result'],guard[i]))
 return dict(index=i,plan=chosen,result=r.enc(z),interface=interface)
def verify(obj,initial,guard,emit=False):
 shape(obj);support=initial_support();need(same(obj['initial_support'],support),'same full initial support proof')
 totals=dict(probability_panels=100,resource_refinements=0,support_H_cells=support['gaussian']['cells'],signed_support_rays=2,signed_quadratic_interfaces=0,surviving_panels=[],excluded_panels=[])
 for i,(source,witness)in enumerate(zip(initial['export']['panels'],obj['rows'])):
  actual=one(i,source,guard,witness['plan']);need(same(actual,witness),'full fixed resource and interface replay')
  z=actual['result'];totals['excluded_panels'if z.get('excluded')else'surviving_panels'].append(i)
  for h in z.get('history',[]):
   totals['resource_refinements']+=1
   for s in h['support']:totals['support_H_cells']+=s['gaussian']['cells'];totals['signed_support_rays']+=1
  totals['signed_quadratic_interfaces']+=len(actual['interface'])
  if emit:print('ACCEPTED_SHARP31_B0_RESOURCE',i,z.get('reason','fixed count target acquired'),flush=True)
 need(totals['surviving_panels']==list(range(36,50)),'exact fourteen-panel count interface')
 return totals
