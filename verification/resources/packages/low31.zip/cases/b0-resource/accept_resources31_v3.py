"""Fresh exact branch resource replay, followed by malformed-object controls."""
from pathlib import Path
import copy,json,sys
import protocol31_v3 as p

def main():
 p.need(len(sys.argv)==1,'fixed acceptance invocation');sys.set_int_max_str_digits(0)
 initial,guard=p.fixed_inputs();obj=p.read('resources31_proof.json')
 report=p.verify(obj,initial,guard,True);accepted=copy.deepcopy(obj);controls=[]
 def fixed(value):p.shape(value);p.need(p.same(value,accepted),'identity with freshly replayed proof')
 def reject(name,change):
  value=copy.deepcopy(obj);change(value);p.need(not p.same(value,obj),'effective mutation')
  try:fixed(value)
  except(ValueError,AssertionError,TypeError,KeyError,ZeroDivisionError):controls.append(name);return
  raise ValueError('accepted malformed branch proof: '+name)
 reject('wrong theorem',lambda x:x.update(schema='UNPROVED_FULL_SHARP31'))
 reject('wrong index',lambda x:x['profile'].update(n=30))
 reject('wrong sharp target',lambda x:x['profile'].update(barrier='1/100'))
 reject('wrong allowance',lambda x:x['theorem'].update(contact_allowance='0'))
 reject('weaker unproved owncap',lambda x:x['profile'].update(cap='469/1000'))
 reject('changed branch floor',lambda x:x['profile']['invariants'].update(rho_lo='11/10'))
 reject('discarded branch ceiling',lambda x:x['profile']['invariants'].pop('rho'))
 reject('wrong initial radius',lambda x:x['profile'].update(radius='2'))
 reject('missing p panel',lambda x:x['rows'].pop())
 reject('duplicated p panel',lambda x:x['rows'].__setitem__(37,x['rows'][36]))
 reject('reordered p panels',lambda x:x['rows'].reverse())
 reject('boolean p index',lambda x:x['rows'][0].update(index=False))
 reject('missing arithmetic module',lambda x:x['input_sha256'].pop('contracted_kernel.py'))
 reject('changed INITIAL bytes',lambda x:x['input_sha256'].__setitem__('initial31_proof.json','0'*64))
 reject('changed support bytes',lambda x:x['input_sha256'].__setitem__('support31.json','0'*64))
 reject('changed count guard',lambda x:x['input_sha256'].__setitem__('contract31.json','0'*64))
 reject('unproved success field',lambda x:x.update(sharp31=True))
 reject('false survivor exclusion',lambda x:x['rows'][36]['result'].update(excluded=True))
 reject('false final defect',lambda x:x['rows'][36]['result']['result'].update(D='0'))
 reject('discarded actual rho floor',lambda x:x['rows'][36]['result']['result'].pop('rho_lo'))
 reject('false actual rho upper',lambda x:x['rows'][36]['result']['result'].update(rho_hi='1'))
 reject('omitted signed interface',lambda x:x['rows'][36]['interface'].pop())
 reject('missing selected support step',lambda x:x['rows'][36]['plan'].pop())
 reject('negative scalar curvature',lambda x:x['rows'][49]['result']['result']['quadratics'][0].update(Qbudget='-1/10000'))
 reject('lost p one-half endpoint',lambda x:x['rows'][49]['result']['result'].update(pu='499/1000'))
 try:json.loads('{"rows":[],"rows":[]}',object_pairs_hook=p.unique)
 except ValueError:controls.append('duplicate JSON key')
 else:raise ValueError('duplicate JSON key accepted')
 report.update(schema='SHARP31_RHO_B0_RESOURCE_ACCEPTANCE_V3',status='PASS_SHARP31_B0_RESOURCES',
  mathematical_status='Conditional same-law branch acquisition, rho in[1,11/10], at the stated scalar/owncap/INITIAL premises. No full-rho sharp31 conclusion.',
  execution_status='Fresh complete rational support/resource/interface replay. Subsequent mutation controls test fixed-object integrity.',
  profile=p.PROFILE,theorem=p.THEOREM,resource_sha256=p.sha('resources31_proof.json'),input_sha256=p.bindings(),negative_controls=controls,acceptor_sha256=p.sha(Path(__file__).name))
 out=Path('RESOURCES31_B0_ACCEPTED.json');p.need(not out.exists(),'fresh branch receipt path')
 out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
