"""Fixed-index direct Gaussian support certificate, all thresholds and full rays.
The new derivative-in-support lemma reduces the ray to a single Gaussian H line.
All numerical operations below use integer/rational outward enclosures.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt
from hashlib import sha256
import json
import finite_binomial_core as g
from small_index_support import constants
S=g.S;Z=g.Z

def need(x,msg):
 if not x:raise ValueError(msg)
def plus(x,y):return x[0]+y[0],x[1]+y[1]
def scale(x,c):return(min(x[0]*c,x[1]*c),max(x[0]*c,x[1]*c))
def product(x,y):
 z=[a*b for a in x for b in y];return min(z),max(z)
def root(x):return g.root(F(x),10**15)
def divroot(a,n):
 lo,hi=root(n);return min(a/lo,a/hi),max(a/lo,a/hi)
@lru_cache(None)
def exponential(q):
 """Outward interval for exp(-q), q>=0, using degree23 Taylor then squaring."""
 need(q>=0,'exponential nonnegative argument');num,den=q.numerator,q.denominator;j=0
 while num>den:den*=2;j+=1
 lo=hi=S;sl=sh=S
 for k in range(1,24):
  lo=lo*num//(den*k);hi=g.ceildiv(hi*num,den*k)
  if k%2:sl-=hi;sh-=lo
  else:sl+=lo;sh+=hi
 next_hi=g.ceildiv(hi*num,den*24);sh+=next_hi
 need(0<=sl<=sh<=S,'alternating exponential bounds')
 for _ in range(j):sl=sl*sl//S;sh=g.ceildiv(sh*sh,S)
 return F(sl,S),F(sh,S)
def phi_at(x):return product((g.PHI_LO,g.PHI_HI),exponential(x*x/2))
def phi_interval(a,b):
 need(a<=b,'ordered normal density argument');small=F(0)if a<=0<=b else min(abs(a),abs(b));large=max(abs(a),abs(b))
 return phi_at(large)[0],phi_at(small)[1]
g.positive_cdf=lru_cache(None)(g.positive_cdf)
def cdf_grid(k):
 if k<0:
  a,b=cdf_grid(-k);return 1-b,1-a
 if k>=5*Z:return 1-g.TAIL,F(1)
 a,b=g.positive_cdf(k);return F(a,S),F(b,S)
def cdf_interval(a,b):
 need(a<=b,'ordered CDF argument');lo=a.numerator*Z//a.denominator;hi=g.ceildiv(b.numerator*Z,b.denominator)
 return cdf_grid(lo)[0],cdf_grid(hi)[1]

def gaussian_point(n,H,R):
 nr=root(n);sr=root(F(n,n-1));za,zb=divroot(H,n);aa,ab=divroot(H-R,n-1)
 ph=phi_interval(za,zb);pha=phi_interval(aa,ab);a,b=cdf_interval(aa,ab);c,d=cdf_interval(za,zb)
 G=plus(product((n*nr[0],n*nr[1]),(a-d,b-c)),scale(ph,n*R+H*(R*R-1)/2))
 derivative=plus(product((n*sr[0],n*sr[1]),pha),scale(ph,-n-R*H+(R*R-1)*(1-H*H/n)/2))
 return G,derivative

@lru_cache(None)
def gaussian_line(n,R,mesh=10):
 need(type(n)is int and n>=2 and R>=1 and type(mesh)is int and mesh>=1,'fixed Gaussian line domain')
 nl,nu=root(n);_,vu=root(n-1)
 H0=max((R+5*vu).numerator//(R+5*vu).denominator+1,(5*nu).numerator//(5*nu).denominator+1)
 H0=F(H0);need(H0>=5*nu and H0-R>=5*vu,'complete threshold-tail coverage')
 curvature=nu*(F(n,n-1)+1)/4+F(2,5)*R+F(2,5)*abs(R*R-1)/nl
 tail=n*nu*g.TAIL+(n*R+H0*abs(R*R-1)/2)*phi_interval(*divroot(H0,n))[1]
 peak_plus=peak_minus=tail;where_plus=where_minus='threshold tails';digest=sha256();cells=2*int(H0)*mesh
 for j in range(cells):
  lo=-H0+F(j,mesh);hi=lo+F(1,mesh);mid=(lo+hi)/2;w=(hi-lo)/2
  G,D=gaussian_point(n,mid,R);err=max(abs(D[0]),abs(D[1]))*w+curvature*w*w/2
  plus_bound=G[1]+err;minus_bound=-G[0]+err
  if plus_bound>peak_plus:peak_plus=plus_bound;where_plus=[str(lo),str(hi)]
  if minus_bound>peak_minus:peak_minus=minus_bound;where_minus=[str(lo),str(hi)]
  digest.update(('|'.join(map(str,(lo,hi,G[0],G[1],D[0],D[1],err)))+'\n').encode())
 return dict(n=n,radius=str(R),mesh=mesh,H0=str(H0),cells=cells,curvature=str(curvature),tail_upper=str(tail),gaussian_plus_upper=str(peak_plus),gaussian_minus_upper=str(peak_minus),where_plus=where_plus,where_minus=where_minus,line_sha256=digest.hexdigest())

def target(n,K,R,q,sign=0,rho=None,beta_lower=None,beta_upper=None,mesh=10):
 need(type(n)is int and n>=2 and K>=0 and R>=1 and q>=0 and type(sign)is int and sign in(-1,0,1),'fixed support scope')
 c,r,b,ell,Sup,e=constants(n,K)
 if rho is not None:need(F(1)<=rho<=r,'acquired moment cap improves published cap');r=rho
 bl=-b if beta_lower is None else beta_lower;bu=b if beta_upper is None else beta_upper
 need(-1<bl<=bu<1,'ordered signed beta range')
 line=gaussian_line(n,R,mesh);rows=[]
 for sig in([-1,1]if sign==0 else[sign]):
  B=bu if sig==1 else-bl
  Q=-R**3+F(3,2)*r*R*R+3*B*R+r*e
  Q1=-3*R*R+3*r*R+3*B;Q2=-6*R+3*r
  L=F(2,5)*(R*R/2+F(1,2)+e)+c*Q1
  L1=F(2,5)*R+c*(-6*R+3*r)
  need(Q<0 and Q1<0 and Q2<0,'negative C coefficient on complete support ray')
  need(L<0 and L1<0 and F(1,5)-3*c<0,'strict contact decrease on complete support ray')
  G=F(line['gaussian_plus_upper'if sig==1 else'gaussian_minus_upper'])
  contact=G+c*Q+r*Sup*q;need(contact<0,('direct contact exclusion fails',n,str(K),str(R),str(q),sig,str(contact)))
  rows.append(dict(sign=sig,beta_star=str(B),coefficient_at_R=str(Q),contact_derivative_at_R=str(L),contact_derivative_slope_at_R=str(L1),contact_upper=str(contact)))
 return dict(schema='DIRECT_SAME_LAW_CONTACT_SUPPORT_DISCOVERY_V1',n=n,K=str(K),q_contact=str(q),radius=str(R),support_sign=sign,score_lower=str(c),rho_upper=str(r),beta_interval=[str(bl),str(bu)],e_upper=str(e),scale_upper=str(Sup),gaussian=line,ray_rows=rows,scope='Attained positive closed maximizer at the stated fixed index, C_n>=CE+K/n and n(C_{n-1}(P)-C_n)_+<=q, with any additionally declared same-law moment caps. Excludes every support point on the specified full ray(s), uniformly in H. This is not a score exclusion.')
