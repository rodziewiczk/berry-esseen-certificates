"""NEW isolated two-probability-half moment consequences; discovery scope.
The formula uses both endpoint extrema of pq and includes1/4 at the seam.
Proof is Lemma res:three-uses in the reviewed consolidated resource chapter.

New signed moment consequences of exact variance-displacement geometry.
No contact/endpoint premises acquired here. This does NOT replace the original
joint gap-plus-variance budget; it bounds moments after spending the gap cost.
"""
def install(k,radius_plus,radius_minus):
 old=k.general_cell
 def general_cell(d,l,u,glob,steps=8):
  z=old(d,l,u,glob,steps)
  if z is None:return z
  k.need(0<l<u<1,'new two-half moment domain')
  F=k.F;lo=lambda x:k.roots(x)[0];hi=lambda x:k.roots(x)[1]
  t=z['theta'];vp=hi((1-l)/l);vm=hi(u/(1-u));vmin=min(l*(1-l),u*(1-u));vmax=max(l*(1-l),u*(1-u),k.F(1,4) if l<=k.F(1,2)<=u else k.F(0))
  dist=max(F(0),(4-k.SU)/2-u,l-(4-k.SL)/2);binary=(6+2*k.SL)*lo((1-t)**3)/hi(vmax)*dist**2;residual=d-binary
  if residual<0:return None
  ell=lo((1-t)/vmax);A0=radius_minus/ell-l;A1=radius_plus/ell-(1-u);S=z['al']+z['bl']
  k.need(A0>0 and A1>0,'geometric sign amplitude divisors')
  kp=3*(k.SL+1)*z['bl']+6*S*(1-u)/A1
  km=3*(k.SL+3)*z['al']+6*S*l/A0
  bj={3:hi((1-2*vmin)**2/vmin),4:1/vmin-3,5:(1-4*vmin+2*vmin*vmin)/(vmin*lo(vmin))}
  def L(j,v,r):
   if j==3:return r+2*v
   if j==4:return r*r+2*r*v+3*v*v
   return r**3+2*r*r*v+3*r*v*v+4*v**3
  improved={}
  for j in(3,4,5):
   slope=F(j,2)if t==0 else ((2-t)if j==4 else max(F(0),(1-hi((1-t)**j))/t))
   improved[j]=k.up(bj[j]+residual*max(F(0),(L(j,vp,radius_plus)-slope*bj[j])/kp,(L(j,vm,radius_minus)-slope*bj[j])/km))
  z['Rho']=min(z['Rho'],improved[3]);z['M']=min(z['M'],improved[4],k.up(1+k.K4*(z['Rho']-1)))
  z['eta']=min(z['eta'],improved[5],k.RADIUS*z['M']);z['g']=min(z['g'],hi(z['M']-1))
  z['uhi']=min(z['uhi'],z['j0']+k.RADIUS*z['douter']/4+(z['M']-3)/6)
  z['geometric_moments']=dict(residual=residual,kp=kp,km=km,A0=A0,A1=A1,improved=improved)
  k.need(z['M']>=1 and z['ulo']<=z['uhi'],'geometric moment intersection')
  return z
 k.general_cell=general_cell
 return old
