#!/usr/bin/env python3
"""FLOAT DISCOVERY: new actual-score charged single-index candidate. Formula audit and fixed-profile acceptance are separate obligations; this is not LOCAL42.
This module uses the separately named contracted-radius analytic domain.

No input theorem is silently acquired here: a named acceptor must bind the
initial moment/defect table and every support contraction used between runs.
"""
from fractions import Fraction as F
import contracted_kernel as k
import high_window_core
high_window_core.install(k)
import paired_extended
paired_extended.install(k)
import signed_variance_resource
signed_variance_resource.install(k)
def lo(x):return k.roots(x)[0]
def hi(x):return k.roots(x)[1]
def init(radius):
 k.RADIUS=radius;k.K4=(radius+1)**2/(radius+F(1,2));k.K5=(radius**3+2*radius**2+3*radius+F(3,2))/(radius+F(1,2));k.constants()
def variance_resource(d,p):
 l,u,t=p['pl'],p['pu'],p['theta'];pq=max(l*(1-l),u*(1-u),F(1,4)if l<=F(1,2)<=u else F(0))
 dist=max(F(0),(4-k.SU)/2-u,l-(4-k.SL)/2)
 binary=(6+2*k.SL)*lo((1-t)**3)/hi(pq)*dist*dist
 residual=d-binary
 if residual<0:return None
 coefficient=min(3*(k.SL+1)*p['bl'],3*(k.SL+3)*p['al'])
 k.need(coefficient>0,'weighted variance divisor')
 return dict(residual=residual,theta_weighted=residual/coefficient,pq=pq)
def cell(n,radius,cap,row,steps=24,barrier=F(0)):
 sf=F('.4095')+barrier/n
 init(radius);l,u,raw,d,theta=(row[x]for x in('pl','pu','raw','D','theta'))
 k.need(type(n)is int and 20<=n<=40 and 0<l<u<1,'BELOW40_FIXED_FLOAT_CANDIDATE index and p scope')
 k.need(0<raw<F(2,5)*n and 0<d<2 and 0<=theta<1,'licensed initial weighted defect and unweighted variance')
 ml=lo((1-theta)*min(l*(1-l),u*(1-u)));gap=lo(2-d);k.need(ml>0 and gap>0,'initial shared shift divisor')
 shift=d/(6*ml*gap);al=lo((1-theta)*l/(1-l))-shift;bl=lo((1-theta)*(1-u)/u)-shift
 al=max(al,row.get('A',al));bl=max(bl,row.get('B',bl))
 k.need(al>0 and bl>0,'retained initial actual gap endpoint floors')
 glob=dict(al=al,bl=bl,theta=theta,pl=l,pu=u);trace=[]
 for j in range(steps):
  z=k.general_cell(d,l,u,glob,steps=24)
  if z is None:return dict(excluded=True,reason='binary asymmetry exceeds weighted defect',stage=j)
  z['Rho']=min(z['Rho'],row['rho']);z['Beta']=min(z['Beta'],row['beta']);z['M']=min(z['M'],row.get('M',z['M']),1+k.K4*(z['Rho']-1));z['eta']=min(z['eta'],row.get('eta',z['eta']));z['g']=min(z['g'],hi(z['M']-1))
  z['rho_lo']=max(F(1),row.get('rho_lo',F(1)))
  gl_branch=max(F(0),k.SL*z['rho_lo']-3-d)
  if z['rho_lo']>z['Rho'] or z['rho_lo']**2>z['M'] or gl_branch>z['g'] or gl_branch**2>z['M']-1:
   raise k.EmptyMomentBranch(dict(rho_lo=z['rho_lo'],rho_hi=z['Rho'],M=z['M'],g=z['g'],gamma_lo=gl_branch))
  cc=min(cap,F('.40974')+raw/n)
  rr=max(k.general_envelope(n,d,raw,z,cc,score_floor=sf));bb=max(k.general_envelope(n,d,raw,z,cc,score_floor=sf,phase_rebate=True,barrier=barrier))
  paired=k.paired_eligible(z,d)
  if paired:
   quad=k.late_envelope(n,d,raw,z,cc);rmin=k.paired(n,z,d)[3]
   rr=min(rr,max(v[3]for v in quad));budgets=[]
   for (A,b,q,_,_),rho in zip(quad,(rmin,z['Rho'],rmin,z['Rho'])):
    extra=(1-F(5,2)*raw/n)*(F('.4095')*rho-d/15)/2
    k.need(extra>0 and q+extra>0,'coherent conserved phase price')
    budgets.append(A+b*b/(4*(q+extra))-barrier*rho)
   bb=min(bb,max(budgets))
   # New actual-score charge: split C at cE+K/n before corner interpolation.
   # These are envelopes for the same actual rho and C, not independent maxima.
   C0=F('.4095');C1=cc;split=F('.40974')+barrier/n
   k.need(C1>C0,'ordered actual-score interpolation interval')
   corners=sorted(set([C0,C1]+([split]if C0<split<C1 else [])))
   charged=[]
   for cv in corners:
    weight=(cv-C0)/(C1-C0)
    for ir,rho in enumerate((rmin,z['Rho'])):
     low,high=quad[ir],quad[ir+2]
     A,b,q=[(1-weight)*low[t]+weight*high[t]for t in range(3)]
     extra=(1-F(5,2)*raw/n)*(F('.4095')*rho-d/15)/2
     charge=max(barrier,n*(cv-F('.40974')))*rho
     charged.append(A-charge+b*b/(4*(q+extra)))
   bb=min(bb,max(charged))
  if bb<0:return dict(excluded=True,reason='negative conserved budget',stage=j)
  raw=min(raw,k.up(rr,10**8));d=min(d,k.up(F(15000,997*n)*bb,10**8))
  glob=dict(al=z['al'],bl=z['bl'],theta=z['theta'],pl=l,pu=u)
  trace.append(dict(raw=raw,D=d,theta=z['theta'],A=z['al'],B=z['bl'],rho=z['Rho'],beta=z['Beta'],M=z['M'],g=z['g'],paired=paired))
 resources=variance_resource(d,z)
 if resources is None:return dict(excluded=True,reason='final binary asymmetry exceeds weighted defect',stage=steps)
 t=z['theta'];result=dict(rho_lo=row.get('rho_lo',F(1)),pl=l,pu=u,raw=raw,D=d,theta=t,rho=z['Rho'],beta=z['Beta'],beta_lo=1-2*u-2*(1-u)*t,A=z['al'],B=z['bl'],trace=trace)
 result.update(resources);result['lambda_max']=n*resources['pq']*resources['theta_weighted']/(1-t)
 result['inward_d_max']=resources['residual']/(6*(1-t)*(z['al']+z['bl']))
 # Raw/phase-quadratic exports require the independently checked paired scope.
 if paired:
  cc=min(cap,F('.40974')+raw/n);qr=k.late_envelope(n,d,raw,z,cc);lc,lh,l2,rmin=k.paired(n,z,d)
  slope=F(212,333)*lh;phi=k.PHI*(1-F(5,2)*raw/n);quads=[]
  for j,((A,_,q,_,_),rho)in enumerate(zip(qr,(rmin,z['Rho'],rmin,z['Rho']))):
   c=F('.4095')if j<2 else cc
   linear=[c*kk+ph*uu for kk in(z['klo'],z['khi'])for ph in(phi,F(2,5))for uu in(z['ulo'],z['uhi'])]
   fp=max(linear)+slope;fm=-min(linear)+slope;qb=q+(1-F(5,2)*raw/n)*(F('.4095')*rho-d/15)/2
   k.need(A>0 and q>0 and qb>0,'exported positive phase quadratic constant and curvature')
   hp=(fp+hi(fp*fp+4*qb*A))/(2*qb);hm=(fm+hi(fm*fm+4*qb*A))/(2*qb)
   quads.append(dict(C=c,rho=rho,A=A,Fplus=fp,Fminus=fm,Qraw=q,Qbudget=qb,Hplus=hp,Hminus=hm))
  result['quadratics']=quads;result['Hplus']=max(q['Hplus']for q in quads);result['Hminus']=max(q['Hminus']for q in quads)
 return result
