#!/usr/bin/env python3
"""New EXTENDED_PAIRED3 conditional transfer: M<3, g^2<2, actual rho lower bound.

See paired_extension.tex. This does not acquire its bounded-support premises.
"""
def install(k):
 def paired(n,p,d):
  F=k.F;SL=k.SL;RADIUS=k.RADIUS;need=k.need;roots=k.roots;exphi=k.exphi
  M,g=p['M'],p['g'];u=p['pu'];s=u*(1-u)
  need(0<p['pl']<u<F(1,2),'paired signed probability scope')
  ss=p['pl']*(1-p['pl']);rBmax=roots((1-2*ss)**2/ss)[1]
  rbmin=roots((1-2*s)**2/s)[0]
  # Actual same-law conditional cubic lower bound, with theta<=Theta.
  reserve=max(F(0),F(3,2)*rBmax-3*min(p['al'],p['bl']))
  rmin=max(F(1),p.get('rho_lo',F(1)),rbmin-reserve*p['theta'])
  gl=max(F(0),SL*rmin-3-d)
  gamma_conditional=roots((1-p['theta'])**3*(1-2*u)**2/(u*(1-u)))[0]-(RADIUS+2*roots(u/(1-u))[1])*p['theta']
  gl=max(gl,gamma_conditional)
  need(1<=M<3 and 0<=gl<=g and g*g<2 and M-1-gl*gl>=0,'EXTENDED actual moment domain')
  need(RADIUS>2*g,'SPERNER_FEEDBACK47 signed Pearson rectangle radius')
  tstar=min(g,(10-2*M)/(2*(RADIUS-g)))
  sig=RADIUS*(M-1)+(10-2*M)*tstar-(RADIUS-g)*tstar*tstar
  Z=min(sig,p['eta']+10*g)/120
  zl=max(-Z,(8*gl-gl**3-(RADIUS+2*gl)*(M-1-gl*gl))/120);zu=Z;cl=(3-M)*gl/144;cu=(2-gl*gl)*g/144
  if 3*g*g<=2:cu=min(cu,(2*g-g**3)/144)
  need(zl<=zu and 0<=cl<=cu,'paired coefficient rectangle')
  I=roots(F(11,7))[1];fac=F(n,n-1)*roots(F(n,n-1))[1]
  def J(z,c):
   if z<=0:return I*(-z+3*c)
   if c==0:return I*z
   old=I*abs(z-3*c)+6*roots(c*z)[1]*exphi(z/(2*c))
   x=z/c;depth=11 if x>=3 else 12;den=F(1)
   for j in range(depth,0,-1):den=1+F(j)/(x*den)
   scaled_mills=1/den;coefficient=6+2*(3-x)*scaled_mills/x
   need(coefficient>0,'Mills cancellation coefficient')
   signed_gaussian=(I if z>=3*c else roots(F(333,212))[0])*(z-3*c)
   improved=signed_gaussian+roots(c*z)[1]*coefficient*exphi(x/2)
   need(improved>=0,'nonnegative cancellation norm bound')
   return min(old,improved)
  aa=(2-gl*gl)/24;lc=fac*max(J(z,c)for z in(zl,zu)for c in(cl,cu))+fac*I/(n-1)*(F(35,48)*aa*g**3+F(35,24)*Z*g*g)+F(251,17280)*g**3
  lh=fac*I*(aa+F(5,2)*Z*g/(n-1))+F(251,4800)*g*g
  m6=min(RADIUS*p['eta'],1+3*g*g+g**4+(RADIUS**2+2*RADIUS*g+3*g*g+2)*(M-1-gl*gl));e=m6/720+g*g/72+(F(1,2)+g*g/144)**3/5;B=aa+Z/2+e/4
  a0=F(n-1,2*n);b0=(45-M)/96*(1-F(2,n));l2=e/(2*a0*a0)+B*B/(2*b0**3)
  return lc,lh,l2,rmin
 def eligible(p,d):
  F=k.F;M=p['M'];g=p['g'];u=p['pu'];l=p['pl']
  if not(0<l<u<F(1,2) and 1<=M<3 and 0<=g and g*g<2 and k.RADIUS>2*g and 0<=p['theta']<1):return False
  s=u*(1-u);ss=l*(1-l);rbmax=k.roots((1-2*ss)**2/ss)[1];rbmin=k.roots((1-2*s)**2/s)[0]
  rmin=max(F(1),p.get('rho_lo',F(1)),rbmin-max(F(0),F(3,2)*rbmax-3*min(p['al'],p['bl']))*p['theta'])
  gl=max(F(0),k.SL*rmin-3-d,k.roots((1-p['theta'])**3*(1-2*u)**2/(u*(1-u)))[0]-(k.RADIUS+2*k.roots(u/(1-u))[1])*p['theta'])
  if gl>g or M-1-gl*gl<0:raise k.EmptyMomentBranch(dict(rho_lo=rmin,rho_hi=p['Rho'],M=M,g=g,gamma_lo=gl))
  return True
 k.paired=paired
 k.paired_eligible=eligible
 return paired
