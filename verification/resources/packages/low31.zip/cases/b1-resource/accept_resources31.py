"""Full exact branch replay, followed by fixed-object rejection controls."""
from pathlib import Path
import copy,json,sys
import protocol31 as p
def main():
 p.need(len(sys.argv)==1,'fixed acceptance invocation');sys.set_int_max_str_digits(0)
 initial,guard=p.fixed_inputs();obj=p.read('resources31_proof.json')
 report=p.verify(obj,initial,guard,True);accepted=copy.deepcopy(obj);controls=[]
 first=p.SURVIVORS[0]
 def fixed(value):p.shape(value);p.need(p.same(value,accepted),'fixed freshly replayed object')
 def reject(name,change):
  z=copy.deepcopy(obj);change(z);p.need(not p.same(z,obj),'effective mutation')
  try:fixed(z)
  except(ValueError,AssertionError,TypeError,KeyError,ZeroDivisionError):controls.append(name);return
  raise ValueError('accepted mutation '+name)
 reject('wrong theorem',lambda z:z.update(schema='UNPROVED_GLOBAL_SHARP31'))
 reject('wrong index',lambda z:z['profile'].update(n=30))
 reject('boolean index',lambda z:z['profile'].update(n=True))
 reject('wrong sharp target',lambda z:z['profile'].update(barrier='1/100'))
 reject('wrong allowance',lambda z:z['theorem'].update(contact_allowance='0'))
 reject('unproved score cap',lambda z:z['profile'].update(cap='1/2'))
 reject('discarded literal rho floor',lambda z:z['profile']['invariants'].update(rho_lo='1'))
 reject('discarded literal rho ceiling',lambda z:z['profile']['invariants'].pop('rho'))
 reject('wrong acquired support',lambda z:z['profile'].update(radius='2'))
 reject('missing panel',lambda z:z['rows'].pop())
 reject('duplicated panel',lambda z:z['rows'].__setitem__(first+1,z['rows'][first]))
 reject('reordered panels',lambda z:z['rows'].reverse())
 reject('boolean panel index',lambda z:z['rows'][0].update(index=False))
 reject('missing exact kernel',lambda z:z['input_sha256'].pop('contracted_kernel.py'))
 reject('changed INITIAL bytes',lambda z:z['input_sha256'].__setitem__('initial31_proof.json','0'*64))
 reject('changed support bytes',lambda z:z['input_sha256'].__setitem__('support31.json','0'*64))
 reject('changed count target',lambda z:z['input_sha256'].__setitem__('contract31.json','0'*64))
 reject('false survivor exclusion',lambda z:z['rows'][first]['result'].update(excluded=True))
 reject('false defect',lambda z:z['rows'][first]['result']['result'].update(D='0'))
 reject('lost actual rho floor',lambda z:z['rows'][first]['result']['result'].pop('rho_lo'))
 reject('false actual rho upper',lambda z:z['rows'][first]['result']['result'].update(rho_hi='1'))
 reject('missing signed interface',lambda z:z['rows'][first]['interface'].pop())
 withplan=next(i for i,z in enumerate(obj['rows'])if z['plan'])
 reject('missing selected support step',lambda z:z['rows'][withplan]['plan'].pop())
 reject('negative quadratic curvature',lambda z:z['rows'][first]['result']['result']['quadratics'][0].update(Qbudget='-1/10000'))
 reject('wrong probability endpoint',lambda z:z['rows'][first]['result']['result'].update(pl='0'))
 try:json.loads('{"n":31,"n":31}',object_pairs_hook=p.unique)
 except ValueError:controls.append('duplicate JSON key')
 else:raise ValueError('duplicate JSON key accepted')
 report.update(schema=f'SHARP31_RHO_B{p.BRANCH}_RESOURCE_ACCEPTANCE_V1',status=f'PASS_SHARP31_B{p.BRANCH}_RESOURCES',mathematical_status='Conditional resource acquisition for the same attained global witness in the literal branch; predecessor, owncap, accepted INITIAL and count theorem remain explicit external dependencies.',execution_status='Fresh full rational support/resource/interface replay; subsequent controls test fixed-object integrity.',profile=p.PROFILE,theorem=p.THEOREM,resource_sha256=p.sha('resources31_proof.json'),input_sha256=p.bindings(),negative_controls=controls,acceptor_sha256=p.sha(Path(__file__).name))
 output=Path(f'RESOURCES31_B{p.BRANCH}_ACCEPTED.json');p.need(not output.exists(),'fresh receipt only');output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
