"""Separate procedural support enumeration for the new lower/middle schemas.

This does not traverse arbitrary nested dictionaries looking for support
fields. It follows the known INITIAL/resource/local driver call sites and
checks every strict radius transition against its necessary signed calls.
"""
from fractions import Fraction as F
from hashlib import sha256
import json,re
def need(x,s):
 if not x:raise ValueError(s)
def canonical(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
PUB=min(F('.3031')*F('.646')/(F('.4095')-F('.3031')),F('.3322')*F('.429')/(F('.4095')-F('.3322')))
def enumerate_support(doc):
 out=[];calls=0;copies=0
 def add(obj,path,duplicate):
  nonlocal calls,copies
  need(obj['schema']in('DIRECT_FIXED_INDEX_GAUSSIAN_SUPPORT_V1','DIRECT_SAME_LAW_CONTACT_SUPPORT_DISCOVERY_V1')and type(obj['n'])is int and obj['n']==25 and F(obj['K'])==0,'known literal floor25 support call')
  out.append(dict(pointer=path,source_object_sha256=canonical(obj),serialization_duplicate=duplicate))
  if duplicate:copies+=1
  else:calls+=1
 def history(d,rm,rp,path,duplicate=False,plan=None):
  need(type(d['excluded'])is bool,'typed resource outcome')
  h=d.get('history',[]);need(type(h)is list and len(h)<=16,'bounded resource history')
  if plan is not None:need(type(plan)is list and len(plan)==len(h),'recorded plan exhausts all history transitions')
  if not h:need(d['excluded']is True,'surviving resource must complete a history');return
  previous=d['base'];need(previous.get('excluded')is not True,'only surviving base enters support history')
  for j,step in enumerate(h):
   keys={'step','radius_minus','radius_plus','support','result'}
   if step['result'].get('excluded')is not True:keys|={'lambda_geometry_cap','theta_before'}
   need(set(step)==keys,'known exact resource transition fields')
   need(type(step['step'])is int and step['step']==j+1,'ordered unique resource transition')
   nm,np=F(step['radius_minus']),F(step['radius_plus']);need(0<nm<=rm and 0<np<=rp,'nested acquired signed support')
   if plan is not None:need(same(plan[j],dict(radius_minus=str(nm),radius_plus=str(np))),'plan matches this exact transition')
   targets=[(sign,new)for sign,old,new in[(-1,rm,nm),(1,rp,np)]if new<old]
   need(type(step['support'])is list and len(step['support'])==len(targets),'every and only strict signed contraction has a target call')
   for k,(obj,(sign,radius))in enumerate(zip(step['support'],targets)):
    need(type(obj['support_sign'])is int and obj['support_sign']==sign and F(obj['radius'])==radius,'support call follows its signed radius transition')
    need(F(obj['rho_upper'])==min(F(previous['rho']),PUB),'support rho is acquired before radius reduction')
    need([F(x)for x in obj['beta_interval']]==[F(previous['beta_lo']),F(previous.get('beta_hi_signed',previous['beta']))],'support beta is acquired before radius reduction')
    add(obj,path+'/history/'+str(j)+'/support/'+str(k),duplicate)
   rm,rp=nm,np;previous=step['result']
   if previous.get('excluded')is True:need(j==len(h)-1 and d['excluded']is True,'resource exclusion is terminal')
  if not d['excluded']:need(previous.get('excluded')is not True and same(previous,d['raw_row']),'final physical row is last resource consequence')
 schema=doc['schema'];p=doc['profile'];need(type(p['n'])is int and p['n']==25,'literal floor25 source profile')
 if re.fullmatch(r'SHARP25_B[0-5]_UNSEEDED_INITIAL_V1',schema):
  z=doc['support']['full_support'];need(z['support_sign']==0 and F(z['radius'])==F(p['radius'])and F(z['rho_upper'])==F(p['invariants']['rho']),'one INITIAL full-ray call at its initial moment cap');add(z,'/support/full_support',False)
 elif re.fullmatch(r'EXACT_SHARP25_B[0-5]_GLOBAL_RESOURCES_V1',schema):
  need(len(doc['rows'])==100,'all100 procedural global rows')
  for i,row in enumerate(doc['rows']):
   need(type(row['index'])is int and row['index']==i,'ordered global row identity');history(row['result'],F(p['radius_minus']),F(p['radius_plus']),f'/rows/{i}/result',plan=row['plan'])
 elif re.fullmatch(r'EXACT_SHARP25_B[0-5]_FOUR_COVER_PANEL_V1',schema):
  need(len(doc['rows'])==1 and doc['rows'][0]['index']==doc['panel'],'one literal local panel')
  row=doc['rows'][0];last=None
  for j,cycle in enumerate(row['cycles']):
   need(type(cycle['cycle'])is int and cycle['cycle']==j+1,'ordered local cycles')
   if 'resource'in cycle:
    r=cycle['resource'];need(r['radius_minus']==cycle['profile']['radius_minus']and r['radius_plus']==cycle['profile']['radius_plus'],'local resource starts from its acquired profile');history(r['derivation'],F(r['radius_minus']),F(r['radius_plus']),f'/rows/0/cycles/{j}/resource/derivation',plan=r['plan']);last=r
   else:need(cycle['excluded']is True and j==len(row['cycles'])-1,'only terminal empty cover omits resource')
  if 'survivor_resource'in row:
   need(row['excluded']is False and last is not None and same(row['survivor_resource'],last['derivation']),'explicit surviving resource copy')
   history(row['survivor_resource'],F(last['radius_minus']),F(last['radius_plus']),'/rows/0/survivor_resource',duplicate=True,plan=last['plan'])
  else:need(row['excluded']is True,'unexcluded local branch retains its last resource')
 elif re.fullmatch(r'EXACT_MIDDLE25_MIDDLE_B[45]_INITIAL_COARSENED_HIGH_V1',schema):
  need(len(doc['initial_signed_support'])==2,'two distinct signed INITIAL calls')
  for k,(sign,key)in enumerate([(-1,'radius_minus'),(1,'radius_plus')]):
   z=doc['initial_signed_support'][k];need(z['support_sign']==sign and F(z['radius'])==F(p[key])and F(z['rho_upper'])==F(p['invariants']['rho']),'INITIAL signed radius and moment cap');add(z,f'/initial_signed_support/{k}',False)
 elif re.fullmatch(r'EXACT_MIDDLE25_MIDDLE_B[45]_GLOBAL_RESOURCES_V1',schema):
  need(len(doc['rows'])==100,'all100 middle global resource rows')
  for i,row in enumerate(doc['rows']):
   need(type(row['index'])is int and row['index']==i,'ordered middle global row');history(row['derivation'],F(row['radius_minus']),F(row['radius_plus']),f'/rows/{i}/derivation')
 elif re.fullmatch(r'EXACT_MIDDLE25_MIDDLE_B[45]_PANEL_(FINITE|TWO_CYCLE)_RESOURCES_V1',schema):
  r=doc['global_resource'];history(r['derivation'],F(r['radius_minus']),F(r['radius_plus']),'/global_resource/derivation',duplicate=True);last=None
  for j,cycle in enumerate(doc['cycles']):
   need(type(cycle['cycle'])is int and cycle['cycle']==j+1,'ordered middle local cycles')
   if 'resource'in cycle:
    r=cycle['resource'];need(r['radius_minus']==cycle['profile']['radius_minus']and r['radius_plus']==cycle['profile']['radius_plus'],'middle local resource starts at acquired profile');history(r['derivation'],F(r['radius_minus']),F(r['radius_plus']),f'/cycles/{j}/resource/derivation');last=dict(profile=cycle['profile'],source=r['input_source'],resource=r)
   else:need(cycle['excluded']is True and j==len(doc['cycles'])-1,'terminal middle empty cover')
  need(same(doc['terminal'],last),'explicit terminal local resource copy')
  if last is not None:
   r=last['resource'];history(r['derivation'],F(r['radius_minus']),F(r['radius_plus']),'/terminal/resource/derivation',duplicate=True)
 else:raise ValueError('unknown procedural proof schema: '+str(schema))
 need(len(out)==calls+copies and len({x['pointer']for x in out})==len(out),'complete distinct procedural paths')
 return dict(schema=schema,procedural_calls=calls,serialization_duplicates=copies,occurrences=out)
