"""Exact actual-index support inventory for selected floor25 proof objects.

Conditional support arithmetic only: source-DAG acquisition, procedural
inventory coverage, uniform floor25 transport, and actual counts are separate.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from copy import deepcopy
import json,sys
import direct_gaussian_support as ds
import small_index_support,finite_binomial_core,heat_support50
H=Path(__file__).resolve().parent;ROOT=H.parents[3]
KERNEL={
 'direct_gaussian_support.py':'5742afc0538fe3fb8473d087810ad391623d38a151f5b789e7520d256197c1d2',
 'small_index_support.py':'6d479445a6c22b84f9799f3d445c8352209c6468aaadd2a02eb87303cf252582',
 'finite_binomial_core.py':'939236711b080f9148ee3d3f7f6a0cd15b86cb24f3d2700f0e7127b2a345291f',
 'heat_support50.py':'650d7f3617775102fe92977605dfda5fb68a11e0ad738eb799aab77bc4a79e18'}
SCHEMAS={'DIRECT_FIXED_INDEX_GAUSSIAN_SUPPORT_V1','DIRECT_SAME_LAW_CONTACT_SUPPORT_DISCOVERY_V1'}
def need(x,msg):
 if not x:raise ValueError(msg)
def digest(p):return sha256(p.read_bytes()).hexdigest()
def canonical(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def located(rel):
 need(type(rel)is str and not Path(rel).is_absolute(),'literal relative source path')
 p=(ROOT/rel).resolve();need(p.is_relative_to(ROOT/'work/cutoff25_20261011')and str(p.relative_to(ROOT))==rel,'canonical selected working proof path');return p
def rat(x):
 need(type(x)is str,'explicit rational string');return F(x)
def sources():
 need(__debug__ and not sys.flags.optimize and sys.flags.dont_write_bytecode,'ordinary exact no-bytecode runtime')
 manifest=read(H/'KERNEL_COPY_MANIFEST.json');need(same(manifest['files'],KERNEL),'fixed copied arithmetic family')
 for module in(ds,small_index_support,finite_binomial_core,heat_support50):
  p=Path(module.__file__).resolve();need(p.parent==H and p.name in KERNEL and digest(p)==KERNEL[p.name],'exact local arithmetic module')
 return {**KERNEL,'KERNEL_COPY_MANIFEST.json':digest(H/'KERNEL_COPY_MANIFEST.json'),'support_inventory.py':digest(Path(__file__))}
def request(obj):
 need(obj['schema']in SCHEMAS and type(obj['n'])is int and obj['n']==25 and rat(obj['K'])==0,'recognized actual floor25 support object')
 need(type(obj['support_sign'])is int and obj['support_sign']in(-1,0,1),'explicit signed ray scope')
 qkey='q_contact'if obj['schema']=='DIRECT_SAME_LAW_CONTACT_SUPPORT_DISCOVERY_V1'else'q'
 need(qkey in obj and rat(obj[qkey])>=0,'explicit retained contact allowance')
 need(type(obj['beta_interval'])is list and len(obj['beta_interval'])==2,'complete beta interval')
 lo,hi=map(rat,obj['beta_interval']);r,R=rat(obj['rho_upper']),rat(obj['radius'])
 need(F(1)<=r and R>=1 and -1<lo<=hi<1,'physical incoming support domain')
 line=obj['gaussian'];need(type(line['n'])is int and line['n']==25 and rat(line['radius'])==R,'source Gaussian matches ray')
 need(type(line['mesh'])is int and line['mesh']>=1,'positive exact Gaussian mesh')
 signs=[-1,1]if obj['support_sign']==0 else[obj['support_sign']]
 need(type(obj['ray_rows'])is list and [x['sign']for x in obj['ray_rows']]==signs,'all declared signed source rays')
 for row in obj['ray_rows']:
  need(type(row['sign'])is int and all(rat(row[k])<0 for k in('coefficient_at_R','contact_derivative_at_R','contact_derivative_slope_at_R','contact_upper')),'strict retained ray gates')
 return dict(radius=str(R),support_sign=obj['support_sign'],rho_upper=str(r),beta_interval=[str(lo),str(hi)],mesh=line['mesh'])
def inventory(doc):
 found=[]
 def walk(x,path):
  if isinstance(x,dict):
   structural=all(k in x for k in('gaussian','ray_rows','radius','rho_upper','beta_interval'))
   claimed=type(x.get('schema'))is str and 'SUPPORT'in x['schema']
   if claimed:need(structural and x['schema']in SCHEMAS,'no unknown explicit support object')
   if structural:found.append(dict(pointer=path,source_object_sha256=canonical(x),request=request(x)))
   for k in sorted(x):walk(x[k],path+'/'+k.replace('~','~0').replace('/','~1'))
  elif isinstance(x,list):
   for j,v in enumerate(x):walk(v,path+'/'+str(j))
 walk(doc,'');return found
def inputs(selection):
 need(type(selection)is dict and set(selection)=={'schema','floor_n','actual_indices','proofs'},'exact selection schema')
 need(selection['schema']=='FLOOR25_ACTUAL26_30_SUPPORT_SELECTION_V1'and type(selection['floor_n'])is int and selection['floor_n']==25,'fixed floor25 selection')
 need(type(selection['actual_indices'])is list and all(type(n)is int for n in selection['actual_indices'])and selection['actual_indices']==list(range(26,31)),'every actual index26 through30')
 need(type(selection['proofs'])is list and bool(selection['proofs']),'nonempty explicitly selected proof list')
 paths=[];objects=[]
 for i,entry in enumerate(selection['proofs']):
  need(type(entry)is dict and set(entry)=={'path','sha256'},'exact selected proof binding')
  p=located(entry['path']);need(digest(p)==entry['sha256'],'current selected source proof bytes');need(entry['path']not in paths,'no duplicate selected proof');paths.append(entry['path'])
  doc=read(p);profile=doc.get('profile',doc);need(type(profile.get('n'))is int and profile['n']==25,'selected proof literal floor25 scope')
  for obj in inventory(doc):objects.append(dict(source=i,**obj))
 need(bool(objects),'at least one actual support occurrence');return objects
def calculate(selection_path):
 frozen=sources();selection_hash=digest(selection_path);selection=read(selection_path);objects=inputs(selection);distinct={}
 for obj in objects:
  key=canonical(obj['request']);need(key not in distinct or same(distinct[key],obj['request']),'exact request hash has no collision');distinct[key]=obj['request'];obj['request_sha256']=key
 requests=[]
 for key in sorted(distinct):
  arg=distinct[key];actual=[]
  for n in selection['actual_indices']:
   z=ds.target(n,F(0),F(arg['radius']),F(0),sign=arg['support_sign'],rho=F(arg['rho_upper']),beta_lower=F(arg['beta_interval'][0]),beta_upper=F(arg['beta_interval'][1]),mesh=arg['mesh'])
   need(type(z['n'])is int and z['n']==n and z['q_contact']==z['K']=='0','actual index and sharp-predecessor contact allowance')
   need(z['radius']==arg['radius']and z['support_sign']==arg['support_sign']and z['rho_upper']==arg['rho_upper']and z['beta_interval']==arg['beta_interval']and z['gaussian']['mesh']==arg['mesh'],'unchanged incoming support premises')
   actual.append(z)
  requests.append(dict(request_sha256=key,parameters=arg,actual_support=actual))
  print('EXACT_ACTUAL_SUPPORT_REQUEST',len(requests),len(distinct),arg['radius'],arg['support_sign'],flush=True)
 need(sources()==frozen and digest(selection_path)==selection_hash,'unchanged arithmetic source and selection closure')
 need(inputs(read(selection_path))==objects_without_keys(objects),'unchanged selected source inventory')
 return dict(schema='CONDITIONAL_FLOOR25_ACTUAL26_30_SUPPORT_INVENTORY_V1',selection_path=str(selection_path.relative_to(ROOT)),selection_sha256=selection_hash,selection=selection,source_sha256=frozen,occurrences=objects,distinct_requests=requests,structural_occurrences=len(objects),unique_parameter_requests=len(requests),actual_index_evaluations=5*len(requests),covered_occurrence_index_pairs=5*len(objects),scope='Conditional exact full-ray support at each actual m26..30, K=0,q_contact=0, with precisely the retained incoming radius/sign/rho/beta/mesh. Every structural serialized occurrence is listed, including duplicates. Complete selected-DAG procedural inventory, same-law acquisition/transport, sharp predecessor, and actual-m count coverage remain separate obligations. No C25, later sharp index, or eventual cutoff theorem is asserted.')
def objects_without_keys(objects):return[{k:v for k,v in x.items()if k!='request_sha256'}for x in objects]
def main():
 need(len(sys.argv)in(4,5)and sys.argv[1]in('construct','accept'),'explicit action, selection and named output directory')
 action=sys.argv[1];selection_path=Path(sys.argv[2]).resolve();out=Path(sys.argv[3]).resolve()
 need(selection_path.is_relative_to(ROOT/'work/cutoff25_20261011')and out.is_relative_to(H.parent),'local reviewed selection and audit output')
 proof=out/'ACTUAL26_30_SUPPORT_PROOF.json';receipt=out/'ACTUAL26_30_SUPPORT_ACCEPTED.json'
 if action=='construct':need(len(sys.argv)==4 and not out.exists(),'fresh constructor directory only');out.mkdir()
 else:
  need(len(sys.argv)==5 and proof.exists()and not receipt.exists(),'fresh acceptance of existing candidate')
  review_path=Path(sys.argv[4]).resolve();review=read(review_path);need(review['status']=='PASS_INDEPENDENT_ACTUAL26_30_SUPPORT_INVENTORY_SOURCE_REVIEW','independent source review')
  mapping=review['files_sha256']
  for p in(Path(__file__),H/'KERNEL_COPY_MANIFEST.json',selection_path):need(str(p.relative_to(ROOT))in mapping,'source review pins exact protocol, kernel and selection')
  for rel,h in mapping.items():need(digest(located(rel))==h,'source-reviewed bytes unchanged')
 result=calculate(selection_path)
 if action=='construct':
  with proof.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
  print('CONDITIONAL_ACTUAL_SUPPORT_CONSTRUCTED',result['actual_index_evaluations']);return
 candidate=read(proof);need(same(candidate,result),'fresh complete exact support-object replay');controls=[]
 changes=[('missing occurrence',lambda x:x['occurrences'].pop()),('duplicate occurrence',lambda x:x['occurrences'].append(deepcopy(x['occurrences'][0]))),('wrong source pointer',lambda x:x['occurrences'][0].update(pointer='/not-selected')),('wrong retained source hash',lambda x:x['occurrences'][0].update(source_object_sha256='0'*64)),('false request reference',lambda x:x['occurrences'][0].update(request_sha256='0'*64)),('missing request',lambda x:x['distinct_requests'].pop()),('duplicate request',lambda x:x['distinct_requests'].append(deepcopy(x['distinct_requests'][0]))),('missing actual index',lambda x:x['distinct_requests'][0]['actual_support'].pop()),('reordered actual indices',lambda x:x['distinct_requests'][0]['actual_support'].reverse()),('boolean actual index',lambda x:x['distinct_requests'][0]['actual_support'][0].update(n=True)),('wrong actual index',lambda x:x['distinct_requests'][0]['actual_support'][0].update(n=25)),('wrong contact allowance',lambda x:x['distinct_requests'][0]['actual_support'][0].update(q_contact='1/100')),('wrong support sign',lambda x:x['distinct_requests'][0]['parameters'].update(support_sign=99)),('false strict contact',lambda x:x['distinct_requests'][0]['actual_support'][0]['ray_rows'][0].update(contact_upper='0')),('missing ray',lambda x:x['distinct_requests'][0]['actual_support'][0]['ray_rows'].pop()),('wrong Gaussian mesh',lambda x:x['distinct_requests'][0]['actual_support'][0]['gaussian'].update(mesh=999)),('missing runtime source',lambda x:x['source_sha256'].pop('finite_binomial_core.py')),('extra success',lambda x:x.update(success=True))]
 for name,change in changes:
  bad=deepcopy(candidate);change(bad);need(not same(bad,result),'malformed full-object mutation must fail: '+name);controls.append(name)
 checked=dict(status='PASS_FRESH_CONDITIONAL_ACTUAL26_30_COMPLETE_STRUCTURAL_SUPPORT_REPLAY',proof_sha256=digest(proof),checker_sha256=digest(Path(__file__)),selection_sha256=digest(selection_path),source_review_sha256=digest(review_path),source_sha256=result['source_sha256'],structural_occurrences=result['structural_occurrences'],unique_parameter_requests=result['unique_parameter_requests'],fresh_actual_index_evaluations=result['actual_index_evaluations'],covered_occurrence_index_pairs=result['covered_occurrence_index_pairs'],negative_controls=controls,scope=result['scope'])
 with receipt.open('x')as f:json.dump(checked,f,indent=2);f.write('\n')
 print(checked['status'],checked['fresh_actual_index_evaluations'])
if __name__=='__main__':main()
