"""Four fresh support actions for the explicit low B0/B1 parent selections.

The exact original numerical protocol is unchanged. The two source selections
retain every structural and procedural support occurrence, with fresh full
actual-index calculations and all eighteen original malformed-proof controls.
This acquires no analytic parent, own-cap, COUNT or final theorem license.
"""
from pathlib import Path
from hashlib import sha256, file_digest
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import argparse
import importlib.util
import json
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
NATIVE = 'work/cutoff25_20261011/new_audit/bridge_support26_30_v1'
CONTROLS = ['missing occurrence', 'duplicate occurrence', 'wrong source pointer',
    'wrong retained source hash', 'false request reference', 'missing request',
    'duplicate request', 'missing actual index', 'reordered actual indices',
    'boolean actual index', 'wrong actual index', 'wrong contact allowance',
    'wrong support sign', 'false strict contact', 'missing ray',
    'wrong Gaussian mesh', 'missing runtime source', 'extra success']


def need(ok, message):
    if not ok:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode('ascii')


def digest(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'Complete ordinary file')
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, 'Unique JSON key')
            result[key] = value
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Finite JSON')))


def verify_source():
    manifest = read(HERE / 'LOW2630-SOURCE-VERIFIED.json')['files']
    for name, expected in manifest.items():
        need(digest(HERE / name) == expected, 'Every whole current source/input byte: ' + name)
    return manifest


def check_inventory(spec, proof, receipt):
    """Pure readback of all actual support objects and literal index/ray scopes."""
    from fractions import Fraction as F
    need(proof['schema'] == 'CONDITIONAL_FLOOR25_ACTUAL26_30_SUPPORT_INVENTORY_V1'
         and proof['selection'] == spec['selection'], 'Whole exact selected parent profile')
    need(proof['structural_occurrences'] == spec['occurrences']
         and proof['unique_parameter_requests'] == spec['requests']
         and proof['actual_index_evaluations'] == 5 * spec['requests']
         and proof['covered_occurrence_index_pairs'] == 5 * spec['occurrences'], 'Complete finite support census')
    need(proof['occurrences'] == spec['structural_inventory'], 'Every exact structural occurrence and request')
    requests = {}
    for row in proof['distinct_requests']:
        key = row['request_sha256']
        need(key not in requests, 'No duplicate unique support request')
        requests[key] = row
        need(row['parameters'] == spec['request_parameters'][key], 'Exact original signed request parameters')
        actual = row['actual_support']
        need([x['n'] for x in actual] == list(range(26, 31))
             and all(type(x['n']) is int for x in actual), 'Every actual index without monotonicity substitution')
        for obj in actual:
            arg = row['parameters']
            need(obj['K'] == obj['q_contact'] == '0', 'Literal sharp predecessor contact premise')
            need(all(obj[k] == arg[k] for k in ('radius', 'support_sign', 'rho_upper', 'beta_interval')),
                 'Entire incoming actual-index support premise')
            need(obj['gaussian']['n'] == obj['n'] and obj['gaussian']['mesh'] == arg['mesh']
                 and obj['gaussian']['radius'] == arg['radius'], 'Whole actual-index Gaussian line')
            signs = [-1, 1] if arg['support_sign'] == 0 else [arg['support_sign']]
            need([x['sign'] for x in obj['ray_rows']] == signs
                 and all(F(x[k]) < 0 for x in obj['ray_rows'] for k in
                         ('coefficient_at_R', 'contact_derivative_at_R', 'contact_derivative_slope_at_R', 'contact_upper')),
                 'All complete strict signed rays')
    need(set(requests) == set(spec['request_parameters']), 'All and only required exact requests')
    need(receipt['status'] == 'PASS_FRESH_CONDITIONAL_ACTUAL26_30_COMPLETE_STRUCTURAL_SUPPORT_REPLAY'
         and receipt['negative_controls'] == CONTROLS
         and receipt['fresh_actual_index_evaluations'] == 5 * spec['requests'], 'Whole fresh native replay and eighteen controls')


def run_branch(task, spec, deadline):
    directory = task / spec['branch']
    shutil.copytree(HERE / 'cases' / spec['branch'], directory / 'capsule')
    root = directory / 'capsule'
    native = root / NATIVE
    selection = root / spec['selection_path']
    review = root / spec['review_path']
    output = native.parent / 'current_low_support_output'
    actions = []
    for action in ('construct', 'accept'):
        remaining = deadline - time.time()
        need(remaining > 1, 'Support action before absolute native deadline')
        argv = [sys.executable, '-B', '-S', str(native / 'support_inventory.py'), action, str(selection), str(output)]
        if action == 'accept':
            argv.append(str(review))
        logs = directory / 'executions' / action
        logs.mkdir(parents=True)
        (logs / 'ARGV.json').write_bytes(encoded(dict(argv=argv, cwd=str(native), deadline=deadline)))
        with (logs / 'stdout.txt').open('xb') as stdout, (logs / 'stderr.txt').open('xb') as stderr:
            result = subprocess.run(argv, cwd=native, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                    timeout=remaining, check=False)
        need(type(result.returncode) is int and result.returncode == 0, 'Actual complete original support action')
        need((logs / 'stderr.txt').stat().st_size == 0, 'Empty successful original stderr')
        actions.append(dict(action=action, returncode=0, stdout_sha256=digest(logs / 'stdout.txt'),
                            stderr_sha256=digest(logs / 'stderr.txt')))
    proof = read(output / 'ACTUAL26_30_SUPPORT_PROOF.json')
    receipt = read(output / 'ACTUAL26_30_SUPPORT_ACCEPTED.json')
    check_inventory(spec, proof, receipt)
    need(receipt['proof_sha256'] == digest(output / 'ACTUAL26_30_SUPPORT_PROOF.json')
         and receipt['checker_sha256'] == digest(native / 'support_inventory.py')
         and receipt['selection_sha256'] == digest(selection)
         and receipt['source_review_sha256'] == digest(review), 'Whole current proof/checker/selection/source projection')
    for name, expected in read(review)['files_sha256'].items():
        need(digest(root / name) == expected, 'Whole source and actual parent unchanged after both passes')
    return dict(branch=spec['branch'], actions=actions, actual_indices=list(range(26, 31)),
        structural_occurrences=spec['occurrences'], unique_requests=spec['requests'],
        fresh_target_evaluations_per_pass=5 * spec['requests'], negative_controls=18,
        proof_sha256=digest(output / 'ACTUAL26_30_SUPPORT_PROOF.json'),
        receipt_sha256=digest(output / 'ACTUAL26_30_SUPPORT_ACCEPTED.json'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['run'])
    parser.add_argument('--task', required=True)
    parser.add_argument('--deadline', required=True, type=int)
    parser.add_argument('--jobs', type=int, choices=[1, 2], default=2)
    args = parser.parse_args()
    source_before = verify_source()
    descriptor = read(HERE / 'LOW2630-DESCRIPTION.json')
    task = Path(args.task).absolute()
    need(not task.exists(), 'Exclusive new support task')
    task.mkdir(parents=True)
    deadline = min(args.deadline, int(time.time()) + 900)
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = [pool.submit(run_branch, task, branch, deadline) for branch in descriptor['branches']]
        rows = [future.result() for future in futures]
    need(verify_source() == source_before, 'Whole source closure unchanged after all four native actions')
    report = dict(schema='be.low2630-two-parent-b0b1-current-support-observation/1',
        status='LOW2630_FOUR_NATIVE_SUPPORT_ACTIONS_COMPLETED_CONDITIONAL', branches=rows,
        native_calls=4, target_evaluations_per_pass=450, target_evaluations_all_actions=900,
        source_before=source_before, source_after=source_before,
        analytical_support_and_owncap_and_predecessor_licenses_still_required=True,
        current_floor25_parent_license_still_required=True, count_acceptance_granted=False,
        high_rho_removed_only_conditional_on_new_universal_acceptance=True,
        mathematical_acceptance=False, full_proof_pass=False)
    output = task / 'RESULT.json'
    output.write_bytes(encoded(report))
    print(json.dumps(dict(status=report['status'], native_calls=4, result_sha256=digest(output)), sort_keys=True))


if __name__ == '__main__':
    main()
