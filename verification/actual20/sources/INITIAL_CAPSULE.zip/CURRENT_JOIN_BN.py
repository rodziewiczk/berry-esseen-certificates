from pathlib import Path
import sys,hashlib
p=Path('/var/tmp/be-phase3-5a01d35d75b74a1a9aeea5d73a842998-worker4-current58h-v1/work/current2024_runtime_entry_v3.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='46a138bc6a0dc69687d3ee73f8f2b314840325a74bc8b5962c6e9f0f05902986'
sys.path.insert(0,str(p.parent))
import current2024_runtime_entry_v3 as bridge
bridge.actual20_main(Path(__file__).resolve().parent.parent,'BN')
