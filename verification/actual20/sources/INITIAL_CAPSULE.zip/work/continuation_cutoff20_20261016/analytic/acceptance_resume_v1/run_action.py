"""Exclusive bounded action with durable PID metadata and interruption cleanup."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,platform,signal,subprocess,sys,time
EPOCH=Path(__file__).resolve().parent;H=EPOCH.parent/'actual_alpha8_v1';ROOT=H.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,m):
 if not v:raise ValueError(m)
def unique(pairs):
 out={}
 for k,v in pairs:need(k not in out,'duplicate key');out[k]=v
 return out
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def bind_all(mapping):
 need(type(mapping)is dict and mapping,'nonempty exact byte map')
 for name,digest in mapping.items():
  p=(ROOT/name).resolve();need(p.is_relative_to(ROOT)and p.is_file()and sha(p)==digest,'current bound source '+name)
def durable(p,value):
 with p.open('x')as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
class Interrupted(BaseException):pass
def main():
 need(__debug__ and sys.flags.dont_write_bytecode and not sys.flags.optimize,'ordinary no-bytecode capture')
 need(len(sys.argv)==2,'independent acceptance-continuation review')
 name='n21_BN_p39';action='accept';review_arg=str(ROOT/'continuation_cutoff20_20261016/root/ACTUAL_ALPHA8_FULL_PANEL_SOURCE_REVIEW_V5.json');runtime_arg=sys.argv[1]
 now=datetime.now(timezone.utc);cutoff=datetime(2026,10,16,20,0 if action=='construct'else 5,tzinfo=timezone.utc);end=datetime(2026,10,16,20,5,tzinfo=timezone.utc)
 need(now<cutoff,'fixed research/replay deadline');allowed=min(660,(end-now).total_seconds());need(allowed>0,'positive remaining action budget')
 S=(H/name).resolve();need(S.parent==H and S.is_dir(),'fixed direct scope');freeze=S/'FROZEN.json';frozen=read(freeze);need(frozen['status']=='FROZEN_ACTUAL21_24_ALPHA8_FULL_PANEL_RETRY_V1','fixed actual retry epoch');bind_all(frozen['files_sha256'])
 n=frozen['n'];band=frozen['band'];i=frozen['index'];C=S/'capsule'
 need(type(n)is int and n in(21,22,23,24)and band in('B0','BN')and type(i)is int and 0<i<99 and name==f'n{n}_{band}_p{i}'and frozen['capsule']==str(C.relative_to(ROOT)),'fixed actual full-panel scope')
 review_path=Path(review_arg).resolve();need(review_path.is_relative_to(ROOT),'local independent review');review=read(review_path)
 need(review['status']=='PASS_INDEPENDENT_ACTUAL21_24_ALPHA8_FULL_PANEL_SOURCE_REVIEW','independent source approval')
 rm=review['files_sha256'];need(rm.get(str((freeze).relative_to(ROOT)))==sha(freeze)and rm.get(str((H/'run_action.py').relative_to(ROOT)))==sha(H/'run_action.py'),'original review binds original manifest and launcher');bind_all(rm)
 runtime_review=Path(runtime_arg).resolve();need(runtime_review.is_relative_to(ROOT),'local independent runtime review');rr=read(runtime_review);runtime_freeze=EPOCH/'FROZEN_RUNTIME.json'
 need(rr['status']=='PASS_INDEPENDENT_ACTUAL21_BN39_FRESH_ACCEPTANCE_CONTINUATION_SOURCE_REVIEW','independent new runtime approval');bind_all(rr['files_sha256'])
 for p in(Path(__file__),runtime_freeze,H/'run_action.py'):need(rr['files_sha256'].get(str(p.relative_to(ROOT)))==sha(p),'runtime review binds new launcher, epoch and unchanged old launcher')
 rf=read(runtime_freeze);need(rf['status']=='FROZEN_ACTUAL21_BN39_ACCEPTANCE_CONTINUATION'and rf['original_launcher_sha256']==sha(H/'run_action.py'),'fixed new runtime epoch');bind_all(rf['files_sha256'])
 forest=C/f'COUNT{i}_FOREST.json';accepted=C/f'COUNT{i}_ACCEPTED.json';run=C/'CONSTRUCTION_RUN.json'
 need(not accepted.exists(),'no existing acceptance')
 old_failure=read(C/'accept.execution.json');old_construct=read(C/'construct.execution.json')
 need(old_failure['status']=='INCOMPLETE_NATIVE_ACTION_PRESERVED'and old_failure['timed_out']is True and old_failure['interrupted']is False and old_failure['child_reaped']is True and type(old_failure['returncode'])is int and old_failure['returncode']!=0,'preserved old deadline timeout only')
 need(old_construct['status']=='COMPLETED_NATIVE_ACTION'and type(old_construct['returncode'])is int and old_construct['returncode']==0 and old_construct['timed_out']is False and old_construct['interrupted']is False,'preserved successful complete original construction')
 if action=='construct':need(not forest.exists()and not run.exists(),'fresh unattempted constructor namespace')
 else:
  need(forest.is_file()and run.is_file(),'complete candidate required');candidate=read(run);need(candidate['status']=='STORED_CONDITIONAL_FOREST_CONSTRUCTED_NOT_ACCEPTED'and candidate['forest_sha256']==sha(forest)and candidate['contract_sha256']==sha(C/'contract.json')and candidate['constructor_sha256']==sha(C/'construct_alpha4.py')and candidate['fixed_acceptor_sha256']==sha(C/'count_protocol.py'),'full unchanged native candidate')
 stdout=EPOCH/(action+'.stdout.txt');stderr=EPOCH/(action+'.stderr.txt');receipt=EPOCH/(action+'.execution.json');process_record=EPOCH/(action+'.process.json')
 need(not receipt.exists()and not process_record.exists(),'fresh captured action')
 command=[sys.executable,'-B','-u',str(C/('construct_alpha4.py'if action=='construct'else'count_protocol.py'))]+([]if action=='construct'else['accept'])
 inputs=dict(rf['files_sha256']);inputs[str((freeze).relative_to(ROOT))]=sha(freeze);inputs[str(review_path.relative_to(ROOT))]=sha(review_path)
 for p in(Path(__file__),runtime_review,runtime_freeze):inputs[str(p.relative_to(ROOT))]=sha(p)
 if action=='accept':inputs[str(forest.relative_to(ROOT))]=sha(forest)
 env=dict(os.environ);env.pop('PYTHONPATH',None);env['PYTHONNOUSERSITE']='1';env['PYTHONDONTWRITEBYTECODE']='1'
 start=datetime.now(timezone.utc).isoformat();began=time.monotonic();timed_out=False;interrupted=False;interrupt_signal=None;cleanup=[];child=None
 def handler(signum,frame):raise Interrupted(signum)
 old={s:signal.signal(s,handler)for s in(signal.SIGINT,signal.SIGTERM)}
 try:
  with stdout.open('x')as out,stderr.open('x')as err:
   try:
    blocked=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
    try:
     child=subprocess.Popen(command,cwd=C,stdout=out,stderr=err,env=env,start_new_session=True,preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,blocked))
     durable(process_record,dict(status='RUNNING_OWNED_CHILD',launcher_pid=os.getpid(),pid=child.pid,pgid=os.getpgid(child.pid),command=command,cwd=str(C),action=action,capsule=name,n=n,band=band,index=i,started_utc=start,nominal_timeout_seconds=660,effective_timeout_seconds=allowed,source_freeze_sha256=sha(freeze),source_review_sha256=sha(review_path),runtime_review_sha256=sha(runtime_review),runtime_freeze_sha256=sha(runtime_freeze),launcher_sha256=sha(Path(__file__)),launcher_path=str(Path(__file__).relative_to(ROOT))))
    finally:signal.pthread_sigmask(signal.SIG_SETMASK,blocked)
    rc=child.wait(timeout=allowed)
   except subprocess.TimeoutExpired:timed_out=True
   except (Interrupted,KeyboardInterrupt)as error:
    interrupted=True;interrupt_signal=error.args[0]if isinstance(error,Interrupted)else signal.SIGINT
   finally:
    # Ignore repeated stop signals during the bounded cleanup; never abandon a detached child.
    for s in old:signal.signal(s,signal.SIG_IGN)
    if child is not None and child.poll()is None:
     try:os.killpg(child.pid,signal.SIGTERM);cleanup.append('SIGTERM_OWNED_PROCESS_GROUP')
     except ProcessLookupError:pass
     try:child.wait(timeout=5)
     except subprocess.TimeoutExpired:
      try:os.killpg(child.pid,signal.SIGKILL);cleanup.append('SIGKILL_OWNED_PROCESS_GROUP')
      except ProcessLookupError:pass
      child.wait()
    if child is not None:rc=child.returncode
 finally:
  for s,h in old.items():signal.signal(s,h)
 need(child is not None,'child launch completed')
 changed=[n for n,h in inputs.items()if not(ROOT/n).is_file()or sha(ROOT/n)!=h]
 outputs={str(p.relative_to(ROOT)):sha(p)for p in(forest,accepted,run)if p.is_file()}
 completed=rc==0 and not timed_out and not interrupted and not changed and (forest.is_file()if action=='construct'else accepted.is_file())
 if completed:
  native=read(run if action=='construct'else accepted);need(read(stdout)==native and not stderr.read_bytes(),'whole successful native captured output')
  if action=='construct':need(native['status']=='STORED_CONDITIONAL_FOREST_CONSTRUCTED_NOT_ACCEPTED'and native['forest_sha256']==sha(forest)and native['contract_sha256']==sha(C/'contract.json')and native['constructor_sha256']==sha(C/'construct_alpha4.py')and native['fixed_acceptor_sha256']==sha(C/'count_protocol.py'),'complete actual fresh candidate')
  else:need(native['status']==frozen['native_acceptance_status']and native['n']==n and type(native['n'])is int and native['index']==i and type(native['index'])is int and native['contract_sha256']==sha(C/'contract.json')and native['checker_sha256']==sha(C/'count_protocol.py')and native['forest_sha256']==sha(forest),'complete actual native replay')
 status='INTERRUPTED_BY_USER_PRESERVED'if interrupted else('COMPLETED_NATIVE_ACTION'if completed else'INCOMPLETE_NATIVE_ACTION_PRESERVED')
 record=dict(status=status,capsule=name,index=i,action=action,n=n,band=band,command=command,cwd=str(C),python=sys.version,platform=platform.platform(),runtime_review_sha256=sha(runtime_review),runtime_freeze_sha256=sha(runtime_freeze),launcher_sha256=sha(Path(__file__)),launcher_path=str(Path(__file__).relative_to(ROOT)),executable_sha256=sha(Path(sys.executable).resolve()),started_utc=start,finished_utc=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-began,returncode=rc,timed_out=timed_out,interrupted=interrupted,interrupt_signal=interrupt_signal,work_timeout_seconds=660,effective_timeout_seconds=allowed,termination_grace_seconds=5,pid=child.pid,pgid=child.pid,child_reaped=child.poll()is not None,cleanup=cleanup,process_record_sha256=sha(process_record),changed_inputs=changed,inputs_sha256=inputs,outputs_sha256=outputs,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),scope='Conditional actual-index count only. Original acquired resources and global sharp predecessor remain unchanged; no global bound is discharged here.')
 durable(receipt,record)
 print(json.dumps({k:record[k]for k in('status','capsule','action','seconds','returncode','timed_out','interrupted','pid','child_reaped')}),flush=True)
 if not completed:raise SystemExit(130 if interrupted else 2)
if __name__=='__main__':main()
