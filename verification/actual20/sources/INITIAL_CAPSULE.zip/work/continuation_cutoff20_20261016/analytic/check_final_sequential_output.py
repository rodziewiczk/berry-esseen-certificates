"""Independent exact output/closure audit; no numerical probability oracle."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,importlib.util
R=Path(__file__).resolve().parents[2];C=R/'continuation_cutoff20_20261016';A=C/'analytic';H=C/'b0/sequential_synthesis_v8';FINAL=H/'CONDITIONAL_CUTOFF20_COMPOSED.json'
def sha(p):
 h=sha256()
 with p.open('rb')as f:
  for z in iter(lambda:f.read(1024*1024),b''):h.update(z)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def need(v,m):
 if not v:raise ValueError(m)
d=read(FINAL);need(d['status']=='PROPOSED_EVENTUAL_CUTOFF20_FROM_COMPLETE_ACTUAL_CHAIN_UNDER_RETAINED_FRAMEWORK','qualified actual final status')
need(d['global_indices']==list(range(20,31))and d['new_finite_indices']==list(range(20,25))and d['retained_indices']==list(range(25,31))and d['retained_tail_from']==31 and d['remaining_finite_indices']==[],'complete finite and infinite index inventory')
need(type(d['eventual_cutoff_under_retained_framework'])is int and d['eventual_cutoff_under_retained_framework']==20 and d['conditional_cutoff20_composed']is True,'only retained-framework cutoff20')
for k in('fully_reproduced_historical_dependency_DAG','fully_rechecked_unconditional_theorem','cutoff20_proved','sample_size_monotonicity_used','historical_execution_reconstructed'):need(d[k]is False,'explicit negative limitation '+k)
need(d['global_predecessors_discharged_only_within_conditional_chain']is True and d['native_false_flags_preserved']is True and d['base20_historical_limitations_preserved']is True and d['numerical_resource_or_leaf_oracle_calls']==0,'scope preserved')
spec=importlib.util.spec_from_file_location('final_independent_checks',H/'checks.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
basep=C/'bn/global20_synthesis_v5/GLOBAL20_SYNTHESIS.json';base=read(basep);high=C/'root/bridge21_24_high_rho_v1';hc=read(high/'CANDIDATE.json');ha=read(high/'ACCEPTED.json');target=F(hc['exact_CE_lower']);bands={};shas={};count=leaves=nodes=0
for n in range(21,25):
 for b in('B0','BN'):
  p=A/f'bridge_family_composition_v4/ACTUAL{n}_{b}_JOINED.json';o=read(p);bands[n,b]=o;shas[n,b]=sha(p)
  need(d['files_sha256'].get(str(p.relative_to(R)))==shas[n,b],'actual complete band byte edge')
  count+=sum(x['disposition']=='EXCLUDED_BY_FRESH_NATIVE_FULL_COUNT'for x in o['panels']);leaves+=o['total_count_leaves'];nodes+=o['total_count_nodes']
steps=v.ledger(base,bands,hc,ha,target,sha(basep),shas);need(steps==d['induction_steps'],'entire independently recomputed actual global-predecessor ledger')
need((count,leaves,nodes)==(114,56034,109397),'all actual bridge count totals')
need(d['base20_certificate_sha256']==sha(basep)and d['high_rho_candidate_sha256']==sha(high/'CANDIDATE.json')and d['high_rho_acceptance_sha256']==sha(high/'ACCEPTED.json')and d['exact_native_target']==str(target),'exact base/high/target sources')
tailp=R/'cutoff25_continue_20261015/direct_union_v1/DIRECT_GLOBAL_THROUGH_30.json';tail=read(tailp);v.tail25(tail);need(sha(tailp)==d['retained_eventual25_certificate_sha256']=='c8c843f49d4b4a88f0a097774edad6eda6f1f4a4a420442160bdce82b1545b2a','exact retained complete25..30 and31-onward')
maps=tuple(('work/cutoff25_20261011/'+n+'/',n+'/')for n in('BE_cutoff35_release_20261007','continuation_20261010','continuation_20261011','threshold31_20261008'))
need(d['explicit_historical_prefix_maps']==[dict(recorded_prefix=a,local_prefix=b)for a,b in maps],'only four finite historical aliases')
need(set(d['historical_tail_edges'])==set(tail['files_sha256']),'no omitted historical declaration')
missing={};available=0
for k,z in tail['files_sha256'].items():
 candidates=[(R/k,'direct')]+([(R/k[5:],'strip_work_only')]if k.startswith('work/')else[])+[(R/(b+k[len(a):]),a)for a,b in maps if k.startswith(a)]
 for p,rule in candidates:need(p.resolve().is_relative_to(R),'only local historical candidates')
 selected=next(((p,rule)for p,rule in candidates if p.is_file()),None)
 expected=dict(expected_sha256=z,declared_by=str(tailp.relative_to(R)),local_path=None,resolution_rule=selected[1]if selected else None,status='UNAVAILABLE_RETAINED_HISTORICAL_EDGE')
 if selected:
  p,rule=selected;expected.update(local_path=str(p.relative_to(R)),status='AVAILABLE_BYTES_MATCH_RETAINED_EDGE');need(d['files_sha256'].get(str(p.relative_to(R)))==z,'available historical byte retained under declared SHA');available+=1
 else:missing[k]=expected
 need(d['historical_tail_edges'][k]==expected,'complete independently reconstructed historical finite resolution')
need(d['missing_historical_tail_edges']==missing and (available,len(missing))==(19092,18719),'exact historical unresolved inventory; no absolute absence inference')
# Independently rehash all currently bound bytes, not historical numerical arithmetic.
g=dict(d['files_sha256'])
for k,z in g.items():
 p=(R/k).resolve();need(p.is_relative_to(R)and sha(p)==z,'entire final current byte closure '+k)
for p in(FINAL,Path(__file__),A/'SEQUENTIAL20_24_SYNTHESIS_SOURCE_REVIEW_V8.json'):g[str(p.relative_to(R))]=sha(p)
out=dict(status='PASS_INDEPENDENT_FINAL_CONDITIONAL_CUTOFF20_OUTPUT_REVIEW',final_sha256=sha(FINAL),files_sha256=g,complete_actual_global_predecessor_ledger=[20,21,22,23,24],actual21_24_count_panels=count,actual21_24_count_leaves=leaves,actual21_24_count_nodes=nodes,retained_eventual_indices=list(range(25,31)),retained_infinite_tail_from=31,qualified_eventual_cutoff=20,current_bound_files_rehashed=len(d['files_sha256']),retained_tail_declared_edges=len(tail['files_sha256']),available_historical_byte_edges=available,finite_resolver_unresolved_edges=len(missing),historical_execution_reconstructed=False,fully_rechecked_unconditional_theorem=False,numerical_resource_or_leaf_oracle_calls=0,scope='Actual completed final output audited against all eight actual bands, fresh actual-index high-rho metadata, exact complete retained tail and whole current byte closure. The unchanged mathematical ledger is recomputed from actual inputs, all historical finite resolutions independently reconstructed. This additional output audit does not repeat native cell arithmetic or reprove the explicitly retained analytical/historical framework. The conclusion is cutoff20 only under those retained premises; no unconditional theorem is asserted.')
p=A/'SEQUENTIAL_CUTOFF20_FINAL_OUTPUT_REVIEW.json'
with p.open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(out['status'],sha(p),out['final_sha256'],len(g))
