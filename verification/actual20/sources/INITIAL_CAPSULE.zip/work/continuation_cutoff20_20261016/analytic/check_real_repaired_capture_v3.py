"""Real successful repair edge plus in-memory bad metadata, never a leaf oracle."""
from pathlib import Path
from hashlib import sha256
from copy import deepcopy
from functools import lru_cache
import json,sys,importlib.util
A=Path(__file__).resolve().parent;ROOT=A.parents[1];H=A/'bridge_family_composition_v3'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def digest(p):return sha256(p.read_bytes()).hexdigest()
def main():
 assert len(sys.argv)==4 and __debug__ and sys.flags.dont_write_bytecode
 n=int(sys.argv[1]);band=sys.argv[2];i=int(sys.argv[3]);core=load('realrepair_core',H/'compose.py');repair=load('realrepair_edges',H/'repair_edges.py');geometry=load('realrepair_geometry',ROOT/'continuation_cutoff20_20261016/root/geometry_audit_v2.py')
 family=core.P/f'n{n}_{band}'/'FROZEN.json';f=core.read(family);family_review=A/f'ACTUAL{n}_{band}_COUNT_FAMILY_SOURCE_REVIEW.json';desc=next(x for x in f['rows']if x['index']==i);original=family.parent/f'capsule{i}';graph={}
 selector=H/'SELECTED_FOURTEEN_MIXED_V1.json';routes=repair.selection(core,graph,selector,n,band);route=routes[i];S=route[0];C=S/'capsule'
 actual=repair.inspect(core,graph,route,n,band,i,original,family,family_review,desc,geometry)
 # Only successful completed metadata are cached. The production code is untouched.
 realread=core.read;realsha=core.sha;core.sha=lru_cache(maxsize=None)(core.sha)
 class NoGeometry:
  @staticmethod
  def inspect_capsule(p):raise AssertionError('bad metadata escaped to geometry')
 tests=[]
 for action in('construct','accept'):
  ep=C/(action+'.execution.json');pp=C/(action+'.process.json')
  for key,value in [('status','INCOMPLETE_NATIVE_ACTION_PRESERVED'),('returncode',True),('timed_out',True),('interrupted',True),('child_reaped',False),('changed_inputs',['source.py']),('n',True),('band','BN'if band=='B0'else'B0'),('index',True),('action','other'),('capsule','other'),('pid',True),('pgid',False),('command',[]),('cwd','/elsewhere'),('work_timeout_seconds',600),('effective_timeout_seconds',661),('inputs_sha256',{}),('outputs_sha256',{}),('process_record_sha256','0'*64),('stdout_sha256','0'*64)]:tests.append((ep,key,value))
  for key,value in [('status','COMPLETE'),('pid',True),('pgid',True),('source_freeze_sha256','0'*64),('source_review_sha256','0'*64),('started_utc','different')]:tests.append((pp,key,value))
 if route[4]is not None:
  for action in('construct','accept'):
   for suffix in('execution','process'):
    for key,value in [('runtime_review_sha256','0'*64),('runtime_freeze_sha256','0'*64),('launcher_sha256','0'*64),('launcher_path','wrong/runtime.py')]:tests.append((C/(action+'.'+suffix+'.json'),key,value))
 for path,key,value in tests:
  bad=deepcopy(realread(path));bad[key]=value
  def changed(p,path=path,bad=bad):return deepcopy(bad)if Path(p)==path else realread(p)
  core.read=changed
  try:repair.inspect(core,{},route,n,band,i,original,family,family_review,desc,NoGeometry)
  except(ValueError,KeyError,TypeError):pass
  else:raise AssertionError('malformed capture accepted '+str((path.name,key)))
 core.read=realread;core.sha=realsha
 # Recheck the source and every selected real evidence byte after in-memory tests.
 for key,z in graph.items():assert digest(ROOT/key)==z
 for p in(Path(__file__),H/'compose.py',H/'repair_edges.py',ROOT/'continuation_cutoff20_20261016/root/geometry_audit_v2.py',C/'construct.execution.json',C/'accept.execution.json'):graph[str(p.relative_to(ROOT))]=digest(p)
 out=dict(status='PASS_REAL_REPAIRED_FULL_PANEL_CAPTURE_AND_GEOMETRY_CHECK',n=n,band=band,index=i,statistics=actual[2]['statistics'],real_successful_capture_pair=True,in_memory_bad_metadata_controls=len(tests),files_sha256=graph,numerical_resource_or_leaf_oracle_calls=0,scope='Actual complete repaired source/capture/native-receipt/geometry edge checked with production helper. Negative cases change only in-memory metadata and must fail before geometry. This is additional author smoke coverage, not independent leaf arithmetic replay or a complete band theorem.')
 p=A/f'REAL_REPAIRED_V3_CAPTURE_n{n}_{band}_p{i}.json'
 with p.open('x')as f:json.dump(out,f,indent=2);f.write('\n')
 print(out['status'],digest(p),len(graph),len(tests))
if __name__=='__main__':main()
