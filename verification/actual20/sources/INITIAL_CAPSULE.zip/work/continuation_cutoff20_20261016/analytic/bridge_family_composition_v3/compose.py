"""Complete actual21--24 conditional band composition; no numerical leaf oracle."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from copy import deepcopy
import json,sys,importlib.util
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];A=HERE.parent
P=ROOT/'continuation_cutoff20_20261016/b0/bridge_counts_v3'
RUNNER=ROOT/'continuation_cutoff20_20261016/root/resume_count_family_v3.py'
SAFETY=A/'RESUMED_COUNT_LAUNCHER_V3_SOURCE_REVIEW.json'
NEW_RUNNER=ROOT/'continuation_cutoff20_20261016/root/resume_count_family_v4.py'
NEW_SAFETY=A/'RESUMED_COUNT_LAUNCHER_V4_SOURCE_REVIEW.json'

def family_runtime(n,band):
 need(type(n)is int and n in(21,22,23,24)and band in('B0','BN'),'literal fixed runtime family')
 return(NEW_RUNNER,NEW_SAFETY)if n in(23,24)else(RUNNER,SAFETY)

def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return sha256(p.read_bytes()).hexdigest()
def unique(pairs):
 out={}
 for k,v in pairs:need(k not in out,'duplicate JSON key');out[k]=v
 return out
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def same(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if type(a)is list:return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b

def bind(graph,p,expected=None):
 p=p.resolve();need(p.is_relative_to(ROOT),'workspace dependency');digest=sha(p);need(expected is None or expected==digest,'exact bound artifact '+str(p));key=str(p.relative_to(ROOT));need(key not in graph or graph[key]==digest,'consistent dependency');graph[key]=digest;return digest
def closure(graph,p):
 obj=read(p);bind(graph,p)
 for key,z in obj.get('files_sha256',{}).items():bind(graph,ROOT/key,z)
 return obj

def load_module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def captured(graph,n,band,i,action,C,family,review):
 RUNNER,SAFETY=family_runtime(n,band)
 cap=P/'captures'/f'n{n}_{band}_p{i}_{action}';ep=cap/'EXECUTION.json';e=read(ep);st=read(cap/'STARTED.json')
 need(type(e['n'])is int and e['n']==n and type(e['index'])is int and e['index']==i and e['band']==band and e['action']==action,'literal captured action')
 need(type(e['returncode'])is int and e['returncode']==0 and e['timed_out']is False and e['interrupted']is False,'completed native process')
 need(type(e['pid'])is int and e['pid']>0 and type(e['pgid'])is int and e['pgid']==e['pid'],'owned native process group')
 suffix=['-B','-u']+(['construct_alpha4.py']if action=='construct'else['count_protocol.py','accept'])
 need(type(e['command'])is list and e['command'][1:]==suffix and e['cwd']==str(C),'unchanged native command')
 need(st['pid']==e['pid']and type(st['pid'])is int and st['pgid']==e['pgid']and type(st['pgid'])is int and st['command']==e['command']and st['cwd']==e['cwd']and st['started_utc']==e['started_utc'],'actual start/finish linkage')
 need(e['source_freeze_sha256']==sha(family)and e['source_review_sha256']==sha(review)and e['launcher_sha256']==sha(RUNNER)and e['safety_review_sha256']==sha(SAFETY),'actual reviewed captured source epoch')
 for name in('stdout','stderr'):bind(graph,cap/(name+'.txt'),e[name+'_sha256'])
 need(not(cap/'stderr.txt').read_bytes(),'successful empty native stderr')
 bind(graph,cap/'STARTED.json');bind(graph,ep);return e,read(cap/'stdout.txt'),str(cap.relative_to(ROOT)),sha(ep)

def compose(n,band,review_path,selector_path):
 need(type(n)is int and n in(21,22,23,24)and band in('B0','BN'),'literal actual conditional band')
 graph={};freeze=HERE/'FROZEN_SOURCES.json';fr=closure(graph,freeze);review=closure(graph,review_path)
 need(review['status']=='PASS_INDEPENDENT_ACTUAL21_24_MIXED_RUNTIME_FAMILY_COMPOSITION_SOURCE_REVIEW','independent compositor source review')
 for p in(freeze,Path(__file__)):need(review['files_sha256'].get(str(p.relative_to(ROOT)))==sha(p),'review binds exact compositor')
 need(fr['status']=='FROZEN_ACTUAL21_24_CONDITIONAL_FAMILY_COMPOSITOR_V3','fixed composition epoch')
 RUNNER,SAFETY=family_runtime(n,band)
 safety=closure(graph,SAFETY);need(safety['status']=='PASS_SAFE_RESUMED_ACTUAL_COUNT_LAUNCHER_SOURCE_REVIEW'and safety['files_sha256'][str(RUNNER.relative_to(ROOT))]==sha(RUNNER),'reviewed captured runtime')
 family=P/f'n{n}_{band}'/'FROZEN.json';f=closure(graph,family);family_review=A/f'ACTUAL{n}_{band}_COUNT_FAMILY_SOURCE_REVIEW.json';fv=closure(graph,family_review)
 need(fv['status']=='PASS_INDEPENDENT_ACTUAL21_24_COUNT_FAMILY_SOURCE_REVIEW'and fv['n']==n and type(fv['n'])is int and fv['band']==band and fv['family_sha256']==sha(family),'actual family source/interface review')
 for p in(family,P/'run_family.py'):need(fv['files_sha256'].get(str(p.relative_to(ROOT)))==sha(p),'family review exact edges')
 need(f['status']=='FROZEN_ACTUAL21_24_CONDITIONAL_COUNT_FAMILY_NOT_EXECUTED'and f['n']==n and type(f['n'])is int and f['band']==band and f['K']=='0'and all(f[k]is False for k in('predecessor_verified','global_bound_proved','cutoff20_proved')),'conditional actual family scope')
 sys.path.insert(0,str(P));import prepare_family as pf;import contract_helpers as h
 sys.path.insert(0,str(A));import review_actual_count_family as audit
 geometry=load_module('actual_geometry',ROOT/'continuation_cutoff20_20261016/root/geometry_audit_v2.py')
 import repair_edges
 routes=repair_edges.selection(sys.modules[__name__],graph,selector_path,n,band)
 cp,ap,rows=pf.parent(n,band,graph)
 need(f['parent_candidate_sha256']==sha(pf.PARENT/f'n{n}_{band}/CANDIDATE.json')and f['parent_acceptance_sha256']==sha(pf.PARENT/f'n{n}_{band}/ACCEPTED.json'),'exact fresh actual resources')
 need(len(f['dispositions'])==len(rows)==100,'whole probability inventory');descs={x['index']:x for x in f['rows']};need(len(descs)==len(f['rows'])and all(type(i)is int for i in descs),'unique actual count indices')
 need(set(routes)<=set(descs),'selected retries are actual full count panels')
 result=[];total_leaves=total_nodes=0;maximum=F(0)
 for i,(row,disp)in enumerate(zip(rows,f['dispositions'])):
  need(type(disp['index'])is int and disp['index']==i,'ordered original probability panel')
  panel=dict(index=i,p=[str(F(i,100)),str(F(i+1,100))],resource_row_sha256=sha(pf.PARENT/f'n{n}_{band}/rows/{i:03d}.json'))
  if row['status']!='RESOURCE_ROW_ACQUIRED_FOR_COUNT':
   need(row['status']=='EXCLUDED_BY_SAME_LAW_RESOURCE'and disp==dict(index=i,status=row['status'])and i not in descs,'actual necessary resource exclusion; unresolved never accepted')
   panel['disposition']='EXCLUDED_BY_FRESH_RESOURCE';result.append(panel);continue
  expected,derivation=h.mapped_contract(row,n,band,i)
  independent,margin=audit.base(row,n,band,i);raw=row['result']['result']
  if expected is None:
   sp=family.parent/f'SCALAR_EXCLUDED_{i}.json';stored=read(sp);need(same(stored,derivation)and stored['status']=='EXCLUDED_BY_STRICT_ACTUAL_INWARD_MOMENT'and disp['status']==stored['status']and i not in descs,'strict stored scalar exclusion')
   floor,cap=audit.scalar(raw,stored['scalar'],n,band,i);need(floor>F(raw['rho_hi']),'independent strict actual contradiction');bind(graph,sp);panel.update(disposition='EXCLUDED_BY_STRICT_SCALAR_MOMENT',scalar_proof_sha256=sha(sp));result.append(panel);continue
  need(i in descs and disp['status']=='PREPARED_CONDITIONAL_COUNT_NOT_EXECUTED','actual count disposition');desc=descs[i];C=family.parent/f'capsule{i}';need(desc['directory']==str(C.relative_to(ROOT)),'literal native capsule')
  kp=C/'contract.json';sp=C/'SCALAR_DERIVATION.json';contract=read(kp);stored=read(sp)
  need(same(stored,derivation)and same(contract['rows'],[expected]),'entire original source/helper contract recomputation')
  floor,cap=audit.scalar(raw,stored['scalar'],n,band,i);l,u=audit.m.folded(independent['p']);coupled=stored['coupled']
  if 0<F(independent['d0'])<=l:
   need(coupled is not None and coupled['coupled_inputs']=={k:independent[k]for k in('n','index','p','d0','Lambda','rho_upper')},'actual coupled inputs')
   bound=audit.ns['coupled_check'](l,u,F(independent['d0']),F(independent['rho_upper']),F(independent['Lambda']),coupled['coupled_derivation'],n);bound=min(F(independent['Lambda']),audit.m.ceiling(bound,10**9));need(bound==F(coupled['coupled_lambda_upper']),'independent coupled output');cap=min(cap,bound)
  else:need(coupled is None,'optional coupled gate retained')
  independent.update(rho_lower=str(floor),acquired_lambda_upper=str(cap));need(same(independent,expected)and stored['signed_quadratic_margins']==margin,'independent entire simultaneous physical/scalar contract')
  need(contract['n']==n and type(contract['n'])is int and contract['index']==i and type(contract['index'])is int and contract['band']==band and contract['K']=='0'and all(contract[k]is False for k in('predecessor_verified','global_bound_proved','cutoff20_proved')),'conditional native contract scope')
  need(contract['resource_candidate_sha256']==f['parent_candidate_sha256']and contract['resource_replay_sha256']==f['parent_acceptance_sha256']and contract['resource_row_sha256']==panel['resource_row_sha256']and contract['scalar_derivation_sha256']==sha(sp),'all actual acquisition-to-contract edges')
  need(desc['contract_sha256']==sha(kp)and desc['scalar_derivation_sha256']==sha(sp),'frozen contract identity')
  if i in routes:
   C,receipt,inspection=repair_edges.inspect(sys.modules[__name__],graph,routes[i],n,band,i,C,family,family_review,desc,geometry);stats=inspection['statistics']
  else:
   rr=C/'ROW_RESULT.json';local=read(rr);need(local['status']=='FRESH_NATIVE_ACTUAL_FULL_PANEL_ACCEPTED_CONDITIONAL_ONLY'and local['n']==n and type(local['n'])is int and local['index']==i and type(local['index'])is int and local['band']==band and local['K']=='0','complete native local result')
   need(local['source_freeze_sha256']==sha(family)and local['source_review_sha256']==sha(family_review)and local['contract_sha256']==sha(kp),'actual local source epoch')
   for action in('construct','accept'):
    e,stdout,path,ehash=captured(graph,n,band,i,action,C,family,family_review);need(local['runs'][action]==dict(path=path,execution_sha256=ehash),'recorded complete action')
    output=C/('CONSTRUCTION_RUN.json'if action=='construct'else f'COUNT{i}_ACCEPTED.json');native=read(output);need(same(native,stdout),'complete native captured JSON');bind(graph,output)
    if action=='construct':need(native['status']=='STORED_CONDITIONAL_FOREST_CONSTRUCTED_NOT_ACCEPTED'and native['forest_sha256']==sha(C/f'COUNT{i}_FOREST.json')and native['constructor_sha256']==sha(C/'construct_alpha4.py')and native['fixed_acceptor_sha256']==sha(C/'count_protocol.py')and native['contract_sha256']==sha(kp),'full original native candidate')
    else:need(native['status']==desc['status'],'exact approved native fresh acceptance status')
   receipt=C/f'COUNT{i}_ACCEPTED.json';inspection=geometry.inspect_capsule(receipt);stats=inspection['statistics'];need(inspection['n']==n and inspection['index']==i and inspection['subpanel']is None,'whole original panel geometry')
   need(local['statistics']==stats and local['forest_sha256']==inspection['forest_sha256']and local['accepted_sha256']==sha(receipt),'independent complete stored geometry matches native replay')
   for p in(kp,sp,rr,C/f'COUNT{i}_FOREST.json',receipt):bind(graph,p)
  total_leaves+=stats['leaves'];total_nodes+=stats['nodes'];maximum=max(maximum,F(stats['maximum_score']));panel.update(disposition='EXCLUDED_BY_FRESH_NATIVE_FULL_COUNT',count_capsule=str(C.relative_to(ROOT)),count_route='REVIEWED_ALPHA8_FULL_PANEL'if i in routes else'ORIGINAL_FULL_PANEL',contract_sha256=sha(kp),scalar_proof_sha256=sha(sp),accepted_sha256=sha(receipt),forest_sha256=inspection['forest_sha256'],statistics=stats);result.append(panel)
 need(len(result)==100 and [p['index']for p in result]==list(range(100)),'complete closed original probability cover')
 for i in range(99):need(result[i]['p'][1]==result[i+1]['p'][0],'closed probability seam')
 need(result[0]['p'][0]=='0'and result[-1]['p'][1]=='1','whole original probability endpoints')
 for p,z in graph.items():need(sha(ROOT/p)==z,'final all dependencies unchanged')
 return dict(status='PASS_COMPLETE_CONDITIONAL_ACTUAL21_24_BAND_COMPOSITION',n=n,K='0',band=band,rho_interval=list(h.BANDS[band]),p_interval=['0','1'],target='CE',panels=result,total_count_leaves=total_leaves,total_count_nodes=total_nodes,maximum_recorded_count_score=str(maximum),exact_native_target=str(geometry.exact_native_target()),files_sha256=graph,conditional_band_excluded=True,predecessor_n=n-1,predecessor_global_sharp_required=True,predecessor_verified=False,global_bound_proved=False,cutoff20_proved=False,historical_dependency_graph_reproduced=False,numerical_resource_or_leaf_oracle_calls=0,scope='Complete actual-n rho-band implication under retained unrestricted-witness framework, acquired owncap and GLOBAL sharp(n-1). Native full fresh replay is retained and source/capture bound; this additional audit verifies complete geometry/interfaces without redoing leaf arithmetic. Other rho bands and final induction are separate.')

def main():
 need(__debug__ and sys.flags.dont_write_bytecode and not sys.flags.optimize and len(sys.argv)==5,'ordinary-B actualn band independent-source-review explicit-selector')
 n=int(sys.argv[1]);need(str(n)==sys.argv[1],'literal actual n');band=sys.argv[2];review=Path(sys.argv[3]).resolve();need(review.is_relative_to(ROOT),'workspace review');selector=Path(sys.argv[4]).resolve();need(selector.is_relative_to(ROOT),'workspace explicit selector');out=compose(n,band,review,selector);dest=HERE/f'ACTUAL{n}_{band}_JOINED.json'
 with dest.open('x')as f:json.dump(out,f,indent=2);f.write('\n')
 print(out['status'],n,band,out['total_count_leaves'],sha(dest))
if __name__=='__main__':main()
