"""Independent closed-domain inspection; never imports a numerical kernel.

This verifies stored geometry and receipt identities. It does not recompute
empty-box inequalities or replace native arithmetic acceptance.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from collections import Counter
from math import isqrt
import json, sys

def need(ok, message):
    if not ok:
        raise ValueError(message)

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'duplicate JSON key')
        out[key] = value
    return out

def read(p):
    return json.loads(p.read_text(), object_pairs_hook=unique)

def rational(x):
    need(type(x) is str, 'rational string')
    return F(x)

def exact_native_target():
    scale = 10**30
    def root_low(x):
        return F(isqrt(x.numerator * scale * scale // x.denominator), scale)
    def atan(q, m):
        lo = sum((F((-1)**k, (2*k+1)*q**(2*k+1)) for k in range(2*m)), F(0))
        return lo, lo + F(1, (4*m+1)*q**(4*m+1))
    _, a5hi = atan(5, 24)
    a239lo, _ = atan(239, 8)
    pi_hi = 16*a5hi - 4*a239lo
    return (3+root_low(F(10))) * root_low(1/(2*pi_hi)) / 6

def inspect_objects(cfg, forest):
    need(type(cfg['n']) is int and 20 <= cfg['n'] <= 24, 'actual n20 through24')
    n=cfg['n']
    need(type(cfg['index']) is int and 0 <= cfg['index'] < 100 and cfg['K'] == '0', 'sharp literal index')
    need(type(forest['n']) is int and forest['n'] == n, 'same literal forest n')
    need(type(forest['index']) is int and forest['index'] == cfg['index'], 'same index')
    target = rational(forest['target'])
    need(target == exact_native_target(), 'unchanged exact native target')
    full_p = list(map(rational, cfg['p']))
    need(full_p == [F(cfg['index'],100), F(cfg['index']+1,100)], 'literal full original p')
    sub = forest.get('subpanel')
    if sub is None:
        p = full_p
    else:
        need(type(sub) is dict and set(sub) == {'parts','part','p'}, 'exact subpanel descriptor')
        m,j = sub['parts'],sub['part']
        need(type(m) is int and m in (2,4) and type(j) is int and 0 <= j < m, 'canonical part index')
        p = list(map(rational, sub['p']))
        a,b = full_p
        need(p == [a+(b-a)*j/m, a+(b-a)*(j+1)/m], 'canonical closed subpanel')
    root_box = [p, [F(0),rational(cfg['Lambda'])], [F(0),F(1)], [-F(1,2),F(1,2)], [F(0),rational(cfg['d0'])]]
    need(all(lo <= hi for lo,hi in root_box), 'nonempty original root')
    roots = forest['roots']
    need(type(roots) is list and len(roots) == n+1, 'all actual n+1 count roots')
    stack = []
    for k,root in enumerate(roots):
        need(type(root) is dict and set(root) == {'k','tree'} and type(root['k']) is int and root['k'] == k, 'ordered literal roots')
        stack.append((root['tree'],root_box,0))
    nodes=leaves=depthmax=0
    decisions=Counter(); maximum=F(0)
    while stack:
        node, box, depth = stack.pop()
        nodes+=1; depthmax=max(depthmax,depth)
        need(nodes <= 10000 and depth <= 128, 'native stored tree bounds')
        need(type(node) is dict, 'tree node mapping')
        if node.get('kind') == 'split':
            need(set(node) == {'kind','axis','cut','left','right'}, 'both closed split children')
            axis=node['axis']; cut=rational(node['cut'])
            need(type(axis) is int and 0 <= axis < 5, 'literal split axis')
            need(box[axis][0] < cut < box[axis][1], 'strict interior split')
            left=[pair[:] for pair in box];right=[pair[:] for pair in box]
            left[axis][1]=cut;right[axis][0]=cut
            stack.extend([(node['left'],left,depth+1),(node['right'],right,depth+1)])
        else:
            need(node.get('kind') == 'leaf' and set(node) == {'kind','box','decision','result'}, 'literal leaf schema')
            need(type(node['box']) is list and len(node['box']) == 5 and all(type(x) is list and len(x)==2 for x in node['box']), 'five leaf coordinates')
            need([list(map(rational,x)) for x in node['box']] == box, 'original closed leaf geometry')
            decision=node['decision'];need(type(decision) is str, 'decision text')
            need(decision == 'PASS_TARGET' or decision.startswith('EMPTY_'), 'retained decision category')
            need(type(node['result']) is dict, 'stored arithmetic mapping')
            if decision == 'PASS_TARGET':
                score=rational(node['result']['score_upper'])
                need(score < target, 'strict leaf score')
                maximum=max(maximum,score)
            decisions[decision]+=1;leaves+=1
    return dict(nodes=nodes,leaves=leaves,closed_statuses=dict(decisions),maximum_score=str(maximum),maximum_depth=depthmax)

def inspect_capsule(receipt_path):
    receipt=read(receipt_path); directory=receipt_path.parent
    index=receipt['index']; forest_path=directory/f'COUNT{index}_FOREST.json'
    need(type(index) is int and 0 <= index < 100, 'literal receipt index')
    contract_path=directory/'contract.json'; protocol_path=directory/'count_protocol.py'
    forest=read(forest_path);contract=read(contract_path)
    need(type(contract['rows']) is list and len(contract['rows']) == 1, 'single acquired contract')
    cfg=contract['rows'][0];stats=inspect_objects(cfg,forest)
    need(type(receipt['n']) is int and receipt['n']==cfg['n'] and index==cfg['index'], 'receipt actual index and sample size')
    need(receipt.get('subpanel')==forest.get('subpanel'), 'same receipt subpanel')
    need(all(type(receipt['statistics'][key]) is int for key in ('nodes','leaves','maximum_depth')), 'typed receipt counts')
    need(type(receipt['fresh_leaf_evaluations']) is int, 'typed actual leaf evaluations')
    need(receipt['statistics'] == stats, 'all native geometry statistics')
    need(receipt['fresh_leaf_evaluations'] == stats['leaves'], 'native fresh-leaf accounting')
    need(receipt['forest_sha256'] == digest(forest_path), 'receipt binds forest')
    for obj in (receipt,forest):
        need(obj['contract_sha256'] == digest(contract_path), 'original contract identity')
        need(obj['checker_sha256'] == digest(protocol_path), 'original checker identity')
        need(obj['kernel_sha256'] == read(directory/'KERNEL_COPY_MANIFEST.json')['files'], 'exact kernel manifest')
        for name,h in obj['kernel_sha256'].items():
            need(Path(name).name == name and digest(directory/name) == h, 'actual local kernel bytes')
    controls=receipt['negative_controls']
    need(type(controls) is list and len(controls) == (27 if 'subpanel' in forest else 24) and len(set(controls)) == len(controls), 'recorded native mutation controls')
    return dict(status='PASS_INDEPENDENT_GEOMETRY_AND_RECEIPT_IDENTITY_NOT_ARITHMETIC_REPLAY',n=cfg['n'],index=index,
        p=cfg['p'],subpanel=forest.get('subpanel'),statistics=stats,
        receipt=str(receipt_path.resolve()),receipt_sha256=digest(receipt_path),forest_sha256=digest(forest_path),
        contract_sha256=digest(contract_path),checker_sha256=digest(protocol_path),
        inherited_analytic_and_resource_premises=True)

if __name__ == '__main__':
    need(sys.flags.dont_write_bytecode and not sys.flags.optimize and len(sys.argv)==3,'ordinary -B receipt output')
    result=inspect_capsule(Path(sys.argv[1]))
    result['geometry_source_sha256']=digest(Path(__file__))
    with Path(sys.argv[2]).open('x') as out:
        json.dump(result,out,indent=2);out.write('\n')
    print(result['status'],result['index'],result['statistics']['leaves'])
