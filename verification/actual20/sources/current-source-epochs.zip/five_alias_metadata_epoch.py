"""Preserve all five exact f587 library aliases before the source registry.

Remaining operations never run the original five aliases' historical main.
The separate CURRENT_PARENT driver replaces only that transport block. All
library math/control functions and every original alias stay byte-identical.
References.add/substitutions and every general ambiguity guard remain exact.
"""
from contextlib import contextmanager
from hashlib import sha256
from pathlib import Path
import ast,importlib.util,io,re,tokenize

SOURCE_SHA='f58735273e2a8cbc87409e3785ed221c78d7c3d8d99e10c45627ea35ca8d3c74'
BATCH_SHA='3c8f2ca68230581aef6afaa9536e2e1b4e82c350cf90b7fb4b8b07e6fd3cda7c'
CONTEXT_SHA='7ac3c24146e583dd6376c9c0ec9b4be675b510d0204d66495a8c92d1f8f4be7f'
ORIGINAL_EPOCH_SHA='c3c9f65e354b237d64f2b60658dedbacaf176e1f568da40377e648f52e8de37d'
ADAPTER_SHA='9c073dd2383a7072a9df2c7bd2fa6e6176260296e775b966b7a11e205e9e73be'
FULL_SHA='cea65c32f87602c32efe7c386fd3d02bc030dd40016450ba670cc0d17375605c'
ALIASES=(
 'work/continuation_cutoff20_20261016/b0/bridge_counts_v1/coupled_math.py',
 'work/continuation_cutoff20_20261016/b0/bridge_counts_v2/coupled_math.py',
 'work/continuation_cutoff20_20261016/b0/bridge_counts_v3/coupled_math.py',
 'work/cutoff20_20261016/finite/coupled_noise_all_v1/helper.py',
 'work/cutoff20_20261016/root/coupled_noise_v1/check.py',
)
HEX=re.compile(r'[0-9a-f]{64}\Z')
def need(ok,message):
 if not ok:raise ValueError(message)
def h(raw):return sha256(raw).hexdigest()
def batch():
 path=Path(__file__).with_name('closed_metadata_epoch.py');need(h(path.read_bytes())==BATCH_SHA,'Exact approved closed batch port before import')
 spec=importlib.util.spec_from_file_location('five_alias_approved_batch',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 need(module.CONTEXT_SHA==CONTEXT_SHA and module.ORIGINAL_EPOCH_SHA==ORIGINAL_EPOCH_SHA,'Same whole old guard and reviewed contexts')
 return module
def contexts():return batch().contexts()
def unchanged_alias(current,original):
 """Accept only the exact whole original or its three admitted SHA-token epoch."""
 need(type(current)is bytes and type(original)is bytes and h(original)==SOURCE_SHA,'One exact original library')
 if current==original:return dict(previous_sha256=SOURCE_SHA,restored_sha256=SOURCE_SHA,restored=False,literal_restorations=[])
 need(len(current)==len(original),'Only equal-width SHA-reference derivatives can be restored')
 api=batch();row=api.contexts()[SOURCE_SHA];_,closed=api.validate_context(original,row)
 text=current.decode('utf-8');lines=text.splitlines(keepends=True);starts=[];offset=0
 for line in lines:starts.append(offset);offset+=len(line)
 edits=[]
 for token in tokenize.generate_tokens(io.StringIO(text).readline):
  if token.type!=tokenize.STRING or token.start not in closed:continue
  value=ast.literal_eval(token.string);need(type(value)is str and HEX.fullmatch(value),'Only exact metadata SHA values at three closed positions')
  original_value=closed[token.start]
  need(token.string in(repr(value),'"'+value+'"'),'Original simple quote convention')
  a,b=token.start,token.end;start,end=starts[a[0]-1]+a[1],starts[b[0]-1]+b[1]
  edits.append((start,end,token.string[0]+original_value+token.string[-1],value,original_value,a[0],a[1]))
 need(len(edits)==3,'All and only the three complete original metadata token positions')
 reverse=text
 for start,end,replacement,*_ in reversed(edits):reverse=reverse[:start]+replacement+reverse[end:]
 need(reverse.encode('utf-8')==original,'Whole byte-exact inverse, every import/math/control/branch/guard/comment unchanged')
 restored=ast.parse(reverse);need(ast.dump(restored,include_attributes=False)==ast.dump(ast.parse(original),include_attributes=False),'Whole exact restored module AST')
 return dict(previous_sha256=h(current),restored_sha256=SOURCE_SHA,restored=True,
  literal_restorations=[dict(line=e[5],column=e[6],previous=e[3],original=e[4])for e in edits if e[3]!=e[4]],
  whole_module_byte_inverse_verified=True,all_mathematical_and_control_functions_exact=True)
def restore(task,full):
 task=Path(task);rows=full.original_files(task)
 need({name for name,row in rows.items()if row['sha256']==SOURCE_SHA}==set(ALIASES),'All and only five exact registered aliases of this library')
 changes={};reports={}
 for name in ALIASES:
  row=rows[name];original=(task/row['location']/name).read_bytes();path=task/'capsule'/name
  need(len(original)==row['bytes']and h(original)==SOURCE_SHA and path.is_file()and not path.is_symlink(),'Whole pinned original and current ordinary alias')
  current=path.read_bytes();report=unchanged_alias(current,original)
  if current!=original:
   path.write_bytes(original);need(path.read_bytes()==original,'Exact restored source alias before any reference registry')
   changes[name]=SOURCE_SHA;reports[name]=dict(schema='CURRENT20_FIVE_EXACT_LIBRARY_ALIAS_RESTORATION_V3',**report,
    original_alias=name,original_historical_main_not_executed_by_remaining_actions=True,
    distinct_current_parent_driver_replaces_old_main_transport=True,mathematical_source_body_changed=False,historical_execution_relabelled=False,
    reference_ambiguity_guard_changed=False,actual_ambiguity_cause_proven_by_this_source_only=False)
 return changes,reports
def preflight(sources,*,delegate):
 report=batch().preflight(sources,delegate=delegate)
 return dict(report,source_epoch_preserves_all_five_aliases_byte_exact=True,five_library_source_sha256=SOURCE_SHA,
  actual_reference_registry_ambiguity_not_assumed=True)
@contextmanager
def install(epoch,adapter,full):
 """Only the new ordinal>=31 adapter enters this explicit source context."""
 need(h(Path(epoch.__file__).read_bytes())==ORIGINAL_EPOCH_SHA and h(Path(adapter.__file__).read_bytes())==ADAPTER_SHA
      and h(Path(full.__file__).read_bytes())==FULL_SHA,'Exact old guard, epoch loop and full mathematical reader source')
 api=batch();old_changes=adapter.epoch_changes
 need(old_changes.__name__=='epoch_changes','One unchanged original epoch loop, no nested replacement')
 before_registry_methods=(epoch.References.add,epoch.References.substitutions,epoch.References.graph)
 with api.install(epoch):
  old_rewrite=epoch.rewrite_reference_literals
  def preserve(original,substitutions):
   if h(original)!=SOURCE_SHA:return old_rewrite(original,substitutions)
   # This is an explicit library-only transport epoch. No historical main
   # premise is promoted; the actual conditional parent uses a distinct driver.
   api.validate_context(original,api.contexts()[SOURCE_SHA])
   return original,dict(schema='CURRENT20_FIVE_LIBRARY_ALIASES_PRESERVED_EXACT_V3',original_sha256=SOURCE_SHA,current_sha256=SOURCE_SHA,
    literal_edits=[],registered_historical_main_metadata_not_applied=sorted(substitutions),
    original_main_is_not_remaining_execution_entry=True,distinct_current_parent_driver_required=True,
    mathematical_source_body_changed=False,historical_identity_impersonated=False,original_mathematical_code_executed=False,
    original_registry_and_ambiguity_guard_unchanged=True)
  def epoch_changes(task,state):
   changes,reports=restore(task,full) # Must precede the first old _reference_map.
   result=old_changes(task,state)
   need(type(result)is dict and result['mathematical_source_body_changed']is False,'Same whole original epoch result')
   files=dict(changes);out_reports=dict(reports)
   for name,pin in result['files_sha256'].items():need(name not in files or files[name]==pin,'No conflicting alias rewrite');files[name]=pin
   for name,report in result['reports'].items():need(name not in out_reports,'Restoration report cannot be overwritten');out_reports[name]=report
   for name in ALIASES:need(h((Path(task)/'capsule'/name).read_bytes())==SOURCE_SHA,'All five aliases still exact after original fixed point')
   return dict(result,files_sha256=files,reports=out_reports)
  epoch.rewrite_reference_literals=preserve;adapter.epoch_changes=epoch_changes
  try:yield
  finally:
   need(epoch.rewrite_reference_literals is preserve and adapter.epoch_changes is epoch_changes,'No concurrent override')
   epoch.rewrite_reference_literals=old_rewrite;adapter.epoch_changes=old_changes
   need(before_registry_methods==(epoch.References.add,epoch.References.substitutions,epoch.References.graph),'Every original registry/ambiguity method unchanged')
   need(h(Path(epoch.__file__).read_bytes())==ORIGINAL_EPOCH_SHA and h(Path(adapter.__file__).read_bytes())==ADAPTER_SHA
        and h(Path(full.__file__).read_bytes())==FULL_SHA,'Whole original modules unchanged through source restoration')
