"""Ten closed original source identities; no change to the general SHA guard.

Only reviewed metadata literals outside that guard are extended. Their exact
whole source, positions and entire definition/use statements are frozen. Every
other literal delegates to the unchanged original guard. No math code is run.
"""
from contextlib import contextmanager
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import ast,io,json,re,tokenize

ORIGINAL_EPOCH_SHA='c3c9f65e354b237d64f2b60658dedbacaf176e1f568da40377e648f52e8de37d'
CONTEXT_SHA='7ac3c24146e583dd6376c9c0ec9b4be675b510d0204d66495a8c92d1f8f4be7f'
HEX=re.compile(r'[0-9a-f]{64}\Z')

def need(ok,message):
 if not ok:raise ValueError(message)
def h(raw):return sha256(raw).hexdigest()
def norm(node):return ast.dump(node,include_attributes=False)
def statement(node,parents):
 while node in parents and not isinstance(node,ast.stmt):node=parents[node]
 return node
def contexts():
 raw=Path(__file__).with_name('CLOSED-METADATA-CONTEXTS.json').read_bytes()
 need(h(raw)==CONTEXT_SHA,'Exact complete manually reviewed closed metadata definitions/uses')
 value=json.loads(raw)
 need(value['schema']=='CURRENT20_CLOSED_METADATA_CONTEXTS_V2'and value['old_general_guard_changed']is False
      and len(value['sources'])==10,'Ten complete closed source identities')
 return value['sources']

def validate_context(original,row):
 tree=ast.parse(original);parents={child:parent for parent in ast.walk(tree)for child in ast.iter_child_nodes(parent)}
 expected={(r['line'],r['column']):r['value']for r in row['literals']}
 constants={(n.lineno,n.col_offset):n for n in ast.walk(tree)if isinstance(n,ast.Constant)}
 need(all(pos in constants and type(constants[pos].value)is str and constants[pos].value==value
          for pos,value in expected.items()),'Every exact closed original SHA token position/value')
 identifier=row['identifier'];uses=[]
 if identifier:
  for node in ast.walk(tree):
   if isinstance(node,ast.Name)and node.id==identifier:
    uses.append(dict(line=node.lineno,column=node.col_offset,context=type(node.ctx).__name__,statement_ast=norm(statement(node,parents))))
 else:
  need(len(expected)==1,'One complete direct b.sha equality guard')
  pos=next(iter(expected));node=constants[pos]
  uses=[dict(line=node.lineno,column=node.col_offset,context='ExactDirectHashGuard',statement_ast=norm(statement(node,parents)))]
 need(sorted(uses,key=lambda r:(r['line'],r['column']))==row['all_definition_uses'],
      'Every complete definition/use is exactly a reviewed hash/graph/identity statement')
 return tree,expected

def rewrite(original,substitutions,*,delegate):
 need(type(original)is bytes and type(substitutions)is dict,'Original immutable source and explicit reference registry')
 for old,new in substitutions.items():
  need(type(old)is str and HEX.fullmatch(old)and type(new)is str and HEX.fullmatch(new)and old!=new,'Exact changed SHA identities only')
 row=contexts().get(h(original))
 if row is None:return delegate(original,substitutions)
 tree,closed=validate_context(original,row)
 blocked_values=set(closed.values())
 # The old guard still validates and rewrites every independently ordinary
 # identity. A blocked value can also occur at an ordinary position; those
 # positions are separately delegated below as single-literal source probes.
 ordinary={old:new for old,new in substitutions.items()if old not in blocked_values}
 base,old_report=delegate(original,ordinary)
 need(old_report.get('mathematical_source_body_changed')is False,'Original general guard handles ordinary identities')
 text=base.decode('utf-8');lines=text.splitlines(keepends=True);starts=[];position=0
 for line in lines:starts.append(position);position+=len(line)
 parents={child:parent for parent in ast.walk(tree)for child in ast.iter_child_nodes(parent)}
 allowed={}
 for node in ast.walk(tree):
  if not isinstance(node,ast.Constant)or type(node.value)is not str or node.value not in substitutions:continue
  pos=(node.lineno,node.col_offset)
  if node.value in blocked_values:
   if pos not in closed:
    # No general new exception: ask the original predicate, from the exact
    # source module bound by install(), about this remaining duplicate use.
    predicate=getattr(delegate,'__globals__',{}).get('_reference_context')
    need(callable(predicate)and predicate(node,parents),'All other duplicate references satisfy the unchanged original guard')
   else:need(closed[pos]==node.value,'Exact closed position and full original metadata context')
  allowed[pos]=node.value
 edits=[]
 for token in tokenize.generate_tokens(io.StringIO(text).readline):
  if token.type!=tokenize.STRING or token.start not in closed and token.start not in allowed:continue
  value=ast.literal_eval(token.string)
  if type(value)is not str or value not in blocked_values or value not in substitutions:continue
  need(token.start in allowed and token.string in(repr(value),'"'+value+'"'),'One simple exact original reference token')
  a,b=token.start,token.end;begin,end=starts[a[0]-1]+a[1],starts[b[0]-1]+b[1]
  edits.append((begin,end,token.string[0]+substitutions[value]+token.string[-1],token.string,value,substitutions[value],a[0],a[1]))
 need(len(edits)==sum(value in blocked_values for value in allowed.values()),'All remaining selected metadata tokens exactly once')
 current=text
 for begin,end,replacement,*_ in reversed(edits):current=current[:begin]+replacement+current[end:]
 reverse=current
 for begin,end,_,token,*_ in reversed(edits):reverse=reverse[:begin]+token+reverse[end:]
 need(reverse.encode('utf-8')==base,'Whole byte-exact inverse of closed edits, all other bytes untouched')
 complete=current;original_text=original.decode('utf-8');need(len(original_text)==len(current),'Only equal-width reference identities')
 original_tokens=list(tokenize.generate_tokens(io.StringIO(original_text).readline))
 for token in reversed(original_tokens):
  if token.type!=tokenize.STRING or token.start not in allowed:continue
  a,b=token.start,token.end;begin,end=starts[a[0]-1]+a[1],starts[b[0]-1]+b[1]
  complete=complete[:begin]+token.string+complete[end:]
 need(complete.encode('utf-8')==original,'Whole byte-exact inverse of ALL ordinary and closed edits')
 expected=deepcopy(tree)
 for node in ast.walk(expected):
  if isinstance(node,ast.Constant)and(node.lineno,node.col_offset)in allowed:node.value=substitutions[allowed[node.lineno,node.col_offset]]
 actual=ast.parse(current)
 need(norm(actual)==norm(expected),'Entire module AST changes only at old-guard or closed metadata SHA tokens')
 # The full inverse includes ordinary edits already checked by the original
 # implementation, and every mathematical/control body outside main is exact.
 before={n.name:norm(n)for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name!='main'}
 after={n.name:norm(n)for n in actual.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name!='main'}
 need(before==after,'All whole mathematical/control functions outside metadata main unchanged')
 output=current.encode('utf-8')
 return output,dict(schema='CURRENT20_CLOSED_BATCH_METADATA_LITERAL_EPOCH_V2',original_sha256=h(original),current_sha256=h(output),
  old_general_guard_report=old_report,closed_contexts_sha256=CONTEXT_SHA,
  literal_edits=[dict(line=e[6],column=e[7],old=e[4],new=e[5])for e in edits],
  complete_definition_use_checked=True,whole_module_AST_and_byte_inverse_verified=True,
  mathematical_source_body_changed=False,historical_identity_impersonated=False,original_mathematical_code_executed=False,
  old_reference_guard_changed=False)

def preflight(sources,*,delegate):
 """Every potential SHA substitution, source-only; no producer or certificate."""
 count=0;reference_sources=0;rows={}
 for name,pin,raw in sources:
  need(type(name)is str and HEX.fullmatch(pin)and h(raw)==pin,'Every complete registered original source in preflight')
  count+=1;rows[name]=pin
  if not re.search(rb'[0-9a-f]{64}',raw):continue
  tree=ast.parse(raw)
  refs={n.value:h(('independent-all-reference-preflight:'+n.value).encode())for n in ast.walk(tree)
        if isinstance(n,ast.Constant)and type(n.value)is str and HEX.fullmatch(n.value)}
  if not refs:continue
  current,report=rewrite(raw,refs,delegate=delegate)
  need(report['mathematical_source_body_changed']is False,'Complete reference-only synthetic source preflight')
  reverse=current
  for old,new in refs.items():reverse=reverse.replace(new.encode(),old.encode())
  need(reverse==raw,'Whole registered source byte inverse for every possible selected reference')
  reference_sources+=1
 return dict(schema='CURRENT20_ALL_REGISTERED_REFERENCE_SUBSTITUTION_PREFLIGHT_V2',
  python_sources=count,reference_sources=reference_sources,registered_python_source_map_sha256=h(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()),
  all_possible_reference_values_tested=True,original_guard_changed=False,mathematical_program_executed=False,
  original_native_calls_repeated=0,mathematical_acceptance=False)

@contextmanager
def install(epoch):
 need(h(Path(epoch.__file__).read_bytes())==ORIGINAL_EPOCH_SHA,'Exact original strict reference module')
 old=epoch.rewrite_reference_literals
 need(old.__name__=='rewrite_reference_literals'and old.__module__==epoch.__name__,'One original source-defined guard, no nested patch')
 def closed(original,substitutions):return rewrite(original,substitutions,delegate=old)
 epoch.rewrite_reference_literals=closed
 try:yield
 finally:
  need(epoch.rewrite_reference_literals is closed,'No conflicting epoch override')
  epoch.rewrite_reference_literals=old
  need(h(Path(epoch.__file__).read_bytes())==ORIGINAL_EPOCH_SHA,'Original whole strict guard source unchanged')
