"""Three closed metadata-copy identities; every native assertion stays intact."""
from pathlib import Path
from hashlib import sha256
import json,re

BASE='work/cutoff20_20261016/'
RELATIONS=(
 dict(document=BASE+'finite/sharp20_b0_resources_all_v1/HELPER_COPY.json',source=BASE+'finite/sharp20_resources_v1/pilot.py',copy=BASE+'finite/sharp20_b0_resources_all_v1/helper.py',
      original='4eebfcddbd51c8d9f844ca18faaa255e61bfe1138ae49f557e762d08fd960886',current='cc975a033bf0ca5e361a1c321ecdd046e20009a98d938d94f3dce895ba8602b6'),
 dict(document=BASE+'finite/feedback20_b0_resources_v1/HELPER_COPY.json',source=BASE+'finite/feedback20_b0_resources_v1/helper_template.py',copy=BASE+'finite/feedback20_b0_resources_v1/helper.py',
      original='ad3fb1fb101a64c4f3be4cd06a1e443f6e3502a5cebb5d69e2f596ffe57d9b4e',current='e142103f7c5c5b0982d47b355d2971fc8741782b001509cfe5d45ade7c1bc4aa'),
 dict(document=BASE+'fourier/narrow_resources_all_v1/HELPER_COPY.json',source=BASE+'fourier/narrow_resources_v1/pilot.py',copy=BASE+'fourier/narrow_resources_all_v1/helper.py',
      original='e126f9e000726335d1bc2aaf296b02cd4d7d881008dd64a8f15a3364d805aa29',current='fc8a4e41131765655dec558335c0d5b5187228e66e8c4c0398fb02fbc4129351'))
def need(ok,message):
 if not ok:raise ValueError(message)
def h(raw):return sha256(raw).hexdigest()
def read(raw):
 def unique(items):
  result={}
  for key,value in items:need(key not in result,'No duplicate copy identity key');result[key]=value
  return result
 return json.loads(raw,object_pairs_hook=unique)
def dump(value):return(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()

def project_relation(row,*,original_source,original_copy,current_source,current_copy,original_document,current_document,substitutions,rewrite):
 """The caller supplies the pinned ORIGINAL rewrite_reference_literals function.

 Its source/function identity is part of the new controller closure. The result
 is only a source-copy identity, never an arithmetic result or parent license.
 """
 need(row in RELATIONS,'One of exactly three declared source/copy pairs')
 need(original_source==original_copy and h(original_source)==row['original'],'Whole original byte-identical source and helper')
 expected,proof=rewrite(original_source,substitutions)
 need(expected==current_source==current_copy and h(expected)==row['current'],'Both current copies equal the exact registered reference-literal projection')
 need(proof.get('mathematical_source_body_changed')is False,'Original source rewrite preserves every mathematical body')
 old=read(original_document);current=read(current_document)
 need(old==dict(source=row['source'],sha256=row['original'])and set(old)=={'source','sha256'},'Exact original two-field copy identity')
 target=dict(old,sha256=h(expected))
 need(current in(old,target)and type(current)is dict and set(current)=={'source','sha256'},'Only the original or this exact already-derived copy pin')
 raw=dump(target)
 return raw,dict(schema='CURRENT20_EXACT_HELPER_COPY_METADATA_EPOCH_V1',document=row['document'],source=row['source'],copy=row['copy'],
  original_source_sha256=row['original'],current_source_and_copy_sha256=h(expected),original_document_sha256=h(original_document),current_document_sha256=h(raw),
  original_literal_projection=proof,native_assertion_removed=False,numerical_source_body_changed=False,mathematical_acceptance=False)

def apply(task,state,full,*,prepared):
 """Use only after the entire unchanged original prepare_action completed."""
 need(type(prepared)is dict and prepared.get('schema')=='ACTUAL20_CURRENT_METADATA_SOURCE_EPOCH_V1','The unchanged original preparation must finish first')
 state=dict(state,additional_derived=sorted(set(state.get('additional_derived',[]))|set(prepared['files_sha256'])))
 task=Path(task);capsule=task/'capsule';rows=full.original_files(task);refs=full.a._reference_map(task,full.Adapter().enriched(task,state))
 substitutions=refs.substitutions();reports={};changes={}
 for row in RELATIONS:
  def original(name):
   descriptor=rows[name];raw=(task/descriptor['location']/name).read_bytes()
   need(len(raw)==descriptor['bytes']and h(raw)==descriptor['sha256'],'Every full original closure byte')
   return raw
  source=original(row['source']);used=set(re.findall(rb'[0-9a-f]{64}',source))
  selected={old:new for old,new in substitutions.items()if old.encode()in used}
  raw,report=project_relation(row,original_source=source,original_copy=original(row['copy']),
   current_source=(capsule/row['source']).read_bytes(),current_copy=(capsule/row['copy']).read_bytes(),
   original_document=original(row['document']),current_document=(capsule/row['document']).read_bytes(),
   substitutions=selected,rewrite=full.a.epoch.rewrite_reference_literals)
  path=capsule/row['document']
  if path.read_bytes()!=raw:path.write_bytes(raw);changes[row['document']]=h(raw)
  reports[row['document']]=report
 return dict(schema='CURRENT20_THREE_CLOSED_HELPER_COPY_EPOCH_V1',files_sha256=changes,relations=reports,
  exactly_three_metadata_relations=True,native_assertions_and_arithmetic_unchanged=True,mathematical_acceptance=False)
