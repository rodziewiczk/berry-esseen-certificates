"""Close ALL123 retained kernels and49views, restoring only five static files.

All mathematical programs, original loaders/manifests, contracts, forests,
receipts and general identity guards remain untouched. The complete observed
source graph, not only the first BN family, is checked before any write.
Only five exact declared SOURCE_TRANSFORM copies under capsule may be added;
authenticated COUNT views under inputs are never modified.
"""
from contextlib import contextmanager
from pathlib import Path,PurePosixPath
from hashlib import sha256
import json
HERE=Path(__file__).resolve().parent
CONTRACT_SHA='f672782cb9a9cd2b13dbbb067aed2505ac16f9db806671817e45cbb2ea9ed015'
TRANSFORM_SHA='5da6ce26255dafad387d566a8620a3549659e834f8aea23f63c0c80d2d8df11c'
ADAPTER_SHA='9c073dd2383a7072a9df2c7bd2fa6e6176260296e775b966b7a11e205e9e73be'
BASE='capsule/work/cutoff20_20261016/fourier/'
MISSING=tuple(BASE+'feedback_bn_remaining_v1/capsule'+str(n)+'/SOURCE_TRANSFORM.json'for n in(39,40,41,45))+(BASE+'feedback_bn_count_v1/capsule42/SOURCE_TRANSFORM.json',)
def need(ok,message):
 if not ok:raise ValueError(message)
def h(raw):return sha256(raw).hexdigest()
def enc(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode('ascii')
def ordinary(path):
 path=Path(path)
 for node in(path,*path.parents):need(not node.is_symlink()and not getattr(node,'is_junction',lambda:False)(),'No symbolic source aliases')
 return path
def file_bytes(path):
 path=ordinary(path);need(path.is_file(),'Complete ordinary static source: '+str(path));return path.read_bytes()
def read(raw):
 def unique(pairs):
  out={}
  for key,value in pairs:need(key not in out,'Unique source JSON fields');out[key]=value
  return out
 return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in()).throw(ValueError('Finite source metadata')))
def source_inputs():
 raw=file_bytes(HERE/'COUNT-SOURCE-CLOSURE.json');need(h(raw)==CONTRACT_SHA,'Whole complete123-kernel49-view source contract')
 data=read(raw);blob=file_bytes(HERE/'SOURCE_TRANSFORM.json')
 need(len(blob)==11401 and h(blob)==TRANSFORM_SHA==data['source_transform_sha256'],'Exact independently retained full source transform')
 rows=data['directories'];need(len(rows)==123 and set(data['count_view_directory_names'])=={str(i)for i in range(49)},'All123 native/source kernels and all49 authenticated view namespaces')
 admitted=set()
 for name,row in rows.items():
  path=PurePosixPath(name)
  need(not path.is_absolute()and'..'not in path.parts and path.as_posix()==name
   and(path.parts[0]=='capsule'or path.parts[:2]==('inputs','counts')),'Only exact original source roots')
  need(row['permitted_initial_missing_source_names']in([],[dict(name='SOURCE_TRANSFORM.json',expected_sha256=TRANSFORM_SHA)]),'No other source omission may be restored')
  admitted.update(name+'/'+r['name']for r in row['permitted_initial_missing_source_names'])
 need(admitted==set(MISSING),'Exactly the five actual omissions, only in writable capsule source')
 return data,blob
def check(task,*,first_new_action=False):
 data,blob=source_inputs();task=ordinary(task);rows=data['directories'];missing=[]
 views=ordinary(task/'inputs/counts');need(views.is_dir()and{p.name for p in views.iterdir()}==set(data['count_view_directory_names'])
  and all(ordinary(p).is_dir()for p in views.iterdir()),'All49 exact COUNT view roots, without omissions or unbound aliases')
 actual={p.parent.relative_to(task).as_posix()for prefix in('capsule','inputs/counts')for p in(task/prefix).rglob('KERNEL_COPY_MANIFEST.json')}
 need(actual==set(rows),'The entire original transitive123-manifest path set, no quietly skipped native family')
 for name,row in rows.items():
  root=ordinary(task/name);need(root.is_dir(),'Every retained mathematical source namespace')
  manifest=file_bytes(root/'KERNEL_COPY_MANIFEST.json')
  need(h(manifest)==row['kernel_manifest_sha256']and read(manifest)['files']==row['source_files'],'Whole original manifest bytes and every source pin')
  need(h(file_bytes(root/'count_protocol.py'))==row['count_protocol_sha256'],'Every exact original retained/view loader')
  for leaf,pin in row['source_files'].items():
   rel=PurePosixPath(leaf);need(rel.name==leaf and leaf not in('.','..')and not rel.is_absolute(),'Literal kernel source basename')
   path=ordinary(root/leaf)
   if not path.exists():
    need(first_new_action and name+'/'+leaf in MISSING and pin==TRANSFORM_SHA
     and dict(name=leaf,expected_sha256=pin)in row['permitted_initial_missing_source_names'],'No missing mathematical or authenticated view source is admitted')
    missing.append(name+'/'+leaf)
   else:need(h(file_bytes(path))==pin,'Every full original helper source: '+name+'/'+leaf)
 need(set(missing)==(set(MISSING)if first_new_action else set()),'Exactly five initial static omissions, then all123 kernels fully closed')
 return data,blob,sorted(missing)
def restore(task,ordinal):
 need(type(ordinal)is int and 37<=ordinal<41,'Only the four original remaining action ordinals')
 data,blob,missing=check(task,first_new_action=ordinal==37);changes={};reports={}
 for name in missing:
  need(name.startswith('capsule/'),'Authenticated view inputs are always read-only')
  path=ordinary(Path(task)/name)
  with path.open('xb')as stream:stream.write(blob)
  need(file_bytes(path)==blob,'Exact missing static source materialized without overwrite')
  relative=PurePosixPath(name).relative_to('capsule').as_posix();changes[relative]=TRANSFORM_SHA
  reports[relative]=dict(schema='CURRENT20_EXACT_DECLARED_STATIC_SOURCE_CLOSURE_V2',source_file=relative,
   previously_missing=True,materialized_sha256=TRANSFORM_SHA,bytes=len(blob),
   original_kernel_manifest_sha256=data['directories'][str(PurePosixPath(name).parent)]['kernel_manifest_sha256'],
   closed_contract_sha256=CONTRACT_SHA,source_only=True,mathematical_source_body_changed=False,numeric_packet_changed=False,
   original_loader_or_manifest_changed=False,historical_execution_relabelled=False,authenticated_COUNT_view_modified=False)
 check(task)
 verification=dict(schema='CURRENT20_ALL123_WHOLE_ORIGINAL_KERNEL_CLOSURES49VIEWS_V2',closed_contract_sha256=CONTRACT_SHA,
  source_transform_sha256=TRANSFORM_SHA,whole_kernel_manifest_path_map_sha256=h(enc({n:r['kernel_manifest_sha256']for n,r in data['directories'].items()})),
  all_retained_kernel_namespaces=123,all_authenticated_COUNT_views=49,new_static_source_files=missing,
  original_loader_manifest_and_guards_unchanged=True,all_transitive_source_closures_checked=True,
  authenticated_COUNT_views_modified=False,native_arithmetic_executed_by_this_port=False)
 return changes,reports,verification
@contextmanager
def install(adapter,task,ordinal):
 need(h(file_bytes(adapter.__file__))==ADAPTER_SHA,'Exact old epoch implementation before closed source restoration')
 original=adapter.epoch_changes;need(original.__name__=='epoch_changes','One unchanged original epoch, no concurrent port')
 def epoch_changes(actual_task,state):
  need(Path(actual_task)==Path(task)and len(state['actions'])==ordinal,'One exact new action source context')
  changes,reports,verification=restore(actual_task,ordinal);result=original(actual_task,state)
  need(type(result)is dict and result['mathematical_source_body_changed']is False,'Entire unchanged original epoch result')
  files=dict(changes);out=dict(reports)
  for name,pin in result['files_sha256'].items():need(name not in files or files[name]==pin,'No static source rewrite');files[name]=pin
  for name,row in result['reports'].items():need(name not in out,'No static source report overwritten');out[name]=row
  check(actual_task)
  return dict(result,files_sha256=files,reports=out,exact_count_source_closure=verification)
 adapter.epoch_changes=epoch_changes
 try:yield
 finally:
  need(adapter.epoch_changes is epoch_changes,'No concurrent source context override');adapter.epoch_changes=original
  need(h(file_bytes(adapter.__file__))==ADAPTER_SHA,'Whole original source epoch remains unchanged')
