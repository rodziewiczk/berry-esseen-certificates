"""Three closed PREPARED identities in one exact original coupled library.

The old reference guard is not changed. Every other source/literal delegates
to it. This extension is restricted to the whole f587 source, three literal
positions and the complete metadata-only definition/use of lowercase pin.
No arithmetic/control/function body is relaxed or executed by this module.
"""
from contextlib import contextmanager
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import ast
import io
import re
import tokenize

SOURCE_SHA = 'f58735273e2a8cbc87409e3785ed221c78d7c3d8d99e10c45627ea35ca8d3c74'
ORIGINAL_EPOCH_SHA = 'c3c9f65e354b237d64f2b60658deDbacaf176e1f568da40377e648f52e8de37d'.lower()
HEX = re.compile(r'[0-9a-f]{64}\Z')
LITERALS = {
    (99,16): 'c9a8e9cf30c7b5da465d3e84a94a02c959a7bd471c36e925653f31082a61551d',
    (102,20): 'c051ecd4e1c8f5925845a3786f9bd183ce962e8e29a14c302568836f75a10a7a',
    (102,90): '44b16c79bf56bc34a8108f4cbd9377f750e0bb0d6d018fa32de32d7af1095bed',
}


def need(ok,message):
    if not ok:raise ValueError(message)


def h(raw):return sha256(raw).hexdigest()


def normalized(node):return ast.dump(node,include_attributes=False)


def validate_closed_context(original):
    need(type(original)is bytes and h(original)==SOURCE_SHA,'One whole exact original coupled source')
    tree=ast.parse(original)
    main=next(node for node in tree.body if isinstance(node,ast.FunctionDef)and node.name=='main')
    parents={child:parent for parent in ast.walk(tree)for child in ast.iter_child_nodes(parent)}
    pins=[node for node in ast.walk(tree)if isinstance(node,ast.Name)and node.id=='pin']
    need(sorted((type(node.ctx).__name__,node.lineno,node.col_offset)for node in pins)
         == [('Load',103,28),('Load',105,47),('Store',99,12),('Store',102,12)],
         'Every pin definition and use is confined to the exact original metadata sequence')
    assignments=[parents[node]for node in pins if isinstance(node.ctx,ast.Store)]
    expected=[ast.parse("pin='"+LITERALS[99,16]+"'").body[0],
              ast.parse("pin={37:'"+LITERALS[102,20]+"',42:'"+LITERALS[102,90]+"'}[i]").body[0]]
    need(sorted(normalized(node)for node in assignments)==sorted(normalized(node)for node in expected),
         'Only the literal B0 preparation and finite BN37/42 preparation table')
    guard=ast.parse("need(sha(preppath)==pin,'pinned preparation')").body[0]
    graph=ast.parse('graph[str(preppath.relative_to(ROOT))]=pin').body[0]
    for node in pins:
        if not isinstance(node.ctx,ast.Load):continue
        cursor=node
        while not isinstance(cursor,(ast.Expr,ast.Assign)):
            cursor=parents[cursor]
        need(normalized(cursor)in(normalized(guard),normalized(graph)),
             'Only the exact complete hash equality guard or metadata graph-value assignment uses pin')
    found={(node.lineno,node.col_offset):node.value for node in ast.walk(main)
           if isinstance(node,ast.Constant)and type(node.value)is str and HEX.fullmatch(node.value)}
    need(found==LITERALS,'All and only the three complete reference literals in original main')
    return tree


def rewrite(original,substitutions,*,delegate):
    """Keep the original guard for all other sources and all other literals."""
    if h(original)!=SOURCE_SHA:return delegate(original,substitutions)
    tree=validate_closed_context(original)
    need(type(substitutions)is dict,'Exact externally registered reference substitution map')
    for old,new in substitutions.items():
        need(type(old)is str and HEX.fullmatch(old)and type(new)is str and HEX.fullmatch(new)and old!=new,
             'Changed exact SHA256 identities only')
    ordinary={old:new for old,new in substitutions.items()if old not in LITERALS.values()}
    base,previous=delegate(original,ordinary)
    need(base==original and previous.get('mathematical_source_body_changed')is False,
         'The unchanged original guard handles every remaining literal')
    text=base.decode('utf-8');lines=text.splitlines(keepends=True);starts=[];position=0
    for line in lines:starts.append(position);position+=len(line)
    edits=[]
    for token in tokenize.generate_tokens(io.StringIO(text).readline):
        if token.type!=tokenize.STRING or token.start not in LITERALS:continue
        old=LITERALS[token.start]
        need(ast.literal_eval(token.string)==old and token.string in(repr(old),'"'+old+'"'),
             'One exact simple original reference token')
        if old not in substitutions:continue
        a,b=token.start,token.end;begin,end=starts[a[0]-1]+a[1],starts[b[0]-1]+b[1]
        new=substitutions[old];replacement=token.string[0]+new+token.string[-1]
        edits.append((begin,end,replacement,token.string,old,new,a[0],a[1]))
    need(len(edits)==sum(old in substitutions for old in LITERALS.values()),'Every selected closed token exactly once')
    current=text
    for begin,end,replacement,*_ in reversed(edits):current=current[:begin]+replacement+current[end:]
    reverse=current
    for begin,end,_,token,*_ in reversed(edits):reverse=reverse[:begin]+token+reverse[end:]
    need(reverse.encode('utf-8')==original,'Whole byte-exact inverse, including every guard/import/control/comment')
    expected=deepcopy(tree)
    for node in ast.walk(expected):
        if isinstance(node,ast.Constant)and(node.lineno,node.col_offset)in LITERALS and node.value in substitutions:
            node.value=substitutions[node.value]
    actual=ast.parse(current)
    need(normalized(actual)==normalized(expected),'Entire module AST changes only in three admitted metadata identities')
    before={n.name:normalized(n)for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name!='main'}
    after={n.name:normalized(n)for n in actual.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name!='main'}
    need(before==after,'Every whole mathematical and control function is identical')
    output=current.encode('utf-8')
    return output,dict(schema='CURRENT20_EXACT_THREE_PREPARED_PIN_LITERAL_EPOCH_V1',
        original_sha256=SOURCE_SHA,current_sha256=h(output),
        literal_edits=[dict(line=e[6],column=e[7],old=e[4],new=e[5])for e in edits],
        whole_pin_definition_use_checked=True,whole_module_byte_inverse_verified=True,
        mathematical_source_body_changed=False,historical_identity_impersonated=False,
        original_mathematical_code_executed=False,old_reference_guard_changed=False)


@contextmanager
def install(epoch):
    """Use only for newly interpreted actions; historical adapters stay exact."""
    need(h(Path(epoch.__file__).read_bytes())==ORIGINAL_EPOCH_SHA,'Exact original strict reference infrastructure before patch')
    old=epoch.rewrite_reference_literals
    need(old.__name__=='rewrite_reference_literals'and old.__module__==epoch.__name__,
         'Actual original source-defined rewrite entry, no nested override')
    def closed(original,substitutions):return rewrite(original,substitutions,delegate=old)
    epoch.rewrite_reference_literals=closed
    try:yield
    finally:
        need(epoch.rewrite_reference_literals is closed,'No concurrent or conflicting rewrite patch')
        epoch.rewrite_reference_literals=old
        need(h(Path(epoch.__file__).read_bytes())==ORIGINAL_EPOCH_SHA,'Whole original guard source remains unchanged')
