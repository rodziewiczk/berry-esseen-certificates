"""Wait for actual cgroup readback before exec; no mathematical work before gate."""
from pathlib import Path
import json,os,sys,time
gate=Path(sys.argv[1]);deadline=float(sys.argv[2]);argv=sys.argv[3:]
if not __debug__ or not argv or not Path(argv[0]).is_absolute():raise RuntimeError('Invalid reviewed-source service entry')
until=min(time.time()+15,deadline)
while not gate.exists():
    if time.time()>=until:raise RuntimeError('Cgroup gate was not licensed in time')
    time.sleep(.05)
record=json.loads(gate.read_text())
if record.get('actual_cgroup_verified')is not True or time.time()>=deadline:raise RuntimeError('Cgroup admission refused')
os.execv(argv[0],argv)
