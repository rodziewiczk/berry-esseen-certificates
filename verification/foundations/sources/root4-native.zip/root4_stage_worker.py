"""Source-exact two-pass ROOT4 entry for the external whole-cgroup transaction.

No old receipt is an input. Original source guards, seccomp guard and terminal
validation all remain active. An accepted physical-class bound still requires
the analytic n3/localization parents to become an unrestricted C4 theorem.
"""
from pathlib import Path
import argparse
import importlib
import math
import sys
import time
import count69_batch as common

HERE = Path(__file__).resolve().parent
SNAPSHOT = HERE / "snapshot"
ROOT4_SHA = "c98366a00cd2f13d8f51ad150fa5a51b7d8b67776f4583686c636d53e6e8de39"
EPOCH_SHA = "63f409204df8b1a786ce049dfdd1868f6b7fb736fc4053729b228f7675ce3a90"


def implementation():
    common.need(common.file_sha(SNAPSHOT / "be_replay/root4.py") == ROOT4_SHA,
                "root4_port_pin", "Exact reviewed complete two-pass source controller")
    sys.path.insert(0, str(SNAPSHOT))
    module = importlib.import_module("be_replay.root4")
    common.need(Path(module.__file__).resolve() == (SNAPSHOT / "be_replay/root4.py").resolve()
                and module.EPOCH_SHA256 == EPOCH_SHA, "root4_import_binding", "Qualified original port and73-source resource epoch")
    return module


def validate_result(module, output, result):
    common.need(result.get("schema") == "ROOT4_TWO_FRESH_FULL_PASSES_V1"
                and result.get("source_epoch_sha256") == EPOCH_SHA
                and result.get("all_required_stages_computed") is True
                and len(result.get("stages", [])) == 2,
                "root4_full_passes", "Both complete actual native passes, not a previous status label")
    capsule = Path(output) / "capsule"; module.verify_capsule(capsule)
    candidate = capsule / module.OUTPUT_NAME
    common.need(candidate.is_file() and not candidate.is_symlink()
                and candidate.stat().st_size <= 48 * common.MIB, "root4_actual_candidate", "Actual complete fresh ROOT4 artifact")
    candidate_pin = common.file_sha(candidate); checked = []
    for name, row in zip(("produce", "replay"), result["stages"]):
        common.need(row.get("stage") == name and row.get("completed") is True
                    and row.get("native_guard_verified") is True
                    and row.get("receipt_sha256") == candidate_pin,
                    "root4_stage_binding", "Actual fresh producer and byte-preserving replay")
        observation = row["observed"]
        common.need(module.guard_verified(observation, capsule), "root4_inner_guard", "Original guard still enforced, never replaced by a Boolean")
        terminal = module.terminal_packet(observation)
        common.need(terminal == row["terminal_result"], "root4_actual_capture", "Reopened actual observed native output")
        checked.append(module.validate_terminal(terminal, name, capsule))
    common.need(checked[0]["summary"] == checked[1]["summary"]
                and checked[0]["root_bound_exact"] == checked[1]["root_bound_exact"],
                "root4_replay_agreement", "All full mathematical outputs agree")
    closed = all(row["conditional_target_closed"] for row in checked)
    common.need(result.get("conditional_physical_root_verified") is closed
                and result.get("all_law_C4_verified") is False,
                "root4_conditional_scope", "Physical-class result only; analytic parents remain explicit")
    return dict(candidate_sha256=candidate_pin, candidate_bytes=candidate.stat().st_size,
                root_bound_exact=checked[1]["root_bound_exact"], conditional_physical_target_closed=closed,
                parents_per_pass=260, high_slots_per_pass=1300,
                unresolved_geometry_indices=checked[1]["unresolved_geometry_indices"])


def run(task, *, campaign_id, runtime_profile_digest, deadline, wall_seconds=54000):
    common.need(sys.platform == "linux" and __debug__ and sys.dont_write_bytecode,
                "root4_linux_worker", "Unoptimized no-bytecode actual Linux execution")
    common.need(type(deadline) in (int, float) and math.isfinite(deadline)
                and deadline - time.time() > 120 and type(wall_seconds) is int and 1 <= wall_seconds <= 54000,
                "root4_deadline", "Explicit immutable campaign cutoff and cleanup reserve")
    common.need(type(campaign_id) is str and campaign_id
                and type(runtime_profile_digest) is str and len(runtime_profile_digest) == 64
                and all(c in "0123456789abcdef" for c in runtime_profile_digest),
                "root4_campaign", "Current campaign and externally authenticated runtime profile")
    task = Path(task).resolve(); sidecar = task.parent / (task.name + ".ROOT4-CONTROLLER-OBSERVATION.json")
    common.need(not task.exists() and not sidecar.exists(), "root4_fresh_transaction", "Separate fresh two-pass task")
    module = implementation(); module.verify_frozen()
    own_pin = common.file_sha(__file__); source_pin = common.file_sha(module.__file__)
    wall = min(wall_seconds, int(deadline - time.time() - 120))
    result = module.run(task, wall_seconds=wall)
    module.verify_frozen(); checked = validate_result(module, task, result)
    common.need(common.file_sha(__file__) == own_pin and common.file_sha(module.__file__) == source_pin,
                "root4_controller_changed", "Immutable reviewed source throughout both passes")
    packet = dict(schema="be.root4-whole-cgroup-controller-observation/1", campaign_id=campaign_id,
                  source_epoch_sha256=EPOCH_SHA, root4_port_sha256=source_pin, implementation_sha256=own_pin,
                  runtime_profile_digest=runtime_profile_digest, absolute_deadline=deadline,
                  inner_wall_seconds_per_pass=wall, result_sha256=common.file_sha(task / "ROOT4_RESULT.json"),
                  checked=checked, whole_cgroup_runtime_seal_required=True,
                  required_math_parents=["strong_n3_upper_bound", "canonical_Q3_physical_class_localization_and_eta_defect_semantics"],
                  outcome="CONDITIONAL_ROOT4_TWO_FRESH_FULL_PASSES_COMPLETED" if checked["conditional_physical_target_closed"]
                          else "ROOT4_TWO_FULL_PASSES_UNRESOLVED",
                  all_law_C4_verified=False, full_proof_pass=False)
    sidecar.write_bytes(common.encoded(packet)); return packet


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--task", type=Path, required=True); p.add_argument("--campaign-id", required=True)
    p.add_argument("--runtime-profile-digest", required=True); p.add_argument("--deadline", type=float, required=True)
    p.add_argument("--wall-seconds", type=int, default=54000)
    args = p.parse_args(); result = run(args.task, campaign_id=args.campaign_id,
        runtime_profile_digest=args.runtime_profile_digest, deadline=args.deadline, wall_seconds=args.wall_seconds)
    print(common.encoded(dict(outcome=result["outcome"], full_proof_pass=False)).decode(), flush=True)
