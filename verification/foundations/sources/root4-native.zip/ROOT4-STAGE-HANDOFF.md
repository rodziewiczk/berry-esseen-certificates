# Fresh full ROOT4 transaction

`root4_stage_worker.py` is a small metadata/admission port around the unchanged
reviewed `be_replay.root4.run`. It does not replace any guard, modify any
mathematical function, use an old result, or promote a retained Boolean. The
source controller is pinned at
`c98366a00cd2f13d8f51ad150fa5a51b7d8b67776f4583686c636d53e6e8de39`.
Its73 original Python sources are validated and deterministically derive the
already reviewed Linux resource-only epoch
`63f409204df8b1a786ce049dfdd1868f6b7fb736fc4053729b228f7675ce3a90`.

Run one independent whole-cgroup transaction:

```text
python -B -S root4_stage_worker.py --task FRESH_TASK --campaign-id CAMPAIGN \
  --runtime-profile-digest AUTHENTICATED_RUNTIME_DIGEST \
  --deadline ABSOLUTE_CAMPAIGN_UNIX_DEADLINE --wall-seconds 54000
```

The wrapper computes `min(requested_wall, remaining_campaign_time-120)` as the
inner allowance per pass. The external cgroup's wall limit and immutable
campaign deadline dominate the complete process tree and both passes together.
Recommended outer reservation is one CPU, 1 GiB RAM, file limit64 MiB, swap0,
bounded logs and confirmed empty-cgroup cleanup. ROOT4 can produce a JSON
artifact up to48 MiB: the old resource-driver16 MiB file cap is insufficient.

The native controller executes **both** complete original passes. Each
recomputes all260 geometry parents and1300 HIGH request slots. Produce starts
without the result; replay recomputes and compares all nonresource mathematical
fields, and cannot rewrite any checkpoint. The original Linux seccomp guard
remains required, including its actual source identity and split320 MiB total
address-space and43230 CPU-second limits. The outer cgroup adds a complete-tree
reservation and campaign cutoff; it does not substitute fake inner guard
fields or remove the native64 MiB HIGH /256 MiB process gates.

After `run`, the new wrapper revalidates the original private capsule and
reopens both actual stdout/stderr captures through `terminal_packet`, then
calls the original `guard_verified` and `validate_terminal`. It checks the
same complete result bytes, both receipts, full summary agreement, scope,
counts and resources. Closed numerical success means **weak** score bound
`C4_physical <= 4097/10000`, not an invented strict margin below that value.
An unresolved parent index or an excessive bound remains explicitly unresolved.

The new observation is a sibling of the native task:
`TASK.ROOT4-CONTROLLER-OBSERVATION.json`. Nothing is appended to the native
source inventory. It binds the source epoch, wrapper/controller digests,
campaign/runtime context, reopened result/candidate digests and actual260/1300
counts. Its conditional outcome is
`CONDITIONAL_ROOT4_TWO_FRESH_FULL_PASSES_COMPLETED` only if both full passes
close the target; otherwise it is `ROOT4_TWO_FULL_PASSES_UNRESOLVED`.

The observation requires authenticated whole-cgroup/source/runtime readback and
an approved current job map. It separately lists `strong_n3_upper_bound` and
the canonical-Q3 physical-class localization/eta-defect analytic premises.
Neither `all_law_C4_verified` nor `full_proof_pass` is set true. An unrestricted
C4 provider is assembled later from those exact mathematical parents. This
transaction can execute before those parents are available and retain its
conditional numerical result without pretending the dependency has vanished.
