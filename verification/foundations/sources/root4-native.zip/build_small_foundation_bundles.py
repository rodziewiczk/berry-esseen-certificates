"""Deterministic source-only bundles; no historical acceptance or binary."""
from pathlib import Path
import json
import zipfile
import count69_batch as common

ROOT = Path(__file__).resolve().parent


def build(kind, names):
    files = {name: common.regular(ROOT / name, 16 * common.MIB) for name in sorted(set(names))}
    record = dict(schema="be.foundation-source-bundle/1", family=kind, source_only=True,
                  historical_acceptance_staged=False, prebuilt_binary_staged=False, full_proof_pass=False,
                  files={name: dict(bytes=len(body), sha256=common.sha(body)) for name, body in files.items()})
    manifest_name = kind.upper().replace("-", "_") + "-BUNDLE-MANIFEST.json"
    raw = common.encoded(record); (ROOT / manifest_name).write_bytes(raw); files[manifest_name] = raw
    output = ROOT / (kind + "-source.zip")
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, body in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 25, 0, 0, 0)); info.create_system = 3
            info.external_attr = 0o100644 << 16; info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, body)
    return dict(archive=output.name, bytes=output.stat().st_size, sha256=common.file_sha(output),
                manifest_sha256=common.sha(raw), files=len(files))


def main():
    root4 = ["count69_batch.py", "root4_stage_worker.py", "ROOT4-STAGE-HANDOFF.md", "build_small_foundation_bundles.py"]
    root4 += ["snapshot/be_replay/" + name for name in ("__init__.py", "root4.py", "linux_supervisor.py", "colab_batch.py")]
    root4 += [path.relative_to(ROOT).as_posix() for path in (ROOT / "snapshot/vendor/root4_75a9470").rglob("*") if path.is_file()]
    small = ["count69_batch.py", "small_indices_worker.py", "small_toolchain.py", "SMALL-INDICES-HANDOFF.md",
             "test_small_indices_worker.py", "build_small_foundation_bundles.py"]
    small += [path.relative_to(ROOT).as_posix() for path in (ROOT / "snapshot/vendor/n2_n3_75a9470").rglob("*") if path.is_file()]
    print(json.dumps([build("root4-stage", root4), build("small-indices", small)], indent=2))


if __name__ == "__main__": main()
