"""One source-bound conditional resource transaction inside a whole cgroup.

This is a finite campaign adapter for reviewed sources, not a hostile-code sandbox.
It never exports all-law or global proof acceptance.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys,time,uuid

def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode('ascii')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def command(args,**kwargs):return subprocess.run(args,stdin=subprocess.DEVNULL,capture_output=True,check=True,**kwargs)
def micros(value):
    result=0;units={'h':3600000000,'min':60000000,'s':1000000,'ms':1000,'us':1}
    for word in value.split():
        m=re.fullmatch(r'(\d+)(h|min|ms|us|s)',word)
        if not m:raise RuntimeError('Unsupported systemd time readback')
        result+=int(m[1])*units[m[2]]
    return result
def main():
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--task-id',required=True);p.add_argument('--campaign',required=True);p.add_argument('--deadline',type=float,required=True);p.add_argument('--wall',type=int,default=54000);p.add_argument('--memory',type=int,default=1024**3);p.add_argument('--cache',type=Path);p.add_argument('--dependencies',type=Path);p.add_argument('--archives',type=Path)
    a=p.parse_args();base=a.base.resolve()
    if a.task_id!='root4.full'or a.cache is not None or a.dependencies is not None or a.archives is not None:raise RuntimeError('Only the one fixed full ROOT4 transaction is supported')
    if a.task_id=='tail49.full14_41':
        folder=base/'resource-tail-transport';archive=folder/'BE_cutoff49_20260930.zip'
        if a.archives is None or a.archives.resolve()!=folder.resolve()or archive.is_symlink()or not archive.is_file():raise RuntimeError('Exact frozen local tail source archive required')
        if archive.stat().st_size!=16660566 or digest(archive)!='ecdb9acca0db29efc9fe2bf496c0bcc61b4881aecdcbc91a4eb6ad49b920c72e':raise RuntimeError('Original complete tail archive differs')
        if set(folder.iterdir())!={archive}:raise RuntimeError('Only the frozen exact tail source ZIP may appear in archives')
    elif a.archives is not None:raise RuntimeError('Archive argument is only defined for the complete tail suite')
    if not __debug__ or sys.platform!='linux' or sys.version_info[:2]!=(3,12):raise RuntimeError('Unoptimized Linux CPython3.12 required')
    if not(base/'SOURCE-VERIFIED.json').is_file()or time.time()>=a.deadline-120:raise RuntimeError('Frozen sources or campaign admission missing')
    manifest_path=base/'SOURCE-VERIFIED.json';manifest_pin=digest(manifest_path)
    manifest=json.loads(manifest_path.read_text())
    if not {'cgroup_driver_root4.py','resource_service_entry.py','root4_stage_worker.py'}<=set(manifest['files']):raise RuntimeError('Complete cgroup driver/entry source binding required')
    def source_check():
        for name,pin in manifest['files'].items():
            f=base/name
            if not f.is_file()or f.is_symlink()or digest(f)!=pin:raise RuntimeError('Resource source drift')
        if digest(manifest_path)!=manifest_pin:raise RuntimeError('Resource source manifest drift')
        return dict(driver_sha256=digest(Path(__file__)),manifest_sha256=manifest_pin,
            archive_manifest_sha256=manifest['archive_manifest_sha256'],
            closure_sha256=hashlib.sha256(encoded(manifest['files'])).hexdigest())
    source_before=source_check()
    from be.count_native import runtime_profile
    before=runtime_profile(); wall=min(a.wall,int(a.deadline-time.time()-120))
    if wall<1 or a.memory<512*1024**2:raise RuntimeError('Resource reservation invalid')
    label=a.task_id.replace('.','-');uid=uuid.uuid4().hex[:12];unit='be-root4-'+uid
    out=base/'runs'/uid;out.mkdir(parents=True,exist_ok=False);task=out/'task';log=out/'controller.log'
    (out/'RUNTIME-BEFORE.json').write_bytes(encoded(before))
    argv=[sys.executable,'-B','-S',str(base/'root4_stage_worker.py'),'--task',str(task),'--campaign-id',a.campaign,'--runtime-profile-digest',before['digest'],'--deadline',str(a.deadline),'--wall-seconds',str(wall)]
    if a.cache:argv+=['--cache',str(a.cache.resolve())]
    if a.dependencies:argv+=['--dependencies',str(a.dependencies.resolve())]
    if a.archives:argv+=['--archives',str(a.archives.resolve())]
    user=command(['id','-un']).stdout.decode().strip()
    launch=['sudo','-n','systemd-run','--unit='+unit,'--wait','--pipe','--quiet',
        '--property=User='+user,'--property=WorkingDirectory='+str(base),
        '--property=KillMode=control-group','--property=SendSIGKILL=yes','--property=TimeoutStopSec=5s',
        '--property=RuntimeMaxSec='+str(wall),'--property=CPUQuota=100%',
        '--property=MemoryMax='+str(a.memory),'--property=MemorySwapMax=0','--property=TasksMax=64',
        '--property=OOMPolicy=kill','--property=LimitFSIZE=67108864',
        '--property=CPUAccounting=yes','--property=MemoryAccounting=yes',
        '--setenv=PYTHONDONTWRITEBYTECODE=1','--setenv=PYTHONPATH='+os.environ.get('PYTHONPATH',''),
        sys.executable,'-B',str(base/'resource_service_entry.py'),str(out/'ENTRY-GATE.json'),str(a.deadline-120),*argv]
    intent=dict(task_id=a.task_id,campaign=a.campaign,unit=unit,deadline=a.deadline,wall_seconds=wall,
        memory_max=a.memory,cpu_quota_percent=100,per_file_bytes=67108864,source_before=source_before,
        archives_sha256='ecdb9acca0db29efc9fe2bf496c0bcc61b4881aecdcbc91a4eb6ad49b920c72e'if a.archives else None,
        runtime_before=before['digest'],status='provisional',full_proof_pass=False)
    (out/'INTENT.json').write_bytes(encoded(intent))
    observed={};reason='completed';child=None
    try:
        with log.open('xb')as stream:
            child=subprocess.Popen(launch,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT)
            properties=('ControlGroup','MemoryMax','MemorySwapMax','CPUQuotaPerSecUSec','RuntimeMaxUSec','KillMode','TasksMax','LimitFSIZE','CPUAccounting','MemoryAccounting')
            readback={};end=time.time()+10
            while time.time()<end:
                actual=subprocess.run(['systemctl','show',unit+'.service','--property='+','.join(properties)],stdin=subprocess.DEVNULL,capture_output=True,timeout=3)
                readback=dict(line.split('=',1)for line in actual.stdout.decode().splitlines()if'='in line)
                if readback.get('ControlGroup'):break
                if child.poll()is not None:break
                time.sleep(.05)
            if (readback.get('ControlGroup')!='/system.slice/'+unit+'.service'
                or readback.get('MemoryMax')!=str(a.memory)or readback.get('MemorySwapMax')!='0'
                or readback.get('KillMode')!='control-group'or readback.get('TasksMax')!='64'
                or readback.get('LimitFSIZE')!='67108864'
                or micros(readback.get('CPUQuotaPerSecUSec',''))!=1000000
                or micros(readback.get('RuntimeMaxUSec',''))!=wall*1000000
                or readback.get('CPUAccounting')!='yes'or readback.get('MemoryAccounting')!='yes'):
                raise RuntimeError('Actual systemd limits differ from requested reservation')
            (out/'CGROUP-READBACK.json').write_bytes(encoded(readback))
            temporary=out/'ENTRY-GATE.pending'
            with temporary.open('xb')as gate:
                gate.write(encoded(dict(actual_cgroup_verified=True,unit=unit,readback_sha256=digest(out/'CGROUP-READBACK.json'))));gate.flush();os.fsync(gate.fileno())
            os.replace(temporary,out/'ENTRY-GATE.json')
            until=min(time.time()+wall+10,a.deadline-110)
            while child.poll()is None:
                if time.time()>=until:reason='wall_timeout';break
                if log.stat().st_size>1024**2:reason='outer_log_limit';break
                time.sleep(.1)
            if reason!='completed':command(['sudo','-n','systemctl','stop',unit+'.service'],timeout=15)
            returncode=child.wait(timeout=20)
        if returncode:reason='service_nonzero'
    finally:
        # Normal cancellation runs this cleanup. SIGKILL of this coordinator cannot
        # run finally: the service RuntimeMaxSec and VM TTL then bound its tail.
        subprocess.run(['sudo','-n','systemctl','stop',unit+'.service'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=20)
        if child and child.poll()is None:child.kill();child.wait(timeout=5)
    cg=Path('/sys/fs/cgroup/system.slice')/(unit+'.service')
    cgroup_events=(cg/'cgroup.events').read_text()if cg.exists()else'cgroup_absent'
    cleanup=cgroup_events=='cgroup_absent'or 'populated 0'in cgroup_events
    if not cleanup:raise RuntimeError('Resource cgroup still populated')
    after=runtime_profile();source_after=source_check()
    if after['digest']!=before['digest']or source_after!=source_before:raise RuntimeError('Resource runtime/source drift')
    (out/'RUNTIME-AFTER.json').write_bytes(encoded(after))
    native=task.parent/(task.name+'.ROOT4-CONTROLLER-OBSERVATION.json')
    accepted=reason=='completed'and returncode==0 and native.is_file()
    root4_detail={}
    if accepted:
        packet=json.loads(native.read_text())
        expected=dict(schema='be.root4-whole-cgroup-controller-observation/1',campaign_id=a.campaign,
            source_epoch_sha256='63f409204df8b1a786ce049dfdd1868f6b7fb736fc4053729b228f7675ce3a90',
            root4_port_sha256='c98366a00cd2f13d8f51ad150fa5a51b7d8b67776f4583686c636d53e6e8de39',
            implementation_sha256='2456072e6f5707719b003e0cc0dc01541589903896774e02dc520657ddbb2b86',
            runtime_profile_digest=before['digest'],absolute_deadline=a.deadline,whole_cgroup_runtime_seal_required=True,
            all_law_C4_verified=False,full_proof_pass=False)
        if any(type(packet.get(k))is not type(v)or packet.get(k)!=v for k,v in expected.items()):raise RuntimeError('Wrong exact ROOT4 source/runtime scope')
        if digest(task/'ROOT4_RESULT.json')!=packet.get('result_sha256'):raise RuntimeError('Actual full ROOT4 result differs')
        closed=(packet.get('outcome')=='CONDITIONAL_ROOT4_TWO_FRESH_FULL_PASSES_COMPLETED'
            and packet.get('checked',{}).get('conditional_physical_target_closed')is True
            and packet.get('checked',{}).get('unresolved_geometry_indices')==[])
        if not closed and packet.get('outcome')!='ROOT4_TWO_FULL_PASSES_UNRESOLVED':raise RuntimeError('ROOT4 cannot advertise closure of unresolved classes')
        root4_detail=dict(root4_outcome=packet['outcome'],conditional_physical_root4_closed=closed,
            unresolved_geometry_indices=packet.get('checked',{}).get('unresolved_geometry_indices'),
            checked=packet['checked'],all_law_C4_verified=False,
            required_math_parents=packet.get('required_math_parents'))
        accepted=closed
    report=dict(intent,status='CONDITIONAL_ROOT4_SEALED'if accepted else('ROOT4_TWO_FULL_PASSES_UNRESOLVED'if root4_detail else'RESOURCE_INCOMPLETE'),
        returncode=returncode,reason=reason,tree_cleanup_complete=cleanup,
        runtime_after=after['digest'],source_after=source_after,task=str(task),log=str(log),
        source_runtime_equal=True,observed_epoch=time.time(),
        observation_sha256=digest(native)if native.is_file()else None,
        cgroup_readback=readback,cgroup_events_after_stop=cgroup_events,
        current_campaign_dependencies_authorized_by_coordinator_required=True,
        parent_licenses_authorized_by_this_driver=False,
        **root4_detail,
        hard_parent_death_safety='service RuntimeMaxSec plus at most TimeoutStopSec=5s and native VM TTL; finally does not survive SIGKILL')
    (out/'FINAL.json').write_bytes(encoded(report));print(json.dumps(report),flush=True)
    return 0 if accepted else 2
if __name__=='__main__':raise SystemExit(main())
