"""Fixed source-resource dispatch ports; existing full native controllers.

The coordinator must supervise the complete container/process tree and authorize
current-campaign dependencies. This worker never promotes conditional exports
to an all-law theorem or a final proof PASS.
"""
from pathlib import Path
import argparse
import importlib
import json
import sys
import count69_batch as common

ROOT=Path(__file__).resolve().parent
SNAPSHOT=ROOT/"snapshot"
sys.path.insert(0,str(SNAPSHOT))


def module(name):return importlib.import_module("be_replay."+name)


def run(task_id,task,cache,*,dependencies=None,campaign_id,log_root=None,
        archives=None,wall_seconds=43200,cpu_seconds=43200):
    common.need(sys.platform=="linux","linux_required","Original full resource controllers require Linux")
    common.need(type(campaign_id)is str and campaign_id,"campaign_id","Explicit fresh campaign context")
    task=Path(task).resolve();root=Path(log_root).resolve()if log_root else task.parent
    root.mkdir(parents=True,exist_ok=True)
    common.need(not task.exists(),"fresh_task","Fresh exclusive resource task")
    deps={}if dependencies is None else{key:Path(value).resolve()for key,value in dependencies.items()}
    if task_id=="shared.kappa62_625":
        checked=module("finite1014_kappa").execute(task,root=root)
    elif task_id.startswith("65.parent."):
        src=module("finite69_parent_sources")
        job_id=task_id[len("65.parent."):]
        checked=module("finite69_parents").execute(task,src.job(job_id),Path(cache),log_root=root)
    elif task_id=="65.owncaps":
        src=module("finite69_caps_sources")
        src.prepare_own(Path(cache),task)
        checked=module("finite69_caps").execute_prepared(task,root=root)
    elif task_id.startswith("65.caps."):
        src=module("finite69_caps_sources");job_id=task_id[len("65.caps."):]
        initial="65.parent."+job_id.replace(".resource.",".initial.")
        common.need({initial,"65.owncaps"}<=set(deps),"fresh_dependencies","Fresh literal-index INITIAL and owncaps exports")
        src.prepare_resource(Path(cache),task,src.base.job(job_id),deps[initial],deps["65.owncaps"])
        checked=module("finite69_caps").execute_prepared(task,root=root)
    elif task_id.startswith("65.remaining."):
        rem=module("finite69_remaining");stage=task_id[len("65.remaining."):];parents=[]
        if stage=="support":
            own=module("finite69_caps_evidence")
            common.need("65.owncaps"in deps,"fresh_dependencies","Fresh complete owncaps")
            parents=[(deps["65.owncaps"],own.validate_completed)]
            for key in("auxiliary","bridge","radius"):
                dep="65.remaining."+key
                common.need(dep in deps,"fresh_dependencies","Fresh complete "+key)
                parents.append((deps[dep],rem.validate_completed))
        checked=rem.execute(Path(cache),task,stage,root=root,parents=parents)
    elif task_id.startswith("56I.core."):
        checked=module("finite1014_core").execute(task_id[len("56I.core."):],Path(cache),task,root=root)
    elif task_id.startswith("57H.core."):
        common.need("57H.high"in deps,"fresh_dependencies","Current complete supported compensated HIGH")
        checked=module("finite1519_core").execute(task_id[len("57H.core."):],Path(cache),task,
                                                  root=root,upstream_high=deps["57H.high"])
    elif task_id=="57H.high":
        checked=module("finite1519_high").execute(task,Path(cache),root=root)
    elif task_id.startswith("56I.control."):
        checked=module("finite1014_join").execute(task_id[len("56I.control."):],Path(cache),task,
                                                  root=root,dependencies={key:value for key,value in deps.items()
                                                                         if key.startswith("work/")})
    elif task_id=="57H.controls":
        key="fresh-count:n15.B0.p56.3ccb81760515"
        common.need(key in deps,"fresh_dependencies","Genuinely current full COUNT geometry fixture")
        checked=module("finite1519_join_controls").execute(Path(cache),task,root=root,upstream_count56=deps[key])
    elif task_id=="tail49.full14_41":
        common.need(archives is not None,"source_archive","Exact locally staged tail source ZIP")
        checked=module("tail49").run(task,archives=Path(archives),download=False,mode="basic",
                                      wall_seconds=wall_seconds,cpu_seconds=cpu_seconds)
        common.need(checked.get("all_required_jobs_computed")is True
                    and checked.get("status")=="COMPUTED_ORIGINAL_BE49_FULL_SUITE_UNTRUSTED_GUARD",
                    "tail_incomplete","The entire14/41 suite must finish; its own diagnostics are preserved")
    else:
        raise common.BatchError("unsupported_resource_task","This resource entry needs its explicit source-specific adapter: "+task_id)
    packet={"schema":"be.resource-source-controller-observation/1","task_id":task_id,"campaign_id":campaign_id,
            "outcome":"CONDITIONAL_RESOURCE_REPLAY_COMPLETED",
            "checked_conditional_export":checked,"current_campaign_dependencies_authorized_by_coordinator_required":True,
            "runtime_source_seal_required":True,"unrestricted_all_law_join_verified":False,"full_proof_pass":False}
    (task/"RESOURCE-CONTROLLER-OBSERVATION.json").write_bytes(common.encoded(packet))
    return packet


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-id",required=True);parser.add_argument("--task",type=Path,required=True)
    parser.add_argument("--cache",type=Path);parser.add_argument("--dependencies",type=Path)
    parser.add_argument("--campaign-id",required=True);parser.add_argument("--archives",type=Path)
    parser.add_argument("--wall-seconds",type=int,default=43200);parser.add_argument("--cpu-seconds",type=int,default=43200)
    args=parser.parse_args()
    deps=common.parsed(common.regular(args.dependencies))if args.dependencies else{}
    result=run(args.task_id,args.task,args.cache,dependencies=deps,campaign_id=args.campaign_id,
               archives=args.archives,wall_seconds=args.wall_seconds,cpu_seconds=args.cpu_seconds)
    print(common.encoded({"task_id":args.task_id,"conditional_export_observed":True,"full_proof_pass":False}).decode())


if __name__=="__main__":main()
