"""Metadata-only v2: keep controller observation outside exact native inventory.

The original d6b source dispatch and every mathematical program stay unchanged.
Only a newly created controller sidecar is relocated after original completion.
Existing sealed tasks and active source bundles are never edited by this port.
"""
from pathlib import Path
import importlib.util
import count69_batch as common

HERE = Path(__file__).resolve().parent
LEGACY_SHA = "d6b442390125b9c673cfa95c4e6842142e8c04285ad6c44fb921583f51e1c7cd"
SELF_SHA = common.sha(common.regular(Path(__file__)))


def _implementation():
    common.need(common.sha(common.regular(Path(__file__))) == SELF_SHA,
                "resource_v2_changed", "No metadata wrapper mutation after import")
    common.need(common.sha(common.regular(HERE / "resource_worker.py")) == LEGACY_SHA,
                "resource_legacy_pin", "Original frozen numerical/source dispatch")


_implementation()
_SPEC = importlib.util.spec_from_file_location("_resource_worker_v2_private", HERE / "resource_worker.py")
_ENGINE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_ENGINE)
_LEGACY_RUN = _ENGINE.run


def run(task_id, task, cache, **kwargs):
    _implementation()
    task = Path(task).resolve()
    sidecar = task.parent / (task.name + ".RESOURCE-CONTROLLER-OBSERVATION.json")
    common.need(not sidecar.exists() and not sidecar.is_symlink(), "fresh_resource_sidecar", "Fresh external observation name")
    packet = _LEGACY_RUN(task_id, task, cache, **kwargs)
    source = task / "RESOURCE-CONTROLLER-OBSERVATION.json"
    raw = common.regular(source, 32 * common.MIB)
    common.need(raw == common.encoded(packet), "resource_sidecar_binding", "Exactly the controller packet, never a native proof file")
    before = {path.relative_to(task).as_posix(): common.file_sha(path)
              for path in task.rglob("*") if path.is_file() and path != source}
    common.need(source.parent == task and sidecar.parent == task.parent
                and source.resolve().is_relative_to(task) and not source.is_symlink(),
                "resource_sidecar_path", "One explicitly named private metadata move")
    source.replace(sidecar)
    after = {path.relative_to(task).as_posix(): common.file_sha(path)
             for path in task.rglob("*") if path.is_file()}
    common.need(before == after and common.regular(sidecar, 32 * common.MIB) == raw,
                "native_inventory_preserved", "Every native artifact unchanged; only the known wrapper sidecar lies outside")
    _implementation()
    return packet


_ENGINE.run = run


if __name__ == "__main__":
    _ENGINE.main()
