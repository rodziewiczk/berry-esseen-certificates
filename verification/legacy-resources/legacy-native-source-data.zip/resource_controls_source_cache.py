"""Explicit new source-only materializer for existing56I/57H control workers."""
from pathlib import Path, PurePosixPath
import argparse
import json
import count69_batch as common

ROOT = Path(__file__).resolve().parent
PLANS = {"56I.controls": "finite1014_join_source_plan.json",
         "57H.controls": "finite1519_join_control_source_plan.json"}


def manifest(cache, pin):
    raw = common.regular(Path(cache) / "MANIFEST.json", 8 * common.MIB)
    common.need(common.sha(raw) == pin, "resource_controls_manifest", "Coordinator-approved new source-only epoch")
    value = common.parsed(raw)
    common.need(value["schema"] == "be.resource-controls-source-cas/1" and set(value["groups"]) == set(PLANS)
                and value["historical_reference_bytes_are_acceptance_authority"] is False,
                "resource_controls_groups", "Exactly the16 missing original control calls, not a parent license")
    for group, name in PLANS.items():
        path = ROOT / "snapshot/proof" / name; row = value["groups"][group]
        common.need(common.file_sha(path) == row["source_plan_sha256"] and row["source_plan"] == name,
                    "resource_controls_plan", "Unchanged original complete mathematical control scope")
        plan = common.parsed(common.regular(path, 32 * common.MIB)); files = dict(plan["source_files"])
        files.update(plan.get("reference_files", {}))
        common.need(row["files"] == files, "resource_controls_closed_selection", "Every exact original source/reference byte")
    return value


def materialize(group, cache, destination, *, manifest_sha256):
    value = manifest(cache, manifest_sha256)
    common.need(group in PLANS, "resource_controls_group", "One exact new source group")
    destination = Path(destination).resolve()
    common.need(not destination.exists(), "resource_controls_new_view", "Never mutate any active resource epoch")
    destination.mkdir(parents=True)
    for name, row in value["groups"][group]["files"].items():
        parts = PurePosixPath(name).parts
        common.need(parts and not PurePosixPath(name).is_absolute() and "\\" not in name and ":" not in name
                    and all(part not in (".", "..") for part in parts), "resource_controls_path", "Exact relative logical source path")
        body = common.regular(Path(cache) / "blobs" / row["sha256"], 128 * common.MIB)
        common.need(len(body) == row["bytes"] and common.sha(body) == row["sha256"], "resource_controls_blob", name)
        path = destination.joinpath(*parts); path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(body)
    return dict(schema="be.resource-controls-source-view/1", group=group, files=len(value["groups"][group]["files"]),
                source_manifest_sha256=manifest_sha256, original_native_worker_unchanged=True,
                historical_reference_authority=False, current_parent_licenses_required=True, full_proof_pass=False)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__); p.add_argument("--group", choices=tuple(PLANS), required=True)
    p.add_argument("--cache", type=Path, required=True); p.add_argument("--output", type=Path, required=True)
    p.add_argument("--manifest-sha256", required=True); a = p.parse_args()
    print(json.dumps(materialize(a.group, a.cache, a.output, manifest_sha256=a.manifest_sha256)), flush=True)
