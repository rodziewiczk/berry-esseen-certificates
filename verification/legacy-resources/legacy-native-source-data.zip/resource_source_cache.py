"""Materialize exact resource source/reference groups, never acquire facts.

Historical numeric bytes are source-design/reference inputs only. Each original
controller separates its own old outputs into provenance and recomputes its
complete numerical actions. All acquired external parents require independently
authorized current-campaign licenses before a global mathematical join.
"""
from pathlib import Path, PurePosixPath
import argparse
import importlib
import json
import sys
import count69_batch as common

ROOT = Path(__file__).resolve().parent
MANIFEST_SHA = "e9c6b37a122617e1800b803ddacacb9827637a6b4d1938e67eea74aead5be6b5"
MAX_SOURCE_BYTES = 128 * common.MIB
sys.path.insert(0, str(ROOT / "snapshot"))


def manifest():
    raw = common.regular(ROOT / "resource-source-cas/MANIFEST.json", 8 * common.MIB)
    common.need(common.sha(raw) == MANIFEST_SHA, "resource_source_manifest", "Fixed complete source-group mapping")
    return common.parsed(raw)


def _path(root, name):
    parts = PurePosixPath(name).parts
    common.need(type(name) is str and parts and not PurePosixPath(name).is_absolute()
                and "\\" not in name and ":" not in name
                and all(p not in (".", "..", "") for p in parts),
                "resource_source_path", "Contained original POSIX source name")
    result = root.joinpath(*parts)
    common.need(result.resolve().is_relative_to(root.resolve()), "resource_source_path", "Within the private source group")
    return result


def materialize(group, destination, *, upstream_high=None):
    data = manifest()
    common.need(group in data["groups"], "resource_source_group", "One frozen source-only resource group")
    definition = data["groups"][group]
    plan = ROOT / "snapshot/proof" / definition["source_plan"]
    common.need(common.sha(common.regular(plan, 32 * common.MIB)) == definition["source_plan_sha256"],
                "resource_source_plan", "Exact mathematical selection and original commitment graph")
    target = Path(destination).resolve()
    common.need(not target.exists(), "fresh_source_cache", "Exclusive private source-group destination")
    if any(meta.get("fresh_high_input") for meta in definition["files"].values()):
        common.need(upstream_high is not None, "fresh_high_required", "Completed current57H HIGH is a real dependency")
        source_module = importlib.import_module("be_replay.finite1519_core_sources")
        source_module.upstream_files(Path(upstream_high))
    target.mkdir(parents=True, exist_ok=False)
    for name, meta in definition["files"].items():
        if "metadata_reconstruction" in meta:
            continue
        pin = meta["sha256"]
        source = (Path(upstream_high) / "capsule" / name if meta.get("fresh_high_input")
                  else ROOT / "resource-source-cas/blobs" / pin)
        raw = common.regular(source, MAX_SOURCE_BYTES)
        common.need(len(raw) == meta["bytes"] and common.sha(raw) == pin,
                    "resource_source_blob", "Exact selected source/reference or completed fresh HIGH byte")
        output = _path(target, name)
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("xb") as stream:
            stream.write(raw)
    for name, meta in definition["files"].items():
        if "metadata_reconstruction" not in meta:
            continue
        recipe = meta["metadata_reconstruction"]
        common.need(recipe["reconstruction"] == "ORIGINAL_POSIX_PREPARED_V1", "metadata_recipe", "Declared transport-only reconstruction")
        module = importlib.import_module("be_replay.finite69_metadata")
        common.need(common.sha(common.regular(Path(module.__file__))) == recipe["metadata_adapter_sha256"],
                    "metadata_adapter", "Pinned nonnumerical metadata reconstruction")
        raw = module.reconstruct_prepared(_path(target, recipe["source_prepared"]).read_bytes(),
                                         _path(target, recipe["candidate"]).read_bytes(),
                                         n=recipe["n"], band=recipe["band"], source_pins=recipe["source_pins"])
        common.need(len(raw) == recipe["bytes"] and common.sha(raw) == recipe["sha256"],
                    "metadata_reconstruction", "Exact externally pinned original PREPARED bytes")
        output = _path(target, name)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(raw)
    # Original controllers independently validate all consumed inputs again.
    return {"schema": "be.resource-source-cache-observation/1", "group": group,
            "source_manifest_sha256": MANIFEST_SHA, "files": len(definition["files"]),
            "historical_acceptance_authority": False, "arithmetic_computed": False,
            "current_campaign_parent_licenses_required": True, "full_proof_pass": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("group", choices=tuple(manifest()["groups"]))
    parser.add_argument("destination", type=Path)
    parser.add_argument("--upstream-high", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.group, args.destination, upstream_high=args.upstream_high)))


if __name__ == "__main__":
    main()
