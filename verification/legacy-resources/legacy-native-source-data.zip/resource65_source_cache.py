"""Source-only65 extension, using a private instance of the frozen materializer."""
from pathlib import Path
import importlib.util
import count69_batch as common

HERE = Path(__file__).resolve().parent
SHARED_SHA = "b63817e73746a83414a3c84c17522b733dbb20a7a1f5c613b036979e3facb7ef"
MANIFEST_SHA = "7175f69ccc43d13ee7312c766d6724483b4e629b408696d9ac6bddbfbf491a23"
common.need(common.sha(common.regular(HERE / "resource_source_cache.py")) == SHARED_SHA,
            "shared_resource_adapter", "Frozen shared source-only cache materializer")
_SPEC = importlib.util.spec_from_file_location("_resource65_cache_private", HERE / "resource_source_cache.py")
_ENGINE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_ENGINE)
_ENGINE.ROOT = HERE / "resource65-cache"
_ENGINE.MANIFEST_SHA = MANIFEST_SHA
manifest = _ENGINE.manifest
materialize = _ENGINE.materialize


if __name__ == "__main__":
    _ENGINE.main()
