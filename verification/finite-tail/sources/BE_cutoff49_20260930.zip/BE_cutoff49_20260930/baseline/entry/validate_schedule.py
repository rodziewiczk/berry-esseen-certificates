#!/usr/bin/env python3
"""Structural source/cover audit only; does not replay the entry inequalities."""
from pathlib import Path
from fractions import Fraction as F
import ast,copy,hashlib,json,sys
P=Path(__file__).resolve().parent
def workspace():
 for parent in (P,*P.parents):
  for root in (parent/'certificates',parent):
   if (root/'work/below50_20260929/root/cutoff50_dependencies_v2.json').is_file() and (root/'work/below50_20260929/entry/initial47_proof.json').is_file():return root
 raise ValueError('Fixed inherited workspace or sibling certificates not found')
ROOT=workspace()
OLD=ROOT/'work/below50_20260929'
MANIFEST=OLD/'root/cutoff50_dependencies_v2.json'
EXPECTED_MANIFEST='904bc8150c0f0295c022fdafea76c50e308647ea0ecb0a7ba94cc12996ef72b0'
COUNT=0
def need(v,s):
 global COUNT
 COUNT+=1
 if not v:raise ValueError(s)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:
  need(k not in d,'duplicate key');d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def rat(s):
 need(type(s)is str and len(s)<100,'rational string')
 v=F(s);need(str(v)==s,'canonical rational');return v
EXPECTED=[('I',[],'signed_initial'),('C',['I'],'central_acquisition'),('L',['I'],'complement_acquisition'),('C1',['C'],'confinement_feedback'),('C2',['C','C1'],'antichain_feedback'),('S',['C2','L'],'signed_resource'),('L2',['S'],'left_radius_refinement')]
SCOPE=dict(floor=47,upper_index=None,barrier='0',own_score_cap='4247/10000',deleted_score_cap='4253/10000',decrement='19/100',initial_radius='96/25',weighted_excess_cap='7/10')
OUTPUTS=['entry/left270_input47_table.json','entry/sperner_feedback47_table.json']
def schedule(d,manifest):
 need(set(d)=={'schema','scope','nodes','selected_outputs','callbacks'},'schedule fields')
 need(d['schema']=='SHORT50_ENTRY_SCHEDULE_V1' and d['scope']==SCOPE,'fixed all-index scope')
 need(len(d['nodes'])==len(EXPECTED),'all schedule nodes')
 seen=set();files=set()
 for row,(ident,deps,op) in zip(d['nodes'],EXPECTED):
  need(set(row)=={'id','dependencies','operation','objects'},'node fields')
  need((row['id'],row['dependencies'],row['operation'])==(ident,deps,op),'fixed ordered operations')
  need(ident not in seen and set(deps)<=seen,'acyclic prior dependencies');seen.add(ident)
  need(type(row['objects'])is dict and bool(row['objects']),'proof objects nonempty')
  for path,h in row['objects'].items():
   p=OLD/path;key=str(p.relative_to(ROOT))
   need(key in manifest and sha(p)==h==manifest[key],'unchanged accepted proof object')
   need(path not in files,'proof object belongs to one node');files.add(path)
 need(d['selected_outputs']==OUTPUTS and set(OUTPUTS)<=files,'exact selected outputs')
 need(d['callbacks']==['global_attainment_contact','global_heat_support','central_support_strip','left_support_strip'],'explicit external analytic callbacks')
 return files

def paneltable(d,count,lo,hi):
 need(d['N']==47 and rat(d['own_score_cap'])==F('.4247'),'table all-index floor and current cap')
 need([rat(t)for t in d['probability_domain']]==[lo,hi],'table domain')
 rows=d['panels'];need(type(rows)is list and len(rows)==count,'row count')
 for j,z in enumerate(rows):
  need(z['index']==j and [rat(t)for t in z['p']]==[lo+F(j,500),lo+F(j+1,500)],'ordered closed probability cover')
  for key in ('T','D','theta','rho','beta_lo','beta_hi','lambda_max','d0','H_plus','H_minus','A_lo','B_lo'):rat(z[key])
  need(0<rat(z['T'])<F('.4')*47 and 0<rat(z['D'])<2,'licensed raw and central-gap domains')
  need(0<=rat(z['theta'])<1 and rat(z['rho'])>=1 and rat(z['lambda_max'])>=0,'physical moment and weighted noise domains')
  need(-1<rat(z['beta_lo'])<=rat(z['beta_hi'])<1,'signed beta order')
  need(0<=rat(z['d0'])<F('.5') and rat(z['A_lo'])>0 and rat(z['B_lo'])>0,'positive actual gap')
  need(rat(z['H_plus'])>0 and rat(z['H_minus'])>0,'both signed phase domains')
  need(type(z['quadratics'])is list and len(z['quadratics'])==4,'all four score-moment corners')
  for q in z['quadratics']:
   need(set(q)=={'A','Fplus','Fminus','Qraw','Qbudget'},'full signed quadratic fields')
   v={k:rat(x)for k,x in q.items()}
   need(v['A']>0 and 0<v['Qraw']<v['Qbudget'],'raw quadratic and additional phase charge')
 need(lo+F(count,500)==hi,'full target interval')
 return count

def initialization(d):
 need(d['format']=='INITIAL47_FULL_P_V1' and d['name']=='INITIAL47_R384','fixed initialization')
 need(len(d['steps'])==13,'thirteen finite signed passes')
 oldr=oldd=None
 for z in d['steps']:
  r,e=rat(z['raw']),rat(z['defect'])
  need(0<r<F('.4')*47 and 0<e<4,'raw sign license before feedback')
  need(z['active']+z['excluded']==18432,'complete signed cover count')
  if oldr is not None:need(r<=oldr and e<=oldd and (r<oldr or e<oldd),'strict stage order')
  oldr,oldd=r,e
 need(oldr<F('1.885') and oldd<F('.590'),'final initialization target')
 need(len(d['panels'])==100,'initial full probability cover')
 for j,z in enumerate(d['panels']):
  need(rat(z['pl'])==F(j,100) and rat(z['pu'])==F(j+1,100),'closed initial probability cells')
  if not z['cells']:need([z[k]for k in ('raw','D','theta','rho','beta','H')]==['-1','-1','0','1','0','0'],'excluded cell sentinel')
 need(sum(z['cells']>0 for z in d['panels'])==35,'surviving probability incidence count')

def scope_source(manifest):
 paths=['entry/accept_initial47.py','entry/local_signed_core.py']
 for p in paths:need(sha(OLD/p)==manifest[str((OLD/p).relative_to(ROOT))],'initialization source binding')
 tree=ast.parse((OLD/paths[1]).read_text())
 uses=[z for z in ast.walk(tree)if isinstance(z,ast.Subscript)and isinstance(z.slice,ast.Constant)and z.slice.value=='nmax']
 need(len(uses)==2,'only nmax guard and lower-score coefficient')
 source=(OLD/paths[1]).read_text()
 need("3<=p['n']<=p['nmax']" in source and "c0=F('.4095')+K/p['nmax']" in source,'nmax has no residual numerical use at K=0')
 src=(OLD/paths[0]).read_text()
 need("P=dict(n=47,nmax=98,radius=F('3.84'),cap=F('.4247'),barrier=F(0)" in src,'actual fixed zero-barrier configuration')

def main():
 need(__debug__ and not sys.flags.optimize,'optimized Python forbidden')
 need(sha(MANIFEST)==EXPECTED_MANIFEST,'accepted manifest identity')
 manifest=read(MANIFEST)['files'];s=read(P/'schedule.json')
 files=schedule(s,manifest)
 inputs=read(P/'SOURCE_MAP_INPUTS.json')
 for row in inputs['sources']:
  need(sha(ROOT/row['path'])==row['sha256']==manifest[row['path']],'unchanged mathematical source')
 left=read(OLD/OUTPUTS[0]);central=read(OLD/OUTPUTS[1]);ini=read(OLD/'entry/initial47_proof.json')
 initialization(ini);scope_source(manifest)
 paneltable(left,38,F('.304'),F('.38'));paneltable(central,45,F('.38'),F('.47'))
 need(left['source_sha256']==sha(OLD/'entry/signed_resource47_table.json'),'left predecessor source')
 for key,path in [('source_sha256','entry/confined_feedback47_table.json'),('weak_input_sha256','local/conditional_input47.json'),('confinement_sha256','local/sperner47_certificate.json')]:
  need(central[key]==sha(OLD/path),'central predecessor binding')
 need('Weighted' in read(OLD/'entry/signed_resource47_table.json')['budget_semantics'],'weighted signed-resource semantics retained')
 need('weighted nD' in central['budget_semantics'],'weighted central-resource semantics retained')
 good_count=COUNT
 controls=[]
 def control(name,fn):
  try:fn()
  except (ValueError,TypeError,KeyError,IndexError,ZeroDivisionError):controls.append(name)
  else:raise ValueError('malformed control accepted: '+name)
 def mutate_schedule(fn):
  z=copy.deepcopy(s);fn(z);schedule(z,manifest)
 def mutate_table(fn):
  z=copy.deepcopy(left);fn(z);paneltable(z,38,F('.304'),F('.38'))
 control('missing node',lambda:mutate_schedule(lambda z:z['nodes'].pop()))
 control('reordered nodes',lambda:mutate_schedule(lambda z:z['nodes'].reverse()))
 control('cyclic dependency',lambda:mutate_schedule(lambda z:z['nodes'][0]['dependencies'].append('L2')))
 control('wrong theorem scope',lambda:mutate_schedule(lambda z:z['scope'].update(upper_index=98)))
 control('missing weighted excess premise',lambda:mutate_schedule(lambda z:z['scope'].pop('weighted_excess_cap')))
 control('corrupt proof hash',lambda:mutate_schedule(lambda z:z['nodes'][0]['objects'].update({'entry/initial47_proof.json':'0'*64})))
 control('missing output',lambda:mutate_schedule(lambda z:z['selected_outputs'].pop()))
 control('missing probability cell',lambda:mutate_table(lambda z:z['panels'].pop()))
 control('duplicate probability cell',lambda:mutate_table(lambda z:z['panels'].__setitem__(1,z['panels'][0])))
 control('false cell endpoint',lambda:mutate_table(lambda z:z['panels'][0]['p'].__setitem__(1,'307/1000')))
 control('missing corner',lambda:mutate_table(lambda z:z['panels'][0]['quadratics'].pop()))
 control('invalid phase charge',lambda:mutate_table(lambda z:z['panels'][0]['quadratics'][0].update(Qbudget='0')))
 control('invalid variance',lambda:mutate_table(lambda z:z['panels'][0].update(theta='1')))
 control('duplicate JSON key',lambda:json.loads('{"a":1,"a":2}',object_pairs_hook=unique))
 result=dict(status='PASS_STRUCTURAL_ENTRY_SCHEDULE_ONLY',mathematical_status='Analytic consolidation reviewed separately; imported arithmetic unchanged',execution_status='Fresh structural PASS, not an arithmetic replay',checks=good_count,negative_controls=controls,proof_objects=len(files),source_inputs=len(inputs['sources']),final_left_panels=38,final_central_panels=45,scope=SCOPE,accepted_manifest_sha256=EXPECTED_MANIFEST,new_sources={p.name:sha(p)for p in [P/'validate_schedule.py',P/'schedule.json',P/'resource_entry.tex',P/'entry_formula_atlas.tex',P/'unsigned_formula_card.tex',P/'build_module.py',P/'FORMULA_MAP.md']})
 print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
