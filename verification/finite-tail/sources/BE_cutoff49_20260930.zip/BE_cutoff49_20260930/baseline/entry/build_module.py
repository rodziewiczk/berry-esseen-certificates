from pathlib import Path
import re,json,hashlib
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
OLD=ROOT/'work/below50_20260929'
FOUND=ROOT/'work/below100_20260929/paper99/sections'
records=[]
def read(f):
 p=f if isinstance(f,Path) else OLD/f
 s=p.read_text();records.append(dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 return s
def cut(s,a,b):return s[s.index(a):s.index(b,s.index(a))]
def scope(s,prefix):
 for old in set(re.findall(r'\\label\{([^}]+)\}',s)):
  for command in ('label','ref','eqref','pageref'):
   s=s.replace('\\'+command+'{'+old+'}','\\'+command+'{'+prefix+':'+old+'}')
 return s
identity=read(FOUND/'identity.tex');entry=read(ROOT/'work/below100_20260929/release/paper/sections/entry.tex')
contact=cut(identity,'\\begin{align}\n n\\mathfrak','\\end{align}')+'\\end{align}\n'
inv=cut(identity,'Write $Z_n','We have inverted a smooth payoff')
proof=identity[identity.index('\\begin{proof}\nCompute $\\mathcal A'):]
# The identity file ends with this proof, not with a document wrapper.
foundation=r'''\section{The minimal contact--Fourier foundation}\label{re:foundation}
The only contact input needed here is the following explicit interface.
At the attained positive maximum, with $F=\Pp(S_n\le H)$,
$z=H/\sqrt n$ and $\nu=\mathcal L(H-S_{n-1})$, one has
$\nu([y,\infty))\le\mathfrak q(y)$ for every real $y$, with equality
on the full closed support, where
'''+contact+r'''
This contact statement and attainment are supplied by the global section.
Everything that follows in this section is derived from it. We abbreviate
$M_4=\mu_4$, $M_5=\eta_5$ when comparing with the implementation.
\subsection{Compensated smooth inversion}
'''+inv+r'''
The payoff is smooth enough for compensated inversion. No discontinuous
CDF is inverted, so no atom midpoint convention is introduced.
\subsection{Derivation of the conserved identity}
'''+proof
# Need original definitions used by exact algebra, already defined in resource.
# Keep all low formulas and proofs; remove historical transition paragraphs.
low=cut(entry,'\\subsection{One Fourier transfer lemma','\\paragraph{One complete high-frequency estimate.}')
low=low.replace('\\subsection{One Fourier transfer lemma and two coefficient choices}',r'\subsection{One complete low-frequency transfer}')
a=low.index('The new paired calculation uses');b=low.index('\\paragraph{The two coefficient choices',a)
low=low[:a]+r'''At every positive coefficient corner use the displayed finite Mills bound.
A negative Gaussian coefficient uses a lower enclosure for
$\sqrt{\pi/2}$; a nonnegative coefficient uses an upper one. The remaining
factor is positive, so outward upper square-root and exponential enclosures
are valid. A simultaneous reflection of both odd coefficients leaves the
norm unchanged.

'''+low[b:]
low=low.replace('The early choice uses $R_0=6$', 'The triangle choice uses the valid enclosing radius $R_0=6$')
low=low.replace('the already proved cell has\n$0\\le\\gamma_l\\le\\gamma\\le g\\le1$', 'the already proved cell has\n$0\\le\\gamma_l\\le|\\gamma|\\le g\\le1$')
low=low.replace('Set\n\\begin{gather*}\n a_*=(2-', 'After reflecting only this auxiliary Fourier integral if necessary, set\n\\begin{gather*}\n a_*=(2-')
low=low.replace(r'''the third row. The implemented constants
$c_0\ge\sqrt{\pi/(16a_0^3)}=\lambda_N$,
$c_1\ge\sqrt{\pi/(256a_0^5)}=\lambda_N N/[2(N-1)]$
are valid weakenings of the transfer lemma.''',r'''the third row. One may also use the actual radius by setting
$r_0=\max(R,2g)>g$ and
\[
 Z_r=\begin{cases}
 r_0(M-1)+(10-2M)t_*-(r_0-g)t_*^2,
 & M\le5,\quad t_*=\min\{g,(10-2M)/[2(r_0-g)]\},\\
 r_0(M-1)+(2M-10)t_*-r_0t_*^2,
 & M>5,\quad t_*=\min\{g,(2M-10)/(2r_0)\}.
 \end{cases}
\]
Indeed for $M\le5$, $P_{r_0}\ge Q_{r_0}$ and $t^3\le gt^2$;
for $M>5$, $P_{r_0}\le r_0(M-1)$ and dropping $-t^3$ bounds
$Q_{r_0}$. Each displayed quadratic is maximized at its clipped vertex.
Thus the selected implementation takes
$120Z=\min(E_5+10g,Z_0,Z_r)$.
It uses $c_0\ge\sqrt{\pi/(16a_0^3)}=\lambda_N$ and $c_1=c_0/2$.
The weaker choice $c_1\ge\sqrt{\pi/(256a_0^5)}
=\lambda_N N/[2(N-1)]$ is also permitted by the same transfer lemma.''')
high=read('entry/high_window50_proof.tex');high=high[high.index('Let $EX=0'):]
high=high[:high.index('\\paragraph{Fixed implementation') ] if '\\paragraph{Fixed implementation' in high else high
# strip final implementation details after theorem proof if present
last=high.rfind('\\end{proof}')
high=high[:last+len('\\end{proof}')]
lag=read('entry/high_tail_proof.tex');lag=cut(lag,'\\begin{lemma}','The fixed checker')
lag=r'''For $b,\kappa>0$ and $n>0$, put
\[
 T_n=\sqrt n\int_b^\infty e^{-n\kappa t^2}t^{-3}\,dt,
 \qquad x=n\kappa b^2.
\]
'''+lag
high=high.replace('gives $|\\gamma|\\le\\sqrt{M-1}$ and proves the sixth term.',r'''gives $|\gamma|\le\sqrt{M-1}$ and proves the sixth term.
Any separately proved upper bound $|\gamma|\le g$ may replace
$\sqrt{M-1}$ in that term. The selected implementation uses
$g=\min(1.85,\sqrt{M-1})$.''')
low+=r'\subsection{The complete high-frequency integral}'+'\n'+lag+'\n'+high
# Add exact choice of real product events.
events=cut(entry,'\\paragraph{Events, not artificial kernels.}','\\subsection{One interval-feedback theorem}')
# Drop middle generic event row; its derivation is supplied below in atlas when used.
low+=events
signed=read('entry/signed_entry50_proof.tex')
signed=signed[signed.index('\\subsection{Signed moments'):]
signed=signed[:signed.index('\\subsection{A same-cell score cap')]
# Insert missing short signed penalty proof instead of directing reader outward.
signed=signed.replace('The full derivation and exact singular examples are in\n\\texttt{moment50.tex} and \\texttt{moment50.py}.',r'''Indeed on either sign, write $a=\E X_s^2$, $b=\E X_s^3$,
$c=\E X_s^4$, $f=\E X_s^5$. Cauchy gives $c\ge b^2/a$,
$f\ge c^2/b$, and
$\rho c/2-f/4\le\rho^2b/4-(c-\rho b)^2/(4b)$.
Distance to the half-line $c\ge b^2/a$ proves the stated penalty
on summing both signs.''')
signed=signed.replace('proved in the accompanying \\texttt{moment50.tex}.','as follows.')
signed=signed.replace('the old gap calculation','the signwise gap calculation')
signed=signed.replace('before the old threshold $D<2$','without assuming $D<2$')
signed=signed.replace('The negative-maximum branch is tested by the exact binary\nlaw supported on $\\{-3/2,2/3\\}$, which already satisfies $D<2$.','For example, the binary endpoints $A=3/2$, $B=2/3$ make this\nmaximum negative; the sign switch is necessary even when $D<2$.')
signed+=r'''
\paragraph{A complete coarse bound before a central gap is licensed.}
Always $-\mu_4/6\le J_1\le\mu_4/2$ and
$-3J_2-\eta_5/4\le0$. On a gap of length $h=b-a$, these follow from
\[
 \int_a^b(t-a)t\,dt+\tfrac12\int_a^bt^2dt=hb^2/2,\quad
 \tfrac32\int_a^bt^2dt-\int_a^b(t-a)t\,dt=h(2a+b)^2/6,
\]
and, on a negative gap $(-v,-u)$, from
$\tfrac13\int_u^v x^3dx-\int_u^v(v-x)x^2dx=u^3(v-u)/3$.
For $1\le r\le\rho$ and actual support radius $R\le6$, set
\[
 \Gamma(R,r)\ge\max_{r\le v\le R}
 \left\{-\frac{v^2}4+\frac{(R+r)v}3-\frac{Rr}2+
                      \frac{r^3(2R-r)}{12v^2}\right\}_+.
\]
Then
\[
 3(\rho J_1-J_2)\le\frac32\Gamma(R,r)(\rho-\gamma)
                              +\frac38\rho^2J.
\]
On negative gaps extract $x=|t|$ and discard the nonpositive part
$x<\rho$. Replacing $\rho$ by $r$ and the outer endpoint by $R$
gives $\int_r^v(R-x)x(x-r)\,dx$. Dividing this integral by $v^2$
gives exactly the displayed expression. Signwise Tonelli now charges
$\Gamma\E X_-^3=\Gamma(\rho-\gamma)/2$.
On positive gaps $(t-a)(\rho-t)\le\rho^2/4$, giving $\rho^2J/8$.
The implementation uses 64 closed $v$-intervals: on each, maximize the
concave quadratic at its clipped vertex $2(R+r)/3$ and the positive
reciprocal term at the left endpoint. This proves its interval bound.
The alternative bound $\Gamma\le5/2$ follows at $r=1,R=6$ by
$3v^4-28v^3+66v^2-11>0$ on $[1,6]$: the endpoint values are $30,205$,
and the interior critical values are $(85\mp35\sqrt5)/2>0$.
These monotone enclosing parameters cover all $r\ge1,R\le6$.
'''
# General probability coefficients include formulas, their proofs, and exact extremum rules.
coeff=cut(entry,'\\subsection{Moment and gap coefficients','\\subsection{Keeping the binary')
coeff=coeff.replace('For $p\\in[l,u]\\subset(0,1)$ set','Write $v=1-\\theta$. For $p\\in[l,u]\\subset(0,1)$ set')
# Avoid repeating the radial-measure proof, but retain actual coefficient rules.
cond=cut(entry,'\\subsubsection{Conditional lower moments','\\subsection{Generic event')
central=cut(entry,'\\subsection{Generic event','\\subsection{One Fourier transfer')
central=central.replace('Assume $|X|\\le R\\le6$. Let $0\\le d<2$ and $D\\le d$. Define', 'Assume $|X|\\le R\\le6$ and $\\rho\\le37/20$. Let $0\\le d<2$ and $D\\le d$. Define')
corner=cut(entry,'\\subsection{One interval-feedback theorem}','\\subsection{One ordered feedback operator}')
# Weight proof already proved in the core; retain full corner proof but not repeated feedback proof.
x=corner.index('For feedback use the conserved');corner=corner[:x]+'\\end{proof}\n'
corner=corner.replace('Once an initial bound $\\cR<T_0<Nc_0$ has been proved without defect or\ndensity feedback, every subsequent strict ceiling $\\cR<T$ implies', 'The weight-removal step in Lemma~\\ref{re:weight} gives')
corner=corner.replace('The weight-removal step in Lemma~\\ref{re:weight} gives', 'If $T$ is a strict upper bound for the final maximum in\\n\\eqref{entry:four-corners}, the weight-removal step in\\nLemma~\\ref{re:weight} gives'.replace('\\n','\n'))
# Remove historical scopes only where replaced by proved generic domain.
cond=cond.replace('The older STOP180 calculation uses $R=9/2$. The formula also permits separate actual bounds on the two signed support magnitudes.','The same formula permits separate actual bounds on the two signed support magnitudes.')
cond=cond.replace('The actual lower $\\rho$ bound is $\\rho_B(u)$, licensed by the\nalready proved central-gap cubic inequality\n$\\rho\\ge\\rho_B(p)+.45\\theta$.',r'''Use the lower bound $\rho\ge\rho_B(u)$ only after checking
$3\min(A_l,B_l)\ge(3/2)\sup_I\rho_B$. Indeed conditional expansion
and $(1-\theta)^{3/2}\ge1-3\theta/2$ then imply
$\rho\ge(1-\theta)^{3/2}\rho_B(p)+3\min(A,B)\theta\ge\rho_B(p)$.
Otherwise retain the universal lower bound one.''')
atlas=r'''\section{Coefficient atlas for the enclosure}\label{re:atlas}
These formulas are inequalities for one actual law. They are the two
coordinate descriptions of the same enclosure: signed moments before a
probability gap is located, and conditional moments afterwards. A bound
is used only with its stated gates, and every refinement is an intersection.
'''+signed+coeff+cond+central+corner
# Reference old repeated joint-resource notation via short compatibility equations.
compat=r'''
\paragraph{Compatible weaker resource constants.}
The implementation also permits the weaker binary charge
$b_I=(616/25)(1-\Theta)^2\operatorname{dist}(p_*,I)^2$.
It follows from $2(6+2\sigma)>616/25$ and
$(1-\theta)^{3/2}\ge(1-\theta)^2$.
With $K=\min(K_+,K_-)$ and $v_* =\max(v_+,v_-)$, the merged charge
\eqref{re:residual} gives
\[
 T_++T_-\le T_*=(d-b_I)\max\{v_*/[3(A_l+B_l)],(R+2v_*)/K\},
 \qquad d_o=\min\{d,(\sigma+1)T_*\}.
\]
Thus $W_o\le d_o$ and, for $R\le6$,
\[
 -75d_o/104\le J_{1,o}\le3d_o/2,\qquad
 3(\rho J_{1,o}-J_{2,o})\le\frac38
 \max\{\rho^2/(\sigma-1),(R-\rho)^2/(\sigma+1)\}d_o.
\]
These are precisely the merged-cost versions of the sign-specific
resource rule; they do not introduce another available budget.
'''
atlas=atlas.replace('\\subsubsection{Conditional lower moments',compat+'\n\\subsubsection{Conditional lower moments',1)
# Whole A confinement once, then add an antichain concentration choice and its simpler ray gate.
conf=read('local/confinement47_proof.tex');sper=read('local/sperner47_proof.tex')
a=cut(conf,'\\section{Statement and hypotheses}','\\begin{theorem}[Conditional confinement')
a=a.replace('Let $n\\ge N=47$','Let $n\\ge N=47$').replace('Select one of the 45 closed probability panels $[l,h]$ in the exact table.','Select an acquired closed probability panel $[l,h]$.')
a=a.replace('Assume the simultaneous moment inequality in its usable form:', 'The simultaneous moment inequality has the following usable form:')
a=a.replace('These are hypotheses on the same law and the same resource; no separate\nmaximizers may be substituted. The generic moment identity in the main\nmanuscript licenses \\eqref{moment}; stating it explicitly makes this\nconditional theorem independent of entry or optimizer-existence claims.',r'''To derive it, the endpoint expansion of \eqref{re:gapexact} gives
$D\ge m(\sqrt{\sigma+1}A-\sqrt{\sigma-1}B)^2
+2(\sigma+2)B^2M_++2(\sigma+4)A^2M_-
+3(\sigma+1)B\theta_++3(\sigma+3)A\theta_-$.
Insert $A\ge E(l-d_0)$, $B\ge E(1-h-d_0)$ and the rational lower
coefficients displayed above. For the square, write
$A=\ell(p-a)$, $B=\ell(1-p-(1-b))$, with
$a+(1-b)=d\le d_0$. Its unshifted coefficient is
$(\sqrt{\sigma+1}+\sqrt{\sigma-1})(p-p_*)$;
$\sqrt{\sigma+1}+\sqrt{\sigma-1}>3.5$ and
$\sqrt{\sigma+1}<2.041$ prove the stated lower square $P$.
For completeness, on the positive class put $Z=X-B\ge0$.
Then $T_+=2B^2M_++3B\E[Z^2;X>0]+\E[Z^3;X>0]$ and
$R_+=BM_++\E[Z^2;X>0]$. Consequently
$(\sigma-1)T_++6BR_+\ge2(\sigma+2)B^2M_+
+3(\sigma+1)B\theta_+$, since $\E[Z^2;X>0]\ge\theta_+$.
The reflected expansion gives the negative-class bound.
The centered absolute deviation on each class is at most twice its
mean distance from the inner endpoint, proving the bound on $\epsilon$.
All quantities refer to the same marginal.''')
b=cut(sper,'\\section{Concentration from an antichain}','\\section{Signed deletion')
b=b.replace('\\begin{equation}\\label{concentration}', '\\begin{equation}\\label{antichainconcentration}')
b+=r'''
Either the score-derived cap or the strict-gap cap may be selected on
an interval where its hypotheses hold. The first confinement uses the
score cap; later central and left schedules use the strict-gap cap.
For the left panels replace the conditional cubic coefficient 24 below
by 28; in general any $c_\rho$ satisfying
$c_\rho^2[l(1-l)]^3>[3(1-l)+.55]^2$ is valid.
'''
c=cut(conf,'\\section{Signed deletion','\\section{Exact coverage')
a0=c.index('For all $t\\le0$, completing the square');a1=c.index('\\paragraph{The sharper lower-ray slope.}',a0)
c=c[:a0]+c[a0:a1].replace('M_-',r'\mathcal M_-').replace('M_+',r'\mathcal M_+')+c[a1:]
# Add alternative strict-gap cap after interval geometry, before common budget.
marker='\\section{One budget, two error bounds}'
alt=r'''
\paragraph{The strict-gap alternative.}
If $1-.55-2d_0>0$ and the displayed lower intervals have width below
$1-d$ throughout $r\in[r_0,.55+d_0]$, take $Q_I=Q_J=M$.
For the upper intervals the corresponding gate is
$1-2d_0-2\tau_+>0$; then again $Q_I=Q_J=M$.
Use the same directed distances. Their concentration caps are now
independent of $r$, and use
$a_e=F_dM\{1/l+1/(1-h)\}/2$ in the next formulas.
The lower-ray gate reduces to $L>0$: its contact side increases with
$r$, while the entire error is constant on the acquired finite strip.
For the score-derived cap retain the explicit affine slope gate below.
No assertion outside that strip is needed.

'''
c=c.replace(marker,alt+marker)
confnew=r'''\section{One confinement lemma with two concentration choices}\label{re:confinement}
A proved amplitude is used as a support update, never as a premise of
its own proof. The following derivation applies to every acquired row,
with the same formulas for the central and left probability ranges.
'''+a+b+c+r'''
\paragraph{The selected schedules.}
The ordinary, central-antichain, and left-antichain certificates substitute
their recorded $r_0$ into these same gates. Noise-dependent amplitudes
are the same theorem with a positive lower noise endpoint in
$R=T_*/\kappa-b_*E^2s_l$. In the central rows the additional amplitudes
are $.35,.30,.275$ on $[.05,.08],[.08,.10],[.10,\Lambda]$;
on the left they are $.375,.325,.30$. Intersect each interval with its
own row's $\Lambda$ and each amplitude with that row's global amplitude.
The fixed acceptance checks both signs of $H$, all closed phase/noise
cells, clipped endpoints, and strict budget exclusions. No proof of
LOW, MID, or a binomial score comparison is used by this confinement lemma.
'''
# Scope confinement's generic labels so no collision with foundation.
confnew=scope(confnew,'conf')
# A concrete Bernstein formula used by central_bound, with proof.
bern=r'''\paragraph{The closed-box Bernstein identity.}\label{re:bernstein}
For a polynomial $P(x)=\sum_{k=0}^dt_kx^k$,
\[
 P(x)=\sum_{i=0}^d b_i\binom di x^i(1-x)^{d-i},\qquad
 b_i=\sum_{k\le i}t_k\binom ik/\binom dk.
\]
Indeed $\binom di\binom ik=\binom dk\binom{d-k}{i-k}$ and the
binomial theorem recover each monomial $x^k$. The basis terms are
nonnegative and sum to one on the closed unit interval. Tensor products
prove the two-variable version below, including all boundary points.
'''
atlas=atlas.replace('\\begin{lemma}[Complete central rectangle]',bern+'\n\\begin{lemma}[Complete central rectangle]')
# Old labels now point to shared definitions, not to a historical PDF.
replacements={
 'smooth:nonnegative-identity':'re:identity','smooth:remainder-polynomial':'re:raw',
 'smooth:coefficients':'re:raw','smooth:defect-definitions':'re:identity',
 'smooth:nonnegative-identity':'re:identity','found:q':'re:contact-q',
 'mom:gap-decomposition':'re:gapexact','smooth:gap':'re:gapexact',
 'entryleap:calculus':'re:pricing','entryleap:conditional':'re:conditional',
 'entryleap:radial':'re:pricing','mom:simultaneous-eq':'conf:moment',
 'mom:joint-eq':'re:joint','entry201:shared-shift':'re:joint',
 'mom:defect-exact':'re:gapexact','mom:outer-gap-budget':'re:gapexact',
 'entry201:residual':'re:residual','entry201:T':'re:outerresource',
 'entry201:outer':'re:outerresource','cert:bernstein':'re:bernstein',
 'smooth:split':'smooth:split','entry:feedback-values':'entry:feedback-values'}
confnew=confnew.replace('\\section{','\\subsection{')
confnew=confnew.replace('\\subsection{One confinement lemma with two concentration choices}', '\\section{One confinement lemma with two concentration choices}',1)
alltext=foundation+'\n'+low+'\n'+atlas+'\n'+(P/'unsigned_formula_card.tex').read_text()+'\n'+confnew
for a,b in replacements.items():
 for command in ('label','ref','eqref'):
  alltext=alltext.replace('\\'+command+'{'+a+'}','\\'+command+'{'+b+'}')
# Remove references in optional extra labels whose formula is retained under a new label.
for key in ['re:identity','re:raw']:
 alltext=alltext.replace('\\label{'+key+'}','')
# root contact display needs its explicit new label
alltext=alltext.replace('\\label{re:contact-q}', '\\label{re:contact-q}',1)
alltext=alltext.replace(r'$E[(R-|X|)(1,|X|)^{\mathsf T}(1,|X|);\pm X>0]$.',r'\[E[(R-|X|)(1,|X|)^{\mathsf T}(1,|X|);\pm X>0].\]')
alltext=alltext.replace(r' c=\frac{1-\max_{u\in\{1/4,81/100\}}',r' \begin{gathered}c=\frac{1-\max_{u\in\{1/4,81/100\}}')
alltext=alltext.replace(r'[1-u+(M+3)u^2/12]}2,\qquad',r'[1-u+(M+3)u^2/12]}2,\\')
alltext=alltext.replace(r' s=\frac{1-(M+3)53/600}{2}.',r' s=\frac{1-(M+3)53/600}{2}.\end{gathered}')
alltext=alltext.replace('suppose $L\\ge(1-\\theta)J$, $e\\ge0$, and','note that the central gap contributes $m\\ell J=(1-\\theta)J$ to $L$.\nThus $L\\ge(1-\\theta)J$; retain $e\\ge0$ and')
alltext=alltext.replace('In particular its first, second and third absolute moments are\n$\\gamma/2$, $\\E X^4/3$ and $\\E|X|^5/4$.',r'''In particular,
$\E X^*=\gamma/2$, $\E(X^*)^2=\E X^4/3$ and
$\E|X^*|^3=\E|X|^5/4$.''')

(P/'entry_formula_atlas.tex').write_text(alltext)
# inventory of source reads; no source copied or modified
(P/'SOURCE_MAP_INPUTS.json').write_text(json.dumps(dict(schema='SHORT50_ENTRY_SOURCES_V1',sources=list({r['path']:r for r in records}.values())),indent=2)+'\n')
print('Generated formula atlas from',len(records),'read-only sources')
