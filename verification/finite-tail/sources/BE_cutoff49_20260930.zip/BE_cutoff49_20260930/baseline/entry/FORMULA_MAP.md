# Resource enclosure: formula and implementation map

The new exposition reorganizes the existing arithmetic. It does not change any accepted kernel, target, table, or source binding. Paths in the third column are relative to `work/below50_20260929/`; the old foundational source paths are spelled out separately. The proof is in `resource_entry.tex` and its included `entry_formula_atlas.tex`. The unsigned card is included by the generator.

| New formula or lemma | Mathematical operation | Unchanged implementation / source |
|---|---|---|
| `re:identity`, `re:raw`, `re:foundation` | Contact → compensated smooth inversion → exact four-term budget; complete atom conventions | `work/below100_20260929/paper99/sections/identity.tex`, smooth remainder and defect identity |
| `re:weight`, `re:extra` | First raw sign license; remove Gaussian weight; coherent phase rebate | `kernel.initial_cell`, `kernel.general_envelope`, `local_signed_core.stage`, `contracted_panel_core.cell`, `sperner_panel_core.cell` |
| `re:pricing`, `re:simplex` | Conditional Taylor remainder and radial positive measures; one shared resource | `kernel.general_cell`, `kernel.signed_k_error`, `signed_variance_resource.install` |
| `re:gapexact`, `re:joint` | Central gap; exact defect decomposition; binary/shift/two-variance charges | `kernel.general_geometry`, `kernel.general_cell`, `local_signed_core.stage` |
| `re:geometry`, `re:exports` | Sequential geometry updates; separately weighted variance, inward shift and lambda | `local_panel_core.cell`, `contracted_panel_core.variance_resource`, `sperner_panel_core.variance_resource` |
| `re:moments`, `re:outerresource` | Separate sign-cost upper moments and outer-gap charge | `signed_variance_resource.install`; `signed_variance_resource47_proof.tex` |
| `re:gamma` and Fourier-only reflection paragraph | Signed gamma lower bound; interpret paired lower endpoint as a bound on absolute gamma | `paired_conditional_gamma47.install`; `paired_fourier_orientation47.tex`; no change to signed contact data |
| Signed-moment subsection | Shared first moment, projection, support-localizing moment matrices; all zero-denominator boundaries | `local_signed_core.stage`; independent derivation `structural/moment50.py` and `moment50.tex` |
| Coarse negative-gap coefficient paragraph | Exact integral formula for Gamma, with 64 interval cells and optional 5/2 bound | `kernel.negative_gap_coefficient`, `contracted_kernel.negative_gap_coefficient` |
| Signed central/outer integral subsection | P1/P2 central polynomials; outer allocation; both signs of multiplying by m | `local_signed_core.stage`; the negative P1 maximum uses the lower m endpoint |
| Complete LOW transfer and Mills lemma | Complete integral on [0,1/2], signed cancellation rectangle, finite positive-integral continued fraction | `kernel.sixth`, `kernel.paired`; same functions in `contracted_kernel` |
| Complete HIGH theorem and rational Laguerre bound | All six frequency pieces; actual common-law product event; wider windows; all-index gates | `high_window_core.install` and `entry/high_refinement.py` for first-barrier Laguerre-only option |
| Closed-box Bernstein identity / complete central rectangle | Tensor degree-four Bernstein upper envelope; same m interval | `kernel.central_bound` |
| Continuous-cell corner lemma | Full C–rho corners, full K1–U–density rectangles, complete-square maximum | `kernel.general_envelope`, `kernel.late_envelope`; four exported coherent quadratics |
| `re:unsigned` | Complete unsigned initial rho cover and its optional signed beta/K1 refinement | `kernel.initial_cell`; `root/propagation/chain_core.stage` universal and initial branches |
| End of `re:unsigned` | General geometry and probability-cell cover | `kernel.general_geometry`, `kernel.general_cell`; `root/propagation/chain_core.stage` general branch |
| `re:radiusfeedback` | Actual amplitude implies actual standardized support | `accept_confined_feedback47.shape`, `accept_sperner_feedback47.shape` |
| Confinement theorem: contact derivative and leakage | Same attaining law; two deleted convolution score caps; moment resource | `local/confinement47_kernel.py` and `local/confinement47_contract.py` |
| Strict-gap antichain / mode cap | Actual product-law concentration for n−1 and n−2 full summands | `local/sperner47_kernel.py` and `local/sperner47_contract.py` |
| Signed deletion and coupled two-interval bounds | Centered noise costs; exceptional-pair Cantelli/Markov bounds | Same two confinement kernels; retained by left and noise-profile wrappers |
| Confinement simplex tangent bounds | Eleven rational tangent choices for the pair event and the same common resource | Same kernels, `check_side` / error-envelope construction |
| `re:localG` | Exact nd<G bridge to local comparisons; empty closed boxes allowed | `root/low47_kernel.py`, `root/phase_left_low47_kernel.py`; local module owns their score proofs |

## Shared callbacks owned by the global chapter

These are prior analytic implications, not consequences of a moment-table hash:

1. Attainment at and above C_E and contact: global labels `global:attainment`, `global:contact`.
2. All-H heat-contact support (including R=3.84 and barrier R=3.5): `support:theorem`, `support:polynomial`.
3. Bounded-H Gaussian series and fixed central radius/coordinate-strip contracts: `root/accept_support47.py`, `root/accept_panel_exterior47.py` and `root/accept_left_strip47.py`.
4. Left radius3 and2.7 heat rows: `entry/accept_left_support47.py`, `entry/accept_left_radius270_47.py`.

Every callback checks its predecessor table's simultaneous premises. In particular the central radius2.5 is acquired from PREP, and the left radius2.7 is acquired from the signed-resource table. No support callback invokes the local score comparison.

## Precise scope changes in the new exposition

- INITIAL47's `nmax=98` is a configuration field. Its sole numerical occurrence in `local_signed_core.stage` is `c0=.4095+K/nmax`; K=0 here. The floor `n=47` is the lower index at which monotone upper formulas are evaluated. This gives every actual n>=47, not just n<=98.
- Confinement has the same all-index scope: its two mass estimates apply to j>=n−2>=45; its index-factor gates decrease after47.
- Reflection is confined to the unsigned Fourier integral. Signed contact, gamma, beta, gaps and phase never change orientation.
- The complete closure uses selected central C2 and selected left L2. The optional further central output of S is not needed for the final local theorem.
- The first finite ceiling still uses positive barrier K/n and a finite nmax; that scope is distinct and remains unchanged.

## What is and is not rechecked here

`validate_schedule.py` checks source equality against the accepted manifest, ordered acyclic dependencies, exact final probability covers, all four corner fields, weighted resource metadata, and the K=0 initialization scope. Its negative controls reject broken schedules and covers. This is a **fresh structural consistency check**, not a rerun of the expensive entry arithmetic. The corresponding old exact acceptors and logged runs remain the arithmetic evidence; the new enclosure theorem supplies their consolidated analytic reduction.

The structural checker locates either an ancestor workspace or an ancestor’s `certificates/` directory. It therefore runs unchanged in the extracted sibling-directory package.
