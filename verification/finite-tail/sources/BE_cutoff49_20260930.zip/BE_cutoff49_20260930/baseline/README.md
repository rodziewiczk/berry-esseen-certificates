# Berry–Esseen cutoff 50: shorter proof

The manuscript proves **C_n < C_E for every integer n ≥ 50**, with the
definitions and published inputs on its opening pages. This is the same
cutoff as the previous delivery: **52 pages instead of 147**, at a readable
11-point type size. Read pages 1–6 first for the statement and global argument.

## What changed

1. Prove just the finite base at 50, then rule out the first later failure.
   Smoothing gives that failure its own excess ceiling, below `.29/n`.
   The old cutoff-99 theorem and the global positive-excess ceiling are
   no longer dependencies.
2. Use Schulz's Theorem 1 on its full domain, every `0 < p < 1`.
   The separate finite left-binomial certificate is unnecessary.
3. Organize entry around one conserved resource and a finite enclosure
   theorem. Prove the Fourier and moment formulas once.
4. Use one local score identity with two sufficient estimates. Central,
   left and positive-phase cases become parameter choices, sharing the
   normalization, quartic, Poisson and count arguments.

The main argument is near the beginning; the subsequent sections supply
all project-specific analytic reductions and the exact-arithmetic method.
This is a computer-assisted research proof, not a Lean formalization or
an external referee report. The remaining unrestricted smaller cases are
not settled by this manuscript.

## Reproduce

Use ordinary Python 3 with assertions enabled. From a fresh extracted
archive, choose an output directory that does not exist:

```sh
python3 -B verify.py --output /tmp/BE_short50_fresh
```

This checks archive integrity, the independently derived scalar
composition, the new finite-base restriction, the entry schedule, the local formula map and
the retained component arithmetic. Logs record versions, hashes, return
codes, timings, stdout and stderr. A declared output-writing inherited
acceptor runs unchanged in a disposable copy and must regenerate exactly
the same bytes. The other sources are read-only during execution.

For a short integrity/scalar check only:

```sh
python3 -B verify.py --quick --output /tmp/BE_short50_quick
```

The quick check does **not** rerun the large certificate suite. Arithmetic
execution does not by itself verify the mathematical reductions in the
manuscript. The two claims are kept separate in the evidence.

## Source organization

- `paper/`: main LaTeX manuscript; it imports the shared entry and local
  chapters from their sibling directories.
- `entry/`, `local/`: consolidated mathematical chapters, source maps and
  targeted checks.
- `finite/`: fixed finite-base acceptance, using unchanged arithmetic
  kernels and only the first old propagation band.
- `audit/`: independent global and module reviews and scalar checks.
- `certificates/`: unchanged workspace-shaped copy of the inherited
  arithmetic capsule. Its historical filenames and records are retained
  for reproducibility. Its old global theorem is **not** a premise of the
  new proof; do not use its legacy top-level launcher for this manuscript.
- `jobs.json`: selected retained jobs. One redundant central-strip check
  is retained as a regression check; the new dependency map distinguishes it.
- `evidence/`: fresh replay summaries and final layout/review records.
- `MANIFEST.json`: hashes of all delivered members except itself.

The discarded uniform-ceiling exploration is not included in the selected
proof. The original 147-page PDF and its source archive remain preserved
in the project workspace.

To rebuild the manuscript, run `latexmk -pdf main.tex` from `paper/` using
TeX Live with the listed standard LaTeX packages. Rebuild in an editable
copy so generated files do not alter the preserved archive.

The top-level `verify.py` and its selected acceptance tools are portable.
Development-only generators and review-binding scripts retain their original
workspace paths as provenance; they are not required by the replay command.
