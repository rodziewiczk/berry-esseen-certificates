# Selected proof: finite base and first later failure

## Statement and evidence boundary

For the iid Berry–Esseen constants defined in the manuscript,
`C_n < C_E = (3 + sqrt(10))/(6 sqrt(2 pi))` for every integer `n >= 50`.
This is the same numerical cutoff as the previous delivery. The new work
shortens its mathematical dependency graph and exposition.

| Input or implication | Mathematical status | Execution status |
|---|---|---|
| Shevtsova's finite estimates; Schulz Theorem 1 for all `0<p<1`; He–Cheng finite contact and Gaussian formula | Cited published/preprint inputs, with exact scope in Section 1.1 | Not claimed to be machine verified |
| Fixed-index attainment, including equality | Locally derived and independently reviewed, Section 2 | Analytic proof; no arithmetic PASS substitutes for it |
| Smoothing and first-failure estimates | Locally derived and independently reviewed, Section 3 | Fresh independent rational scalar checks |
| Uniform support and finite support rows | Locally derived, fully stated in Section 4 | Fresh exact arithmetic replay, including infinite index endpoint |
| Resource, Fourier, moment and confinement formulas | Consolidated and independently reviewed, Sections 5–8 | Fresh component replay plus structural schedule check |
| One local comparison theorem | Consolidated and independently reviewed, Section 9 | Fresh six local component replays and complete cover check |
| Finite base `40..45` | New restricted composition of unchanged arithmetic | Fresh new finite acceptor; 704 closed cells |
| Final cutoff 50 | Locally derived computer-assisted research proof, conditional on the cited inputs and correctness of the documented computational stack | Fresh selected arithmetic and composition checks; not a Lean proof or external referee report |

## Directed dependencies and their hypotheses

1. **Finite caps → attained contact.** At each fixed index the supremum is
   attained as a positive closed discrepancy. Compactness of the support
   follows from the cubic contact tail, before higher moments are used.
2. **Contact + support + resource enclosure → four supported exclusions.**
   `A40`: n=40, radius3.3, score cap.469, barrier1.5, decrement.88.
   `P41`: certified band41..49, radius2.9, score cap.469, barrier1.5,
   decrement1.5/40; used only41..45.
   `A45`: n=45, radius3.5, score cap.4431, barrier.7, decrement.8341.
   `P46`: certified band46..98, radius3.5, score cap.432, barrier.7,
   decrement.7/45; used only46..50.
3. **A40 + P41 → `a_j<1.5/j`, 40≤j≤45**, where `a_j=C_j-C_E`.
   **A45 + P46 + smoothing → `a_j<.7/j`, 45≤j≤50**.
   These implications require no larger-index theorem.
4. **Local premises → acquired parameter cover.** For every n≥47 assume
   `0≤a_n≤.7/n`, `δ_n=n(C_(n−1)−C_n)_+≤.19`, current score<.4247,
   and both deleted-index scores<.4253. Uniform support first gives radius
   3.84. The finite resource schedule and confinement give the 83 closed
   probability panels and their actual weighted noise bounds.
   The stored INITIAL47 endpoint98 has no arithmetic effect at barrier0:
   its only coefficient occurrence is `K/nmax`, with K=0. Weighted `nD`
   and `n E U²` are retained throughout; the index is not fixed to47.
5. **Acquired cover + local identity → contradiction.** Positive noise gives
   `rho_B (C-C_B^+(n,p,k)) < -.001 lambda`, using the actual Bernoulli score.
   Schulz handles all p in (0,1), including the left panels below1/3.
   At zero noise the law is Bernoulli itself. Thus the local premises in4
   cannot simultaneously hold. All these formulas are valid for n≥47.
6. **Finite ceiling + local contradiction → C50<CE.** A failure at50 forces
   four losses at50,49,48,47, so
   `a46 > .19(1/50+1/49+1/48+1/47) > .7/46`.
   The exact reserve is `2930539/6356280000`.
7. **Least later failure + smoothing → local premises.** If n≥51 is the
   least failure, its predecessor is below CE, hence δ_n=0. Smoothing gives
   `n a_n < 75975113/262500000 < .29`, stronger than the required.7.
   Current and deleted caps follow; at n=51 the second predecessor49 uses
   the finite ceiling. Apply5. This proves the infinite tail directly.

## Removed dependencies

The previous cutoff-99 theorem, global positive-excess ceilings, the finite
left-binomial certificate, and eventual-tail claims are not premises.
The old all-band ceiling40 acceptor is replaced by the named finite-base
acceptor. The old cutoff50 composition launcher is not run.

The selected `jobs.json` has 43 retained jobs: 42 required component,
coverage and control jobs, plus `certificate_central_strip47` as an extra
regression. The central support acceptor already verifies the same strip
cells. Auxiliary controls test identities and domain semantics; their
success is not a substitute for the analytic derivations.

## Trusted stack and reproducibility

Acceptance uses unoptimized CPython, exact integers/Fractions, the shipped
arithmetic source, and the manuscript's reductions. The file manifest
establishes byte integrity only. Fresh evidence records all interpreter
versions, return codes, input hashes and standard streams. The inherited
output-writing complement acceptor runs in an isolated copy and must
reproduce identical bytes. See README.md for fresh replay commands.

The manuscript does not settle the unrestricted remaining indices below50,
and it makes no claim of formal verification in Lean.
