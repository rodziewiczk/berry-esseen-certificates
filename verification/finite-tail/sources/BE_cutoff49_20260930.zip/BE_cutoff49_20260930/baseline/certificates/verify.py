#!/usr/bin/env python3
"""Run the complete selected arithmetic suite, then its fixed composition."""
from pathlib import Path
import argparse,json,subprocess,sys
if sys.flags.optimize or not __debug__:raise SystemExit('Use unoptimized Python')
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    root=Path(__file__).resolve().parent;out=a.output.resolve()
    if out.exists():raise SystemExit('Output directory already exists')
    out.mkdir(parents=True)
    runner=root/'work/below50_20260929/release_tools/run_certificates_v2.py'
    command=[sys.executable,'-B',str(runner),'--workspace-root',str(root),'--output',str(out/'components')]
    rc=subprocess.run(command,cwd=root).returncode
    if rc:return rc
    composition=root/'work/below50_20260929/root/accept_cutoff50_composition_v2.py'
    with (out/'composition.stdout.txt').open('wb')as so,(out/'composition.stderr.txt').open('wb')as se:
        rc=subprocess.run([sys.executable,'-B',str(composition)],cwd=root,stdout=so,stderr=se).returncode
    (out/'result.json').write_text(json.dumps({'status':'PASS'if rc==0 else'FAIL','selected_component_jobs':48,'composition_returncode':rc},indent=2)+'\n')
    print('PASS_COMPLETE_CUTOFF50_REPLAY'if rc==0 else'FAIL_CUTOFF50_COMPOSITION',flush=True)
    return rc
if __name__=='__main__':sys.exit(main())
