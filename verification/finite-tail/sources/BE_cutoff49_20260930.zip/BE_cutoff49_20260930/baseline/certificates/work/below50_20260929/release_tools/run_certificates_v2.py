#!/usr/bin/env python3
"""Portable V2 runner: declared writers execute unchanged in full disposable copies."""
import argparse,hashlib,json,os,platform,re,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
from isolated_acceptance import run_isolated
WRITERS={
 "certificate_complement47": {"cwd":"work/below50_20260929/entry","argv":["accept_complement47.py"],"outputs":["work/below50_20260929/entry/complement47_accepted.json"]}
}
if sys.flags.optimize or not __debug__:raise SystemExit('Unoptimized Python is required; -O/-OO are forbidden.')

def stamp():return datetime.now(timezone.utc).isoformat()
def sha(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def unique(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('Duplicate JSON key: '+k)
  d[k]=v
 return d
def relative(s):
 p=Path(s)
 if not s or p.is_absolute()or'..'in p.parts or'\\'in s:raise ValueError('Unsafe relative path: '+s)
 return p
def load_jobs(path):
 jobs=json.loads(path.read_text(),object_pairs_hook=unique)
 if type(jobs)is not list or not jobs:raise ValueError('Expected nonempty jobs list')
 names=set()
 for j in jobs:
  if type(j)is not dict or set(j)!=set(('name','cwd','argv','source_run')):raise ValueError('Exact job fields required')
  if type(j['name'])is not str or re.fullmatch('[a-z][a-z0-9_]*',j['name'])is None or j['name']in names:raise ValueError('Invalid/duplicate job name')
  names.add(j['name']);relative(j['cwd']);relative(j['source_run'])
  if type(j['argv'])is not list or not j['argv']or any(type(s)is not str for s in j['argv']):raise ValueError('Invalid argv')
  relative(j['argv'][0])
  if not j['argv'][0].endswith('.py')or any(s in('-O','-OO')for s in j['argv']):raise ValueError('Expected unoptimized Python script')
 return jobs

def discover_workspace(jobs,start):
 for p in(start,*start.parents):
  if all((p/relative(j['cwd'])/relative(j['argv'][0])).is_file()for j in jobs):return p
 raise ValueError('Could not find the workspace-shaped capsule; pass --workspace-root')
def snapshot(root,jobs,extra):
 files=set(extra)
 for cwd in{j['cwd']for j in jobs}:
  directory=root/relative(cwd)
  for suffix in('*.py','*.json','*.tex'):
   for p in directory.rglob(suffix):
    if '__pycache__'not in p.parts:files.add(p)
 result={}
 for p in sorted(files):
  if not p.is_file():raise ValueError('Missing source '+str(p))
  try:key=p.relative_to(root).as_posix()
  except ValueError:key=str(p)
  result[key]=sha(p)
 return result

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--workspace-root',type=Path);ap.add_argument('--job-file',type=Path,default=Path(__file__).with_name('jobs.json'));ap.add_argument('--only',action='append',default=[]);args=ap.parse_args()
 all_jobs=load_jobs(args.job_file);known={j['name']for j in all_jobs}
 if any(n not in known for n in args.only):raise ValueError('Unknown --only job')
 jobs=[j for j in all_jobs if not args.only or j['name']in args.only]
 root=args.workspace_root.resolve()if args.workspace_root else discover_workspace(jobs,Path(__file__).resolve().parent)
 for j in jobs:
  cwd=(root/relative(j['cwd'])).resolve();script=(cwd/relative(j['argv'][0])).resolve()
  if root not in cwd.parents or root not in script.parents or not script.is_file():raise ValueError('Job path outside workspace or missing')
 for j in jobs:
  if j['name'] in WRITERS and (j['cwd']!=WRITERS[j['name']]['cwd'] or j['argv']!=WRITERS[j['name']]['argv']):raise ValueError('Declared writer invocation changed')
 out=args.output.resolve()
 if any(j['name'] in WRITERS for j in jobs) and (out==root or root in out.parents):raise ValueError('An isolated writer requires output outside the complete capsule')
 if out.exists():raise ValueError('Refuse existing output directory: '+str(out))
 # Keep fresh logs out of all snapshotted source directories.
 if any((root/j['cwd']).resolve()==out or(root/j['cwd']).resolve()in out.parents for j in jobs):raise ValueError('Output must be outside selected source directories')
 out.mkdir(parents=True);meta=dict(schema='BE_FIXED_CERTIFICATE_SUITE_V2',status='RUNNING',workspace=str(root),started_utc=stamp(),python=sys.version,executable=sys.executable,platform=platform.platform(),optimized=False,job_file_sha256=sha(args.job_file),runner_sha256=sha(Path(__file__)),isolation_helper_sha256=sha(Path(__file__).with_name('isolated_acceptance.py')),selected_jobs=len(jobs),source_run_note='source_run is provenance for the prior run; each job below is freshly executed by this runner.',snapshot_scope='All .py/.json/.tex beneath the selected job cwd directories, plus the runner and jobs file. Per-certificate dependency hashes and the release manifest cover additional imported or inherited files.',jobs=[])
 before=snapshot(root,jobs,{Path(__file__).resolve(),args.job_file.resolve(),Path(__file__).with_name('isolated_acceptance.py').resolve()});meta['input_sha256']=before
 def save():
  target=out/'metadata.json';temp=out/'metadata.tmp';temp.write_text(json.dumps(meta,indent=2)+'\n');temp.replace(target)
 save();env=os.environ.copy();env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONHASHSEED']='0';failed=False;interrupted=False
 try:
  for job in jobs:
   start=time.monotonic();name=job['name'];stdout=out/(name+'.stdout.txt');stderr=out/(name+'.stderr.txt');command=[sys.executable,'-B',*job['argv']]
   print('START '+name,flush=True);record=dict(**job,command=command,started_utc=stamp())
   try:
    with stdout.open('wb')as so,stderr.open('wb')as se:
     if name in WRITERS:
      rc,details,verified=run_isolated(root,job,WRITERS[name]['outputs'],command,env,so,se)
      record['isolated_acceptance']=details
      record['process_returncode']=rc
      if not verified:rc=rc if rc!=0 else 3
     else:
      proc=subprocess.run(command,cwd=root/job['cwd'],env=env,stdout=so,stderr=se);rc=proc.returncode
   except KeyboardInterrupt:rc=130;interrupted=True
   record.update(returncode=rc,elapsed_seconds=time.monotonic()-start,finished_utc=stamp(),stdout_sha256=sha(stdout),stderr_sha256=sha(stderr));meta['jobs'].append(record);failed|=rc!=0;save();print(('PASS 'if rc==0 else'FAIL ')+name+' exit='+str(rc),flush=True)
   if interrupted:break
 finally:
  after=snapshot(root,jobs,{Path(__file__).resolve(),args.job_file.resolve(),Path(__file__).with_name('isolated_acceptance.py').resolve()});meta['input_sha256_after']=after;meta['sources_unchanged']=before==after;meta['finished_utc']=stamp();meta['status']='INTERRUPTED'if interrupted else'PASS'if not failed and before==after and len(meta['jobs'])==len(jobs)else'FAIL';save()
 print(json.dumps(dict(status=meta['status'],jobs=len(meta['jobs']),sources_unchanged=meta['sources_unchanged'],metadata=str(out/'metadata.json'))),flush=True)
 return 0 if meta['status']=='PASS' else 1
if __name__=='__main__':
 try:sys.exit(main())
 except Exception as e:print(type(e).__name__+': '+str(e),file=sys.stderr);sys.exit(2)
