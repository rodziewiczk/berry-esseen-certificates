"""Pure exact kernel for the newly named CONDITIONAL_HEAT47_CENTRAL234.

No old target is changed. Reconstruct the signed fifth-order envelope on
[2.34,4.5] and both whole far rays. The mathematical hypotheses include
attained same-law contact, C>=CE, rho<=1.15, |beta|<=.252, decrement<=.19.
The proof in heat47_central234.tex licenses every real threshold and n>=47.
"""
from fractions import Fraction as F
from hashlib import sha256
import json,sys
import heat_support50 as H
assert __debug__ and not sys.flags.optimize

def data():
 N=47;v=N-1;c=F('.4095');rho=F('1.15');beta=F('.252')
 ell=H.root(F(v))[0];S=H.root(F(N,v))[1]
 A=H.A;J=H.trim([0,-15,0,0,0,1]);H4=H.H4
 DU=H.scale(J,F(1,120*v));W=H.add(A,H.scale(DU,F(-15,2)))
 E=H.add(H.scale([0,0,0,0,0,0,1],F(51,14400*v)/ell),
         H.scale([-2,0,3],F(51,960*v)/ell),[0,F(1,8*v*v)])
 B2=H.scale(H.mul(H4,H4),F(1,256*v))
 Numer=H.add(H.mul(A,W),B2)
 Dom=H.add(H.mul(H.add(H.scale(A,F(1,2)),H.scale(DU,-3),
                     H.scale(H4,F(-1,12)/ell)),W),B2)
 Q=[rho*H.EC/N,3*beta,F(3,2)*rho,-1]
 PA0=H.add(H.scale(Numer,F(2,5)*S**3),
          H.scale(H.mul(E,W),S**3),H.mul(H.scale(Q,c),W))
 PAq=H.scale(W,rho*S)
 ray0=H.add([F(1,2),F(1,5),0,F(1,15)],H.scale(Q,c))
 return dict(N=N,c=c,rho=rho,beta=beta,ell=ell,S=S,J=J,W=W,
             Dom=Dom,Q=Q,PA0=PA0,PAq=PAq,ray0=ray0)

def reconstruct(radius=F('2.34'),decrement=F('.19')):
 if not (F(2)<radius<F('4.5') and decrement>=0):raise ValueError('domain')
 p=data();pa=H.add(p['PA0'],H.scale(p['PAq'],decrement))
 gate=[];cells=[];l=radius
 H.scale_gate(p['N'])
 if not(p['ell']>0 and p['ell']**2<=46 and p['S']**2>F(47,46)):
  raise ValueError('root directions')
 while l<F('4.5'):
  r=min(F('4.5'),l+F(1,20))
  for name,poly in [('A',H.A),('H4',H.H4),('J',p['J']),('W',p['W']),
    ('outer_domination',p['Dom']),('negative_C',H.scale(p['Q'],-1)),
    ('contact',H.scale(pa,-1))]:
   coeff=H.bern(poly,l,r)
   if min(coeff)<=0:raise ValueError((name,str(l),str(min(coeff))))
   gate.extend((name,str(x))for x in coeff)
  cells.append([str(l),str(r)]);l=r
 for name,poly in [('coefficient_ray',p['Q']),
                  ('contact_ray',H.add(p['ray0'],[p['rho']*p['S']*decrement]))]:
  for j in range(4):
   value=-H.val(poly,F('4.5'))
   if value<=0:raise ValueError((name,j,str(value)))
   gate.append((name+str(j),str(value)));poly=H.deriv(poly)
 return dict(schema='CONDITIONAL_HEAT47_CENTRAL234_V1',
     hypotheses={'n_floor':47,'C_lower':'CE','rho_upper':'23/20',
       'beta_absolute_upper':'63/250','decrement_upper':str(decrement),
       'contact':'actual attained positive closed same-law contact'},
     radius=str(radius),threshold_scope='every real H',
     closed_cells=cells,gates=len(gate),
     minimum_contact=str(min(F(x)for name,x in gate if name=='contact')),
     gate_sha256=sha256(json.dumps(gate,separators=(',',':')).encode()).hexdigest())
