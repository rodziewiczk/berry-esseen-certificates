#!/usr/bin/env python3
"""Fixed acyclic refinement after the separately proved INPUT47 confinement.

This checker binds both the weak input and its confinement conclusion. It
does not prove confinement or claim anything about the left p-complement.
"""
from fractions import Fraction as F
from pathlib import Path
import copy, hashlib, json, sys
import contracted_panel_core as c

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'duplicate JSON key')
        out[key] = value
    return out

def load(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)

def shape(table):
    need(table['schema'] == 'CONFINED_FEEDBACK47_INPUT_V1', 'fixed theorem')
    need(type(table['N']) is int and table['N'] == 47, 'fixed index floor')
    need(table['own_score_cap'] == '4247/10000', 'fixed own score cap')
    need(table['probability_domain'] == ['19/50', '47/100'], 'central domain')
    need(table['source_sha256'] == sha('../local/conditional_input47.json'), 'weak input binding')
    need(table['confinement_sha256'] == sha('../local/confinement47_certificate.json'), 'confinement binding')
    old = load('../local/conditional_input47.json')
    confinement = load('../local/confinement47_certificate.json')
    need(confinement['contract']['input_sha256'] == table['source_sha256'], 'same weak hypotheses')
    need(len(confinement['rows']) == 90, 'both signs in complete confinement cover')
    need(type(table['panels']) is list and len(table['panels']) == 45, 'complete feedback cover')
    for j, row in enumerate(table['panels']):
        need(type(row['index']) is int and row['index'] == j, 'ordered unique indices')
        need(list(map(F, row['p'])) == [F(190+j,500), F(191+j,500)], 'closed contiguous p cells')
        need(row['p'] == old['panels'][j]['p'], 'same probability cells')
        amp = F(row['amplitude'])
        need(amp == F(old['panels'][j]['candidate_amplitude']), 'proved amplitude')
        for sign, prev in zip((-1,1), confinement['rows'][2*j:2*j+2]):
            need(prev['index'] == j and prev['sign'] == sign and prev['p'] == row['p'] and F(prev['amplitude']) == amp, 'both actual sign conclusions')
        l,u = map(F,row['p'])
        lower_root = c.k.roots(min(l*(1-l),u*(1-u)))[0]
        radius = c.k.up(max(u+amp,1-l+amp)/lower_root,1000)+F(1,1000)
        need(F(row['actual_radius']) == radius and 1 < radius < F('2.3'), 'outward contracted actual radius')
        need(len(row['quadratics']) == 4, 'all four signed corner quadratics')
        for q in row['quadratics']:
            need(set(q) == {'A','Fplus','Fminus','Qraw','Qbudget'}, 'quadratic fields')
            need(F(q['A'])>0 and 0<F(q['Qraw'])<F(q['Qbudget']), 'positive phase curvatures')

def verify(table, emit=False):
    shape(table)
    old = load('../local/conditional_input47.json')
    for j,target in enumerate(table['panels']):
        z = old['panels'][j]
        l,u = map(F,z['p'])
        row = dict(pl=l,pu=u,raw=F(z['T']),D=F(z['D']),theta=F(z['theta']),rho=F(z['rho']),beta=F(z['beta_hi']))
        out = c.cell(47,F(target['actual_radius']),F('.4247'),row,steps=24)
        need(not out.get('excluded') and 'quadratics' in out, 'selected complete paired output')
        for actual, claim in [('raw','T'),('D','D'),('theta','theta'),('rho','rho'),('beta','beta_hi'),('lambda_max','lambda_max'),('inward_d_max','d0'),('Hplus','H_plus'),('Hminus','H_minus')]:
            need(out[actual] <= F(target[claim]), ('feedback upper',j,claim))
        for actual,claim in [('beta_lo','beta_lo'),('A','A_lo'),('B','B_lo')]:
            need(out[actual] >= F(target[claim]), ('feedback lower',j,claim))
        for actual,claim in zip(out['quadratics'],target['quadratics']):
            for key in ('A','Fplus','Fminus'):
                need(actual[key] <= F(claim[key]), ('feedback signed corner upper',j,key))
            for key in ('Qraw','Qbudget'):
                need(actual[key] >= F(claim[key]), ('feedback signed corner curvature',j,key))
        if emit:
            print('PASS_CONFINED_FEEDBACK47',j,flush=True)
    return dict(status='PASS_CONFINED_FEEDBACK47',panels=45,weighted_resources=True,acyclic_premises='acquired weak INPUT47 and separately proved confinement')

def controls(table):
    cases=[]
    for action in [lambda z:z['panels'].pop(),lambda z:z['panels'].reverse(),lambda z:z['panels'].insert(1,z['panels'][0]),lambda z:z['panels'][0].update(index=True),lambda z:z['panels'][0].update(p=['19/50','39/100']),lambda z:z['panels'][0]['quadratics'].pop(),lambda z:z.update(source_sha256='0'*64),lambda z:z.update(confinement_sha256='0'*64),lambda z:z['panels'][0].update(amplitude='1/10'),lambda z:z['panels'][0].update(actual_radius='1')]:
        bad=copy.deepcopy(table);action(bad);cases.append(bad)
    for bad in cases:
        try:
            shape(bad)
        except (ValueError,KeyError,TypeError):
            pass
        else:
            raise ValueError('malformed feedback proof accepted')
    for field,value in [('T','1/100'),('lambda_max','1/100000000')]:
        bad=copy.deepcopy(table);bad['panels'][0][field]=value
        try:
            verify(bad)
        except ValueError:
            pass
        else:
            raise ValueError('false feedback arithmetic target accepted')
    try:
        unique([('x',1),('x',2)])
    except ValueError:
        pass
    else:
        raise ValueError('duplicate key accepted')
    return len(cases)+3

if __name__ == '__main__':
    need(__debug__ and not sys.flags.optimize and len(sys.argv)==1, 'fixed invocation')
    table=load('confined_feedback47_table.json')
    out=verify(table,True)
    out['negative_controls']=controls(table)
    out['table_sha256']=sha('confined_feedback47_table.json')
    out['source_sha256']={p:sha(p) for p in ('accept_confined_feedback47.py','contracted_panel_core.py','contracted_kernel.py','high_window_core.py','confined_feedback47_proof.tex')}
    print(json.dumps(out,sort_keys=True),flush=True)
