"""Exact finite-count envelope from conditional variance alone.

This is a new conditional comparison, independent of contact/confinement.
The interval Gaussian/Bernoulli primitive is the root coordinator's kernel,
copied byte-for-byte as finite_count_interval.py for an immutable local input.
"""
from fractions import Fraction as F
from math import comb
from functools import lru_cache
import json,hashlib,sys
from finite_count_interval import I,PHI,CE,constants,score_cell
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
CFG=dict(schema='DIRECT_CONDITIONAL_VARIANCE_45_98_A_V1',first=45,last=98,pl='1/4',pu='13/50',pc=16,
 lambda_max='3/200',delta='3/2',phase='1/2',target='2/5')
def need(b,s):
 if not b:raise ValueError(s)
def ceiling(x):
 x=F(x);return F(-((-x.numerator*10**12)//x.denominator),10**12)
def lo(x):return I(x).fraction_lower()
def hi(x):return I(x).fraction_upper()
@lru_cache(None)
def pm_vector(n,p):
 p=F(p);a=p.numerator;b=p.denominator-a;den=p.denominator**n
 aa=[1];bb=[1]
 for j in range(n):aa.append(aa[-1]*a);bb.append(bb[-1]*b)
 return tuple(F(comb(n,j)*aa[j]*bb[n-j],den)for j in range(n+1))
def cell(n,k,pl,pu,L,delta):
 need(0<pl<=pu<F('.5') and 0<=k<n and L>0,'cell domain')
 # Intersect the p-cell with |k-np|<=delta; preserves all closed faces.
 pl=max(pl,(k-delta)/n);pu=min(pu,(k+delta)/n)
 if pl>pu:return None
 vl=pl*(1-pl);vh=pu*(1-pu);sn=I(n).sqrt()
 rhol=(I(1-2*vh)/I(vh).sqrt()).fraction_lower()
 rhoh=(I(1-2*vl)/I(vl).sqrt()).fraction_upper()
 fac=(sn/rhol).fraction_upper()
 ratio=(I(1+L/(n*vl))*I(1+L/(n*vl)).sqrt()).fraction_upper()
 pm1,pm2=pm_vector(n,pl),pm_vector(n,pu)
 pml=min(pm1[k],pm2[k]);mass=(sn*I(pml)/rhoh).fraction_lower()
 need(mass>0,'own mass')
 t=L*max(F(k,n)/pl,F(n-k,n)/(1-pu))
 c=PHI.fraction_upper()/(1-2*vh)
 r0=2*c*t/mass
 gates=dict(negative_split=F('.5')-r0,
  negative_at_split=mass*r0-c*(t+r0*r0),
  negative_at_endpoint=mass/2-c*(t+F(1,4)),
  phase_density=1-2/(n*vl))
 negcost=c*c*(t+r0*r0)/(4*mass)
 tails=[]
 for u in (F(0),F(1,2)):
  total=F(0)
  for j in range(k+1,n+1):
   pm=max(pm1[j],pm2[j]);mode=F(j,n)
   if pl<=mode<=pu:pm=max(pm,pm_vector(n,mode)[j])
   tj=L*max(F(j,n)/pl,F(n-j,n)/(1-pu))
   gates['incoming_convex:'+str(j)]=3*(j-k-F(1,2))**2-tj
   total+=pm*tj/(tj+(j-k-u)**2)
  tails.append(fac*total)
 slope=(I(PHI.fraction_lower()*gates['phase_density'])/(rhoh*I(vh+L/n).sqrt())).fraction_lower()
 positive=max(tails[0],tails[1]-slope/2)
 negative=tails[0]+negcost
 variance=PHI.fraction_upper()*max(F(0),k-n*pl)*L/(2*n*vl*(1-2*vh))
 cb=score_cell(n,k,pl,pu)[0].fraction_upper()
 bound=ceiling(ratio*max(F(0),cb+variance+max(positive,negative)))
 return dict(p=[str(pl),str(pu)],bound=bound,cb=cb,variance=variance,
  negative=negative,positive=positive,ratio=ratio,gates=gates)
def evaluate(progress=False):
 constants();L=F(CFG['lambda_max']);d=F(CFG['delta']);pl0=F(CFG['pl']);pu0=F(CFG['pu']);pc=CFG['pc'];target=F(CFG['target'])
 rows=[];bad={};digest=hashlib.sha256();count=0;worst=(F(-1),None);per_n=[]
 need(CE.fraction_lower()>target,'target below exact CE')
 for n in range(CFG['first'],CFG['last']+1):
  wn=(F(-1),None)
  for pi in range(pc):
   pl=pl0+(pu0-pl0)*pi/pc;pu=pl0+(pu0-pl0)*(pi+1)/pc
   k0=max(0,(n*pl-d).numerator//(n*pl-d).denominator)
   k1=min(n-1,(n*pu+d).numerator//(n*pu+d).denominator+1)
   for k in range(k0,k1+1):
    o=cell(n,k,pl,pu,L,d)
    if o is None:continue
    key=f'{n}:{pi}:{k}';o['gates']['score']=target-o['bound']
    for name,v in o['gates'].items():
     count+=1;digest.update((key+':'+name+'='+str(v)+'\n').encode())
     if v<=0:bad[key+':'+name]=str(v)
    row=dict(n=n,p_cell=pi,k=k,**{name:([str(x)for x in val]if isinstance(val,list)else str(ceiling(val)))for name,val in o.items()if name!='gates'})
    rows.append(row)
    if o['bound']>wn[0]:wn=(o['bound'],key)
    if o['bound']>worst[0]:worst=(o['bound'],key)
  per_n.append(dict(n=n,bound=str(wn[0]),key=wn[1]))
  if progress:print(json.dumps(dict(n=n,bound=float(wn[0]),bad=len(bad))),flush=True)
 return dict(schema=CFG['schema'],contract=CFG,rows=rows,per_n=per_n,bad=bad,gates=count,
  gate_sha256=digest.hexdigest(),worst=dict(bound=str(worst[0]),key=worst[1]),
  scope='Conditional centering; n45..98; p in[.25,.26]; every 0<=lambda<=.015; every nearest phase and |k-np|<=1.5. No amplitude/contact/moment-defect assumption.')
if __name__=='__main__':
 from pathlib import Path
 o=evaluate(True);p=Path(__file__).with_name('direct_variance45a_discovery01.json');need(not p.exists(),'fresh output required');p.write_text(json.dumps(o,indent=2)+'\n')
 print(json.dumps(dict(status='EXACT_DISCOVERY_ONLY',gates=o['gates'],bad=len(o['bad']),worst=o['worst'])))
