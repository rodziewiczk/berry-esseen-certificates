# Independent review of SIGNED_RESOURCE47

Mathematical status: independently derived and reviewed at its stated
conditional scope; no defect found. Execution status: fresh exact replay
entry/signed_resource47_accept01 checks84 predecessor cells, excludes the
first complete left cell and verifies83 remaining closed panels[.304,.47],
with14 controls. This is acquired entry, not a complete local comparison.

## Independent derivation

On a fixed sign class, Taylor expansion about its positive magnitude v
has centered linear term zero. Dividing the remainder of t^j by(t-v)^2
gives t+2v for j3; t²+2tv+3v² for j4; and
 t³+2t²v+3tv²+4v³ for j5. All coefficients are nonnegative. Therefore the
stated L_j bounds follow for actual t<=R and conditional mean<=v_+ or v_-.
The means' contribution is exactly(1-theta)^(j/2)B_j(p).

Each Bernoulli absolute moment B_j decreases towards p=.5; differentiating
its displayed expression in s=p(1-p) verifies this. Convexity of(1-theta)^a
puts it BELOW its endpoint chord. The coefficient1-k_j*theta is nonnegative
throughout[0,Theta], so replacing B_j(p) by its upper bound is valid even
when a residual coefficient subsequently becomes negative. The resource
prices then follow from
K+theta+ +K-theta- <=residual
by taking the maximum of zero and the two coefficient/price ratios. The
code uses lower outward k_j, upper outward B_j and positive lower prices,
all in safe directions. Its theta=0 branch is the continuous limiting slope.
The min with previous bounds is an intersection of independently valid
moment bounds, not a new feasibility assumption.

For the outer gap, T+ equals its deterministic term
m(barB²-B²) plus the positive conditional cubic remainder, and analogously
for T-. The deterministic difference is <=2m barB DeltaB. Dividing these
two terms and the two variance remainders by their separate costs in the
same joint budget gives exactly the four displayed ratios. The positive
outer weight is sigma-1 and the negative weight sigma+1; they are not
interchanged. Upper sigma in numerators and lower sigma in positive cost
denominators make the implementation conservative.

## Source semantics and coverage

The wrapper calls the earlier valid general cell first, freezes its geometry
and residual, and then tightens rho,M,eta,g and the outer charge. The lower
J1 update adds exactly the reduction in its original negative outer penalty;
it does not alter the unchanged central lower bound. The upper J1/variance
term uses the smaller M and outer upper bound. Other older signed coefficient
rectangles are retained as conservative valid bounds. The new positive
moment/order gates are enforced before any downstream Fourier use.

Only this moment/outer wrapper is installed in coupled_panel_core.py. The
separate experimental phase-resource variant is not selected. There is no
exception swallowed as an exclusion. All finite updates consume prior valid
bounds, and the already reviewed weighted nD/lambda/gap export remains intact.
The acceptor binds both preceding tables and their radii, explicitly processes
all39 left plus45 central cells, and excludes only the complete first left
cell. Endpoints remain covered, including the shared p=.38 boundary. Every
upper coefficient and lower curvature is compared in its correct direction.

## Independent finite controls

structural/check_signed_resource_actual.py imports no constructor kernel.
Its fresh structural/signed_resource_actual01 passes84 exact standardized
Bernoulli mixtures, including tiny mixture weights,2268 moment and conditional
Taylor checks and252 separately weighted outer-charge checks. It rejects
the wrong tangent-instead-of-chord direction and the misuse of an upper B
with a negative multiplier. These finite controls supplement, not replace,
the continuum derivation. The test resource is computed directly from the
same law's exact shared charges; no approximation of D is assumed.

The fixed R2.7 left support row additionally has a fresh complete all-H
fifth-order acceptance with three false arithmetic controls. The signed
resource table's38 left panels imply its rho<=1.2563,|beta|<=.3926 premises;
that seam is checked exactly in the binding. Its lower index47 and slow
increment.19 remain explicit premises. No heat source was changed.
