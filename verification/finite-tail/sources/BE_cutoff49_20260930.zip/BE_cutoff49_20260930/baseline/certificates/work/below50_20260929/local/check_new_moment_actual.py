"""Independent exact actual-law controls for the quartic and Poisson lemmas.

The Poisson reference uses its first three full moments minus the finite
lower tail, rather than the acceptance kernel's infinite positive-tail sum.
"""
from fractions import Fraction as F
from collections import defaultdict
from math import factorial
from hashlib import sha256
from pathlib import Path
import json,sys
if sys.flags.optimize:raise RuntimeError('Unoptimized Python required')
def need(b,s):
 if not b:raise ValueError(s)
def centered(d,a):
 need(sum(d.values())==1 and all(v>0 for v in d.values()),'Probability law')
 need(sum(x*v for x,v in d.items())==0,'Centering')
 need(max(d)<=a,'Upper bound')
def two(l,r):return {-F(l):F(r)/(F(l)+F(r)),F(r):F(l)/(F(l)+F(r))}
def conv(d,e):
 out=defaultdict(F)
 for x,p in d.items():
  for y,q in e.items():out[x+y]+=p*q
 return dict(out)
def exp_negative_interval(x):
 need(x>=0,'Nonnegative exponent');last=80
 series=sum(x**j/F(factorial(j))for j in range(last+1))
 ratio=x/(last+2);need(ratio<1,'Taylor tail domain')
 tail=x**(last+1)/F(factorial(last+1))/(1-ratio)
 return 1/(series+tail),1/series
def poisson_cubic_lower(mu,j):
 poly=mu**3+(3-3*j)*mu**2+(1-3*j+3*j*j)*mu-j**3
 finite=-sum(mu**k/F(factorial(k))*(F(k)-j)**3 for k in range(j.numerator//j.denominator+1))
 need(finite>=0,'Finite lower-tail sign')
 return poly+exp_negative_interval(mu)[0]*finite
laws=[{F(0):F(1)},two('.4','.4'),two('.4','.001'),two('.001','.4'),
 {F('-.4'):F('.001'),F(0):F('.998'),F('.4'):F('.001')},
 two('.4',F(1,10**9)),two(F(1,10**10),'.4')]
quartic=poisson=zero=collisions=0
for law in laws:
 a=F('.4');centered(law,a);d={F(0):F(1)}
 for count in range(1,6):
  d=conv(d,law);v=sum(x*x*p for x,p in d.items());m4=sum(x**4*p for x,p in d.items())
  if not v:zero+=1;continue
  prob=sum(p for x,p in d.items()if x>0)
  need(prob*m4>=F('.4641')*v*v,'Quartic sign control');quartic+=1
  mu=v/(a*a)
  for j in map(F,('0','.5','1','1.4','1.6','2','2.5','3')):
   actual=sum(max(F(0),x/a+mu-j)**3*p for x,p in d.items())
   lower=poisson_cubic_lower(mu,j)
   need(actual<=lower,'Independent Poisson cubic control');poisson+=1
   collisions+=any(x/a+mu==j for x in d)
# The coefficient 1/2 is false: rational approximation to the sharp three-point law.
r=F('1.366');eps=F('1/100');d={F(-1):r*eps,F(0):1-(1+r)*eps,r:eps}
centered(d,r);v=sum(x*x*p for x,p in d.items());m4=sum(x**4*p for x,p in d.items())
need(eps*m4<F('.5')*v*v,'Counterexample to inflated quartic coefficient')
rejected=1
for law,a in [({F(1):F(1)},F(1)),(two('.5','.5'),F('.4')),
              ({F(-1):F('.25'),F(1):F('.25')},F(1))]:
 try:centered(law,a)
 except ValueError:rejected+=1
 else:raise ValueError('Malformed actual law accepted')
print(json.dumps(dict(status='PASS_EXACT_QUARTIC_POISSON_ACTUAL_CONTROLS',laws=len(laws),
 quartic_checks=quartic,independent_Poisson_checks=poisson,zero_noise_cases=zero,collision_cases=collisions,
 negative_controls=rejected,source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
 scope='Finite actual-law controls with tiny atoms and threshold collisions; the analytic continuum lemmas are proved separately.'),indent=2))
