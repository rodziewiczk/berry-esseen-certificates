# External input scope checked on29 September2026

These are cited inputs, not project-specific lemmas replaced by arithmetic.

- [Schulz, dissertation, Theorem1, printed page1](https://d-nb.info/1197702695/34)
  states a strict bound for every integer n and Bernoulli parameter in(0,1).
  The same theorem includes the sharper coefficient
  `(3+|p-q|)/(6 sqrt(2*pi*n*p*q))` on p in[1/3,2/3]. This is exactly
  the strict binary input used in the manuscript, including zero noise.
- [Shevtsova2013, printed pages124–125](https://www.mathnet.ru/eng/ia252)
  gives the iid minimum of `.4690*l_n`, `.3322*(l_n+.429*tau_n)` and
  `.3031*(l_n+.646*tau_n)` for all n>=1. For standardized iid summands
  divided by sqrt(n), `l_n=rho/sqrt(n)` and `tau_n=1/sqrt(n)`.
  Dividing by rho/sqrt(n) gives the three manuscript caps. The source's
  strict-CDF convention gives the same supremum against continuous Phi.
- The supplied local He–Cheng source is
  `work/optimized301_20260927/sources/He_Cheng_2609.06358v1.pdf`, with
  extracted text in the sibling `.txt`. Lemma4.3 assumes an attained
  positive maximum C_n>0, so applies at the critical C_n=C_E as well.
  It differentiates contamination at the fixed raw threshold, and
  upper semicontinuity extends almost-sure equality to the whole closed
  support. The finite Gaussian bound is the separate imported AppendixA.1
  inequality(70). No asymptotic expansion or finite cutoff from that
  paper is used as a finite-n theorem here.

Both online published statements were opened directly during this audit.
Their proofs are cited under the user's chosen self-containment policy.
