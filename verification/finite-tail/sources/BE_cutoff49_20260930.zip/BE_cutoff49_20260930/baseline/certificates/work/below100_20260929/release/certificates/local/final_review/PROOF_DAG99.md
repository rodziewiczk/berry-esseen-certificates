# Independent composition review for cutoff 99

**Status:** the selected contracts, complete local phase/noise coverage and
integer-index arithmetic pass the supplementary exact checker. The component
proofs and their fresh acceptance runs remain separate obligations. This note
does not replace attainment, Fourier inversion, or an actual-law argument.

## Dependency graph

```mermaid
flowchart TD
  A[Attainment, contact identity, finite caps] --> B[All-H support and finite-band support]
  B --> C[ANCHOR90: an anchor by index 94]
  C --> D[PROPAGATE95 on indices 95 through 188]
  D --> E[STOP180 plus all-H support extends the .7/n ceiling]
  E --> F[Three score caps available from local index 96]
  F --> G[Assume a nonnegative witness with decrement at most .19]
  G --> H[Radius 4.1 and ENTRY95]
  H --> I[All-H heat bridge: radius 2.5]
  I --> J[INPUT95: coherent moment and raw budgets]
  J --> K[Direct Gaussian95 and exterior95B]
  K --> L[Confinement95B: amplitude .30 and noise below .20]
  L --> M[Normalization, TINY and five MID rectangles]
  J --> N[Whole-count LOW95B]
  L --> N
  M --> O[Complete local comparison: decrement must exceed .19]
  N --> O
  O --> P[Four losses from index 99 contradict the .7/n ceiling]
```

Every edge in the local branch refers to the **same actual attaining marginal**.
INPUT95 must follow the heat bridge: its radius-2.5 hypothesis is not supplied
by its own moment conclusions. The heat bridge uses ENTRY95's rho < 1.15 and
absolute beta < .31, and the selected slow-index assumption .19 <= .2. It
requires no phase bound, so this ordering has no circular threshold estimate.

## Contracts at the local joins

ENTRY95 starts from radius 4.1 and the independently licensed current cap
.41719. Its accepted final raw and defect bounds are below .77 and .12,
the INPUT95 initialization thresholds. The heat bridge supplies radius 2.5.

INPUT95 supplies n >= 95, raw R < .75, D < .117, |H| < 1.15,
p in (.35,.46), rho < 1.14, beta in (.075,.3), theta < .0085,
A > .73 and B > 1.02. Its additional raw envelope is

`R < .68963 + .30513 |H| - .44494 H^2`.

These fit the wider Gaussian95 domain |H| <= 1.5, rho <= 1.15,
beta in [.05,.3], cap .418 and decrement .2. Gaussian95 gives
support [-1.85,2.4]. Exterior95B uses the stricter decrement .19 and
the same actual B2 budget to acquire Y in (-.49,1.49). The initial
inward displacement d < .012 follows from INPUT95 and the shared-shift
moment inequality before concentration or noise confinement is used.

Confinement95B, both normalization copies, the direct companions and LOW95B
agree on N=95, T=.75, D=.117, theta=.0085, d0=.012, p=[.35,.46],
H=1.15, C=.418, rho=1.14, amplitude=.30 and maximum noise=.20.
The one-budget phase rebate is .199. The conditional span is .312 and
its certified harmonic rate is 14.17. LOW uses INPUT95's raw quadratic
with the correct upper/upper/lower directions on its three coefficients.

## Complete phase/noise cover

Let u be either nearest-integer phase, so abs(u) <= .5. Every interval below
is closed; the physical noise endpoint .20 is covered although confinement
already gives a strict upper bound. Noise zero is covered by the separate
published Bernoulli theorem.

| Noise range | LOW covers | Direct comparison covers |
|---|---:|---:|
| 0 < lambda <= .026 | — | All phases by TINY |
| [.026,.0275] | abs(u) <= .04 | abs(u) >= .04 |
| [.0275,.03] | abs(u) <= .09 | abs(u) >= .09 |
| [.03,.08] | abs(u) <= .13 | abs(u) >= .13 |
| [.08,.10] | abs(u) <= .18 | abs(u) >= .18 |
| [.10,.12] | abs(u) <= .25 | abs(u) >= .25 |
| [.12,.20] | abs(u) <= .5 | — |

The checker reconstructs all 70 LOW bands and all 362 positive MID cells,
checks both negative-phase records in each of the five rectangles, and
verifies a covering MID rectangle for the entire noise interval of every
LOW band whose radius is below .5. Thus the check is an exact rectangle
cover argument, not a grid sampling argument. The target in both direct
and LOW certificates is the same strict improvement of .001 lambda.

## The global index arithmetic

Write a_n = C_n - C_E and d_n = n(a_{n-1}-a_n), and let K=.7.
The anchor argument uses the finite band 90..94, loss threshold 1.17,
and the global cap a_89 < .469-.4095. The checked inequality

`K/94 + 1.17 sum_{j=90}^{94} 1/j > .469-.4095`

forces a slow barrier index if no earlier .7/n ceiling occurs. At a first
barrier crossing the decrement is below K/(j-1), which is below 1.17.
ANCHOR90 excludes that slow barrier index. PROPAGATE95 then excludes a
first barrier failure on 95..188, using its finite-band score floor with
the **upper** endpoint 188.

At a hypothetical first later barrier failure j >= 189,
d_j < K/(j-1) < 1.02. The all-H support theorem gives radius 4.1, inside
STOP180's radius 4.5; j >= 180. The retained supported STOP180 gives
a_j < .49823/j < K/j. This extends the ceiling without using the old
cutoff189 local comparison.

The current cap at n=95 is licensed because
`.40974 + .7/95 < .41719`.
All three caps needed by the local comparison are licensed only from n=96:
its earliest predecessor is n-2=94, and
`.40974 + .7/94 < .418`.
Consequently the conditional local theorem has arithmetic floor 95 but
its selected global **application floor is 96**.

If a_N >= 0 for N >= 99, repeated local contradictions force four losses
at N, N-1, N-2 and N-3. Every reached predecessor stays positive. Hence

`a_{N-4} > .19 sum_{j=N-3}^{N} 1/j > .7/(N-4)`.

At N=99 the exact positive reserve is
`12229769/28609257600`.
Uniformity for all larger N follows by multiplying by N-4: each factor
`(N-4)/(N-i) = 1-(4-i)/(N-i)`, 0 <= i <= 3, increases with N.
Three losses do not close this inequality. Four losses starting at 98
would require the unlicensed local application at 95; the checker rejects
both modifications, as well as using decrement .20 in exterior95B.

## Verification and limitations

`seam_check99.py` parses explicit rational source contracts without executing
the component kernels. It reads the fixed proof objects, checks source-bound
local metadata, performs 805 exact checks and rejects 12 intentionally
corrupted seams. It also hashes itself and every inspected dependency.
Its portable installation path is
`certificates/local/final_review/seam_check99.py`; it resolves the other
components relative to `certificates/`, including `certificates/stop/`.
It needs no historical execution logs outside the package.

The only provenance issue found during this review was an old LOW acceptance
log predating a normalization descriptor/header edit and certificate rebinding.
The coordinating worker is replaying the frozen release suite. That freshness
check is separate from the mathematical seam checker; a historical PASS is
not silently promoted to a fresh PASS for changed files.
