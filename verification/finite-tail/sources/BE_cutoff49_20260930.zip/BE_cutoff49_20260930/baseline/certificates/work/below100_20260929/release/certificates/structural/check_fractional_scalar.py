"""Fixed scalar harmonic inequality: 1-cos(2*pi*r) <= (23/5)*r on [0,1].

This checks only the universal scalar inequality. Conditional support spans,
variance rates and the probability-law reduction belong to separate lemmas.
See FRACTIONAL_SCALAR_PROOF.md. No floating point, external data or options.
"""
from fractions import Fraction as F
from math import factorial,comb
from pathlib import Path
from hashlib import sha256
import json,sys,copy
assert __debug__ and not sys.flags.optimize
PL=F('3.141592653589793');PU=F('3.141592653589794')
END=F(10,23);WIDTH=F(5,92)

def atan_bounds(x):
    assert 0<x<1
    low=sum(((-1)**j*x**(2*j+1)/F(2*j+1)for j in range(20)),F(0))
    return low,low+x**41/41

def polynomial(multiplier=F(23,5)):
    # P(r)=multiplier-Q(r)/r, where Q is an upper bound on 1-cos(2*pi*r).
    p=[F(0)]*10;p[0]=multiplier
    for j in range(1,6):
        bound=PU if j%2 else PL
        p[2*j-1]=-F((-1)**(j+1))*(2*bound)**(2*j)/factorial(2*j)
    return p

def bernstein(p,left,right):
    n=len(p)-1
    # First expand P(left+(right-left)*x) into powers of x.
    powers=[sum((p[j]*comb(j,k)*left**(j-k)*(right-left)**k
                 for j in range(k,n+1)),F(0))for k in range(n+1)]
    # x^k=sum_{i=k}^n binom(i,k)/binom(n,k) B_i^n(x).
    return [sum((powers[k]*F(comb(i,k),comb(n,k))for k in range(i+1)),F(0))
            for i in range(n+1)]

def check_cover(rows):
    assert type(rows)is list and len(rows)==8
    p=polynomial()
    for j,row in enumerate(rows):
        assert type(row)is dict and set(row)=={'interval','coefficients'}
        left=j*WIDTH;right=(j+1)*WIDTH
        assert row['interval']==[str(left),str(right)]
        want=[str(x)for x in bernstein(p,left,right)]
        assert row['coefficients']==want and min(map(F,want))>0
    assert 8*WIDTH==END

def main():
    assert len(sys.argv)==1
    a,b=atan_bounds(F(1,5)),atan_bounds(F(1,239))
    pi_lower=16*a[0]-4*b[1];pi_upper=16*a[1]-4*b[0]
    assert pi_lower>PL and pi_upper<PU
    sigma_lo=F('3.162277660');sigma_hi=F('3.162277661')
    assert sigma_lo*sigma_lo<10<sigma_hi*sigma_hi
    assert 2*PU*F('.39886')**2<1<2*PL*F('.4')**2
    assert F('.3988')<F('.39886')
    assert (3+sigma_lo)**2>72*PU*F('.4095')**2
    assert (3+sigma_hi)**2<72*PL*F('.40973219')**2
    # tan(4 atan(1/5)-atan(1/239))=1, with angle in(0,1)<(0,pi/2).
    assert (F(120,119)-F(1,239))/(1+F(120,119)*F(1,239))==1
    assert 4*(F(1,5)-F(1,375))-F(1,239)>0 and F(4,5)<1
    # Successive cosine terms decrease already after degree2.
    assert (2*PU*END)**2<12
    p=polynomial()
    rows=[dict(interval=[str(j*WIDTH),str((j+1)*WIDTH)],
               coefficients=[str(x)for x in bernstein(p,j*WIDTH,(j+1)*WIDTH)])for j in range(8)]
    check_cover(rows)
    controls=[]
    for name,mutate in [
        ('missing_interval',lambda x:x.pop()),
        ('duplicated_interval',lambda x:x.append(copy.deepcopy(x[0]))),
        ('reordered_intervals',lambda x:x.reverse()),
        ('coverage_gap',lambda x:x[0].update(interval=['1/1000',str(WIDTH)])),
        ('missing_coefficient',lambda x:x[0]['coefficients'].pop()),
        ('changed_coefficient',lambda x:x[0]['coefficients'].__setitem__(0,'0'))]:
        bad=copy.deepcopy(rows);mutate(bad)
        try:check_cover(bad)
        except AssertionError:controls.append(name)
        else:raise AssertionError('corrupted scalar cover accepted')
    assert min(x for j in range(8)for x in bernstein(polynomial(F(4)),j*WIDTH,(j+1)*WIDTH))<0
    controls.append('false_multiplier_4')
    coefficients=[F(x)for row in rows for x in row['coefficients']]
    assert len(coefficients)==80
    print(json.dumps(dict(status='PASS_EXACT_FRACTIONAL_SCALAR_23_OVER_5',
          multiplier='23/5',near_domain=['0','10/23'],far_domain=['10/23','1'],
          near_argument_squared_upper=str((2*PU*END)**2),
          pi_lower_proved=str(pi_lower),pi_upper_proved=str(pi_upper),
          sqrt10_bounds=[str(sigma_lo),str(sigma_hi)],
          phi0_bounds=['.39886','.4'],Esseen_bounds=['.4095','.40973219'],
          closed_intervals=8,positive_Bernstein_coefficients=80,
          minimum_coefficient=str(min(coefficients)),negative_controls=controls,
          exact_cover=rows,source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
          scope='Only the scalar inequality 1-cos(2*pi*r)<=(23/5)*r for0<=r<=1; no conditional span or variance rate asserted.'),indent=2))

if __name__=='__main__':main()
