"""Fixed complete LOCAL95B LOW domain; no adjustable acceptance choices."""
from normalization95b import CFG,F
from low95b_kernel import rootlo
def contract():
    assert ((F('12.32455532')-6)/2)**2<10
    c=dict(CFG)
    bands=[(F('.026'),F('.0275'),F('.04')),(F('.0275'),F('.03'),F('.09'))]
    for i in range(68):
        l=F('.03')+F(i,400);h=l+F(1,400)
        a=F('.13')if l<F('.08')else F('.18')if l<F('.10')else F('.25')if l<F('.12')else F('.5')
        bands.append((l,h,a))
    assert len(bands)==70 and bands[0][0]==F('.026') and bands[-1][1]==F('.20')
    assert all(bands[i][1]==bands[i+1][0]for i in range(69))
    c.update(p_cells=32,H_cells=32,maxnoise=c['lmax'],mlo=rootlo((1-c['theta'])*c['pl']*(1-c['pl'])),
             rebate=F('.199'),phase0=F('.04'),bands=70,noise_intervals=bands,
             repair_normal=c['repair_pos'],R_A=F('.68963'),R_F=F('.30513'),R_Q=F('.44494'))
    return c
