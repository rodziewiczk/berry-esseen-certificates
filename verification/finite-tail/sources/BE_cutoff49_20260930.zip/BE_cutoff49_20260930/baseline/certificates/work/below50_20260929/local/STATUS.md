# Local cutoff-50 attack — working checkpoint

All files under this directory are new work. Prior cutoff-99 delivery remains unchanged.

## Accepted conditional results

| Result | Mathematical status | Execution status |
|---|---|---|
| TINY45C: n>=45, old near-binary tuple, amplitude<=.4, every phase and 0<ns<=.033; strict binary comparison | Locally derived and independently reviewed; hypotheses not globally acquired at45 | Fresh strict PASS:77 gates,6 closed phases,21 rejection controls; quartic/Poisson actual controls; corrected derivative control |
| DIRECT45A:45<=n<=98,p in[.25,.26],0<=ns<=.015,|k-np|<=1.5,all nearest phases; C<.4 | Locally derived and independently reviewed; only conditional centering and finite third moment required | Fresh strict PASS:153861 gates,2639 cells,21 rejection controls; 696 actual identities+696 inequalities |

Selected bindings are `TINY45C_FREEZE02.json` and `DIRECT45A_FREEZE.json`. Independent review and source binding: `../structural/LOCAL45_REVIEW.md`, `../structural/LOCAL45_BINDING.json`.

PDFs (all pages rendered and inspected):
- `build_tiny45c_final/tiny45c_proof.pdf` — 4 pages.
- `build_direct_variance45a/direct_variance45a_proof.pdf` — 3 pages.

TINY45B is **superseded due a real gate defect**: its negative far-end derivative had an extra divisor t. C corrects it; corrected gate is about1.298148 and all arithmetic remains positive. The first C proof-text freeze was also superseded to state the all-t_k derivative comparison explicitly. B sources/logs and both freezes remain preserved.

## New structural candidates

1. Centered signed deletion divides the epsilon concentration cost by2. Accepted generic derivation and exact actual-law controls; does not halve an absolute-noise bound.
2. Common interval hull bounds both signed deletion terms together, using one remaining sum. Combined with signed H and shared bad-pair moment budget in `joint_interval_confinement_kernel.py` (discovery only).
3. `COMMON_BACKGROUND_MARKS.md` couples the two deleted whole-count tails through one actual background and bounds their sum by one quadratic Markov inequality. Floating LOW pressure (`common_background_low01`) improves the stronger hypothetical interface at n47 to worst score<-.06458 across its full stated LOW cover. The interface/amplitude profile and MID complement are not acquired.
4. Cubic centered-Poisson and sharp quartic sign lemmas are fully proved in TINY45C; the quartic coefficient .4641 is backed by the sharp analytic value2sqrt3−3.

## Remaining bottlenecks

Root's new anchor K=.7 and propagation license three score caps<.4253 at the prospective local floor47. Root exterior45 gives conditional initial strip(-.55,1.55) under old near-binary tuple. A fresh finer exact discovery `joint_interval47_02` uses these premises: at n47/amplitude.4, lower-confinement margins still about−.01415 (negative H) and−.01038 (positive H); n50 negative H is−.00186. These are enclosure failures, not counterexamples.

Entry is deriving a fresh p-dependent interface under the improved score caps. Earlier unrestricted n45 interface with cap.4473 was much wider than old INPUT95, so oldtuple and stronger-interface local runs remain explicitly hypothetical.

Next runnable experiments:
- Both `joint_interval47_02` and `common_background_low01` completed with logs preserved.
- Common-background controls now PASS (3,141 inequalities,459 collisions); independent analytic review found no defect.
- Use entry's new coherent raw T(H,p)/noise bounds in confinement and LOW; do not silently substitute the stronger hypothetical tuple.
- Root's exact Bernoulli reserve primitive is available for cellwise finite-index reserve. LOW normalized excess is multiplied by lambda/rhoB, **not** lambda/(n rhoB).

No full LOCAL47 or global cutoff below99 has been claimed here.

## Checkpoint: canonical index47 confinement and shifted quartics

**CONDITIONAL_CONFINEMENT47_A is frozen and independently reviewed.** Exact scope is `conditional_input47.json` (SHA b9d2aa15ad96181f5a8eb846e76ae296d2c2c8ed1a5975c6f389c2f7d14ff2b7), 45 contiguous p-panels [.38,.47], both H signs, n>=47, initial strip(-.55,1.55), score caps .4253, and the actual common moment/leakage resource and both deleted concentrations. It proves amplitude .425/.4/.375/.35/.325/.3 on the six listed ranges. Its noise ceiling is an input, never a claimed acquisition.

- Mathematical status: complete conditional proof independently read; no defect found.
- Execution status: fresh strict PASS, 248,960 gates; 10,546 excluded+24,014 surviving closed boxes; 20 mutation controls.
- Sources: `confinement47_kernel.py`, `confinement47_contract.py`, `accept_confinement47.py`, `confinement47_certificate.json`, `confinement47_proof.tex`.
- Freeze: `CONFINEMENT47A_FREEZE.json` SHA2686a711a69ea3cb855b7b25e4bf2868c04273fef1d673dae32b3b3424c2f93c.
- Proof/PDF: `build_confinement47/confinement47_proof.pdf`, five pages, all rendered and inspected under `qa_confinement47`; no overlap/clipping or final box warnings.
- Logs: `confinement47_build01`, `confinement47_accept01`, `confinement47_compile03`.
- Independent binding: `../structural/CONFINEMENT47_BINDING.json`; full review in `CONFINEMENT47_FINAL_REVIEW.md` and `CONFINEMENT47_REFINEMENTS_REVIEW.md`.
- Entry reports all45 canonical inputs now fresh exact PASS in `runs/below50_20260929/entry/central47_input_accept01`; root owns composition with support acquisition. The left p<.38 complement and complete score comparison remain open.

**Active forward marks:** `ACTIVE_FORWARD_MARKS.md` proves that the active Dminus event permits the inward d in place of absolute amplitude in its forward deleted tail. The common-background quadratic then uses asymmetric projected thresholds. Independently rederived. Actual controls: 3,915 marked bounds, 3,915 pair projections, 10,789 quadratics, 308 collision cases and an unmarked-replacement rejection in `active_mark_actual01`. LOW use remains discovery.

**LOW pressure:** `adaptive_low_finite_cells01.json` uses the canonical-compatible noise-dependent amplitude diagnostics from `pressure_adaptive_panel_confinement01.json`; all tested LOW cells p>=.400 pass. p<.400 remains unresolved. Root's finite integer/phase and Bernoulli-reserve check closes more cells, but not the whole left domain. The recorded positive-bracket score using a lower mass is not a valid upper bound: use the actual mass or the separately licensed mass upper bound1. Root has the exported bracket/inverse-n components.

**Shifted quartic advance (not yet frozen):** applying the quartic sign polynomial to W+r, and also W-r, strengthens own-count bounds. `pressure_shifted_both01.json` verifies all6 phase gates at p[.38,.382], amplitude.425, every positive noise through.04, with min reserve>.166 on the negative side and>.357 on the positive small-phase side. This is an exact conditional diagnostic, not a global theorem. `check_shifted_quartic_actual.py`, log `shifted_quartic_actual01`, passes 2,688 moment bounds, 17,560 pointwise bounds, 5,184 variance-uniform inequalities and 504 collisions on7 actual laws.

A stronger version retains the positive quadratic term by concavity in the variance t. At t=0 and t=tmax, reduce the z-quartic to a quadratic by z^4<=zsplit^2 z^2 and minimize at its clipped vertex. `pressure_shifted_concave.py` is running in log `shifted_concave02`; `shifted_concave01` is a preserved syntax-error run. Analytic reviewer has the derivation; no frozen acceptance yet.

## Later checkpoint: TINY47A frozen

`TINY47A_FREEZE.json` (SHAd5eb9d22f71fba9f508527897614292d7c7fcdf980fe1229005e643283a2652b) fixes the new uniform theorem:

    n>=47, p∈[.38,.47], |H|<=1.257, theta<=.0154, d<=.0181,
    |U|<=.425, 0<lambda<=.05, every nearest phase, signed C>=.4
    => rhoB(C−CB^+(k))<−.001lambda.

All45 canonical input rows and their proved confinement amplitudes fit this scope. Execution: fresh strict PASS77gates,6closed phase cells,24rejection controls, minimum comparison reserve .1389918321. Complete five-page proof and clean PDF are `tiny47a_proof.tex`, `build_tiny47a/tiny47a_proof.pdf`; all pages rendered and inspected. Fresh logs `tiny47a_build01`, `tiny47a_accept01`, `tiny47a_compile03`, `quartic_uniform01`. Independent final review is pending in a separate binding; do not infer it from this construction freeze.

`check_quartic_uniform.py` independently checks2,210 rational variance/phase cases and130 exact quartic-minorant identities, with2inflated-coefficient rejections. The underlying proof uses variance concavity and an exact quadratic minimum, not sampled positivity. `SHIFTED_QUARTIC_EXPLAINED.md` is a short human-readable explanation.

Further diagnostics, still not accepted full LOCAL statements:
- `narrow_low_finite_cells01.json`: LOW beginning atlambda.05 with smaller central phase radii; p.38 worst+ .13657. The corresponding MID complement is incomplete.
- `pressure_shifted_mid01.json`, `pressure_shifted_mid_fine01.json`: shifted-quartic MID closes firstlambda.05..06 rectangle atp.38, but later tails fail. Failures preserved.
- `pressure_shifted_uniform55.json`: exact conditional full-phase diagnostics pass for the entire fallback55range p[.318,.466],H1.313,theta.0112,d.0131,amplitude.425,lambda<=.05; minimumreserve .116318. Requires amplitude acquisition.
- `pressure_left_direct01.json`: variance-only exact envelope closes p[.302,.304],lambda<=.001020,all47<=n<=98,withscore<=.3920074; nextpanel [.304,.306] fails at.41136. No full left-complement claim.
- `fallback55_confinement01` is checking the entire74panel fallback55interface under a conditional initial strip(-.55,1.55), amplitude target.425, bothHsigns. Third-moment coefficient28 replaces24 for its widerpdomain. No fixed theorem yet.

## New checkpoint: strict-gap antichain concentration, 2026-09-29

- **Mathematical:** New exact lemma: conditional steps >=c imply concentration on every interval of strict width<c is at most the largest binomial atom. The permutation-chain proof handles all atoms/tiny noise; the width=c extension is false and explicitly rejected. The all-index rational mode cap follows from finite Stirling with j>=N−2. Independent derivation/source-delta review clear (`../structural/BIASED_ANTICHAIN_REVIEW.md`).
- **Execution:** `accept_sperner47.py` fresh PASS, run `local/sperner47_accept01`; fixed certificate `sperner47_certificate.json`, freeze `SPERNER47A_FREEZE.json`. Full acquired lower ray remains inside strict-width domain; no unbounded-ray claim. Improved amplitudes range .375 at [.38,.382] to .200 at [.452,.47], see contract. Input remains original acquired canonical table, so no feedback cycle.
- **Controls:** `check_sperner_actual.py`, run `sperner_actual01`:7 laws,401 probability checks,486 collision checks,28 LYM checks,600 chain checks,930 exact mode checks,1 false-width negative control.
- **Exposition:** `sperner47_proof.tex` compiled to6 clean pages, all rendered pages inspected in `qa_sperner47`. No warnings/overlap/clipping.
- **Remaining:** New LOW diagnostic `sperner_low47_finite_cells01.json` closes all tested p>=.400 before finite Bernoulli reserve. The14 residual sign rows at p<.400 remain open, worst+.28567. MID complements are separate. Entry is preparing further feedback from new accepted amplitudes.
- **Fallback55:** `pressure_fallback55_amplitudes01.json` has all74 conditional panels at amplitudes<=.375. `fallback55_low_finite_cells01.json` has124 sign rows, no comparison failure, worst−.10095;90 floating zero root-gates are not strict acceptance. Uniform TINY55 through lambda .05 also passes diagnostics. Actual fallback entry/strip and MID seams remain separate.
- **TINY47A:** independent complete review/binding now PASS at `../structural/TINY47A_REVIEW.md` and `TINY47A_BINDING.json`; all9 freeze entries verified. Existing freeze remains unchanged.

## Compact noise schedule and intermediate phases

- Strict `accept_sperner47_profile.py` PASS (`sperner47_profile_accept02`), freeze `SPERNER47_PROFILE_A_FREEZE.json` SHA c7a2bf7d052a055f67f4ccd5208198d8c6c06ec671eb9b0f74f7d7338c3fe054. All original45 panels imply: lambda[.05,.08] amplitude<.35; [.08,.10] <.30; [.10,Lambda] <.275.98 panel/noise rectangles,196 signs,313738 gates,29355 feasible+20821 excluded. One-page proof PDF visually checked. Final source closure uses sperner47_contract directly; the earlier certificate/import binding is preserved as `_prebinding` with its logs.
- Strict `accept_mid47a.py` PASS (`mid47a_accept01`), freeze `MID47A_FREEZE.json` SHA3558f4005cf2ef59de5c642d15ca5b9cddfbe515ce6553b7e33e8d7f7091de01. Uniform n>=47,p[.38,.47],|H|<=1.257,theta<=.0154,d<=.0181; four noise/phase complements: [.05,.06],|u|>=.09,A.35; [.06,.08],|u|>=.13,A.35; [.08,.10],|u|>=.18,A.30; [.10,.12],|u|>=.29,A.275. Conclusion rho_B(C-C_B)<-.001lambda for C>=.4.7901 rational gates,2620closedphase rows,26mutation controls. Min reserve .0019865871. All five proof PDF pages visually checked. Auditor final review pending.
- MID actual controls (`mid47a_actual01`):7laws1044inequalities40collisions24 exact variance-concavity identities.
- New entry table `../entry/sperner_feedback47_table.json` is freshly acquired. Combining it with noise-dependent amplitudes leaves only2 LOW positive endpoints, both p[.380,.382],H<0,lambda[.12,.1225], maxnormalized .01615431. Export `sperner_feedback_low47_finite_cells01.json`; root asked to check finite integer phase/Bernoulli reserve and own strict LOW acceptance. Final LOW phase radius on [.10,.12] must be .29 (previous floating runner used .28); fullphase >=.12 unaffected.
- Left conditional probe `pressure_sperner_left47.py` is running on everythird acquired signed-resource left panel, with a separate unacquired .55 strip premise. Do not claim that strip until root proves it.
- Left sparse probe completed: `sperner_left47_pressure01.json` tests whole everythird probability cell of signed_resource47 under an additional strip.55 premise. Amplitudes .20 atp.304,.25 atp.310,.30 atp.316,.35 atp.322/.328,.40 thereafter through.378. Intervening cells and the strip are not claimed by this diagnostic.

## Left-range checkpoint: 29 September, latest extension

Acquired input `left270_input47_table.json` has 38 panels covering [.304,.380], SHA 4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a. Parent has freshly accepted its initial strip Y in (-.55,1.55). The following are newly named exact conditional extensions; final independent parameter/source bindings are requested:

- `LEFT_SPERNER47_A_FREEZE.json` (54f95130b6b16f13b41359d036e20596f1b43e7e374c39d67098ace095e54647): all38 panels, amplitude at most .375, n>=47. Fresh `left_sperner47_accept01` PASS,122578 gates,11475 feasible+7981 excluded boxes,20 controls. Six-page complete proof compiled and visually inspected.
- `TINY47_WIDE_A_FREEZE.json` (77fc964010b242a87f6dadcd135e28a965a0e6957b29cf88d62fc348f69815a2): n>=47,p=.304..47,|H|<=1.393,theta<=.0154,d<=.0181,|U|<=.425,C>=.4, all phases and0<lambda<=.05. Fresh `tiny47wide_accept01` PASS,77 gates,24 controls,minimum normalized reserve .028448. Five-page proof compiled and visually inspected. This covers all acquired left and central tuples after confinement.
- `LEFT_SPERNER47_PROFILE_A_FREEZE.json` (5797816f385c35a535cc4941efa867c731d3664c8e9806ffc8b8d877e458826d): noise schedule [.05,.08]→.375,[.08,.10]→.325,[.10,Lambda]→.30. Fresh `left_sperner47_profile_accept01` PASS,180 sign rows,284400 gates,26586 feasible+19494 excluded boxes. One-page proof compiled and visually inspected; exact no-ceiling-on-internal-seam check passed. Take min with each panel's global confinement bound.

`selected_left_low47_finite_cells01.json` is floating diagnostic only: negative-H p>=.35 has positive LOW residual up to .126324. Parent's new phase-sliced LOW substantially improves this and owns its proof/acceptance. Central strict LOW now passes according to parent. Left MID is under construction; no complete LOCAL47/global cutoff is asserted here.

Rejected diagnostic: `pressure_left_panelmid47_v2.py` and `pressure_left_panelmid47_02.json` used a proposed first-incoming variance bound for k-i. The actual count identity has incoming k+i, so this candidate is invalid. It was detected before any certificate or claim; all selected TINY/MID/confinement sources remain unchanged. Correct baseline left MID is `pressure_left_panelmid47_01.json`. It has small seam failures below lambda=.10, and positive phase near.5 failures at lambda=.10..12. Parent is testing full-phase LOW from.10; a refined phase cover below.10 is running as `left_panelmid47_03`.

## Final left MID complement: LEFT_MID47_B

The final selected companion is `LEFT_MID47_B_FREEZE.json`, SHA715ca6963c8391607df81ddb8c3ed9f3b6c07e4170b6fca043e83766dc862b38.

- Scope: acquired left270 probability panels, n>=47. Both phase signs are covered on noise .05..06 with |u|>=.09, .06..08 with |u|>=.14, and .08..10 with |u|>=.19. The fourth .10..12 row covers **negative phase only**, u<=-.29. Every row is clipped to the acquired noise ceiling, with amplitude min(global panel bound, .375/.375/.325/.30).
- Exact acceptance `left_mid47b_accept01`: PASS,217 blocks,74370 closed phase cells,224463 gates,24 rejection controls; minimum unnormalized reserve>.00125604.
- Exact controls `left_mid47b_actual01`:7 actual laws,7140 inequalities,294 atom collisions,12 directed Bennett-rounding comparisons,152 singleton checks.
- Five-page `left_mid47b_proof.tex` compiled clean (`left_mid47b_compile02`) and all pages inspected under `qa_left_mid47b`.
- Constructor selects a quartic/Cantelli/normal witness using float only for efficiency; acceptance evaluates every chosen bound exactly. It floors the positive Bennett exponent to1e-12 before the positive exponential lower series, which enlarges the upper tail bound. Both changes independently cleared analytically; final source/proof binding requested.
- Root owns complementary positive-phase LOW on .10..12 as well as ordinary LOW. These are required edges before claiming the complete local theorem.

The earlier first-three-only `left_mid47_*` A construction is unselected and remains preserved. The selected final B names are `left_mid47b_kernel.py`, `left_mid47b_normalization.json`, `accept_left_mid47b.py`, and `left_mid47b_certificate.json`; both A/B share the exact generic checker `left_mid47_normalization.py`. Do not accidentally package the unfinished A as the selected theorem.

Final independent bindings already received for the preceding three extensions: `../structural/LEFT_SPERNER47_A_BINDING.json`, `LEFT_SPERNER47_PROFILE_A_BINDING.json`, `TINY47_WIDE_A_BINDING.json`; review `LEFT_TINY47_EXTENSIONS_REVIEW.md`, fresh binding run `structural/left_tiny47_binding01` PASS. No defect found at their declared scopes.
