"""Bind independent analytical review to the two completed fixed LOW replays.

This performs source/log integrity and finite inventory checks only.  It does
not duplicate the expensive rational gate reconstruction in those replays.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json, sys

assert __debug__ and not sys.flags.optimize
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
PROJECT = BASE.parents[1]
hashes = {}

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def bind(p):
    hashes[str(p.relative_to(PROJECT))] = digest(p)

def objects(text):
    result = []
    decoder = json.JSONDecoder()
    while text.strip():
        text = text.lstrip()
        obj, n = decoder.raw_decode(text)
        result.append(obj)
        text = text[n:]
    return result

def run_report(rel):
    folder = PROJECT / rel
    meta = json.loads((folder / 'metadata.json').read_text())
    assert meta['returncode'] == 0, (rel, 'returncode')
    for stream in ['stdout', 'stderr']:
        p = folder / (stream + '.txt')
        assert digest(p) == meta[stream + '_sha256'], (rel, stream)
    for name in ['metadata.json', 'stdout.txt', 'stderr.txt']:
        bind(folder / name)
    report = objects((folder / 'stdout.txt').read_text())[-1]
    for source, expected in report['source_sha256'].items():
        path = BASE / source
        assert digest(path) == expected, (rel, source, 'current source')
        bind(path)
        # The logger snapshots files under the command's working directory.
        try:
            relative = str(path.relative_to(Path(meta['cwd'])))
        except ValueError:
            continue
        assert meta['input_sha256'][relative] == expected, (rel, source, 'start source')
    return report

inventory = []
for stem, expected_status, expected in [
    ('phase_left', 'PASS_EXACT_PHASE_LEFT_LOW47', (66, 15125118, 136048, 159376, 1)),
    ('positive_left', 'PASS_EXACT_POSITIVE_LEFT_LOW47', (54, 2950742, 26572, 27444, 2)),
]:
    rel = 'runs/below50_20260929/root_' + stem + '_low47_accept01'
    report = run_report(rel)
    assert report['status'] == expected_status
    fields = ['rows', 'gates', 'feasible_cells', 'excluded_cells', 'entirely_excluded_rows']
    assert tuple(report[k] for k in fields) == expected
    assert report['controls'] == 13
    assert F(report['worst_score']) < -F('.001')
    inventory.append(dict(component=stem, run=rel, **{k: report[k] for k in fields},
                          controls=13, worst_score=report['worst_score'],
                          gate_sha256=report['gate_sha256']))

partition = run_report('runs/below50_20260929/structural/left_partition47_01')
assert partition['status'] == 'PASS_EXACT_LEFT47_CLOSED_PARTITION'
assert (partition['probability_panels'], partition['H_signs'], partition['rectangles'],
        partition['closed_boundary_and_open_slab_checks']) == (38, 2, 3230, 4768)
assert len(partition['negative_controls']) == 3

for rel in [
    'root/phase_low47_proof.tex', 'root/local47_composition.tex',
    'root/low47_normalization_proof.tex',
    'structural/low47_new_lemmas.tex', 'structural/LOW47_REVIEW.md',
    'structural/LOW47_BINDING.json', 'structural/PHASE_LEFT_LOW47_REVIEW.md',
    'structural/LEFT270_INPUT47_BINDING.json',
    'structural/PAIRED_ORIENTATION47_BINDING.json',
    'structural/LEFT_SPERNER47_A_BINDING.json',
    'structural/LEFT_SPERNER47_PROFILE_A_BINDING.json',
    'structural/LEFT_MID47B_BINDING.json', 'structural/TINY47_WIDE_A_BINDING.json',
    'structural/LEFT_BINARY47_BINDING.json', 'structural/CUTOFF50_SELECTOR_BINDING.json',
    'entry/PHASE_LOW47_REVIEW.md', 'structural/bind_phase_left_low47.py',
]:
    bind(BASE / rel)

out = HERE / 'PHASE_LEFT_LOW47_BINDING.json'
assert not out.exists(), 'Preserve earlier binding; name a new review if sources change'
out.write_text(json.dumps(dict(
    schema='INDEPENDENT_PHASE_LEFT_LOW47_REVIEW_V1',
    mathematical_status='Both conditional signed-phase LOW comparisons independently derived and reviewed; no unresolved defect in these modules.',
    execution_status='Both selected fixed exact acceptances freshly PASS; no duplicate expensive replay by this reviewer.',
    scopes={
        'base': 'Acquired left270 panels, n>=47, .05<=lambda<=Lambda, closed symmetric phase envelope .09/.14/.19/.29/.5.',
        'extra_positive': 'Same panels, n>=47, .10<=lambda<=min(.12,Lambda), .29<=u<=.5, both actual H signs.',
    },
    inventory=inventory,
    exact_partition=dict(rectangles=3230, closed_boundary_and_open_slab_checks=4768,
                         controls=3, positive_noise_only=True),
    zero_noise='Separate attained-binary argument and the reviewed finite left Bernoulli bound; no division by zero or limiting argument.',
    retained_dependencies='Same-law entry, amplitude profiles, checked finite normalization, whole-count transfer, harmonic reserve, joint defect budget, marked and Poisson tail lemmas.',
    composition_review='Read local47_composition.tex including extra-positive scope and finite47..98 selector. Global publication still requires the assembled dependency closure and manuscript audit.',
    visual_qa='Reviewer analytical/source read; constructor and entry proof PDF QA is recorded separately. No new reviewer PDF inspection claimed.',
    sha256=hashes,
), indent=2) + '\n')
print(json.dumps(dict(status='PASS_INDEPENDENT_PHASE_LEFT_LOW47_BINDING',
                      binding_sha256=digest(out), components=2, partition_checks=4768), indent=2))
