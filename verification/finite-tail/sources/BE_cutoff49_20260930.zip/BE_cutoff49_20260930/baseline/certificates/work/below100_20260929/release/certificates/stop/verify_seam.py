#!/usr/bin/env python3
"""Fixed acceptance semantics for support-radius entry/refinement objects.

No discovery imports, target generation or floating-point arithmetic.  A thin
named acceptor supplies its literal fixed object and exact arithmetic kernel.
"""
import sys
if sys.flags.optimize: raise RuntimeError('optimized Python forbidden')
from fractions import Fraction as F
from pathlib import Path
import json,copy,hashlib

def need(c,s):
    if not c: raise ValueError(s)
def unique(pairs):
    out={}
    for k,v in pairs:
        need(k not in out,'duplicate JSON key');out[k]=v
    return out
def loads(s):return json.loads(s,object_pairs_hook=unique)
def shape(x,y):
    need(type(x)is type(y),'strict object type')
    if isinstance(y,dict):
        need(set(x)==set(y),'exact object fields')
        for k in y:shape(x[k],y[k])
    elif isinstance(y,list):
        need(len(x)==len(y),'complete ordered object')
        for a,b in zip(x,y):shape(a,b)
    else:need(x==y,'fixed theorem parameter')

def audit(data,expected,kernel,mode,contract):
    shape(data,expected);kernel.constants();n=data['n_min']
    need(mode in ('full','refine'),'named mathematical scope')
    need(kernel.RADIUS==(F(9,2)if mode=='full'else F(23,10)),'actual radius premise')
    need(data['general_updates']==24 and data['cell_updates']==8,'sequential update counts')
    # CE=(3+sqrt(10))/(6sqrt(2pi)); this proves the common cap constant.
    need((3+kernel.SU)**2 < 72*F(333,106)*F(40974,100000)**2,'CE upper positive-square gate')
    summary=[];icells=gcells=pcells=empty=0;previous=None
    if mode=='full':
        need(data['initial']and data['general'],'complete early bridge')
        for j,row in enumerate(data['initial']):
            target=F(row['target']);kind=row['kind'];d=None if previous is None else F(15000)*previous/(997*n)
            need(kind in('universal','gap'),'actual initial event')
            if kind=='gap':need(d is not None and 0<d<=F(contract['event_defect']),'generic event before use')
            end=F(37,20)if d is None else min(F(37,20),F(25,54)*(3+d))
            need(F(row['rho_upper'])==end,'entire current moment domain')
            count=data['initial_cells'];need(type(count)is int and count>0,'initial full cover')
            peak=F(0)
            for i in range(count):
                lo=1+(end-1)*F(i,count);hi=1+(end-1)*F(i+1,count)
                need(lo<hi and (i>0 or lo==1) and (i+1<count or hi==end),'closed moment cover')
                for endpoint in('lower','upper'):
                    value=kernel.initial_cell(n,lo,hi,previous,kind,endpoint)
                    need(value<target,'initial continuous enclosure');peak=max(peak,value)
                icells+=1
            if previous is None:need(F(819,2000)-target/n>0,'first-stage weighted-to-unweighted sign')
            need(F(2,5)-target/n>0,'initial phase density sign')
            summary.append(dict(unit='initial',stage=j,target=str(target),reserve=str(target-peak)));previous=target
        need(F(15000)*previous/(997*n)<F(contract['general_defect']),'general geometry licensed')
        for j,row in enumerate(data['general']):
            d,target=F(row['d']),F(row['target'])
            need(d==F(15000)*previous/(997*n),'actual preceding general defect')
            glob=kernel.general_geometry(d,data['general_updates']);lo,hi=glob['pl'],glob['pu'];count=data['general_cells'];peak=F(0);nonempty=0
            for i in range(count):
                l=lo+(hi-lo)*F(i,count);u=lo+(hi-lo)*F(i+1,count)
                p=kernel.general_cell(d,l,u,glob,data['cell_updates']);gcells+=1
                if p is None:empty+=1;continue
                vals=kernel.general_envelope(n,d,previous,p)
                need(len(vals)==4 and max(vals)<target,'all general score/moment corners')
                peak=max(peak,max(vals));nonempty+=1
            need(nonempty and F(2,5)-target/n>0,'general cover and phase sign')
            summary.append(dict(unit='general',stage=j,target=str(target),reserve=str(target-peak)));previous=target
        need(F(15000)*previous/(997*n)<F(contract['late_defect']),'late geometry input')
        glob=kernel.general_geometry(F(contract['late_defect']),data['general_updates'])
        need(glob['al']>F(3,4)and glob['bl']>F(21,20),'initial actual late endpoints')
        need(F(37,100)<glob['pl']<glob['pu']<F(47,100),'initial actual late probability')
        need(F(29,5)*min(F(104,25)*glob['al'],F(54,25)*glob['bl'])>F(261,20),'initial proportional actual variance')
    else:
        need(data['initial']==[]and data['general']==[],'conditional refinement input, no early bootstrap claim')
    profiles=[];last_fields=None;inherited_general=previous
    need(mode=='full' and data.get('retain_general_budget') is True,'explicit inherited general budget')
    for k,profile in enumerate(data['profiles']):
        cap=F(profile['cap']);previous=inherited_general if k==0 else None;count=profile['cells'];allrows=[]
        need(type(count)is int and count>0,'complete late cover')
        if k==0:need(cap==(F(469,1000)if mode=='full'else F(103,250)),'first independently licensed score cap')
        else:
            prior=profiles[-1]
            need(F(40974,100000)+F(prior['ratio'])/n<cap,'same-witness cap in strict order')
        for j,row in enumerate(profile['stages']):
            d=(F(contract['late_defect'])if k==0 else F(15000)*F(profiles[-1]['target'])/(997*n))if previous is None else F(15000)*previous/(997*n)
            need(0<d<=F(contract['late_defect']),'actual reset remains inside proved late domain')
            glob=kernel.late_geometry(d);lo,hi=glob['pl'],glob['pu'];target,ratio=F(row['target']),F(row['ratio']);peak=F(0);rows=[];fields=[]
            for i in range(count):
                l=lo+(hi-lo)*F(i,count);u=lo+(hi-lo)*F(i+1,count)
                p=kernel.general_cell(d,l,u,glob,data['cell_updates']);pcells+=1
                if p is None:empty+=1;continue
                vals=kernel.late_envelope(n,d,previous,p,cap)
                need(len(vals)==4 and all(v[3]<target and v[4]<ratio for v in vals),'all late same-law corners')
                rows.extend(vals);fields.append(p);peak=max(peak,max(v[3]for v in vals))
            need(rows and F(2,5)-target/n>0,'nonempty late cover and phase sign')
            summary.append(dict(unit='late',profile=k,stage=j,defect=str(d),target=str(target),ratio=str(ratio),reserve=str(target-peak)))
            previous=target;allrows=rows;last_fields=fields
        aa,ff,qq=map(F,profile['raw']);hh=F(profile['H'])
        need(all(v[0]<aa and v[1]<ff and v[2]>qq>0 for v in allrows),'all raw continuous corners')
        need(aa+ff*hh-qq*hh*hh<0 and ff-2*qq*hh<0,'all-phase raw confinement')
        profiles.append(dict(cap=str(cap),target=str(previous),ratio=profile['stages'][-1]['ratio'],raw=profile['raw'],H=profile['H']))
    need(last_fields and profiles,'nonempty final profile')
    pl=min(p['pl']for p in last_fields);pu=max(p['pu']for p in last_fields)
    rho=max(p['Rho']for p in last_fields);beta_lo=min(1-2*p['pu']-2*(1-p['pu'])*p['theta']for p in last_fields);beta_hi=max(p['Beta']for p in last_fields)
    need(all(F(29,5)*min(F(104,25)*p['al'],F(54,25)*p['bl'])>F(261,20)for p in last_fields),'final proportional actual variance')
    need(all(3*(kernel.SL+1)*p['bl']>F(1617,125)and 3*(kernel.SL+3)*p['al']>F(1617,125)for p in last_fields),'simultaneous joint variance output')
    need(rho<F(11,10)and beta_lo>F(contract['beta_lower'])and beta_hi<F(1,4),'declared initial moment domain')
    need(F(profiles[-1]['target'])<F(11,20)and F(profiles[-1]['H'])<F(1437,1000),'supported stopping and preliminary phase bounds')
    need(F(15000)*F(profiles[-1]['target'])/(997*n)<F(27,500),'final preliminary defect domain')
    need(F(40974,100000)+F(profiles[-1]['ratio'])/n<F(contract['score_upper']),'declared final same-law score cap')
    if mode=='refine':
        need(F(15000)*F(profiles[-1]['target'])/(997*n)<F(contract['refine_defect']),'declared refined actual defect')
        need(F(profiles[-1]['H'])<F(1437,1000),'refined phase domain')
        need(F(contract['p_lower'])<pl and pu<F(contract['p_upper'])and rho<F(73,65)and beta_lo>F(2,25)and beta_hi<F(1,4),'refined actual scalar geometry')
        su=pu*(1-pu)
        need(pu<F(1,2)and (1-2*su)**2>su,'actual binary moment floor 1')
    later_n=contract['geometry_floor'];need(type(later_n)is int and later_n>=n,'later geometry floor')
    later_d=F(15000)*F(profiles[-1]['target'])/(997*later_n);gg=kernel.late_geometry(later_d);later=[]
    for i in range(256):
        l=gg['pl']+(gg['pu']-gg['pl'])*F(i,256);u=gg['pl']+(gg['pu']-gg['pl'])*F(i+1,256)
        z=kernel.general_cell(later_d,l,u,gg,8)
        if z is not None:later.append(z)
    need(later,'complete later geometry cover')
    later_rho=max(z['Rho']for z in later);later_blo=min(1-2*z['pu']-2*(1-z['pu'])*z['theta']for z in later);later_bhi=max(z['Beta']for z in later)
    need(later_rho<F(11,10)and later_blo>F(contract['later_beta_lower'])and later_bhi<F(1,4),'later support-contraction moment domain')
    need(F(40974,100000)+F(profiles[-1]['ratio'])/later_n<F(contract['later_score_upper']),'later same-law score cap')
    later_result={'score_upper':contract['later_score_upper'],'n_min':later_n,'defect':str(later_d),'rho_upper':str(later_rho),'beta_lower':str(later_blo),'beta_upper':str(later_bhi),'cells':256}
    return dict(later_geometry=later_result,status='PASS_'+data['schema'],mathematical_status='conditional supported theorem; see stopping180.tex; no unrestricted cutoff',output_contract=contract,initial_cells=icells,initial_endpoint_enclosures=2*icells,general_cells=gcells,late_cells=pcells,continuous_corners=4*(gcells+pcells-empty),empty_cells=empty,profiles=profiles,final_geometry={k:str(v)for k,v in dict(p_lower=pl,p_upper=pu,rho_upper=rho,beta_lower=beta_lo,beta_upper=beta_hi).items()},stages=summary)

def negative_controls(data,expected):
    bad=[]
    def add(name,fn):
        x=copy.deepcopy(data);fn(x);bad.append((name,x))
    for key in data:add('missing_'+key,lambda x,key=key:x.pop(key))
    if 'retain_general_budget' in data:add('remove_general_budget',lambda x:x.update(retain_general_budget=False))
    add('bool_floor',lambda x:x.update(n_min=True));add('lower_floor',lambda x:x.update(n_min=x['n_min']-1));add('unrestricted_scope',lambda x:x.update(schema='UNRESTRICTED'))
    if data['initial']:
        add('initial_omitted',lambda x:x['initial'].pop());add('initial_reordered',lambda x:x['initial'].reverse());add('initial_corrupt',lambda x:x['initial'][0].update(target='1'));add('event_scope',lambda x:x['initial'][-1].update(kind='gap' if x['initial'][-1]['kind']=='universal' else 'universal'))
        add('bridge_omitted',lambda x:x['general'].pop());add('bridge_defect',lambda x:x['general'][0].update(d='1/4'))
    else:add('invented_early',lambda x:x['initial'].append({'kind':'universal','target':'1'}))
    add('profile_omitted',lambda x:x['profiles'].pop());add('caps_reordered',lambda x:x['profiles'].reverse());add('unlicensed_first_cap',lambda x:x['profiles'][0].update(cap='2/5'))
    add('p_cell_omitted',lambda x:x['profiles'][-1].update(cells=x['profiles'][-1]['cells']-1));add('feedback_reordered',lambda x:x['profiles'][-1]['stages'].reverse());add('feedback_duplicated',lambda x:x['profiles'][-1]['stages'].__setitem__(1,x['profiles'][-1]['stages'][0]))
    add('raw_Q_corrupt',lambda x:x['profiles'][-1]['raw'].__setitem__(2,'1'));add('ratio_corrupt',lambda x:x['profiles'][-1]['stages'][0].update(ratio='1/4'));add('endpoint_update_omitted',lambda x:x.update(general_updates=23));add('joint_update_omitted',lambda x:x.update(cell_updates=7))
    canonical=json.dumps(data,sort_keys=True,separators=(',',':'))
    for name,x in bad:
        need(json.dumps(x,sort_keys=True,separators=(',',':'))!=canonical,'mutation must change bytes '+name)
        try:shape(x,expected)
        except(ValueError,KeyError,TypeError):pass
        else:raise ValueError('accepted corrupted object '+name)
    text=json.dumps(data)
    serial=[('malformed','{'),('truncated',text[:-12]),('duplicate_root','{"n_min":0,'+text[1:]),('duplicate_nested',text.replace('"cap":','"cap":"0","cap":',1))]
    for name,s in serial:
        need(s!=text,'serialization mutation changes input')
        try:shape(loads(s),expected)
        except(ValueError,KeyError,TypeError):pass
        else:raise ValueError('accepted malformed JSON '+name)
    return len(bad)+len(serial)

def main(expected,kernel,mode,certificate,acceptor,contract):
    path=Path(certificate);data=loads(path.read_text());result=audit(data,expected,kernel,mode,contract);result['negative_controls']=negative_controls(data,expected)
    files=[path,Path(acceptor),Path(__file__),Path(kernel.__file__)]
    result['input_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
    print(json.dumps(result,indent=2))
