from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json
B=Path(__file__).resolve().parents[3];E=B/'work/below50_20260929/entry';L=B/'work/below50_20260929/local';S=B/'work/below50_20260929/structural';h=lambda p:sha256(p.read_bytes()).hexdigest()
def recorded(area,name,multiline=False):
 r=B/'runs/below50_20260929'/area/name;m=json.loads((r/'metadata.json').read_text());text=(r/'stdout.txt').read_text();o=json.loads(text if multiline else text.splitlines()[-1]);assert m['returncode']==0
 assert h(r/'stdout.txt')==m['stdout_sha256'] and h(r/'stderr.txt')==m['stderr_sha256']
 fs=set(r.iterdir())
 for n,v in o.get('source_sha256',{}).items():
  p=(L if area=='local'else E)/n
  if not p.exists():p=S/n
  assert h(p)==v,(area,name,n)
  if n in m['input_sha256']:assert v==m['input_sha256'][n]
  fs.add(p)
 return o,m,fs
freeze=L/'SPERNER47A_FREEZE.json';assert h(freeze)=='d673f668d45a75841044e372ff4202b1be47be27420b8f5de941f7b37a783b07';doc=json.loads(freeze.read_text())
files={freeze,S/'SPERNER47A_FINAL_REVIEW.md',S/'BIASED_ANTICHAIN_REVIEW.md',S/'CONFINEMENT47_BINDING.json',Path(__file__)}
for n,v in doc['files'].items():assert h(L/n)==v;files.add(L/n)
o,m,fs=recorded('local','sperner47_accept01',True);files|=fs
assert (o['gates'],o['feasible'],o['excluded'],len(o['negative_controls']))==(249410,24014,10546,20)
for n in ('sperner47_kernel.py','sperner47_contract.py','accept_sperner47.py','sperner47_certificate.json'):assert h(L/n)==m['input_sha256'][n]
r=B/'runs/below50_20260929/local/sperner_actual01';mm=json.loads((r/'metadata.json').read_text());assert mm['returncode']==0 and h(L/'check_sperner_actual.py')==mm['input_sha256']['check_sperner_actual.py'];files.update(r.iterdir())
def write(name,math,execution,files):
 z={'schema':name+'_REVIEW_V1','mathematical_status':math,'execution_status':execution,'sha256':{str(p.relative_to(B)):h(p)for p in sorted(files)if p.is_file()}}
 path=S/(name+'_BINDING.json');path.write_text(json.dumps(z,indent=2)+'\n');return path
b1=write('SPERNER47A','Independently derived/reviewed conditional improved confinement; no defect. Input acquisition/strip/contact remain explicit premises.','Current selected sources match fresh249410 gates,20 controls. Final freeze/PDF bound separately; constructor visual QA only.',files)
files={b1,S/'CONFINED_FEEDBACK47_BINDING.json',S/'SPERNER_FEEDBACK47_REVIEW.md',E/'sperner_feedback47_table.json',E/'confined_feedback47_table.json',L/'conditional_input47.json',L/'sperner47_certificate.json',E/'check_gamma47.py',Path(__file__)}
o,m,fs=recorded('entry','sperner_feedback47_accept01');files|=fs;assert(o['panels'],o['negative_controls'])==(45,14)
t=E/'sperner_feedback47_table.json';assert h(t)==o['table_sha256']==m['input_sha256'][t.name]=='4a1ea8a439e85e9f481bb6c6eb7a197ec4d35e53ceecf0ec92c3d4c96b9f618a';table=json.loads(t.read_text())
assert table['source_sha256']==h(E/'confined_feedback47_table.json') and table['weak_input_sha256']==h(L/'conditional_input47.json') and table['confinement_sha256']==h(L/'sperner47_certificate.json')
r=B/'runs/below50_20260929/entry/gamma47_actual_laws02';mm=json.loads((r/'metadata.json').read_text());assert mm['returncode']==0 and h(E/'check_gamma47.py')==mm['input_sha256']['check_gamma47.py'];files.update(r.iterdir())
b2=write('SPERNER_FEEDBACK47','Independently reviewed acquired central refinement with stronger gamma lower endpoint and acyclic Sperner confinement premise; no defect.','Current selected sources/targets match fresh45 panels,14 controls.',files)
files={b2,S/'LEFT47_INPUT_BINDING.json',S/'SIGNED_RESOURCE47_REVIEW.md',E/'signed_resource47_table.json',E/'left_input47_table.json',E/'sperner_feedback47_table.json',S/'check_signed_resource_actual.py',Path(__file__)}
o,m,fs=recorded('entry','signed_resource47_accept01');files|=fs;assert(o['previous_panels'],o['excluded'],o['panels'],o['negative_controls'])==(84,1,83,14)
t=E/'signed_resource47_table.json';assert h(t)==o['table_sha256']==m['input_sha256'][t.name]=='8ede412f88e5b0758dadf2590ca0f48f24b579cac22db6e4701cb6de532e6c39';table=json.loads(t.read_text())
for dep in table['sources']:assert h(E/dep['path'])==dep['sha256']
for j,row in enumerate(table['panels']):
 assert list(map(F,row['p']))==[F(152+j,500),F(153+j,500)]
 if j<38:assert F(row['rho'])<=F('1.2563') and F(row['beta_hi'])<=F('.3926')
o,m,fs=recorded('entry','left_radius270_47_accept01');files|=fs;assert o['status']=='PASS_LEFT_SUPPORT47_R270' and len(o['negative_controls'])==3
r=B/'runs/below50_20260929/structural/signed_resource_actual01';mm=json.loads((r/'metadata.json').read_text());assert mm['returncode']==0 and h(S/'check_signed_resource_actual.py')==mm['input_sha256']['check_signed_resource_actual.py'];files.update(r.iterdir())
b3=write('SIGNED_RESOURCE47','Independently derived and reviewed sign-specific actual moment/outer resources; complete acquired entry[.304,.47]; no defect. Includes exact38-left-row implication to separately accepted R2.7 all-H support. No final local comparison or cutoff50 claim.','Current selected sources/targets match fresh84 predecessor cells,1 exclusion,83 outputs,14 controls; independent84-law control fresh PASS.',files)
print(json.dumps({'status':'PASS_SPERNNER_RESOURCE47_REVIEW_BINDINGS','bindings':{p.name:h(p)for p in(b1,b2,b3)}}))
