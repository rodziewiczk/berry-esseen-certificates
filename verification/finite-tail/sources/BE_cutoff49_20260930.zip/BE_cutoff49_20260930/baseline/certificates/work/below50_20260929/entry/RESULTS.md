# Cutoff-50 entry attack: status

## Fixed result

**ANCHOR40:** no attained oriented n=40 witness supported on [-3.3,3.3]
can have C40 >= CE+1.5/40. Mathematical status: locally derived conditional
entry exclusion, depending on inherited exact signed-identity and moment
cell proofs. Execution status: fresh PASS, 320 closed cells, 14 controls.
Proof: `anchor40_proof.tex`; fixed data: `anchor40_proof.json`;
acceptor: `accept_anchor40.py`; log: `runs/below50_20260929/entry/anchor40_accept01/`.
This does not alone establish a ceiling, propagation, or a new cutoff.

New HIGH integration lemma: e^-x*(x+2)/(x^2+4x+2) bounds the transformed
zero-peak tail, replacing e^-x/x. Complete analytic proof in
`high_tail_proof.tex`; independent derivations by root and structural reviewer.
Execution status fresh PASS via `accept_high_tail.py`, 12 malformed controls,
`runs/below50_20260929/entry/high_tail_accept01/`.
The all-index derivative is checked for x>=1/4; the original estimate
remains in force below that threshold. The original HIGH domain and damping
gates are still executed.

## Discovery only

`map_profiles.py` diagnoses exact conditional covers but does not accept a
theorem. `signed_initial_discovery.py` is floating only and introduces
additional signed rho/beta/gamma enclosures. Its logs and targets must never
be substituted for acceptance. New sign-event conditional moments and
support-based E|X| bounds are being tested there.

N45, support3.84, own cap.4473, signed event-mass cover: raw remainder5.422,
D1.762; insufficient for local input. The worst cell is highly skewed,
rho about1.84,beta about.62,gamma about1.60. Further signed mean and event
conditional-moment refinements are running in signed_eventmoment01.

Next: independently supported K1.5 propagation bands from41; sharper signed
entry sufficient to reach the local comparison near47. All earlier releases
remain unchanged.

## Further fixed results (signed entry)

**ANCHOR45_K07:** no attained oriented n=45 witness with actual support3.5,
own Ccap.4431, and C>=CE+.7/n. Fresh fixed PASS:221184 cells,12stages,
15controls. `accept_signed_entry.py anchor45_signed_proof.json`, log
`runs/below50_20260929/entry/anchor45_signed_accept01/`.
**PROP46_K07:** same exclusion on46<=n<=98, support3.5, own Ccap.432.
Fresh fixed PASS:239616 cells,13stages,15controls; proofobject
`prop46_signed_proof.json`, log `.../prop46_signed_accept01/`.
Both use the now-frozen `signed_core.py` plus the unchanged frozen kernel,
chain/HIGH modules. Root supplies predecessor-score cap.432 and structural
supplies `accept_barrier45_support.py`; these interfaces are separate.
The complete new analytic delta is `signed_entry50_proof.tex`, compiled
cleanly as `signed_proof_notes.pdf` (3pages), all three pages visually read
in `qa/signed-1.png`..`signed-3.png`. It cites the independent moment proof
`../structural/moment50.tex` for the full common-m PSD derivation.

A real pre-acceptance bug was found and repaired: when a rectangular P1
maximum is negative, its upper product uses m_lower, not m_upper. The old
`exact_signed45_01` was discovery only. Selected acceptance ran after the
repair. `check_signed_regressions.py` uses the actual standardized binary
law {-3/2,2/3}, which also satisfiesD<2. Fresh regression log02. Both signed
acceptance sources are frozen; later experiments must not edit them.

## New HIGH_WINDOW50 branch (separate, not yet fixed acceptance)

`high_window_core.py` enlarges peak windows up to1/4, adds a secant/Laguerre
bound for frequency [.5,.9], and a sharper full comparator tail. The first
two analytic changes were independently checked by the structural reviewer;
the comparator refinement was sent for independent review. This new module
is installed only in new discovery runs; none of the preceding fixed entry
certificates depends on it.

With conditional actualR2.5 after p-dependent moment/support contraction,
`panel_radius25_47_fine.json` exports all four raw quadratics per pcellwidth
.002 on[.38,.48], including signed Fplus/Fminus and separate H endpoints.
Nearp[.418,.420], raw<.54266,theta<.01197,lambda=npqtheta/(1-theta)<.13870,
Hminus<1.0781. All these remain floating/conditional, not accepted inputs.
A new comparator pass is running in `panel_radius25_47_compare`.

The old scalarD route near45 stalls because binary skew itself spendsD.
Per-p shared-shift initialization, then conditional support and paired
Fourier refinement, is materially stronger and is the active local route.

## HIGH_WINDOW50 (new fixed analytic component)

- Mathematical status: locally derived and independently reviewed conditional
  six-piece Fourier estimate; not a cutoff-50 theorem or entry assertion.
- Execution: fresh PASS `runs/below50_20260929/entry/high_window_accept01`,
  18 malformed/formula controls and 11 invalid-domain controls.
- Frozen new sources: `high_window_core.py`, `accept_high_window50.py`,
  `high_window50_proof.tex`; prior accepted kernels are unchanged.
- Gains: permissible windows up to 1/4; secant/Laguerre bound on [.5,.9];
  exact split plus Mills/Pearson bound for the full Gaussian comparator.
- Every frequency piece, actual-law event condition, and all-index damping
  gate is retained. Proof includes the complete partition and positive tails.
- Three fixed conditional example HIGH bounds: <.174 at N45; <.162 at N47;
  <.171 at N50. These tuples do not assert that a maximizing law satisfies
  their hypotheses.
- `high_window_notes.tex` compiled cleanly in `high_window_compile01` to
  `build_high_window/high_window_notes.pdf` (3 pages). All three actual page
  images `qa/high-window-{1,2,3}.png` were inspected; no clipping or overlap.

## Latest central local discovery (conditional, floating)

`panel_radius25_47_compare.json` uses new HIGH_WINDOW50 and a separately
conditional support contraction to radius 2.5. At p in [.418,.420], raw
remainder <.501241, theta<.0110165, lambda<.127535, negative-H limit<1.036922.
The four `raw_quadratics` are C/rho corner upper bounds; `Qbudget` already
includes the conserved Gaussian phase charge. No second .19H^2 subtraction
is permitted. The local worker is assessing these panels conditionally.
The complementary p region is still open; none of these central panels
alone supplies a whole-domain entry theorem.

## INITIAL47 and central acquisition (fresh exact PASS)

Mathematical status: conditional entry components, locally derived and checked;
not a cutoff-50 theorem. All old fixed barrier kernels remain unchanged.

- `INITIAL47_R384`: n>=47, actual |X|<=3.84, attained oriented
  CE<=C_n<=.4247 imply raw remainder<1.885, nD<47*.590,
  rho<1.421, |beta|<.490, |H|<1.781. Exact targets are
  raw=94229/50000 and weighted defect nD<=47*(7367/12500).
  `accept_initial47.py initial47_proof.json` freshly passed in
  `initial47_accept01`: 258048 signed cells, full 100-cell [0,1] p cover,
  35 nonempty p cells, 16 negative controls.
  Proof SHA: 95c5c1de0062b6a9e294a81ee8497eee8bdb2e0798299422d7ad39b885e4a951.
- `PREP47_CENTRAL_R384`: consumes that accepted initial table; all ten
  broad p cells [.38,.48] freshly accepted, with [.47,.48] excluded.
  `accept_central47.py prep`, `central47_prep_proof.json`, log
  `central47_prep_accept01`: 10 cells / 6 controls.
- The nine surviving prep rows satisfy root's independently verified
  actual-support contraction to R2.5. That contraction is a separate
  explicit theorem edge; the entry checker does not manufacture it.
- `INPUT47_CENTRAL`: after R2.5, `accept_central47.py input` freshly
  acquires all 45 rows of the local canonical table, including weighted
  lambda/inward-gap bounds, both H signs, and all four budget quadratics.
  Log `central47_input_accept01`: 45 cells / 8 controls. Canonical SHA:
  b9d2aa15ad96181f5a8eb846e76ae296d2c2c8ed1a5975c6f389c2f7d14ff2b7.
- New exact engines: `local_signed_core.py`, `local_panel_core.py`.
  The latter derives nTheta from nD anew; it never multiplies an initial
  unweighted Theta bound by N without the resource inequality.
- Analytic export/weighted proof: `initial47_panel_proof.tex`.
  `initial47_notes.tex` compiles cleanly (log `initial47_compile01`) to
  `build_initial47/initial47_notes.pdf`, 3 pages. All actual page images
  `qa/initial47-{1,2,3}.png` inspected with no clipping/overlap.
- Important discovery-code limitation: the older signed floating driver
  directly called its old HIGH on the gap event, even after installing
  new HIGH on the universal branch. Therefore its raw~2.176 was weaker
  than the exact new initializer's raw~1.885. This did not affect any
  earlier accepted theorem or create a false pass.

## Complement and fallback discovery remains conditional

`panel_left270_floor47.json` has surviving p in [.302,.380] after several
separately conditional support contractions; all M<2. Lambda is tiny
near .302, but reaches about .18 around .36. A finite Bernoulli reserve
comparison is still needed; this is not a whole-domain entry closure.

Requested full-domain fallback maps (all floating, using a valid but wider
own cap .4247) are `fallback{55,60,65}_radius01.json`. Conditional exact
support rows were supplied independently by the structural worker.

| N | surviving p | max raw | max D | max Theta | max lambda | max inward d |
|---|---|---:|---:|---:|---:|---:|
|55|[.318,.466]|.968923|.260504|.011118|.145375|.013032|
|60|[.326,.464]|.897390|.221368|.009322|.133537|.011089|
|65|[.332,.462]|.843414|.192014|.008072|.125626|.009700|

Each file retains signed per-p budget quadratics. None is yet an accepted
full local theorem; the left comparison and exact acquisition remain.

## Complete complementary preparation (fresh exact PASS)

`accept_complement47.py` consumes the fixed accepted INITIAL47 proof SHA
and covers all 125 closed .002 cells in [.25,.38] union [.48,.60].
Fresh run `complement47_accept01` passed with 6 controls. It excludes the
entire right complement and all p<.29; survivors lie in [.29,.38] with
rho<1.390, |beta|<.430, Theta<.026 and the full exact per-cell resources
in `complement47_accepted.json`. Combined with the central preparation,
every surviving actual witness has p in [.29,.47]. This is an entry
reduction, not a local-comparison theorem on the remaining left range.
The checker writes a fresh result artifact, so a reproduction should run
in a new disposable source copy or otherwise use a new output location.

## Further exploratory refinements (not in accepted acquisition sources)

- `paired_conditional_gamma.py`: installs a new lower bound for actual
  gamma before the existing paired cumulant/Mills rectangle:
  gamma >= (1-Theta)^(3/2)*(1-2u)/sqrt(u(1-u))
           -(R+2sqrt(u/(1-u)))*Theta.
  It follows from the exact conditional cubic expansion and discarding
  the nonnegative positive-class residual. Independent audit requested.
  `panel_central25_gamma47.json` gives critical raw .495031, lambda .125911
  (only a modest improvement); `panel_left270_gamma47.json` is analogous.
  Old fixed kernels and central acceptance files are unchanged.
- `panel_left270_score47.json`: retains compulsory binary defect in the
  prior-raw own-score cap. It excludes p<.306 instead of .302, but leaves
  the bulk left lambda near .18. This is not a large missing cancellation.
- `panel_confined47_01.json`: conditional feedback from already accepted
  local amplitudes. If Y=Bernoulli+U, |U|<=a, then
  |X|<=max(p+a,1-p+a)/sqrt(pq+s)<=max(u+a,1-l+a)/sqrt(min pq).
  Critical p[.418,.420], a=.325 gives actual R<1.839; a rounded R1.840
  discovery gives raw .480949, weighted lambda .122414, Hminus1.008514.
  This acyclic bootstrap is weak-entry -> confinement -> tighter support
  -> tighter entry. It needs a separately named analytic extension below
  the inherited R>=2.3 kernel guard before fixed acceptance. The elementary
  K4/K5 moment-ratio monotonicities are valid for R>=1, and all remaining
  paired coefficient gates pass in discovery, but this is not yet a proof
  of the complete extended kernel.

## Selected left support and new exact input table

`accept_left_support47.py` instantiates the unchanged independently proved
fifth-order all-H heat-support theorem: n>=47, C_n>=CE, decrement<=.19,
rho<=1.390 and |beta|<=.430 imply actual support(-3,3). Fresh
`left_support47_accept01`: 1448 exact gates / 3 rejected false targets.
No prior support cap is assumed by this support theorem.

`left_input47_discovery01.json` then exactly refines every previously
surviving complementary p cell at actual R3. It excludes the next six cells
and leaves39 cells [.302,.380], all with paired signed quadratics.
`left_input47_table.json` is the readable outward 1e-4 declared target table;
`accept_left_input47.py` is its fixed replay. Fresh run
`left_input47_accept01` returned PASS: 45 preceding cells, 6 exclusions,
39 acquired panels, and 9 rejected negative controls. It checks the complete
preceding survivor cover, all weighted noise/gap resources, moments, phase
signs, and corner coefficients. Table SHA256:
`2270ab68dd18e13afb7382e046589346e4cab26721a4e48be77b66ec22aa4b9a`.
No local comparison or confinement amplitude on the left is asserted.

## Contracted-radius exact candidate

The amplitude feedback was also run with exact rationals in separately
named copies: `contracted_kernel.py`, `contracted_panel_core.py`,
`probe_confined_feedback47.py`, log `confined_feedback47_discovery01`.
All45 arithmetic rows complete in `confined_feedback47_discovery01.json`.
The old kernel is unchanged. The new copy changes only the named radius
scope to1<=R<=6 and strengthens the paired Pearson guard toR>2g.
`confined_feedback47_proof.tex` proves the amplitude normalization, the
K4/K5 ratio extension, and the acyclic dependency route. Independent analytic
review is pending; this exact discovery is not yet a fixed accepted theorem.

Independent analytic review has now cleared the contracted-radius local-panel
extension and weighted resource exports. Fixed feedback acceptance is being
constructed; the previous discovery remains distinct from that acceptance.

## Accepted contracted-radius feedback

`accept_confined_feedback47.py` freshly passed all45 central panels and
13 negative controls in `confined_feedback47_accept01`. Its table is
`confined_feedback47_table.json`, SHA256
`360e13d125b5fb9cac6e7ee6ae0599dd796d19f8ac123794967c977c2bf4482c`.
The fixed checker binds both the old acquired input and both-sign confinement
certificate; every support radius is derived outward from that proved amplitude.
The independent final review is `../structural/CONFINED_FEEDBACK47_FINAL_REVIEW.md`
and its binding. The two-page `build_confined_feedback47/confined_feedback47_notes.pdf`
compiled without warnings and both rendered pages were visually checked.

## Sperner feedback candidate and cubic tests

The local worker supplied fresh SPERNER47A confinement with a separate
certificate using the original acquired input (hence no feedback cycle).
`sperner_panel_core.py` and `paired_conditional_gamma47.py` also incorporate
the independently derived conditional gamma lower bound, without changing
the phase convexity formula and retaining the explicit R>2g gate.
`conditional_gamma47_proof.tex` gives its short complete derivation.
`gamma47_actual_laws02` checks96 actual two/three/four-point laws, including
zero noise, symmetric and skew conditional noise: all pass;23 cases reject
the false bound obtained by omitting the negative residual penalty, and
2 malformed sign/centering decompositions reject. The first test run failed
because it compared two unrelated lower enclosures at equality; the corrected
checker compares the actual irrational moment using exact sign-aware squares.
No analytic inequality was changed by that test correction.

`sperner_feedback47_table.json` is the new fixed target (45 panels), bound
to the first accepted feedback table and to the newly accepted Sperner
confinement. Fresh `sperner_feedback47_accept01` returned PASS for45 panels and14
negative controls. The table SHA256 is
`4a1ea8a439e85e9f481bb6c6eb7a197ec4d35e53ceecf0ec92c3d4c96b9f618a`.
The one-page gamma proof compiled cleanly and was visually inspected.
The independent final source binding is pending.

## Separate sign charges: new exact discovery

`signed_variance_resource.py`, `coupled_panel_core.py`, and
`signed_variance_resource47_proof.tex` retain positive/negative conditional
variance charges separately, use a convex-power chord for the binary
moment shrinkage, and retain the correct sign weights in the outer-gap
budget. Old sources remain unchanged. Fresh exact discovery
`coupled_resource47_discovery01` covers all84 prior surviving cells; it
excludes [.302,.304] and leaves83 cells. For example lambda improves
.1534 to.12298 at p[.33,.332], and .1848 to.16414 at p[.35,.352].
The improvement is awaiting independent analytic review and fixed
acceptance; it is not yet an acquired replacement table.

## Final selected entry checkpoint

The sign-specific resource formula and implementation have now been
independently derived and found sound. Fixed `signed_resource47_accept01`
passed84 predecessor cells, one exclusion,83 complete survivors,14 controls.
The unchanged uniform heat kernel then freshly proves actualR2.7 from
rho<=1.2563, |beta|<=.3926, n>=47 and decrement<=.19:
`left_radius270_47_accept01`,1736 gates/3 false controls.
`left270_input47_accept01` freshly passes all38 left cells and11 controls,
including the acquired moment seam for that support theorem.
Latest table `left270_input47_table.json` SHA256:
`4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a`.
Final independent byte bindings are being completed. Parent requested
holding further exploratory branches and is acquiring the left noise strip.

A sign-premise omission was identified and explicitly resolved:
`paired_fourier_orientation47.tex` proves that the paired Fourier routine
may use |gamma| after reflecting only its unsigned Fourier estimate.
Exactly I0_{-X}(-H)=I0_X(H), and the odd cancellation coefficients flip
together. The actual signed contact/phase coefficients are unchanged.
This licenses max(0,signed gamma lower) without assuming original gamma>=0.
Both agents independently derived the repair; no arithmetic target or code
was changed. Its one-page PDF compiles cleanly and was visually checked.
The complete acquired DAG is `ENTRY47_DAG.md`; a complete manuscript must
include this orientation clarification.

The separate K1 sign-resource experiment `phase_resource47_discovery01`
yielded negligible additional gain and is not selected or accepted.

Final independent review checkpoint: all holds cleared. The four bindings
SPERNER_FEEDBACK47, SIGNED_RESOURCE47, LEFT270_INPUT47, and
PAIRED_ORIENTATION47 are frozen under `../structural/`; the last explicitly
supplements all affected prior Fourier-scope reviews. Fresh binding logs
are structural/sperner_resource47_binding01 and final47_review_binding01.
Independent sign-resource controls covered84 actual laws. The selected
acquisition is complete on [.304,.47]; the local comparison remains separate.
