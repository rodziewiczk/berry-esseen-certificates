"""Fixed complete certificate for a_n<1.5/n from40, using proved99tail.

The analytic contact/entry reduction and prior99 theorem remain explicit inputs.
No cutoff50 assertion. Exact arithmetic and strict closed-cell reconstruction.
"""
import sys,json,copy,hashlib
from pathlib import Path
from fractions import Fraction as F
import chain_core as c
import high_refinement
import fifth_heat50 as heat
import heat_support50 as basic
import accept_anchor40 as anchor

def need(x,s):
 if not x:raise ValueError(s)
SPECS=[('PROPAGATE_41_49',41,49,F('2.9'),6),
       ('PROPAGATE_50_69',50,69,F(3),5),
       ('PROPAGATE_70_98',70,98,F('3.2'),4)]
def profiles():
 return{name:dict(n=n,nmax=last,R=r,rho=basic.constants(n,last,F('1.5'))[1],barrier=F('1.5'),cap=F('.469'),cells=64)for name,n,last,r,_ in SPECS}
def keys(d,names):need(type(d)is dict and set(d)==set(names),'exact fields')
def shape(doc):
 keys(doc,('format','profiles'));need(doc['format']=='propagation40-v1','format')
 need(type(doc['profiles'])is list and len(doc['profiles'])==3,'complete profile count')
 for row,(name,n,last,r,length)in zip(doc['profiles'],SPECS):
  keys(row,('name','steps'));need(row['name']==name,'named ordered profile')
  need(type(row['steps'])is list and len(row['steps'])==length,'fixed pass count')
  oldr=oldd=None;phase=-1
  for j,z in enumerate(row['steps']):
   keys(z,('kind','R','D','active','excluded'))
   need(z['kind']in('universal','initial','general'),'kind')
   p=('universal','initial','general').index(z['kind'])
   need((j==0)==(p==0)and phase<=p<=phase+1,'ordered stages');phase=p
   raw,d=anchor.parse_f(z['R']),anchor.parse_f(z['D'])
   need(0<raw<F('.4095')*n,'feedback license')
   need(d>0 or j==length-1,'negative defect only at exclusion')
   for f in('active','excluded'):need(type(z[f])is int and 0<=z[f]<=64,'cell count')
   need(z['active']>0 and z['active']+z['excluded']==64,'complete cover')
   if oldr is not None:need(raw<=oldr and d<=oldd and(raw<oldr or d<oldd),'strict progress')
   oldr,oldd=raw,d
  need(phase==2 and oldd<0,'barrier exclusion goal')
def verify(doc):
 shape(doc);ps=profiles();total=0;out=[]
 # The first-failure decrement is below1.5/(n-1), on the current law.
 for row,(name,n,last,r,length)in zip(doc['profiles'],SPECS):
  support=heat.target(n,last,F('1.5'),r,F('1.5')/(n-1))
  p=ps[name];c.initialize(p);raw=d=None
  for z in row['steps']:
   got=c.stage(p,z['kind'],raw,d);rr,dd=F(z['R']),F(z['D'])
   need(got['active']==z['active']and got['excluded']==z['excluded'],'arithmetic cover cardinality')
   need(rr==raw or got['R']<rr,'strict raw target')
   need(dd==d or got['D']<dd,'strict defect target')
   total+=64;raw,d=rr,dd
  out.append(dict(name=name,support=support,raw=str(raw),defect=str(d)))
 return out,total
def negatives(doc):
 cases=[]
 def add(name,f,deep=False):
  z=copy.deepcopy(doc);f(z);cases.append((name,z,deep))
 add('missing_band',lambda z:z['profiles'].pop(1))
 add('reordered_bands',lambda z:z['profiles'].reverse())
 add('duplicate_band',lambda z:z['profiles'].__setitem__(1,copy.deepcopy(z['profiles'][0])))
 add('extra_field',lambda z:z.update(ignored=1))
 add('missing_step',lambda z:z['profiles'][0]['steps'].pop(1))
 add('stage_reorder',lambda z:z['profiles'][0]['steps'].reverse())
 add('noncanonical',lambda z:z['profiles'][0]['steps'][0].update(R='01'))
 add('bool_count',lambda z:z['profiles'][0]['steps'][0].update(active=True))
 add('false_raw',lambda z:z['profiles'][0]['steps'][0].update(R='1/100'),True)
 add('false_cover',lambda z:z['profiles'][0]['steps'][0].update(active=63,excluded=1),True)
 out=[]
 for name,z,deep in cases:
  try:verify(z)if deep else shape(z)
  except(ValueError,AssertionError,TypeError,ZeroDivisionError):out.append(name)
  else:raise ValueError(('negative control accepted',name))
 try:json.loads('{"format":1,"format":2}',object_pairs_hook=anchor.unique)
 except ValueError:out.append('duplicate_JSON_key')
 else:raise ValueError('duplicate JSON accepted')
 return out
if __name__=='__main__':
 need(__debug__ and not sys.flags.optimize,'optimized Python forbidden')
 need(len(sys.argv)==1,'no configurable target')
 # Importing anchor installed the HIGH bound once; do not install twice.
 c.PROFILES={'ANCHOR40':dict(n=40,nmax=40,R=F('3.3'),rho=F(712569,574000),barrier=F('1.5'),cap=F('.469'),cells=64)}
 base=Path(__file__).resolve().parent
 aobj=json.loads((base/'anchor40_proof.json').read_text(),object_pairs_hook=anchor.unique)
 anchors,acount=anchor.verify(aobj)
 # a39<.469-.4095 and hypotheticala40>=1.5/40 implyd40<.88.
 need(40*(F('.469')-F('.4095')-F('1.5')/40)==F('.88'),'anchor decrement')
 asupport=heat.target(40,40,F('1.5'),F('3.3'),F('.88'))
 doc=json.loads((base/'propagation40_proof.json').read_text(),object_pairs_hook=anchor.unique)
 rows,n=verify(doc);controls=negatives(doc)
 need(SPECS[0][1]==41 and SPECS[-1][2]==98,'finite seams with anchor and99tail')
 for left,right in zip(SPECS,SPECS[1:]):need(left[2]+1==right[1],'adjacent bands')
 # Fromj>=42 all three current/deleted caps are<.45.
 need(F('.40974')+F('1.5')/40<F('.45'),'threecap floor42')
 files=[base/name for name in('accept_ceiling40.py','accept_anchor40.py','anchor40_proof.json','propagation40_proof.json','chain_core.py','kernel.py','high_refinement.py','fifth_heat50.py','heat_support50.py')]
 print(json.dumps(dict(status='PASS_CEILING40_WITH_EXPLICIT_PRIOR99_TAIL',anchor=anchors,anchor_support=asupport,propagation=rows,
  complete_entry_cells=n+acount,negative_controls=controls,
  conclusion='a_n<1.5/n for alln>=40; threecaps<.45 for alln>=42',
  dependencies=['attained contact and finite caps','old exact entry analytic reduction','new HIGH rational tail proof','new fifth-order support proof','independently completed cutoff99 for n>=99'],
  scope='This is a global ceiling, not a cutoff50 or a local binary comparison.',
  source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}),indent=2))
