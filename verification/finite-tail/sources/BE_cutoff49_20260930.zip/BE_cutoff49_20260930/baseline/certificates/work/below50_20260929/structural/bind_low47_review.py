"""Bind the independently reviewed LOW47 proof and fresh fixed replays."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,sys
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;PROJECT=BASE.parents[1]
RUN=PROJECT/'runs/below50_20260929'
def digest(p):return sha256(p.read_bytes()).hexdigest()
def evidence(name):
    p=RUN/name;m=json.loads((p/'metadata.json').read_text())
    assert m['returncode']==0
    assert digest(p/'stdout.txt')==m['stdout_sha256']
    assert digest(p/'stderr.txt')==m['stderr_sha256']
    return p,m
def last_json(p):
    txt=(p/'stdout.txt').read_text()
    start=txt.rfind('\n{\n')
    return json.loads(txt[start+1:]if start>=0 else txt)
p,m=evidence('root_low47_accept01');r=last_json(p)
assert r['status']=='PASS_EXACT_CONDITIONAL_CENTRAL_LOW47'
assert (r['rows'],r['gates'],r['feasible_cells'],r['excluded_cells'],r['controls'])==(74,2183897,20031,17121,11)
assert Fraction(r['worst_score'])<Fraction('-0.0022896')
for rel,h in r['source_sha256'].items():assert digest(BASE/rel)==h,(rel,'current hash')
for name in ['accept_low47.py','low47_contract.py','low47_kernel.py','low47_normalization.py','low47_constructed02.json']:
    assert digest(BASE/'root'/name)==m['input_sha256'][name],(name,'before hash')
np,nm=evidence('entry/low47_normalization_accept02');nr=last_json(np)
assert (nr['configurations'],nr['gates'],nr['negative_controls'])==(90,5400,26)
for rel,h in nr['source_sha256'].items():assert digest(BASE/rel)==h,(rel,'normalization source')
ap,am=evidence('structural/low47_actual01');ar=last_json(ap)
assert ar['status']=='PASS_EXACT_ACTUAL_LAW_CONTROLS'
assert digest(HERE/'check_low47_new_lemmas_actual.py')==am['input_sha256']['check_low47_new_lemmas_actual.py']
cp,cm=evidence('structural/low47_lemmas_compile01')
files=list(r['source_sha256'])+[
 'root/low47_normalization_proof.tex','entry/accept_low47_normalization.py',
 'entry/paired_fourier_orientation47.tex','structural/low47_new_lemmas.tex',
 'structural/low47_lemma_notes.tex','structural/LOW47_REVIEW.md',
 'structural/check_low47_new_lemmas_actual.py','structural/bind_low47_review.py',
 'structural/build_low47_lemmas/low47_lemma_notes.pdf',
 'structural/PAIRED_ORIENTATION47_BINDING.json','structural/SPERNER_FEEDBACK47_BINDING.json',
 'structural/SPERNER47A_BINDING.json','structural/SPERNER47_PROFILE_A_BINDING.json',
 'structural/MID47A_BINDING.json','structural/TINY47A_BINDING.json']
records={str(p.relative_to(PROJECT)):digest(p)for p in [BASE/x for x in files]}
for folder in [p,np,ap,cp]:
    for name in ['metadata.json','stdout.txt','stderr.txt']:
        f=folder/name;records[str(f.relative_to(PROJECT))]=digest(f)
out=HERE/'LOW47_BINDING.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='INDEPENDENT_LOW47_REVIEW_V1',
 mathematical_status='Reviewed conditional all-n>=47 central LOW comparison; global selector and complementary acquired regions remain separate.',
 execution_status='Fresh exact fixed acceptance PASS; independent finite actual-law controls PASS.',
 rows=74,gates=2183897,feasible=20031,excluded=17121,controls=11,
 normalization=dict(configurations=90,gates=5400,controls=26),
 actual_law_controls=ar['counts'],visual_qa=dict(reviewer_pages=[1,2,3,4],
 pdf='structural/build_low47_lemmas/low47_lemma_notes.pdf',clean_compile=True),
 sha256=records),indent=2)+'\n')
print(json.dumps(dict(status='PASS_INDEPENDENT_LOW47_BINDING',files=len(records),binding_sha256=digest(out)),indent=2))
