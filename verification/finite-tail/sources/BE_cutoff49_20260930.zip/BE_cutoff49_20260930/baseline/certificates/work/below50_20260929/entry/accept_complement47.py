#!/usr/bin/env python3
"""Fixed exact preparation of the complement to central p at index47.

Consumes INITIAL47_R384; does not assert local domination on surviving cells.
"""
from fractions import Fraction as F
from pathlib import Path
import copy,hashlib,json,sys
import local_panel_core as c
SOURCE='95c5c1de0062b6a9e294a81ee8497eee8bdb2e0798299422d7ad39b885e4a951'
SPEC=list(range(125,190))+list(range(240,300))
def need(x,s):
 if not x:raise ValueError(s)
def coverage(cells):
 need(type(cells)is list and cells==SPEC and all(type(i)is int for i in cells),'exact ordered complementary closed cover')
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,list):return [enc(v)for v in x]
 if isinstance(x,dict):return {k:enc(v)for k,v in x.items()}
 return x
def verify(cells,emit=False):
 coverage(cells);blob=Path('initial47_proof.json').read_bytes();need(hashlib.sha256(blob).hexdigest()==SOURCE,'fixed accepted INITIAL47 dependency')
 initial=json.loads(blob);survivors=[];excluded=[]
 for i in cells:
  base=initial['panels'][i//5];need(base['cells']>0,'selected initial panel exists')
  row={key:F(value)for key,value in base.items()if key!='cells'};row['pl'],row['pu']=F(i,500),F(i+1,500)
  out=c.cell(47,F('3.84'),F('.4247'),row,steps=24)
  if out.get('excluded'):excluded.append(i)
  else:
   need(145<=i<190,'fixed complementary exclusions below.29 and above.48')
   for key,bound in [('raw','1.885'),('D','.590'),('rho','1.390'),('beta','.430'),('theta','.026')]:need(out[key]<F(bound),('fixed complement cap',i,key))
   out.pop('trace');out.update(index=i,H=F(base['H']));survivors.append(out)
  if emit:print('PASS_COMPLEMENT47',i,'EXCLUDED'if out.get('excluded')else'SURVIVES',flush=True)
 return dict(status='PASS_PREP47_COMPLEMENT_R384',N=47,actual_radius='96/25',own_score_cap='4247/10000',initial_sha256=SOURCE,closed_cells=len(cells),excluded_cells=excluded,surviving_cells=survivors,scope='The actual p complement [.25,.38] union [.48,.60] is covered. Survivors lie in [.29,.38] with the printed moment/resource caps; no local-comparison claim.')
def controls():
 bad=[SPEC[:-1],list(reversed(SPEC)),SPEC[:2]+[SPEC[1]]+SPEC[2:],SPEC[:20]+SPEC[21:]]
 z=SPEC[:];z[0]=True;bad.append(z)
 for cells in bad:
  try:coverage(cells)
  except ValueError:pass
  else:raise ValueError('malformed complementary cover accepted')
 # An independent genuine arithmetic rejection on a surviving input.
 blob=json.loads(Path('initial47_proof.json').read_text());base=blob['panels'][35]
 row={key:F(value)for key,value in base.items()if key!='cells'};row['pl'],row['pu']=F(35,100),F(352,1000)
 out=c.cell(47,F('3.84'),F('.4247'),row,steps=24)
 need(not out.get('excluded') and out['raw']>F(1,100),'false tiny remainder target rejected')
 return len(bad)+1
if __name__=='__main__':
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed unoptimized invocation');out=verify(SPEC,True);out['negative_controls']=controls()
 out['source_sha256']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()for name in('accept_complement47.py','local_panel_core.py','high_window_core.py','kernel.py')}
 path=Path('complement47_accepted.json');need(not path.exists(),'fresh output path');path.write_text(json.dumps(enc(out),indent=2)+'\n')
 print(json.dumps({key:value for key,value in out.items()if key not in('surviving_cells','excluded_cells')},sort_keys=True),flush=True)
