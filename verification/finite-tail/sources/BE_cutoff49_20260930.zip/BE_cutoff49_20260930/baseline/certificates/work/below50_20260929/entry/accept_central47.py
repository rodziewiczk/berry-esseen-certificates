#!/usr/bin/env python3
"""Fixed conditional central-p acquisition checks; hypotheses stay explicit.

PREP47 consumes the separately accepted INITIAL47 table. INPUT47 consumes
PREP47 and the separately proved actual-support contraction to radius2.5.
Neither stage proves anything about p outside its displayed closed cover.
"""
from fractions import Fraction as F
from pathlib import Path
import copy,hashlib,json,sys
import local_panel_core as c
def need(x,s):
 if not x:raise ValueError(s)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rational(x):
 need(type(x)is str and len(x)<100,'rational string');return F(x)
def unique(pairs):
 z={}
 for key,value in pairs:need(key not in z,'duplicate JSON key');z[key]=value
 return z
def load(p):return json.loads(Path(p).read_text(),object_pairs_hook=unique)
def shape_prep(o):
 need(type(o)is dict and set(o)=={'format','name','initial_sha256','rows'},'exact prep fields')
 need(o['format']=='CENTRAL47_PREP_V1' and o['name']=='PREP47_CENTRAL_R384','fixed prep theorem')
 need(o['initial_sha256']==digest('initial47_proof.json'),'bound initial proof object')
 need(type(o['rows'])is list and len(o['rows'])==10,'complete central prep cover')
 for j,z in enumerate(o['rows']):
  need(type(z)is dict and set(z)=={'pl','pu','excluded','raw','D','theta','rho','beta','H'},'prep row fields')
  need(rational(z['pl'])==F(38+j,100) and rational(z['pu'])==F(39+j,100),'contiguous closed central prep cells')
  need(type(z['excluded'])is bool,'explicit exclusion status')
  for key in('raw','D','theta','rho','beta','H'):rational(z[key])
  if z['excluded']:need(j==9 and all(z[key]=='0'for key in('raw','D','theta','rho','beta','H')),'selected last-cell exclusion')
  else:need(j<9 and 0<F(z['D'])<2 and 0<=F(z['theta'])<F(1,10) and 1<=F(z['rho'])<F('1.216') and 0<F(z['H'])<=F('1.781'),'selected prep scope')
def verify_prep(o,emit=False):
 shape_prep(o);initial=load('initial47_proof.json');rows=[]
 for j,target in enumerate(o['rows']):
  base=initial['panels'][38+j];need(base['cells']>0,'nonempty initial source panel')
  row={key:F(value)for key,value in base.items()if key!='cells'}
  result=c.cell(47,F('3.84'),F('.4247'),row,steps=24)
  if target['excluded']:need(result.get('excluded')is True,'proved complete prep exclusion')
  else:
   need(not result.get('excluded'),'selected nonempty target')
   for key in('raw','D','theta','rho','beta'):need(result[key]<=F(target[key]),'prep upper target '+key)
   need(F(base['H'])<=F(target['H']),'inherited phase target')
  rows.append(result)
  if emit:print('PASS_PREP47',j,target['excluded'],flush=True)
 return dict(status='PASS_PREP47_CENTRAL_CONDITIONAL',panels=10,excluded_panels=1,source_sha256=digest('initial47_proof.json'))
def input_shape(table,prep):
 shape_prep(prep)
 need(table['schema']=='CONDITIONAL_LOCAL47_COMPARATOR_INPUT_V1','fixed canonical schema')
 need(table['N']==47 and table['support_radius']=='2.5' and table['decrement_cap']=='0.19','fixed canonical domain')
 need(table['constant_excess_cap']=='0.7' and F(table['score_cap'])>=F('.4247'),'compatible own score cap')
 need(table['probability_domain']==['.38','.47'],'fixed probability domain')
 rows=table['panels'];need(type(rows)is list and len(rows)==45,'complete central fine cover')
 for j,row in enumerate(rows):
  need(type(row['index'])is int and row['index']==j,'ordered unique panel indices')
  need(list(map(F,row['p']))==[F(190+j,500),F(191+j,500)],'contiguous closed .002 probability cells')
  need(len(row['quadratics'])==4,'all four score/rho corner bounds')
  for q in row['quadratics']:
   need(set(q)=={'A','Fplus','Fminus','Qraw','Qbudget'},'quadratic fields')
   for v in q.values():rational(v)
   need(F(q['A'])>0 and F(q['Qraw'])>0 and F(q['Qbudget'])>F(q['Qraw']),'positive phase curvatures')
def verify_input(table,prep,emit=False):
 input_shape(table,prep);results=[]
 for j,target in enumerate(table['panels']):
  parent=prep['rows'][j//5];row={key:F(value)for key,value in parent.items()if key!='excluded'}
  row['pl'],row['pu']=map(F,target['p'])
  result=c.cell(47,F('2.5'),F('.4247'),row,steps=24)
  if result.get('excluded'):
   if emit:print('PASS_INPUT47_EXCLUDED',j,flush=True)
   results.append(result);continue
  need('quadratics'in result,'paired proof available in every surviving fine cell')
  for actual,claim in [('raw','T'),('D','D'),('theta','theta'),('rho','rho'),('beta','beta_hi'),('lambda_max','lambda_max'),('inward_d_max','d0'),('Hplus','H_plus'),('Hminus','H_minus')]:
   need(result[actual]<=F(target[claim]),('canonical upper target',j,claim,str(result[actual]),target[claim]))
  for actual,claim in [('beta_lo','beta_lo'),('A','A_lo'),('B','B_lo')]:need(result[actual]>=F(target[claim]),('canonical lower target',j,claim))
  for actual,claim in zip(result['quadratics'],target['quadratics']):
   for key in('A','Fplus','Fminus'):need(actual[key]<=F(claim[key]),('quadratic upper target',j,key))
   for key in('Qraw','Qbudget'):need(actual[key]>=F(claim[key]),('quadratic curvature target',j,key))
  if emit:print('PASS_INPUT47',j,flush=True)
  results.append(result)
 return dict(status='PASS_INPUT47_CENTRAL_CONDITIONAL',panels=45,weighted_lambda_checked=True,weighted_inward_gap_checked=True,prep_sha256=digest('central47_prep_proof.json'))
def controls_prep(o):
 bad=[]
 for action in [lambda z:z['rows'].pop(),lambda z:z['rows'].reverse(),lambda z:z['rows'].insert(1,z['rows'][0]),lambda z:z.update(initial_sha256='0'*64),lambda z:z['rows'][0].update(pu='2/5')]:
  z=copy.deepcopy(o);action(z);bad.append(z)
 for z in bad:
  try:shape_prep(z)
  except (ValueError,KeyError,TypeError):pass
  else:raise ValueError('malformed prep accepted')
 z=copy.deepcopy(o);z['rows'][0]['raw']='1/100'
 try:verify_prep(z)
 except ValueError:pass
 else:raise ValueError('false prep arithmetic target accepted')
 return len(bad)+1
def controls_input(table,prep):
 bad=[]
 for action in [lambda z:z['panels'].pop(),lambda z:z['panels'].reverse(),lambda z:z['panels'].insert(1,z['panels'][0]),lambda z:z['panels'][0].update(index=True),lambda z:z['panels'][0].update(p=['19/50','39/100']),lambda z:z['panels'][0]['quadratics'].pop()]:
  z=copy.deepcopy(table);action(z);bad.append(z)
 for z in bad:
  try:input_shape(z,prep)
  except (ValueError,KeyError,TypeError):pass
  else:raise ValueError('malformed input cover accepted')
 for field,value in [('T','0.01'),('lambda_max','0.000001')]:
  z=copy.deepcopy(table);z['panels'][0][field]=value
  try:verify_input(z,prep)
  except ValueError:pass
  else:raise ValueError('false input arithmetic target accepted')
 return len(bad)+2
if __name__=='__main__':
 need(__debug__ and not sys.flags.optimize,'optimized Python forbidden');need(len(sys.argv)==2 and sys.argv[1]in('prep','input'),'fixed mode')
 prep=load('central47_prep_proof.json')
 if sys.argv[1]=='prep':out=verify_prep(prep,True);out['negative_controls']=controls_prep(prep)
 else:
  table=load('../local/conditional_input47.json');out=verify_input(table,prep,True);out['negative_controls']=controls_input(table,prep);out['canonical_sha256']=digest('../local/conditional_input47.json')
 out['source_sha256']={name:digest(name)for name in('accept_central47.py','local_panel_core.py','high_window_core.py','kernel.py')}
 print(json.dumps(out,sort_keys=True),flush=True)
