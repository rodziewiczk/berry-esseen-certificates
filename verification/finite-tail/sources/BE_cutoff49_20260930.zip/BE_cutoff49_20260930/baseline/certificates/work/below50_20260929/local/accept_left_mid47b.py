"""Read-only exact acceptance of LEFT_MID47_B with explicitly checked witnesses."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,copy,sys
from left_mid47b_kernel import reconstruct,need,own
from left_sperner47_contract import unique
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
SOURCES=('left_mid47b_kernel.py','left_mid47_normalization.py','left_mid47b_normalization.json','left_sperner47_contract.py','sperner47_kernel.py','left270_input47_table.json','mid47a_kernel.py','mid47a_normalization.py','tiny47a_kernel.py','tiny47a_normalization.py')
def sources():return {s:sha256((HERE/s).read_bytes()).hexdigest()for s in SOURCES}
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def validate(a,b):need(same(a,b),'Fixed scope/source/witness/arithmetic/cover mismatch')
def controls(want):
 done=[]
 def reject(name,f):
  x=copy.deepcopy(want);f(x)
  try:validate(x,want)
  except ValueError:done.append(name)
  else:raise ValueError('Accepted mutation '+name)
 reject('missing',lambda x:x.pop('blocks'));reject('extra',lambda x:x.update(extra=1));reject('theorem',lambda x:x.update(schema='WRONG'))
 reject('floor',lambda x:x['contract'].update(N=46));reject('noise_gap',lambda x:x['contract']['regions'][1].__setitem__(0,'.061'))
 reject('amplitude',lambda x:x['contract']['regions'][0].__setitem__(3,'.4'));reject('phase_gap',lambda x:x['contract']['regions'][0].__setitem__(2,'.10'))
 reject('missing_block',lambda x:x['blocks'].pop());reject('duplicate_block',lambda x:x['blocks'].__setitem__(1,x['blocks'][0]));reject('reordered',lambda x:x['blocks'].reverse())
 reject('sign',lambda x:x['blocks'][0].update(sign=0));reject('missing_phase',lambda x:x['blocks'][0]['witnesses'].pop());reject('extra_phase',lambda x:x['blocks'][0]['witnesses'].append(0))
 reject('bad_witness',lambda x:x['blocks'][0]['witnesses'].__setitem__(0,-1));reject('boolean_witness',lambda x:x['blocks'][0]['witnesses'].__setitem__(0,True));reject('arithmetic',lambda x:x['blocks'][0].update(arithmetic_sha256='0'*64))
 for v in('0','-1',True):reject('gate_'+str(v),lambda x,v=v:x['minimum_gates'].__setitem__('score',v))
 reject('source',lambda x:x['source_sha256'].__setitem__(SOURCES[0],'0'*64))
 try:json.loads('{"x":0,"x":0}',object_pairs_hook=unique)
 except ValueError:done.append('duplicate_JSON_key')
 else:raise ValueError('Duplicate JSON key accepted')
 for v in(-1,58,True):
  try:own(v,1,F('.2'),F('.201'),F('.05'),F('.06'),F('.3'),{})
  except ValueError:done.append('invalid_witness_'+str(v))
  else:raise ValueError('Invalid witness accepted')
 return done
if __name__=='__main__':
 raw=(HERE/'left_mid47b_certificate.json').read_bytes();got=json.loads(raw,object_pairs_hook=unique);want=reconstruct(got['blocks']);want['source_sha256']=sources();validate(got,want);tests=controls(want)
 print(json.dumps(dict(status='PASS_EXACT_CONDITIONAL_LEFT_MID47_B',blocks=len(want['blocks']),phase_cells=want['phase_cells'],gates=want['gates'],normalization_gates=want['normalization_gates'],minimum_reserve=want['minimum_reserve'],negative_controls=tests,certificate_sha256=sha256(raw).hexdigest(),source_sha256={**want['source_sha256'],'accept_left_mid47b.py':sha256(Path(__file__).read_bytes()).hexdigest()},scope='Acquired left270 p panels n>=47, all clipped closed noise/phase rectangles .05..06/|u|>=.09, .06..08/|u|>=.14, .08..10/|u|>=.19, fourth .10..12 only u<=-.29, accepted min amplitudes. Full local/global composition separate.'),indent=2))
