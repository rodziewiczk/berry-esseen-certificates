"""Strict read-only acceptance for fixed CONDITIONAL_LEFT_SPERNER47_A."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,copy,sys
from left_sperner47_contract import input_table,config,unique,INPUT_SHA256
from sperner47_kernel import evaluate
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
SOURCES=('left270_input47_table.json','sperner47_kernel.py','left_sperner47_contract.py')
def need(x,s):
 if not x:raise ValueError(s)
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def reconstruct():
 rows=[];total=excluded=feasible=0;mins={};digest=sha256()
 for panel in input_table()['panels']:
  for sign in(-1,1):
   c=config(panel,sign);o=evaluate(c);keys=[x[0]for x in o['empty']]+o['feasible']
   expected={f'0:{h}:{l}'for h in range(16)for l in range(16)}
   need(len(keys)==len(set(keys))==256 and set(keys)==expected,'Incomplete closed H/noise cover')
   for name,v in o['gates'].items():
    need(type(v)is F and v>0,f'Nonpositive gate {panel["index"]}/{sign}/{name}: {v}')
    tag=name.split(':')[0];mins[tag]=min(mins.get(tag,v),v)
   atom=dict(index=panel['index'],sign=sign,p=panel['p'],amplitude=str(c['amplitude']),
    gates=len(o['gates']),excluded=len(o['empty']),feasible=len(o['feasible']),
    arithmetic_sha256=sha256(canonical(dict(gates={k:str(v)for k,v in o['gates'].items()},empty=o['empty'],feasible=o['feasible']))).hexdigest())
   rows.append(atom);digest.update(canonical(atom));total+=len(o['gates']);excluded+=len(o['empty']);feasible+=len(o['feasible'])
 need(len(rows)==76 and excluded+feasible==38*2*16*16,'Incomplete panel/sign cover')
 return dict(schema='CONDITIONAL_LEFT_SPERNER47_A_V1',contract=dict(N=47,score_cap='.4253',strip='.55',probability=['.304','.38'],
  p_cells=38,H_cells=16,noise_cells=16,signs=[-1,1],noise_ceiling='explicit panel hypothesis',input_sha256=INPUT_SHA256),
  rows=rows,gates=total,excluded=excluded,feasible=feasible,arithmetic_sha256=digest.hexdigest(),
  minimum_reserves={k:str(v)for k,v in mins.items()},source_sha256={s:sha256((HERE/s).read_bytes()).hexdigest()for s in SOURCES})
def validate(x,want):need(same(x,want),'Fixed scope, source, arithmetic, or coverage mismatch')
def controls(want):
 tests=[]
 def reject(name,f):
  o=copy.deepcopy(want);f(o)
  try:validate(o,want)
  except ValueError:tests.append(name)
  else:raise ValueError('Mutation accepted: '+name)
 reject('missing_rows',lambda o:o.pop('rows'));reject('extra_field',lambda o:o.update(extra=1))
 reject('wrong_theorem',lambda o:o.update(schema='CONDITIONAL_CONFINEMENT46_A_V1'))
 reject('wrong_floor',lambda o:o['contract'].update(N=46));reject('wider_strip',lambda o:o['contract'].update(strip='.6'))
 reject('higher_score_cap',lambda o:o['contract'].update(score_cap='.43'))
 reject('missing_sign',lambda o:o['rows'].pop());reject('duplicate_panel',lambda o:o['rows'].__setitem__(2,o['rows'][0]))
 reject('reordered_panels',lambda o:o['rows'].reverse());reject('changed_sign',lambda o:o['rows'][0].update(sign=1))
 reject('changed_amplitude',lambda o:o['rows'][0].update(amplitude='.3'))
 reject('changed_coverage',lambda o:o['rows'][0].update(feasible=0));reject('changed_arithmetic',lambda o:o.update(arithmetic_sha256='0'*64))
 key=next(iter(want['minimum_reserves']))
 for name,value in(('zero_gate','0'),('negative_gate','-1'),('boolean_gate',True)):
  reject(name,lambda o,v=value:o['minimum_reserves'].__setitem__(key,v))
 reject('changed_source',lambda o:o['source_sha256'].update({'sperner47_kernel.py':'0'*64}))
 try:input_table((HERE/'left270_input47_table.json').read_bytes()+b' ')
 except ValueError:tests.append('changed_input_bytes')
 else:raise ValueError('Changed fixed input accepted')
 try:config(input_table()['panels'][0],0)
 except ValueError:tests.append('zero_phase_sign')
 else:raise ValueError('Invalid sign accepted')
 try:json.loads('{"x":0,"x":0}',object_pairs_hook=unique)
 except ValueError:tests.append('duplicate_JSON_key')
 else:raise ValueError('Duplicate JSON accepted')
 return tests
if __name__=='__main__':
 want=reconstruct();raw=(HERE/'left_sperner47_certificate.json').read_bytes();validate(json.loads(raw,object_pairs_hook=unique),want);negative=controls(want)
 print(json.dumps(dict(status='PASS_EXACT_CONDITIONAL_LEFT_SPERNER47_A',gates=want['gates'],excluded=want['excluded'],feasible=want['feasible'],panels=38,signs=2,
  minimum_reserves=want['minimum_reserves'],negative_controls=negative,certificate_sha256=sha256(raw).hexdigest(),
  source_sha256={**want['source_sha256'],'accept_left_sperner47.py':sha256(Path(__file__).read_bytes()).hexdigest()},
  scope='n>=47 and the exact supplied panel hypotheses imply |U| below the listed panel amplitude. Entry, support-strip acquisition, and final score comparison are separate obligations. Both deleted concentration bounds follow from the strict-gap antichain lemma at j>=n-2.'),indent=2))
