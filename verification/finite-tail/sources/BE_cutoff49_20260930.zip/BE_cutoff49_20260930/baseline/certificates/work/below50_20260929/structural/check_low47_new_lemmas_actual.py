"""Exact actual-law controls for the three LOW47 tail changes.

No constructor module is imported. These finite tests supplement the proof;
they do not certify its continuous-domain quantifiers.
"""
from fractions import Fraction as F
from math import factorial
from collections import defaultdict
import json, sys
assert __debug__ and not sys.flags.optimize

def conv(a,b):
    out=defaultdict(F)
    for x,px in a.items():
        for y,py in b.items():out[x+y]+=px*py
    return dict(out)

def power(a,n):
    r={F(0):F(1)}
    for _ in range(n):r=conv(r,a)
    return r

def moment(a,j):return sum(p*x**j for x,p in a.items())
def prob(a,f):return sum(p for x,p in a.items() if f(x))
def centered(lo,hi):
    assert lo<=0<=hi
    if lo==hi:return {F(0):F(1)}
    return {lo:hi/(hi-lo),hi:-lo/(hi-lo)}

def poisson_upper(V,A,b,j):
    mu=V/A**2;x=mu+b/A
    assert mu>0 and 0<=j<x
    raw=mu**3+(3-3*j)*mu**2+(1-3*j+3*j*j)*mu-j**3
    correction=sum(mu**k*(j-k)**3/F(factorial(k))
                   for k in range(j.numerator//j.denominator+1))
    eupper=1/sum(mu**k/F(factorial(k))for k in range(25))
    return min(F(1),(raw+eupper*correction)/(x-j)**3)

counts=defaultdict(int)
specs=[]
for A in map(F,['.275','.35','.425']):
    for d in map(F,['.002','.018','.04']):
        for frac in [F(1,10),F(1,2),F(9,10)]:
            a0=d*frac;a1=d-a0
            specs.append((A,d,centered(-A,a0),centered(-a1,A)))
# Degenerate conditional law, balanced small noises, and a tiny atom.
specs += [(F('.35'),F('.018'),{F(0):F(1)},centered(-F('.018'),F('.35'))),
          (F('.35'),F('.018'),centered(-F('.018'),F('.018')),{F(0):F(1)}),
          (F('.425'),F('.00000001'),centered(-F('.425'),F('.000000005')),
            centered(-F('.000000005'),F('.425')))]

for A,d,U0,U1 in specs:
    assert moment(U0,1)==moment(U1,1)==0
    D=conv(U1,{-x:p for x,p in U0.items()})
    vartheta=sum(p*max(F(0),-x) for x,p in D.items())
    assert vartheta==sum(p*max(F(0),x)for x,p in D.items())
    c=1-d
    for n in [3,5]:
        for k in [1,n-1]:
            Z=conv(power(U1,k-1),power(U0,n-k-1))
            A0=conv(Z,U1);A1=conv(Z,U0);W=conv(A0,U0)
            t=moment(W,2)
            assert 0<=moment(Z,2)<=t and moment(A0,2)<=t and moment(A1,2)<=t
            if t==0:continue
            eta=F('.013')
            phases={F(j,10)for j in range(-5,6)}
            # Include exact atom collisions of both deleted tail events.
            for i in [1,2]:
                phases.update(x-d+c*i for x in A0 if abs(x-d+c*i)<=F(1,2))
                phases.update(x-eta-i+A for x in A1 if abs(x-eta-i+A)<=F(1,2))
            for u in sorted(phases):
                for i in [1,2]:
                    weighted=sum(pa*p0*p1*max(F(0),x0-x1)
                        for x,pa in A0.items() for x0,p0 in U0.items()
                        for x1,p1 in U1.items() if x+x0<=u-c*i)
                    p0=prob(A0,lambda x:x<=u+d-c*i)
                    p1=prob(A1,lambda x:x>u+eta+i-A)
                    assert weighted<=vartheta*p0
                    counts['active_mark_checks']+=1
                    if u+d-c*i in A0 or u+eta+i-A in A1:counts['exact_collisions']+=1
                    # A nondegenerate closed phase cell surrounding this u.
                    ul=max(-F(1,2),u-F(1,200));uh=min(F(1,2),u+F(1,200))
                    b1=c*i-d-uh;b2=i-A+ul
                    alpha=c*i-2*d-uh;beta=i-A-d+ul
                    if min(b1,b2,alpha,beta)<=0:
                        counts['outside_positive_distance_domain']+=1;continue
                    for inflation in [F(1),F(3,2)]:
                        T=inflation*t;Tl=T/2;Th=2*T
                        commonZ=prob(Z,lambda x:x<=-alpha)+prob(Z,lambda x:x>beta)
                        assert p0+p1<=commonZ
                        mid=(beta-alpha)/2
                        center=max(-Tl/beta,min(mid,Tl/alpha))
                        radius=min(center+alpha,beta-center)
                        assert radius>0
                        common=(1+center*center/Tl)/radius**2
                        assert p0+p1<=T*common
                        counts['common_background_checks']+=1
                        # Verify optimizer against a rational interior grid.
                        for h in range(1,12):
                            z=-alpha+(alpha+beta)*F(h,12)
                            r=min(z+alpha,beta-z)
                            assert common<=(1+z*z/Tl)/r**2
                            counts['quadratic_center_controls']+=1
                        independent=F(0)
                        for dist in [b1,b2]:
                            mu=Th/A**2;x=mu+dist/A
                            anchors={F(0),F(x.numerator//x.denominator)}
                            anchors.update(max(F(0),F(x.numerator//x.denominator)-j)
                                           for j in [F(1,4),F(1,2),F(3,4),F(1)])
                            pbound=min(poisson_upper(Th,A,dist,j)for j in anchors if j<x)
                            independent+=min(1/(dist*dist+Tl),pbound/Tl)
                        assert p0+p1<=T*independent
                        counts['poisson_and_cantelli_checks']+=1
    counts['actual_noise_pairs']+=1

# Three false generalizations must fail.
# 1: overlapping projected events cannot be bounded by one probability.
assert (int(0<=F(1))+int(0>-F(1)))>1
# 2: omitting the finite low-count correction makes the cubic numerator negative.
mu=F(1,100);anchor=F(1)
raw=mu**3+3*(1-anchor)*mu**2+(1-3*anchor+3*anchor**2)*mu-anchor**3
assert raw<0
# 3: an upper-variance proxy is not an actual variance lower bound.
assert moment({F(0):F(1)},2)<F(1,100)
counts['false_claim_controls']=3
print(json.dumps({'status':'PASS_EXACT_ACTUAL_LAW_CONTROLS','counts':dict(counts),
 'scope':'Finite actual-law adversarial tests; continuous proof is low47_new_lemmas.tex.'},indent=2))
