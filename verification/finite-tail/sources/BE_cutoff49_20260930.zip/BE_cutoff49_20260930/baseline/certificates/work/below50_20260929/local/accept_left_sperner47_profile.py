"""Read-only strict acceptance of CONDITIONAL_LEFT_SPERNER47_PROFILE_A."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,copy,sys
from left_sperner47_contract import input_table,config,unique,INPUT_SHA256
from sperner47_kernel import evaluate
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
SOURCES=('left270_input47_table.json','left_sperner47_contract.py','sperner47_kernel.py')
SCHEDULE=((F('.05'),F('.08'),F('.375')),(F('.08'),F('.10'),F('.325')),(F('.10'),None,F('.30')))
def need(x,msg):
 if not x:raise ValueError(msg)
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def reconstruct():
 rows=[];mins={};total=empty=feasible=0
 for row in input_table()['panels']:
  ceiling=F(row['lambda_max']);last=F('.05')
  for bi,(lo,end,amp)in enumerate(SCHEDULE):
   hi=min(end,ceiling)if end is not None else ceiling
   if lo>=hi:continue
   need(lo==last,'Noise cover gap');last=hi
   for sign in(-1,1):
    c=config(row,sign);c.update(amplitude=amp,lower_buffer=amp*F(5,12),upper_buffer=amp*F(7,15),noise_min=lo,maxnoise=hi,lc=16)
    out=evaluate(c);keys=[x[0]for x in out['empty']]+out['feasible'];expected={f'0:{h}:{l}'for h in range(16)for l in range(16)}
    need(len(keys)==len(set(keys))==256 and set(keys)==expected,'Closed H/noise cover mismatch')
    for name,v in out['gates'].items():
     need(type(v)is F and v>0,f'Nonpositive gate {row["index"]}/{bi}/{sign}/{name}: {v}')
     tag=name.split(':')[0];mins[tag]=min(mins.get(tag,v),v)
    encoded=dict(gates={k:str(v)for k,v in out['gates'].items()},empty=out['empty'],feasible=out['feasible'])
    rows.append(dict(index=row['index'],band=bi,sign=sign,noise=[str(lo),str(hi)],amplitude=str(amp),gates=len(out['gates']),excluded=len(out['empty']),feasible=len(out['feasible']),arithmetic_sha256=sha256(canonical(encoded)).hexdigest()))
    total+=len(out['gates']);empty+=len(out['empty']);feasible+=len(out['feasible'])
  need(ceiling<=F('.05')or last==ceiling,'Noise cover incomplete')
 need(len(rows)==180 and empty+feasible==180*256,'Fixed profile coverage mismatch')
 return dict(schema='CONDITIONAL_LEFT_SPERNER47_PROFILE_A_V1',contract=dict(N=47,input_sha256=INPUT_SHA256,range='each panel: .05<=lambda<=Lambda',schedule=[[str(l),str(h)if h is not None else'Lambda',str(a)]for l,h,a in SCHEDULE],H_cells=16,noise_cells=16),rows=rows,gates=total,excluded=empty,feasible=feasible,minimum_reserves={k:str(v)for k,v in mins.items()},source_sha256={s:sha256((HERE/s).read_bytes()).hexdigest()for s in SOURCES})
def validate(o,want):need(same(o,want),'Fixed theorem/source/coverage/arithmetic mismatch')
def controls(want):
 done=[]
 def reject(name,f):
  x=copy.deepcopy(want);f(x)
  try:validate(x,want)
  except ValueError:done.append(name)
  else:raise ValueError('Accepted mutation: '+name)
 reject('missing',lambda x:x.pop('rows'));reject('extra',lambda x:x.update(extra=1));reject('theorem',lambda x:x.update(schema='WRONG'))
 reject('floor',lambda x:x['contract'].update(N=46));reject('schedule_gap',lambda x:x['contract']['schedule'][1].__setitem__(0,'.081'))
 reject('schedule_overlap',lambda x:x['contract']['schedule'][1].__setitem__(0,'.079'));reject('amplitude',lambda x:x['contract']['schedule'][0].__setitem__(2,'.34'))
 reject('missing_row',lambda x:x['rows'].pop());reject('duplicate_row',lambda x:x['rows'].__setitem__(1,x['rows'][0]));reject('order',lambda x:x['rows'].reverse())
 reject('sign',lambda x:x['rows'][0].update(sign=0));reject('cellcover',lambda x:x['rows'][0].update(feasible=0));reject('arithmetic',lambda x:x['rows'][0].update(arithmetic_sha256='0'*64))
 for val in('0','-1',True):reject('gate_'+str(val),lambda x,v=val:x['minimum_reserves'].__setitem__('confinement_lower',v))
 reject('source',lambda x:x['source_sha256'].__setitem__(SOURCES[0],'0'*64))
 try:json.loads('{"x":0,"x":0}',object_pairs_hook=unique)
 except ValueError:done.append('duplicate_key')
 else:raise ValueError('Duplicate key accepted')
 return done
if __name__=='__main__':
 want=reconstruct();raw=(HERE/'left_sperner47_profile_certificate.json').read_bytes();validate(json.loads(raw,object_pairs_hook=unique),want);tests=controls(want)
 print(json.dumps(dict(status='PASS_EXACT_CONDITIONAL_LEFT_SPERNER47_PROFILE_A',rows=len(want['rows']),gates=want['gates'],excluded=want['excluded'],feasible=want['feasible'],controls=tests,minimum_reserves=want['minimum_reserves'],certificate_sha256=sha256(raw).hexdigest(),source_sha256={**want['source_sha256'],'accept_left_sperner47_profile.py':sha256(Path(__file__).read_bytes()).hexdigest()},scope='Conditional additional amplitude schedule on the original left270 acquired interface; strict-gap antichain proof and shared resource; no final local comparison.'),indent=2))
