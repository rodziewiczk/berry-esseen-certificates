# Why shifting the quartic helps

The local comparison conditions on the number of Bernoulli labels. At the nearest count, its noise sum is a centered random variable W. The troublesome term is the probability that W crosses a small threshold u.

The earlier argument bounded P(W>0), then paid separately for moving the normal approximation from zero to u. That loses useful information: if u is negative, the event itself becomes larger. A polynomial lower bound can follow that moving threshold.

Use the quartic

    h_a(x) = (−x⁴ + 3a²x² + 2a³x)/(K a⁴),

where K is slightly larger than (9+6√3)/4. This polynomial is below the indicator of x>0. Applying it to W+r directly bounds P(W>−r); applying it to W−r bounds P(W>r). Expanding the expectation uses only the variance, third moment and fourth moment. Independence and the established bound on each noise variable control those moments explicitly.

The apparently two-variable problem becomes small. Write r=z Var(W). The resulting expression is concave in the variance, so its worst value is at one of two variance endpoints. At each endpoint, a quadratic lower bound handles the remaining quartic in z. Its minimum is checked at two endpoints and one clipped vertex. The finite certificate therefore verifies a continuum statement with rational arithmetic.

This improves both signs of the own-count estimate. Combined with the previously proved Poisson tail comparison, **TINY47A** covers every nearest phase and every positive noise level up to .05, from index47, under the explicit support and moment hypotheses in `tiny47a_proof.tex`. The exact replay checks77 positive gates and24 negative controls. Its five-page proof includes the two probability lemmas and the full comparison.

This is a component of the global argument. It does not settle the larger-noise range or the remaining left-hand probability panels, and it does not itself prove a new global cutoff.
