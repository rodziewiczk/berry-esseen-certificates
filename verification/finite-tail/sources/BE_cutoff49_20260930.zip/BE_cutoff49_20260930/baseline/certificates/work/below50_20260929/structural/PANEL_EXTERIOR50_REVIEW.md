# Independent review of the conditional panel exterior calculation

Status: the analytical contact reduction and selected closed-cell coverage
have been independently checked. The input moment/threshold panel bounds were
rounded from floating discovery and are explicit conditional hypotheses;
this calculation does not acquire them or prove cutoff50.

Read root/panel_exterior.py in full against the already reviewed finite
Gaussian expansion in root/gaussian_exterior40.tex and gaussian_core.py.
Write C=CE+a with 0<=a<=.7/n. The contact is

  0 <= CE Q(t)+phi0*(t³-3t)/6 + a Q(t)
       + finite Gaussian error + rho*(s_n*delta+e_n*C).

On each standardized cell, the two signed cubics in support_cell are valid
upper bounds on the first two terms. All selected beta intervals are positive,
so their CE endpoint choices have the required sign. For the excess term it
is valid to take .7*max(0,max(Q))/47. All other charged terms are nonnegative
and decrease with n>=47, and e_n<.384/n. The current score cap is justified
by CE+.7/47<.40974+.7/47<.425. Positive-part Bernstein bounds for P1--P3,
absolute coefficient bounds for P4--P5, and the absolutely convergent tail
are uniform on each whole closed H,t rectangle.

For p in[pl,pu] subset(0,.5), theta<=thetaU<1,

  ell >= sqrt((1-thetaU)/(pu*(1-pu))).

Therefore Y<=-.55 implies -X>=ell_lower*(.55+pl), while Y>=1.55 implies
X>=ell_lower*(1.55-pu). The code takes the square root downward. It checks
all points from these conservative starts to the prior support endpoints
+/-2.5. Thus it excludes the full Y exterior, including boundary support
points and accumulation points, when every contact upper is strictly negative.

I independently checked the selected result file
root/panel_exterior47_discovery01.json: all47 panels have 0<pl<=pu<.5,
0<=thetaU<1, 0<betaLower<=betaUpper and rhoUpper>=1. Each of both exterior
starts is strictly below2.5; the smallest endpoint slack is
361309773/3125000000. All1503 closed cells join exactly from their prescribed
start to2.5 and have a negative reported contact upper. There is no sample or
index gap in this selected conditional scope.

The generic discovery code skips a side when start>=2.5. Equality would require
a singleton endpoint check if a future scope attained it; the selected scope
has strict positive slack, so this branch is dormant here. The final fixed
acceptance should either retain the selected strict-start guard or explicitly
handle equality. It should also enforce the p/beta sign guards used above.
No remaining analytical defect found in the selected conditional reduction.

## Final fixed conditional component

The frozen root/panel_exterior.py now explicitly enforces the p, beta, rho,
theta and H domains and handles start==2.5 as a singleton cell. I read this
revised constructor, accept_panel_exterior47.py, the fixed hypothesis table
and panel_exterior_proof.tex. The acceptance fixes the entire rational table
by hash, reconstructs both sides and their adjacency, checks exactly1503 cells,
and requires the stronger upper target<-.097. Its four table controls reject
missing, duplicated, reordered or changed hypotheses. A fifth arithmetic
control actually reconstructs the false narrower strip.50 and sees a positive
contact upper on the first row. The current source hashes and five controls
were checked against fresh root_panel_exterior_accept01. The bound remains
conditional on every displayed row hypothesis; it does not acquire them.
