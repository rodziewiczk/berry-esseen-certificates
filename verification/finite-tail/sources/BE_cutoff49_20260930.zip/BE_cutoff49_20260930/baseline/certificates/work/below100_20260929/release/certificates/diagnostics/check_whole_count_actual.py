"""Independent exact actual-law controls for the new global transfer.

This imports neither the new finite kernel nor any historical project code.
It checks identities/inequalities on rational marginals, including collisions;
it is adversarial evidence, not a substitute for the quantified analytic proof.
"""
from fractions import Fraction as Q
from itertools import product
from math import comb, floor
from pathlib import Path
import hashlib,json,sys
if sys.flags.optimize or not __debug__:
    raise RuntimeError('Optimized Python is forbidden')

def conv(a,b):
    out={}
    for x,px in a.items():
        for y,py in b.items(): out[x+y]=out.get(x+y,Q(0))+px*py
    return out

def power(a,n):
    out={Q(0):Q(1)}
    for _ in range(n): out=conv(out,a)
    return out

def cdf(a,x,closed=True):
    return sum((v for y,v in a.items() if y<=x if closed),Q(0)) if closed else sum((v for y,v in a.items() if y<x),Q(0))

def centered_pair(lo,hi):
    if lo==hi==0:return {Q(0):Q(1)}
    lo,hi=Q(lo),Q(hi)
    if not lo<0<hi:raise ValueError('signs')
    return {lo:hi/(hi-lo),hi:-lo/(hi-lo)}

counts={'cdf_identities':0,'closed_collisions':0,'pathwise_marks':0,
        'mean_floor':0,'deletion_marks':0,'binomial_remainders':0,
        'crossing_moment_polynomials':0}
negative={}

# Global binomial envelope, including k=0,n and cutoffs outside0..n.
for n in range(1,31):
    for p in (Q(1,10),Q(2,5),Q(1,2),Q(7,10),Q(9,10)):
        masses=[Q(comb(n,j))*p**j*(1-p)**(n-j) for j in range(n+1)]
        P={Q(j):m for j,m in enumerate(masses)}; top=max(masses)
        for k in range(n+1):
            aa=(n+1)*p-k
            if aa>=2:continue
            for r in range(-n-4,n+5):
                rp=max(r,0); rm=max(-r,0)
                poly=max(aa-1,0)*rp+max(aa,0)*comb(rm,2)+comb(rm,3)
                actual=cdf(P,k+r)-cdf(P,k)-r*masses[k]
                bound=top*poly/((n+1)*p*(1-p))
                if actual>bound:raise ArithmeticError(('global',n,p,k,r,actual,bound))
                counts['binomial_remainders']+=1
                without_rising=top*(max(aa,0)*comb(rm,2)+comb(rm,3))/((n+1)*p*(1-p))
                without_cubic=top*(max(aa-1,0)*rp+max(aa,0)*comb(rm,2))/((n+1)*p*(1-p))
                if actual>without_rising:negative.setdefault('omit_rising',[n,str(p),k,r])
                if actual>without_cubic:negative.setdefault('omit_cubic',[n,str(p),k,r])

# Deterministic moment conversion at every extremal allowed crossing.
for c in (Q(3,5),Q(9,10),Q(1993,2000),Q(1)):
    for u in (Q(j,40) for j in range(-20,21)):
        for j in range(1,101):
            wplus=c*j-u
            if j>wplus*wplus/(c-u)**2:raise ArithmeticError('rising moment')
            wminus=c*j+u
            a2=1/(c+min(u,c/3))**2
            if comb(j+1,2)>a2*wminus*wminus:raise ArithmeticError('second moment')
            if comb(j+1,3)>wminus**3/(2*c-Q(1,2))**3:raise ArithmeticError('third moment')
            counts['crossing_moment_polynomials']+=3

laws=[
    (centered_pair(0,0),centered_pair(0,0)),
    (centered_pair(Q(-1,10),Q(1,10)),centered_pair(0,0)),
    (centered_pair(0,0),centered_pair(Q(-1,100),Q(1,5))),
    (centered_pair(Q(-1,10),Q(1,10)),centered_pair(Q(-1,20),Q(3,20))),
    (centered_pair(Q(-2,5),Q(1,500)),centered_pair(Q(-3,1000),Q(3,10))),
    (centered_pair(Q(-2,5),Q(1,10**6)),centered_pair(0,0)),
]
for law_id,(U0,U1) in enumerate(laws):
    d=max(U0)-min(U1); c=1-d
    if not Q(1,2)<c<=1:raise ValueError('crossing domain')
    pair=[(x,y,px*py) for x,px in U0.items() for y,py in U1.items()]
    vartheta=sum((prob*max(y-x,0) for x,y,prob in pair),Q(0))
    s0=sum((x*x*v for x,v in U0.items()),Q(0));s1=sum((x*x*v for x,v in U1.items()),Q(0))
    for n in (2,3,4):
        paths=[]
        for seq in product(pair,repeat=n):
            probability=Q(1)
            for _,_,prob in seq: probability*=prob
            w=[sum((seq[i][1] if i<j else seq[i][0] for i in range(n)),Q(0)) for j in range(n+1)]
            paths.append((seq,probability,w))
        for p in (Q(1,5),Q(2,5),Q(3,5)):
            mixed={}
            for x,px in U0.items():mixed[x]=mixed.get(x,Q(0))+(1-p)*px
            for x,px in U1.items():mixed[1+x]=mixed.get(1+x,Q(0))+p*px
            actual=power(mixed,n)
            binlaw={Q(j):Q(comb(n,j))*p**j*(1-p)**(n-j) for j in range(n+1)}
            for k in range(1,n):
                phases={Q(-1,2),Q(-1,10),Q(0),Q(1,10),Q(1,2)}
                phases.update(x-k for x in actual if abs(x-k)<=Q(1,2))
                A0=conv(power(U1,k),power(U0,n-k-1))
                A1=conv(power(U1,k-1),power(U0,n-k))
                wkvar=k*s1+(n-k)*s0
                if wkvar!=n*((1-p)*s0+p*s1)+(k-n*p)*(s1-s0):raise ArithmeticError('actual variance')
                if s0!=s1 and k!=n*p:negative.setdefault('equal_variance_shortcut',[law_id,n,str(p),k])
                for u in sorted(phases):
                    x=k+u; expected_cdf=Q(0); ER=Q(0); row=[]
                    for seq,prob,w in paths:
                        if x<w[0]: cutoff=floor(x-w[0])
                        elif x>=n+w[n]:cutoff=floor(x-w[n])
                        else:cutoff=max(j for j in range(n) if j+w[j]<=x)
                        r=cutoff-k
                        expected_cdf+=prob*cdf(binlaw,cutoff); ER+=prob*r
                        row.append((seq,prob,w[k],r))
                    if expected_cdf!=cdf(actual,x):raise ArithmeticError('actual CDF identity')
                    counts['cdf_identities']+=1
                    if x in actual:
                        counts['closed_collisions']+=1
                        if cdf(actual,x)!=cdf(actual,x,False):negative.setdefault('closed_to_strict',[law_id,n,str(p),k,str(u)])
                    for eta in (Q(1,100),Q(1,10),Q(1,2),Q(1)):
                        EZ=Q(0); fractional=Q(0)
                        for seq,prob,wk,r in row:
                            zf=sum((max(seq[k+i-1][0]-seq[k+i-1][1],0) for i in range(1,n-k+1) if wk<=u-c*i),Q(0))
                            zb=sum((max(seq[k-i][1]-seq[k-i][0],0) for i in range(1,k+1) if wk>u+eta+i),Q(0))
                            z=zf+zb; ref=u+eta-wk
                            if r>floor(ref)+z/eta:raise ArithmeticError('pointwise mark')
                            counts['pathwise_marks']+=1;EZ+=prob*z;fractional+=prob*(ref-floor(ref))
                        deleted=vartheta*(sum((cdf(A0,u+Q(49,100)-c*i) for i in range(1,n-k+1)),Q(0))+
                            sum((1-cdf(A1,u+eta+i-Q(49,100)) for i in range(1,k+1)),Q(0)))
                        if EZ>deleted:raise ArithmeticError('deleted mark law')
                        counts['deletion_marks']+=1
                        if ER>u+eta-fractional+deleted/eta:raise ArithmeticError('whole floor mean')
                        counts['mean_floor']+=1

required={'omit_rising','omit_cubic','closed_to_strict','equal_variance_shortcut'}
if set(negative)!=required:raise ArithmeticError(('unexercised negative controls',negative))
print(json.dumps({'status':'PASS_EXACT_ACTUAL_LAW_WHOLE_COUNT_CONTROLS','counts':counts,
    'refuted_shortcuts':negative,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope':'Exact finite-law adversaries and algebra controls; the quantified proof is separate.'},indent=2))
