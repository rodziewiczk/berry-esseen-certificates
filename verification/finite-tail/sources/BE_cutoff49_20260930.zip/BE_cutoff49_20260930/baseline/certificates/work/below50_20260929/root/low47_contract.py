"""Fixed closed-domain contract for central LOW47; no discovery imports."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import sys,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'local'))
from low47_normalization import generate_checked as generate
from confinement47_contract import config
from sperner47_contract import AMPLITUDES
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
SOURCE=HERE.parent/'entry/sperner_feedback47_table.json'
SHA='4a1ea8a439e85e9f481bb6c6eb7a197ec4d35e53ceecf0ec92c3d4c96b9f618a'
def read():
    blob=SOURCE.read_bytes()
    if sha256(blob).hexdigest()!=SHA:raise ValueError('Fixed acquired input table')
    rows=json.loads(blob)['panels']
    if len(rows)!=45:raise ValueError('Complete45 rows')
    for i,z in enumerate(rows):
        if z['index']!=i or list(map(F,z['p']))!=[F('.38')+F(i,500),F('.38')+F(i+1,500)]:raise ValueError('Closed probability cover')
    return rows
def selected(row,sign):
    r=dict(row);r['candidate_amplitude']=r['amplitude']
    base=config(r,sign);base['amplitude']=F(AMPLITUDES[r['index']])
    c=generate({k:v for k,v in base.items()if k!='raw_quads'})
    assert sign in (-1,1) and all(q[2]>0 for q in base['raw_quads'])
    lm=c['maxnoise'];points=sorted(set([F('.05'),lm]+[F(i,400)for i in range(21,int(lm*400)+1)]))
    bands=[];amps=[];rates=[]
    for low,high in zip(points,points[1:]):
        phase=F('.09')if low<F('.06')else F('.13')if low<F('.08')else F('.18')if low<F('.10')else F('.29')if low<F('.12')else F('.5')
        amp=min(c['amplitude'],F('.35')if low<F('.08')else F('.30')if low<F('.10')else F('.275'))
        assert c['d0']<amp and F('.85')*high<1
        assert 0<low<high and 0<phase<=F('.5')
        span=amp+c['d0'];x=F('3.14159')*span
        assert 0<span<F('.5') and 0<x<F('1.571')
        sine=x-x**3/6+x**5/120-x**7/5040
        assert sine>0
        rate=2*sine*sine/span**2
        bands.append((low,high,phase));amps.append(amp);rates.append(rate)
    c.update(N=47,p_cells=1,H_cells=64 if r['index']==0 else 16,
        bands=len(bands),noise_intervals=bands,amplitude_profile=amps,rate_profile=rates,
        phase0=F('.05'),rebate=F(0),repair_normal=c['repair_pos'],raw_quads=base['raw_quads'])
    return c
