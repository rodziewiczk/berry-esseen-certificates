# The missing paired-LOW sign convention and its repair

## Finding

The paired numerical helper uses gl=max(0,L), where L is a valid lower bound
for the actual signed third moment gamma. Some inherited prose describes this
as a lower bound for signed gamma and states0<=gl<=gamma. That implication
is not justified when L<0. A positive p<.5 does not by itself exclude negative
gamma in a noisy law. The new conditional gamma formula also does not fix
this logical issue when its right side is negative. Earlier review bindings
that relied on that prose need the explicit orientation lemma below as an
additional dependency. No failed arithmetic or actual counterexample to the
accepted numerical bounds is asserted.

## Independent orientation lemma

Let f_X(t)=E exp(itX), and let e_X(t)=exp(-nt²/2)(1-in gamma_X t³/6)
be the signed Gaussian comparator. Set

 I0_X(H)=integral_0^.5 |Im[(f_X(t)^n-e_X(t))exp(-iHt)]| dt/t³.

Under X->-X, f and e are conjugated. Therefore, for every real H,

 I0_{-X}(-H)=I0_X(H).

All even moments, absolute moments, support radius and moment upper bounds
are unchanged. With a=(3-mu4)/24, z=(10gamma-EX^5)/120 and c=a gamma/6,
reflection leaves a unchanged and sends(z,c) to(-z,-c). The paired
cancellation norm integral exp(-t²/2)|zt²-ct⁴|dt is invariant under this
simultaneous reflection. Every other term of the signed Gaussian transfer
uses |gamma|,g,absolute moment bounds and |H|. Consequently its complete
triple L0,LH,L2 can be computed in the auxiliary orientation with gamma>=0.
Choose X itself when gamma>=0 and -X when gamma<0. At gamma=0 either
orientation suffices; the rectangle's Z bound covers the possible fifth sign.

If the original law satisfies gamma>=L, then |gamma|>=max(0,L). If several
valid signed lower bounds are available, their maximum with0 is likewise a
lower bound for |gamma|. Thus every currently used gl is valid in the auxiliary
Fourier orientation. The Pearson rectangle, including its lower z and c
bounds, is then applied to the simultaneously oriented coefficients.
The positive-gamma paired assumptions hold in precisely that calculation.

This does NOT reflect the maximizing witness, select the opposite CDF branch,
or change its support/contact equations. The actual beta,K1,J and signed
phase coefficients in general_envelope/late_envelope remain those of the
original law. Only an upper bound for I0_X(H) is transferred back from the
auxiliary law at -H. Since the final estimate is
(L0+LH|H|)/sqrt(n)+L2/n, this transfer is exact for every H and n in scope.

## Source inspection

The inherited full signed Gaussian transfer already explicitly states that
it assumes no signs for a,z,c or gamma, and proves J(-z,-c)=J(z,c).
Its paired specialization omitted saying that its local gamma convention
may use this auxiliary orientation. I reread that proof and its Mills
refinement independently, and checked the current paired helpers return
only lc,lh,l2 and a reflection-invariant rho lower bound. They do not return
or overwrite an actual signed gamma for the outside phase calculation.

The repair is an explicit analytic scope clarification. It changes no gate,
source arithmetic, accepted table or target. It must be attached to every
new broad paired application whose signed gamma positivity was not separately
proved. The selected current refinements are reviewed subject to this added
lemma. Any final manuscript should state it at the generic paired transfer,
then call gl a lower bound for the oriented magnitude, not automatically for
the original signed moment.
