# Active forward marks and a shared remaining sum

Mathematical status: locally derived conditional lemma, independently rederived by the structural reviewer. Execution status: fresh exact finite-product controls; the LOW integration remains discovery only.

Let U0 and U1 be independent centered conditional noises, with U0≤a0 and U1≥−a1, where a0,a1≥0, d=a0+a1<1 and c=1−d. Let A bound both absolute noises. Write Dminus=(U0−U1)+. A selected count-k noise sum has the decomposition Wk=A0+U0, where the remaining sum A0 is independent of the marked pair (U0,U1).

For i≥1, every u, and every outcome with Dminus>0,

    U0>U1≥−a1≥−d,
    Wk≤u−ci  implies  A0<u+d−ci.

Thus, including all endpoint atoms safely,

    E[Dminus 1{Wk≤u−ci}]
      ≤ E[Dminus] P(A0≤u+d−ci).

The reduction from the absolute amplitude A to the inward displacement d is valid only inside the active marked expectation. It is generally false for the unmarked probability.

## Combining the two actual deleted laws

For 1≤k≤n−1 introduce one common centered sum

    Z=(k−1) copies of U1 + (n−k−1) copies of U0.

Take fresh independent conditional noises and represent the two actual deleted laws by

    A0 = Z + fresh U1,
    A1 = Z + fresh U0.

This coupling proves an inequality between their probabilities; it does not replace either deleted law, or assert that the two deleted sums are independent. The new forward event and the usual backward event satisfy

    {A0≤u+d−ci} ⊆ {Z≤u+2d−ci},
    {A1>u+eta+i−A} ⊆ {Z>u+eta+i−A−d},

where eta≥0. Put L=u+2d−ci and R=u+eta+i−A−d. If L<R, their projected events are disjoint. For every fixed z0 in (L,R), with r=min(z0−L,R−z0),

    P(A0≤u+d−ci)+P(A1>u+eta+i−A)
      ≤ P(Z≤L or Z>R)
      ≤ E[(Z−z0)^2]/r^2
      = (Var Z+z0^2)/r^2.

If t=Var Wk, then Var Z=t−Var U0−Var U1≤t. Zero variances and collision atoms are included; the right event remains strict and the left event weak throughout.

## Closed parameter cells

For d≤d0, eta≥0, c0=1−d0 and u∈[ul,uh], one may use

    alpha=c0*i−2d0−uh,
    beta=i−A−d0+ul.

If alpha,beta>0, freeze any rational z0∈(−alpha,beta) and r=min(z0+alpha,beta−z0). Then the pair probability is at most (t+z0²)/r² on the entire cell. If t≤omega*lambda and lambda≥lambda_low>0, division by omega*lambda yields the upper factor

    (1+z0²/(omega*lambda_low))/r².

No numerical optimizer is required: a proposed center is only a witness checked against its two positive distances. The floating discovery uses the midpoint clipped between −t/beta and t/alpha, with t=omega*lambda_low. Strict acceptance must instead store a rational center and verify these inequalities. This bound may be minimized against any independently valid tail bound.

## Controls and limits

`check_active_mark_actual.py` enumerates seven exact actual conditional-law pairs, including zero noise, one deterministic conditional law, a tiny atom, a three-point law, and atom collisions. The fresh run `runs/below50_20260929/local/active_mark_actual01` passed 3,915 marked inequalities, 3,915 projected pair inequalities, 10,789 centered quadratic bounds and 308 collision cases; it found 847 strict improvements over the old mark bound. A negative control explicitly rejects applying the inward replacement to an unmarked tail.

These controls do not certify the complete LOW domain. Acquisition of the probability-panel hypotheses, the normal and cubic-moment comparison, and the remaining phase/noise cover are separate obligations.
