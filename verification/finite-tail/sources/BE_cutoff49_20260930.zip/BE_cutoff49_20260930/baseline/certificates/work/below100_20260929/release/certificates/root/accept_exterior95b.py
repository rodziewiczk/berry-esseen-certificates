"""Fixed conditional exterior95B at n>=95, T=.75,d_n<=.19.

Analytic premises and transports are in gaussian_exterior95b.tex. This does
not assert the existence of an earlier anchor or establish a cutoff.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json,hashlib,sys
assert __debug__ and not sys.flags.optimize

def add(*ps):
    q=[F(0)]*max(map(len,ps))
    for p in ps:
        for j,c in enumerate(p):q[j]+=c
    return q
def scale(p,c):return [x*c for x in p]
def mul(p,q):
    r=[F(0)]*(len(p)+len(q)-1)
    for j,c in enumerate(p):
        for k,d in enumerate(q):r[j+k]+=c*d
    return r
def bern(p,l,r):
    n=len(p)-1
    a=[sum(p[j]*comb(j,k)*l**(j-k)*(r-l)**k for j in range(k,n+1))for k in range(n+1)]
    return [sum(a[k]*F(comb(i,k),comb(n,k))for k in range(i+1))for i in range(n+1)]

def build():
    v=[0,1,-1];bb=[1,-2,2];skew=[1,-2];c=F('1.56')
    Nb=add(scale(bb,F('3.162277660')),[-1,2],scale(v,-6))
    assert max(bern(Nb,F('.35'),F('.48')))<F('.06')
    assert F('1.26')-6*c*F('.06')>0
    cells=[]
    for sign in [-1,1]:
      for K in [F('6.162277660'),F('6.162277661')]:
        u=[F('1.49'),-1]if sign==1 else[F('.49'),1]
        P=add(scale(mul(mul(u,u),u),-K+sign),scale(mul(bb,mul(u,u)),F('1.5')*K),
              mul(mul(add(scale(skew,3*K*sign),[-3*sign]),v),u))
        E=add(scale(P,F('-.3988')),scale(mul(v,Nb),6*c),scale(v,F('-1.26')))
        for j in range(26):
            l=F('.35')+F(j,200);r=l+F(1,200)
            coefficients=bern(E,l,r)
            assert min(coefficients)>F('.006'),('binary',sign,str(l))
            cells.append(dict(sign=sign,K=str(K),interval=list(map(str,[l,r])),coefficients=list(map(str,coefficients))))
    # Whole rays: P',P'' strictly negative at every boundary.
    for m,ul,uh,T in [(F('5.16'),F('1.01'),F('1.14'),(3*F('6.17')*F('.3')-3)/4),
                      (F('7.16'),F('.84'),F('.97'),F('.75'))]:
        assert -6*m*ul+3*F('6.17')*F('.545')<0
        assert -3*m*ul*ul+3*F('6.17')*F('.545')*uh+T<0
    # Same-law transport, retaining the negative sqrt(s)*theta*rho_B term.
    assert F('1.363')**2>F(13,7)
    assert F('.9957')**2<1-F('.0085')
    price=F('1.5')*F('.40974')*F('2.4')**2*(2*F('1.363')+F('2.4')-F('.9957'))+F('2.4')*(3*F('.40974')+F('.2'))+F('.63')
    assert price<F('18.683')<c*F('12.321')
    # INPUT95B supplies A>.73,B>1.02,theta<=.0085,D<=.117.
    # First prove D_B<=D using the tangent and positive variance coefficient.
    K=min(3*F('4.16')*F('1.02'),3*F('6.16')*F('.73'))
    assert K-F('1.5')*F('.117')/(1-F('1.5')*F('.0085'))>0
    assert K-F('1.5')*F('.117')>F('12.321')
    # Initial inward gap d<.012, before any concentration or confinement.
    assert F('.4749')**2<(1-F('.0085'))*F('.35')*F('.65')
    assert F('1.9977')**2*F('.46')*F('.54')<1-F('.0085')
    assert 6*F('.4749')*F('1.75')*F('1.9977')*F('.012')>F('.117')
    # One common B2 budget, with a nonnegative actual leakage.
    ef=1-F('1.5')**2/(2*95)
    assert F('.4095')*ef/2>F('.202')
    assert F('.3988')*ef/6>F('.065')
    assert 24*F('.065')==c
    completed=F('.5')+F('.09')/(4*(24*F('.202')-F('.2')))
    assert completed<F('.51')
    reserve=F('.42')-(24*F('.75')+F('.51'))/95-F('1.16')*F('.19')
    assert reserve>F('.0047')
    # A deliberately excessive decrement does not satisfy the closing gate.
    assert F('.42')-(24*F('.75')+F('.51'))/95-F('1.16')*F('.2')<0
    return dict(version='CONDITIONAL_EXTERIOR95_B_V1',floor=95,binary_cells=cells,
        variance_price=str(price),completed_square=str(completed),reserve=str(reserve),
        hypotheses=dict(support=['-1.85','2.4'],p=['.35','.46'],theta='.0085',D='.117',A='.73',B='1.02',
             beta=['.075','.3'],rho='1.14',cap='.418',H='1.15',decrement='.19',T='.75',
             joint='D >= D_B + 12.321 theta',contact='DIRECT_GAUSSIAN95',budget='same-law B2'),
        conclusion='Full transformed support Y belongs to(-.49,1.49).')

if __name__=='__main__':
    assert len(sys.argv)==1
    obj=build()
    print(json.dumps(dict(status='PASS_CONDITIONAL_EXTERIOR95_B',proof=obj,
         negative_controls=['decrement_.2_fails_closing_gate'],
         source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         scope='Conditional analytic transport, Gaussian contact and actual common budget required. No cutoff inferred.'),indent=2))
