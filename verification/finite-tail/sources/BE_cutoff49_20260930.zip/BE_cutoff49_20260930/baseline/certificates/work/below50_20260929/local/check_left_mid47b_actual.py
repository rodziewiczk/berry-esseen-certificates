"""Independent actual-law and directed-rounding controls for LEFT_MID47_B."""
from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path
from hashlib import sha256
import json,sys
from left_mid47b_kernel import own,tail_bennett,input_table
from tiny47a_kernel import bennett as original_bennett
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
def two(a,b):
 a,b=F(a),F(b);return {-a:b/(a+b),b:a/(a+b)}
def conv(a,b):
 d=defaultdict(F)
 for x,px in a.items():
  for y,py in b.items():d[x+y]+=px*py
 return dict(d)
laws=[two('.375','.375'),two('.375','.001'),two('.001','.375'),two('.3','.1'),two('.1','.3'),two('.325',F(1,10**10)),{F('-.3'):F('1/4'),F(0):F('1/2'),F('.3'):F('1/4')}]
checks=collisions=0;c={'derivative_lo':F('.8'),'derivative_hi':F('1.2')}
for law in laws:
 assert sum(law.values())==1 and sum(x*m for x,m in law.items())==0
 A=max(abs(x)for x in law);dist={F(0):F(1)}
 for count in range(1,5):
  dist=conv(dist,law);t=sum(x*x*m for x,m in dist.items());tl=F('.9')*t;th=F('1.1')*t
  points={F('.09'),F('.14'),F('.19'),F('.29'),F('.499')};points.update(abs(x)for x in dist if F('.09')<=abs(x)<=F('.499'))
  for l in sorted(points):
   h=min(F('.5'),l+F('.001'))
   for sign in(-1,1):
    sigma=1 if sign<0 else -1;b=-c['derivative_hi']if sign<0 else c['derivative_lo']
    for choice in(0,10,20,30,40,55,56 if sign<0 else 57):
     lower=own(choice,sign,l,h,tl,th,A,c)
     for r in(l,(l+h)/2,h):
      actual=sum(m for x,m in dist.items()if x+sigma*r>0)+b*r
      assert lower<=actual;checks+=1;collisions+=(-sigma*r in dist)
rounding=0
for A in map(F,('.2','.3','.375')):
 for V in map(F,('.03','.1')):
  for b in map(F,('.5','1.2')):
   assert tail_bennett(A,V,b)>=original_bennett(A,V,b);rounding+=1
seams=0
for r in input_table()['panels']:
 for x in map(F,('.05','.06','.08','.10')):
  assert F(r['lambda_max'])!=x;seams+=1
print(json.dumps(dict(status='PASS_EXACT_LEFT_MID47_B_CONTROLS',laws=len(laws),actual_inequalities=checks,collision_checks=collisions,directed_Bennett_controls=rounding,singleton_controls=seams,source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),scope='Finite semantic controls, not a substitute for the uniform analytic proof.'),indent=2))
