#!/usr/bin/env python3
"""Fixed exact 10-pass persistent-cell proof of conditional INPUT95.

Inputs: n>=95, supported witness, |X|<=5/2, C<=.41719,
raw R<.77 and D<.12. Radius acquisition is a separate lemma.
Every p cell retains its own raw and defect ceilings; rounding is outward.
"""
import sys,json,copy
from fractions import Fraction as F
import kernel as k
CONTRACT=dict(name='INPUT95',n=95,radius='5/2',cap='41719/100000',raw='77/100',defect='3/25',cells=192,passes=10)
def ceil(x):return k.up(x,10**6)+F(1,10**6)
def need(c,s):
 if not c:raise ValueError(s)
def verify(contract,emit=False):
 need(type(contract)is dict and contract==CONTRACT,'fixed INPUT95 contract')
 for a in('n','cells','passes'):need(type(contract[a])is int,'integer INPUT95 parameter')
 n,R,cap,raw,d,count=95,F('2.5'),F('.41719'),F('.77'),F('.12'),192
 k.RADIUS=R;k.K4=(R+1)**2/(R+F(1,2));k.K5=(R**3+2*R**2+3*R+F(3,2))/(R+F(1,2));k.constants()
 geom=k.general_geometry(d);pl,pu=geom['pl'],geom['pu'];cells=[]
 for i in range(count):cells.append(dict(lo=pl+(pu-pl)*F(i,count),hi=pl+(pu-pl)*F(i+1,count),R=raw,D=d))
 visited=0;exclusions=0
 for stage in range(10):
  for z in cells:
   if z.get('excluded'):continue
   oldR,oldD=z['R'],z['D'];p=k.general_cell(oldD,z['lo'],z['hi'],k.general_geometry(oldD));visited+=1
   if p is None:z['excluded']=True;exclusions+=1;continue
   rows=k.late_envelope(n,oldD,oldR,p,cap);rmin=k.paired(n,p,oldD)[3];efloor=1-F(5,2)*oldR/n;rr=max(t[3]for t in rows);bb=F(-1)
   need(len(rows)==4 and efloor>0,'four complete corners')
   for (A,ff,qq,_,_),rho in zip(rows,(rmin,p['Rho'],rmin,p['Rho'])):
    extra=efloor*(F('.4095')*rho-oldD/15)/2;need(extra>0,'positive phase rebate');qq+=extra
    bb=max(bb,A+ff*ff/(4*qq))
   z['R']=min(oldR,ceil(rr));z['D']=min(oldD,ceil(15000*bb/(997*n)))
  if emit:print('INPUT95 pass',stage+1,'active',sum(not z.get('excluded',False)for z in cells),flush=True)
 active=[];mom=[];H=F(0);AA=F(-1);FF=F(-1);QQ=F(100)
 for z in cells:
  if z.get('excluded'):continue
  p=k.general_cell(z['D'],z['lo'],z['hi'],k.general_geometry(z['D']))
  if p is None:z['excluded']=True;exclusions+=1;continue
  rows=k.late_envelope(n,z['D'],z['R'],p,cap);rmin=k.paired(n,p,z['D'])[3];efloor=1-F(5,2)*z['R']/n
  for (A,ff,qq,_,_),rho in zip(rows,(rmin,p['Rho'],rmin,p['Rho'])):
   AA=max(AA,A);FF=max(FF,ff);QQ=min(QQ,qq);q=qq+efloor*(F('.4095')*rho-z['D']/15)/2
   H=max(H,(ff+k.roots(ff*ff+4*q*A)[1])/(2*q))
  active.append(z);mom.append(p)
 need(len(active)+exclusions==192 and active,'complete persistent cover')
 bounds=dict(R=max(z['R']for z in active),D=max(z['D']for z in active),H=H,p_lower=min(z['lo']for z in active),p_upper=max(z['hi']for z in active),rho=max(p['Rho']for p in mom),beta_upper=max(p['Beta']for p in mom),beta_lower=min(1-2*p['pu']-2*(1-p['pu'])*p['theta']for p in mom),theta=max(p['theta']for p in mom),A=min(p['al']for p in mom),B=min(p['bl']for p in mom),mu4=max(p['M']for p in mom),gamma=max(p['g']for p in mom),quad_A=AA,quad_F=FF,quad_Q=QQ)
 upper=dict(R=F('.75'),D=F('.117'),H=F('1.15'),p_upper=F('.46'),rho=F('1.14'),beta_upper=F('.3'),theta=F('.0085'),quad_A=F('.68963'),quad_F=F('.30513'))
 lower=dict(p_lower=F('.35'),beta_lower=F('.075'),A=F('.73'),B=F('1.02'),quad_Q=F('.44494'))
 for a,b in upper.items():need(bounds[a]<b,'INPUT95 upper '+a)
 for a,b in lower.items():need(bounds[a]>b,'INPUT95 lower '+a)
 return dict(status='FRESH_PASS',name='INPUT95',visited_cells=visited,active_cells=len(active),excluded_cells=exclusions,passes=10,bounds={a:str(x)for a,x in bounds.items()})
def controls():
 rows=[]
 for a in CONTRACT:
  z=copy.deepcopy(CONTRACT);z.pop(a);rows.append(z)
 for a,v in [('n',94),('radius','2'),('cap','.41719'),('raw','3/4'),('defect','3/25 '),('cells',191),('passes',9),('name','INPUT94')]:
  z=copy.deepcopy(CONTRACT);z[a]=v;rows.append(z)
 for z in rows:
  try:verify(z)
  except ValueError:pass
  else:raise ValueError('malformed INPUT95 contract accepted')
 return len(rows)
if __name__=='__main__':
 need(not sys.flags.optimize,'optimized Python forbidden');result=verify(CONTRACT,True);result['malformed_controls']=controls();print(json.dumps(result,sort_keys=True),flush=True)
