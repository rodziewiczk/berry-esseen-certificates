"""Exact fixed-point interval kernel for finite Bernoulli score reserves.

Discovery and acceptance scripts separately choose domains. All interval
operations round outwards using integers; binomial probabilities are exact.
"""
from fractions import Fraction as F
from math import isqrt,comb,factorial
from functools import lru_cache
S=10**15
class I:
    __slots__=('lo','hi')
    def __init__(self,lo,hi=None):
        if isinstance(lo,I):self.lo,self.hi=lo.lo,lo.hi;return
        a=F(lo);b=F(lo if hi is None else hi)
        assert a<=b
        self.lo=a.numerator*S//a.denominator
        self.hi=-((-b.numerator*S)//b.denominator)
    @staticmethod
    def raw(l,h):
        assert type(l)is int and type(h)is int and l<=h
        z=object.__new__(I);z.lo=l;z.hi=h;return z
    def __add__(a,b):
        b=I(b);return I.raw(a.lo+b.lo,a.hi+b.hi)
    __radd__=__add__
    def __neg__(a):return I.raw(-a.hi,-a.lo)
    def __sub__(a,b):return a+-I(b)
    def __rsub__(a,b):return I(b)+-a
    def __mul__(a,b):
        b=I(b);v=[a.lo*b.lo,a.lo*b.hi,a.hi*b.lo,a.hi*b.hi]
        return I.raw(min(v)//S,-((-max(v))//S))
    __rmul__=__mul__
    def __truediv__(a,b):
        b=I(b);assert b.lo>0
        return a*I.raw(S*S//b.hi,-((-S*S)//b.lo))
    def __rtruediv__(a,b):return I(b)/a
    def sqrt(a):
        assert a.lo>=0
        l=isqrt(a.lo*S);h=isqrt(a.hi*S)
        if h*h<a.hi*S:h+=1
        return I.raw(l,h)
    def square(a):
        lo=0 if a.lo<=0<=a.hi else min(a.lo*a.lo,a.hi*a.hi)
        hi=max(a.lo*a.lo,a.hi*a.hi)
        return I.raw(lo//S,-((-hi)//S))
    def power(a,k):
        assert type(k)is int and k>=0
        z=I(1)
        for _ in range(k):z=z*a
        return z
    def fraction_lower(a):return F(a.lo,S)
    def fraction_upper(a):return F(a.hi,S)

PHI=I('0.398942280401432','0.398942280401433')
CE=I('0.409732183702394','0.409732183702399')
def constants():
    def atan_bounds(q,k):
        s=sum((F((-1)**j,(2*j+1)*q**(2*j+1))for j in range(k+1)),F(0))
        t=s+F((-1)**(k+1),(2*k+3)*q**(2*k+3))
        return min(s,t),max(s,t)
    a,b=atan_bounds(5,24);c,d=atan_bounds(239,6)
    pl,pu=16*a-4*d,16*b-4*c
    assert 2*pu*PHI.fraction_lower()**2<1<2*pl*PHI.fraction_upper()**2
    sl=F('3.162277660168379');su=F('3.162277660168380')
    assert sl*sl<10<su*su
    assert (3+sl)*PHI.fraction_lower()/6>CE.fraction_lower()
    assert (3+su)*PHI.fraction_upper()/6<CE.fraction_upper()
    # Machin's angle identity and positive branch, independently exact.
    t=F(1,5);t=2*t/(1-t*t);t=2*t/(1-t*t)
    assert (t-F(1,239))/(1+t/239)==1
    return dict(pi_lower=str(pl),pi_upper=str(pu))

def exp_negative(x):
    """Alternating exponential enclosure, 0<=x<=1/2."""
    x=I(x);assert 0<=x.lo<=x.hi<=S//2
    term=I(1);s=term
    for j in range(1,16):
        term=term*x/j
        s=s+term if j%2==0 else s-term
        if j==14:upper=s.hi
    return I.raw(s.lo,upper)

def cdf_point(z):
    assert type(z)is int and abs(z)<=S
    if z<0:return I(1)-cdf_point(-z)
    x=I.raw(z,z);xx=x.square()/2;term=x;s=term
    for j in range(1,16):
        term=term*xx/j
        piece=term/(2*j+1)
        s=s+piece if j%2==0 else s-piece
        if j==14:upper=s.hi
    return I(F(1,2))+PHI*I.raw(s.lo,upper)
def cdf(z):
    return I.raw(cdf_point(z.lo).lo,cdf_point(z.hi).hi)
def density(z):return PHI*exp_negative(z.square()/2)

@lru_cache(maxsize=100000)
def binomial(n,k,p):
    """Exact integer numerator for the closed CDF and pmf at rationalp."""
    p=F(p);a,b=p.numerator,p.denominator-p.numerator;den=p.denominator**n
    assert 0<a and 0<b and 0<=k<n
    aa=[1];bb=[1]
    for _ in range(n):aa.append(aa[-1]*a);bb.append(bb[-1]*b)
    numer=sum(comb(n,j)*aa[j]*bb[n-j]for j in range(k+1))
    pm=comb(n,k)*aa[k]*bb[n-k]
    return I(F(numer,den)),I(F(pm,den))

def score_point(n,k,p):
    x=I(p);v=x*(1-x);z=(I(k)-n*x)/(n*v).sqrt()
    B=binomial(n,k,F(p))[0]-cdf(z)
    return (n*v).sqrt()/(1-2*v)*B

def score_cell(n,k,lo,hi):
    """Mean value theorem with rigorous derivative enclosure on oneclosedcell."""
    assert 0<lo<=hi<F(1,2)and 0<=k<n
    x=I(lo,hi);v=I(lo*(1-lo),hi*(1-hi));q=1-x;vp=1-2*x;b=1-2*v
    zl=(I(k)-n*I(hi))/(n*I(hi*(1-hi))).sqrt()
    zu=(I(k)-n*I(lo))/(n*I(lo*(1-lo))).sqrt()
    z=I.raw(zl.lo,zu.hi);assert abs(z.lo)<=S and abs(z.hi)<=S
    fl,ml=binomial(n,k,lo);fh,mh=binomial(n,k,hi)
    pmlo=min(ml.lo,mh.lo);pmhi=max(ml.hi,mh.hi)
    mode=F(k,n)
    if lo<=mode<=hi:pmhi=max(pmhi,binomial(n,k,mode)[1].hi)
    pm=I.raw(pmlo,pmhi)
    B=I.raw(fh.lo,fl.hi)-cdf(z)
    A=(n*v).sqrt()/b
    deriv=A*(-(n-k)*pm/q+density(z)*(I(n).sqrt()/v.sqrt()+z*vp/(2*v))+vp*(1/(2*v)+2/b)*B)
    middle=(lo+hi)/2;point=score_point(n,k,middle)
    m=max(abs(deriv.lo),abs(deriv.hi))
    error=I(F(m,S))*I((hi-lo)/2)
    result=I.raw(point.lo-error.hi,point.hi+error.hi)
    return result,deriv

if __name__=='__main__':
    import json
    print(json.dumps(constants()))
