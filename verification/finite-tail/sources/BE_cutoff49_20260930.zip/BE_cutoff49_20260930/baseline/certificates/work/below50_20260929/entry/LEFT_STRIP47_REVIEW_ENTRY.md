# Independent review of the acquired left exterior strip

Mathematical status: independently derived and checked; no defect found in
the stated contact-exclusion scope. Execution status: fresh PASS in
`runs/below50_20260929/entry/left_strip47_independent01`.

Reviewed the full `root/left_strip47_proof.tex`,
`root/accept_left_strip47.py`, `root/panel_exterior.py`, the polynomial
construction and Bernstein transformation in `root/gaussian_core.py`,
and the finite Gaussian expansion in `root/gaussian_exterior40.tex`.
The acquired source is exactly `entry/left270_input47_table.json`, SHA256
`4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a`.

## Independent mathematical checks

For p in[l,u] below1/2, pq<=u(1-u), so the actual scale obeys
ell>=sqrt((1-Theta)/(u(1-u))). The checker rounds this square root down.
The exact coordinate X=ell(Y-p) implies:

- Y<=-.55 requires X<=-ell_lower(l+.55);
- Y>=1.55 requires X>=ell_lower(1.55-u).

Every possible remaining exterior support point lies between one of
these conservative thresholds and the acquired radius2.7. When a threshold
exceeds2.7 there is no point to check. Equality is explicitly retained as
a singleton, so boundary atoms and support accumulation points are covered.

Write C=C_E+a, 0<=a<=.7/n. The contact polynomial is
Q(t)=-|t|^3+1.5 rho t^2+3 beta t. For t>=0, the leading contact term is
bounded by the implemented cubic

  (1/15-.4095)t^3 +1.5(.40974)rhoU t^2
  +(3(.40974)betaU-.3988/2)t.

For t=-x<=0 its upper cubic is

  (-.3988/6-.4095)x^3 +1.5(.40974)rhoU x^2
  +(.2-3(.4095)betaL)x.

The source checks betaL>=0 before using these endpoints. The positive-part
upper bound for Q licenses a Q<=.7*max(0,Qupper)/47. The current-score
cap is valid independently of deleted-law scores, since
.40974+.7/47<.425.

The Gaussian expansion is uniform for any finite row h and cell radius:
its absolutely convergent majorant uses only |H|<=h,|t|<=R and n>=4.
Thus substituting the current row's h (possibly above1.15) and radius2.7
is justified by that proof; it does not invoke the narrower numerical
Gaussian40 conclusion. P1--P3 use whole-rectangle Bernstein upper bounds
clipped at zero, P4--P5 use absolute coefficient sums, and the tail is a
positive absolute series bound. Every charged term decreases for n>=47.
The scale correction e_n<.384/n holds already for n>=36. These facts give
exactly support_cell's full rational upper bound on the contact expression.

The tensor Bernstein transform is the standard affine monomial expansion
followed by power-to-Bernstein coefficients binom(k,i)/binom(d,i), in each
variable. Its maximum bounds the polynomial throughout the closed box;
no sampling or endpoint-convexity shortcut is used.

## Coverage and fresh arithmetic

The immutable input contains38 adjacent closed p cells covering[.304,.38].
All have0<l<u<1/2, 0<=Theta<1,1<=rhoU<1.85,0<=betaL<=betaU<1,
and both signed raw-threshold ceilings below2. The larger absolute ceiling
covers both phase signs. Each exterior interval is subdivided into
floor(80*width)+1 equal closed pieces, so the pieces join exactly and
have width at most1/80, including singleton intervals.

The fresh replay checks3073 cells, all with negative contact upper bounds;
the maximum is strictly below-.01658. Gate digest:
`ee820b348e12dc97bcabae028593f3cbb8a530f87d0a0e92c5e57f94107ed20b`.
Four changed-input controls reject missing, duplicated, reordered or
altered tables. The fifth reconstructs a genuinely unsupported smaller
strip and rejects on its arithmetic bound.

Conclusion: under the acquired LEFT270 inputs, attained positive closed
contact, n>=47,0<=a<=.7/n and decrement<=.19, the full actual support of Y
is contained in(-.55,1.55). No Bernoulli comparison is used to prove this
strip. This is not by itself the left local comparison or cutoff50.
