"""Independent exact actual-sum controls for the MID own-count interval bound."""
from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path
from hashlib import sha256
import sys,json
from mid47a_kernel import own
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
def two(a,b):
 a,b=F(a),F(b)
 return {-a:b/(a+b),b:a/(a+b)}
def conv(a,b):
 d=defaultdict(F)
 for x,px in a.items():
  for y,py in b.items():d[x+y]+=px*py
 return dict(d)
laws=[two('.35','.35'),two('.35','.001'),two('.001','.35'),two('.275','.1'),two('.1','.275'),two('.3',F(1,10**10)),{F('-.3'):F('1/4'),F(0):F('1/2'),F('.3'):F('1/4')}]
checks=collisions=0
for law in laws:
 assert sum(law.values())==1 and sum(x*m for x,m in law.items())==0
 A=max(abs(x)for x in law);dist={F(0):F(1)}
 for count in range(1,5):
  dist=conv(dist,law);t=sum(x*x*m for x,m in dist.items());tl=F('.9')*t;th=F('1.1')*t
  points={F('.09'),F('.13'),F('.18'),F('.29'),F('.499')}
  points.update(abs(x)for x in dist if F('.09')<=abs(x)<=F('.499'))
  for lo in sorted(points):
   hi=min(F('.5'),lo+F('.001'))
   for sign,b in[(1,F('-1.10127')),(-1,F('.89873'))]:
    lower,_=own(sign,lo,hi,tl,th,A,b)
    for r in(lo,(lo+hi)/2,hi):
     actual=sum(m for x,m in dist.items()if x+sign*r>0)+b*r
     assert lower<=actual;checks+=1;collisions+=(-sign*r in dist)
# Concavity identity on exact positive parameters; no finite test replaces proof.
identities=0
for a in(F('.3'),F('.5'),F(1)):
 for t0,t1 in[(F('.01'),F('.07')),(F('.1'),F('.13'))]:
  for z in(F(0),F('1/3'),F('2/3'),F(1)):
   K=F(9)/(4*F('.4641'));den=K*a**4;A=F('.35');r=F('.2')
   def f(t):return(-A*A*t-3*t*t-4*r*A*t-6*r*r*t-r**4+3*a*a*(t+r*r)+2*a**3*r)/den
   assert f((1-z)*t0+z*t1)-(1-z)*f(t0)-z*f(t1)==3*z*(1-z)*(t1-t0)**2/den;identities+=1
print(json.dumps(dict(status='PASS_EXACT_MID47_ACTUAL_CONTROLS',laws=len(laws),probability_inequalities=checks,collision_checks=collisions,concavity_identities=identities,source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),scope='Finite controls of the own-count shifted quartic across complete closed intervals; no extremizer or global cutoff claim.'),indent=2))
