#!/usr/bin/env python3
"""Independent exact implementation of MOMENT50 signed moment lemmas.

The analytic proof is moment50.tex. Actual-law tests below are adversarial
checks, not a substitute for that proof. No cutoff or optimizer is assumed.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json


def require(p, why):
    if not p:
        raise ValueError(why)


def positive(x):
    return max(F(0), x)


def bounds(R, rho, beta, gamma, steps=64):
    """Outward rational bounds on a full closed moment box.

    excluded means every law in this box violates an explicitly necessary
    inequality. Singular localizing matrices are retained by dropping their
    nonnegative correction; zero denominators never imply exclusion alone.
    """
    require(isinstance(R, F) and R >= 1, 'rational radius >= 1')
    require(type(steps) is int and 1 <= steps <= 256, 'bisection steps')
    for cell in (rho, beta, gamma):
        require(type(cell) in (tuple, list) and len(cell) == 2, 'closed interval')
        require(all(isinstance(x, F) for x in cell) and cell[0] <= cell[1], 'ordered rational endpoints')
    rl, ru = rho
    bl, bu = beta
    gl, gu = gamma
    require(rl >= 1 and -1 < bl <= bu < 1, 'standardized moment domain')
    al = [(1+bl)/2, (1-bu)/2]
    au = [(1+bu)/2, (1-bl)/2]
    cl = [positive((rl+gl)/2), positive((rl-gu)/2)]
    cu = [(ru+gu)/2, (ru-gl)/2]
    if min(cu) <= 0:
        return {'status': 'excluded', 'reason': 'positive sign second moment needs positive sign third moment'}
    Du = [R*a-c for a,c in zip(au,cl)]
    if min(Du) < 0:
        return {'status': 'excluded', 'reason': 'negative upper support deficit'}
    beta_abs_lo = F(0) if bl <= 0 <= bu else min(abs(bl),abs(bu))
    ml = max((1+beta_abs_lo**2)/(2*ru), *(a*a/c for a,c in zip(al,cu)))
    mh = F(1,2)
    if ml > mh:
        return {'status': 'excluded', 'reason': 'inconsistent common first moment'}
    def fmean(m):
        return 2*m + sum(positive(R*m-a)**2/d for a,d in zip(au,Du) if d > 0)
    if fmean(ml) > R:
        return {'status': 'excluded', 'reason': 'sign probabilities exceed one'}
    if fmean(mh) > R:
        lo = ml
        for _ in range(steps):
            mid = (lo+mh)/2
            if fmean(mid) > R:
                mh = mid
            else:
                lo = mid
    Dl = [positive(R*a-c) for a,c in zip(al,cu)]
    den = [R*mh-a for a in al]
    if min(den) < 0 or any(z == 0 and d > 0 for z,d in zip(den,Dl)):
        return {'status': 'excluded', 'reason': 'inconsistent first support deficit'}
    corrections = [d*d/z if z > 0 else F(0) for d,z in zip(Dl,den)]
    c4 = [R*c-e for c,e in zip(cu,corrections)]
    M = R*ru-sum(corrections)
    if min(c4) < 0 or M < rl*rl:
        return {'status': 'excluded', 'reason': 'fourth moment violates nonnegativity or Cauchy'}
    e5 = [positive(R*c-v)**2/d if d > 0 else F(0) for c,v,d in zip(cl,c4,Du)]
    eta = R*M-sum(e5)
    products = [r*b for r in rho for b in beta]
    dp = positive(gl-max(products))
    dm = positive(min(products)-gu)
    penalty = positive(rl+gl)*dp*dp/(8*(1+bu)**2) + positive(rl-gu)*dm*dm/(8*(1-bl)**2)
    return dict(status='bounded', m_lower=ml, m_upper=mh, fourth_upper=M,
                fifth_upper=eta, sign_fourth_upper=c4, signed_penalty_lower=penalty,
                signed_constant_upper=ru**3/4-penalty,
                singular_support_terms=sum(d == 0 for d in Du),
                singular_first_terms=sum(d == 0 for d in den))


def merge_law(law):
    mass = {}
    for x,p in law:
        mass[x] = mass.get(x,F(0))+p
    return [(x,p) for x,p in sorted(mass.items()) if p]


def binary(t):
    require(t > 0, 'positive binary parameter')
    return [(t,1/(1+t*t)),(-1/t,t*t/(1+t*t))]


def mix(a,b,w):
    return merge_law([(x,p*w) for x,p in a]+[(x,p*(1-w)) for x,p in b])


def moment_record(law):
    require(all(p > 0 for x,p in law) and sum(p for x,p in law) == 1, 'probability law')
    require(sum(x*p for x,p in law) == 0 and sum(x*x*p for x,p in law) == 1, 'mean zero variance one')
    rho = sum(abs(x)**3*p for x,p in law)
    beta = sum(x*abs(x)*p for x,p in law)
    gamma = sum(x**3*p for x,p in law)
    M = sum(x**4*p for x,p in law)
    eta = sum(abs(x)**5*p for x,p in law)
    m = sum(positive(x)*p for x,p in law)
    return max(abs(x) for x,p in law),rho,beta,gamma,M,eta,m


def verify_law(law, widen):
    R,r,b,g,M,e,m = moment_record(law)
    eps = min(F(1,10**6),(1-abs(b))/4) if widen else F(0)
    out = bounds(R,(max(F(1),r-eps),r+eps),(b-eps,b+eps),(g-eps,g+eps))
    require(out['status'] == 'bounded', 'actual law incorrectly excluded')
    require(out['m_lower'] <= m <= out['m_upper'], 'actual first moment')
    require(M <= out['fourth_upper'], 'actual fourth moment')
    require(e <= out['fifth_upper'], 'actual fifth moment')
    require(r*M/2-e/4 <= out['signed_constant_upper'], 'actual signed constant')
    return out


def check():
    checks = 0
    def ck(p,why):
        nonlocal checks
        require(p,why)
        checks += 1
    R=F('3.84'); r=F('1.84'); b=F('.62'); g=F('1.60')
    point=bounds(R,(r,r),(b,b),(g,g))
    ck(point['status']=='bounded','point not excluded')
    ck(point['m_upper'] < F('.386166800630'),'point first moment target')
    ck(point['fourth_upper'] < F('3.905131080'),'point fourth target')
    ck(point['fifth_upper'] < F('8.923502410'),'point fifth target')
    ck(point['signed_penalty_lower'] > F('.03454953'),'point signed penalty')
    # Feasible three-point law at the illustrative moment triple: root-free
    # positivity and recurrence checks for its two negative magnitudes.
    x=F(172,81); pp=F(531441,2958400); qq=1-pp; mm=F(6561,17200)
    aa=F(19,100); bb=F(3,25); det=qq*aa-mm*mm
    ss=F(384108,153275); tt=F(143104,153275)
    ck(det==F(6131,591680) and det>0,'example Hankel determinant')
    ck(ss==(qq*bb-aa*mm)/det and tt==(mm*bb-aa*aa)/det,'example recurrence coefficients')
    ck(ss>0 and tt>0 and (mm/qq)**2-ss*mm/qq+tt<0,'two positive roots and positive weights')
    ck(max(ss,x)<R,'example support')
    ck(pp*x==mm and pp*x*x==F('.81') and pp*x**3==F('1.72'),'example positive moments')
    ck(ss*mm-tt*qq==aa and ss*aa-tt*mm==bb,'example negative moments')
    laws = [binary(F(1)), binary(F(3,2)), binary(F(2)), binary(F(3)),
            [(F(-2),F(1,8)),(F(0),F(3,4)),(F(2),F(1,8))],
            mix(binary(F(1)),binary(F(2)),F(1,3)),
            mix(binary(F(3,2)),binary(F(2,3)),F(2,5)),
            mix(binary(F(1)),binary(F(1000)),1-F(1,10**18)),
            mix(binary(F(1)),binary(F(1000)),F(1,10**18)),
            mix(binary(F(1)),binary(F(1)),F(1,2))]
    actual_count=0
    for law in laws:
        for reflection in (1,-1):
            for widen in (False,True):
                verify_law([(reflection*x,p)for x,p in law],widen)
                actual_count+=1
    # The exact singular branches must survive, including atoms at zero.
    for law in (laws[0],laws[4]):
        out=verify_law(law,False)
        ck(out['singular_support_terms']==2,'both singular sign matrices retained')
    invalid = [lambda: bounds(R,(r,r-1),(b,b),(g,g)),
               lambda: bounds(R,(r,r),(F(-1),b),(g,g)),
               lambda: bounds(F('.9'),(r,r),(b,b),(g,g)),
               lambda: bounds(R,(r,r),(b,b),(g,g),0),
               lambda: bounds(3.84,(r,r),(b,b),(g,g)),
               lambda: bounds(R,(r,),(b,b),(g,g))]
    for call in invalid:
        try: call()
        except ValueError: checks+=1
        else: raise ValueError('malformed input accepted')
    impossible=bounds(F(1),(F(2),F(2)),(F(0),F(0)),(F(0),F(0)))
    ck(impossible['status']=='excluded','impossible support moment rejected')
    # Corrupt a derived claim, ensuring comparisons are strict and operative.
    ck(not (point['fourth_upper'] < F('3.8')),'false fourth target rejected')
    ck(not (point['fifth_upper'] < F('8.9')),'false fifth target rejected')
    return dict(schema='MOMENT50_LEMMAS_EXAMPLES_V1', mathematical_status='locally derived analytic lemma with independent rational examples; no cutoff claim',
                execution_status='fresh PASS',actual_law_tests=actual_count,checks_and_controls=checks,
                point={k:str(v) if isinstance(v,F) else [str(x)for x in v] if isinstance(v,list) else v for k,v in point.items()},
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())


if __name__=='__main__':
    print(json.dumps(check(),indent=2))
