# Current checkpoint: acquired entry and central LOW47 (29 September 2026)

The user target remains cutoff50. Completed global theorem remains cutoff98 until full left local comparison closes. Latest delivered archive remains preserved99.

- Acquired full probability cover [.304,.47]: entry/left270_input47_table.json (38 cells, SHA4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a) plus central45 cells. Complete acquisition chain and independent bindings: entry/ENTRY47_DAG.md, structural/LEFT270_INPUT47_BINDING.json, SIGNED_RESOURCE47_BINDING.json. Fourier-only |gamma| orientation omission repaired explicitly in entry/paired_fourier_orientation47.tex and structural/PAIRED_ORIENTATION47_BINDING.json; no arithmetic changed.
- Central local input selected for LOW is entry/sperner_feedback47_table.json SHA4a1ea8a439e85e9f481bb6c6eb7a197ec4d35e53ceecf0ec92c3d4c96b9f618a. It is weaker than final signed-resource input but already acquired and independently bound.
- Accepted SPERNER47A reduces amplitudes to [.375,...,.200] using biased antichain concentration. SPERNER47_PROFILE_A adds all-index amplitudes .35 on lambda .05-.08, .30 on .08-.10, .275 above.10. Scope must take MIN(global amplitude, noise profile). Final files/freezes in local/, independent binding in structural/.
- Accepted TINY47A covers all central p and lambda<=.05/all phases. MID47A covers complementary phases on lambda bands .05-.06/.06-.08/.08-.10/.10-.12, with radii .09/.13/.18/.29; 7901 gates/26 controls. Both independently reviewed/bound.
- Central LOW floating selected full45 table passes except two firstpanel negative-H endpoints. Both close by exact finite mass atn47..49, but simpler chosen route is Hgrid64 on panel0 (16 onothers), which passes alln>=47. New rational root/low47_kernel.py + construct_low47.py running root_low47_construct01; firstpanel exact worst-.004571, panel1 -.002289. Uses exact Poisson full cubic moment+finite correction, no truncated floating tails. Final independent review and checked normalization pending; not yet fixed accepted. No finite-index exception needed.
- Root LEFT_STRIP47 fresh strict PASS: root/accept_left_strip47.py, runs/below50_20260929/root_left_strip47_accept01,3073closedcells/5controls,worstupper<-.01658. Actual acquired left270 rows + priorR2.7 -> Ystrip(-.55,1.55). Proof root/left_strip47_proof.tex, independent entry review pending. Local now building complete left confinement/comparison on this acquired strip.
- Local diagnostic all38 left270 confinement passes, maxamp.375. Unified TINY diagnostic p[.304,.47],H1.393,theta.0154,d.0181,amp.425,lambda<=.05 hasreserve>.0289; strict acceptance underway. Left noise profiles/MID/LOW still open.
- Root finite-left-Bernoulli exact reserve construction root/left_binary_reserves47.py running root_left_binary47_construct01. Range47..98,p.304..38,|k-np|<=1.25. This may pay positive LOW remainders; no noisy theorem until integrated.
- Root is responsible for strict central LOW object and new proof. Entry agent owns root/low47_normalization.py plus left-strip review; audit agent independently derives LOW analytic replacements; local agent owns left local closure.

---

# Later checkpoint: exact support47 and finite-count attempt

Completed new global result remains cutoff98, with .7/n ceiling from45. Target50 is unproved.

- root/accept_support47.py: fresh PASS root_support47_accept02, 1080 central radius cells +1431 shared-strip cells,6 rejection controls. Conditional initial moment rows imply R3.84->R2.5; conditional canonical45 rows imply fullYstrip(-.55,1.55). Independent structural/SUPPORT47_BINDING.json.
- structural/accept_heat47_central234.py: fresh PASS2120gates,44closedintervals+bothwhole rays,8controls. For alln>=47, attainedcontact,C>=CE,rho<=1.15,absbeta<=.252,decrement<=.19 -> actualR2.34, no H/priorR/upperC assumption. Contains all45 canonical local rows. Root independently checked proof+kernel and bound review in HEAT234_ANALYTIC_REVIEW.json.
- root/count_phase_reserve.py: exact integer-count feasibility and binary reserve on joint(p,H,u,theta) cells. Fresh180coordinate controls plus singleton. Examples eliminate many relaxed cells but this is no noisy-law theorem.
- root/probe_finite_low_cells.py: combines unaccepted floating LOW inputs with exact finite phase/binary bounds; atn47..50 eliminates11956 cells and bounds5358, but7862diagnosticcells remainpositive. Alltestedp>=.402close; p.4..402fivefails; p.38..392stilllarge residual~.44–.47. See finite_low_cells_diagnostic01.json. This is an upper-bound failure, not a counterexample.
- New entry exact INITIAL47 uses HIGH improvements on BOTH actual-event branches; previous floating signedinitializer leftoldHIGH in gap branch. New raw<1.885,nD<47*.590,rho<1.421,absbeta<.490,H<1.781 expected; acceptance stillrunning. Full100closedp-panelcover[0,1]. Root readcompleteacceptor+delta; auditorreviewactive.
- Local canonical_input47.json:45 conditionalp-panels[.38,.47], rational1e-4 upper/lowerbounds andfour coherent signed budgetquadratics. All45confinementdiagnostics pass withp-dependentamplitude. Fixedacceptance/hypothesisacquisitionstillbeingprepared.
- Leftcomplementp.302..38 remains afterR2.7 contraction; maxlambda~.18. Entry fallbackN55/60/65 underway while47exactinitializer runs. Localattempt noise-dependentamplitudes toreduceLOWlossatsmalllambda.
- Explicit weightedvariance obligation sententry: neednTheta<=NTheta, not justtheta<=Theta,toexportuniformlambda. UsesweightednD andnonnegativebinarycharge. This is separate fromconditionaltablevalidity.

Latestrootresearchnote12pages build06/gaussian_exterior40.pdf; newpages8–12visuallyinspected, pages1–7sameaspreviousinspectedbuild04. No overflow. Finalshortlastpage remainslayoutcleanup, PDFnotyetdelivered. Old129preservationfiles intact atlastcheckpoint.

---

# Cutoff-50 research: new ceiling45 and cutoff98 (29 September 2026)

The new locally derived and independently reviewed ceiling is a_n<.7/n for every n>=45. Fixed ANCHOR45 and PROP46 exact covers freshly pass 221,184 and 239,616 cells. The unrestricted composition is written in work/below50_20260929/root/ceiling45_and_cutoff98.tex. It also yields cutoff98 by acquiring old LOCAL95's three score caps at95; scalar/dependency checks freshly pass. The selected delivered archive remains the preserved99 package until a new deliverable is assembled. Cutoff50 remains open.

Other fresh conditional results: Gaussian40/Exterior40, Exterior45's narrower strip, TINY45C, amplitude-free DIRECT45A, and exact finite-Bernoulli reserve1/4000 on n40..98,p.35..46,central counts. Do not infer acquired entry/local47 from these pieces.

# New global dependency path (29 September 2026)

Prior complete99 proof remains independent. Finite caps/contact + fifth-order support + ANCHOR40/propagation41..98 + prior99tail -> a_n<1.5/n from40. This licenses anchor45 owncap.4431 and decrement.8341. New supportR3.5 + signed ANCHOR45 excludes a45>=.7/45. At first subsequent failure46..98, predecessor smoothing recurrence supplies cap.432, decrement<=.7/45, supportR3.5; signed PROP46 excludes. Prior99tail closes infinity -> a_n<.7/n from45. New ceiling licenses oldENTRY95 owncap.41719 and all three LOCAL95 caps.418 already at95. Four losses95..98 contradict a94<.7/94 -> cutoff98.

Cutoff50 still requires unrestricted entry and full local exclusion at47..50. Its scalar four-loss reserve is positive but is not a substitute for those missing nodes. root/ceiling45_dependencies.json binds254 source/evidence files, seven existing fresh execution logs; root_ceiling45_composition02 freshly checks seams and integrity only, explicitly not fresh replay of dependencies.

# Active cutoff-50 actions (29 September 2026)

1. Entry agent: exact signed entry near47, improved HIGH peak window and small-frequency integral, p-dependent localization and support contraction.
2. Local agent: restricted-half-line contact slope for confinement, joint deleted intervals, common-background paired mark tails; close actual acquired parameter interfaces.
3. Root: retain completed ceiling45/cutoff98 composition, independently read all new proofs, update readable PDF and exact artifact evidence. Current fixed composition command: python3 -B work/below50_20260929/root/accept_ceiling45_composition.py.
4. Audit agent: review current signed entry refinements and global source binding; no floating discovery becomes a theorem.

---

Historical research checkpoints below:

# Active cutoff-50 attempt (29 September 2026)

No unrestricted cutoff below99 has been established in this attempt.
The completed99release and all129mappedfiles are preserved.

| New component | Mathematical status | Execution status |
|---|---|---|
| Fifth-order all-H support and R3.84 from36 at decrement.19 | Derived by structural worker; coordinator independently rederived expansion, signs, band endpoints, ray coverage | Three fixed suites freshPASS:89,188gates,21negativecontrols |
| HIGH rational integral bound | Independently derived by coordinator and reviewed by structural worker | Entry fixed acceptance freshPASS; see entry logs |
| Unrestricted ceiling a_n<1.5/n from40 | Anchor40, complete finite propagation41..98, and independent completed99tail composed; independent full review pending | FreshPASS1280entrycells, supportseams,11newnegativecontrols; anchorcontrols14 previouslypassed |
| Gaussian40 and exterior40 | Coordinator-derived conditional theorems; independent review pending | FreshPASS76outer/90inner Gaussiancells and104binarycells;3false-targetcontrols |
| Centered signed deletion | Coordinator independently derived factor1/2; absolute-noise version remains unchanged | Actual-law controls freshPASS |
| Cubic Poisson comparison and quartic sign bound | Independent mathematical derivations checked; conditional local construction in progress | TINY45B discovery positive; fixed acceptance pending |
| Full entry/local chain near45 | Open | Exploratory signedmoment covers only |
| Cutoff50 | Not established | No assembled acceptance |

## Precise Gaussian/exterior scope

For n>=40, C in[CE,.45], predecessor decrement<=.4, attained contact,
prior support[-4.1,4.1], rho<=1.14,beta in[.075,.3],|H|<=1.15,
Gaussian40 gives actual support(-1.9,2.5) and
0<L_P+(.2H^2+.3|H|+.46)/n+2a+1.155*decrement.
Adding the same-law Fourier budget R<.75,D<=.117,theta<=.0085,
p in[.35,.46],central endpoints A>=.73,B>=1.02 gives fullYstrip(-.6,1.6)
and inwardgapd<.012. All of these inputs remain hypotheses until entry closes.
Sources:root/{accept_gaussian40.py,accept_exterior40.py,gaussian_core.py,
gaussian_exterior40.tex};5-pagePDF inroot/build/. All5pages visually reviewed.
Logs:runs/below50_20260929/root_{gaussian_accept01,exterior_accept01,compile01}/.

## Current routes and missing links

1. Anchor at40 from highscore support + ANCHOR40 + universal excesscap.
2. Propagate ceiling1.5/n over41..98 in three finite bands;99tail alreadyproved.
   Root experiment:root/propagation/discover_propagation40.py;logroot_propagation_discovery01.
3. Unrestricted signed entry:entry/signed_initial_discovery.py. Keep joint
   rho,beta,gamma,m and bounded-support moment constraints. No floatPASS theorem.
4. Full local comparison:local/; improvedcenteredsigneddeletion, Poisson tails,
   quartic signbound; oldtupleTINY45B appearspositive, fullnoise stillopen.
5. Four losses>.4 at47..50 exceed1.5/46 exactly, but this scalar alone proves nothing.

## Next runnable checks

Replay root acceptances with python -B; finish propagation discovery and freeze
fixed contracts only after its support/entry seams pass. Independently review
root proof and new signedmoment lemmas. Keep all support/phase/noise scopes explicit.

## New finite-Bernoulli reserve route

Strict binary domination is stronger than needed. Root exact interval kernel
root/bernoulli_reserve.py computes C_B^+(k) and parameter derivative bounds from
integer binomial probabilities and alternating Gaussian series. Discovery
root/discover_bernoulli_reserve.py covers n40..98,p.35–.46,|k−np|≤1.1.
First run rejected an overly tight chosen CE enclosure; fixed outward bounds
are separately checked from Machin/squared constants. No sampled positivity.
Entry now finds skew, almostbinary cells whose D is mostly binary asymmetry;
per-p noise bounds may replace the old uniform smallD entry requirement.

## Further accepted steps and corrected defect

- root/propagation/accept_ceiling40.py gives a_n<1.5/n from40 via
  ANCHOR40,41..49,50..69,70..98,and prior99tail. BothPython3.12/3.9freshPASS,
  1280entrycells+fullsupportseams+11negativecontrols. Proofpropagation/ceiling40.tex.
- ExactfiniteBernoulli theorem: root/accept_bernoulli_reserve40_98.py,
  n40..98,p.35..46,|k−np|≤1.1,positiveclosedCDF score<CE−1/4000.
  FreshPASS28851cellsincluding4singletonboundaries,8controls. Independent
  derivative/interval/coverage reviewstructural/BERNOULLI50_REVIEW.md.
- Initial Bernoullidiscovery skipped singleton count intersections; repaired
  before fixedacceptance. score_cell interval lowerendpoint nowsubtracts
  meanvalueerror; itsupperendpoint and acceptedreserveunchanged.
- root/support_from_moments.py: conditional N45,R3.84,rho1.456,beta±.498,
  H1.84,cap.4473,slow.19 contractsfullsupporttoR3.2;freshPASS. Inputsnotacquired.
- Newone-steprecursion root/predecessor_score_cap.tex suppliescurrentcap.432
  at firstfailureof.7ceiling from46. ScalarfreshPASS; independentreviewpending.
- TINY45B newderivativegatehadextra factort in denominator. This was areal
  gateerror, not a claimedcutoffdefect. PreserveB; use repaired TINY45C only,
  local/TINY45C_FREEZE.json. Oldcutoff99 correspondingderivativewas correct.
- EntryANCHOR45_K.7 closesfloatingdiscovery andconditionalexactpairedpasses;
  signedinitializerisbeingrationalized. Noaccepted.7ceilingfrom45yet.
- Rootoldunsignedpropagation.7 onlycloses80..98; earlierbandsstalled.
  Earlygeneraltransition atD≤.7 failed its probabilitydomain gate.
- Newfar-skewroute bylocalagent: p.25..26,noiseλ≤.015,n45..98 canbe
  excludedby directCantelli/binomialcomparison withoutsupport/amplitude.
  Exactdiscoverypasses; strictacceptance/proofbeingfrozen.
