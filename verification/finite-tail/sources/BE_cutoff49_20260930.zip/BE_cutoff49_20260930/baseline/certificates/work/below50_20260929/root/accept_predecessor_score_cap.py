"""Exact scalar consequences of the proved one-step smoothing recurrence."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import hashlib,json,sys
assert __debug__ and not sys.flags.optimize
def rootup(x):
    den=10**12;v=isqrt(x.numerator*den*den//x.denominator)+1
    out=F(v,den);assert out*out>x;return out
def cap(N,K):
    # Direct rational upper square roots; do not cube an inward root.
    return rootup(F(N,N-1))*(F('.40974')+K/(N-1))+rootup(F(N,(N-1)**3))/15+F('.08')*rootup(F(N))/(N-1)**2
def main():
    assert len(sys.argv)==1
    rows=[]
    for N in [42,45,46,47,50,60,80]:
        c=cap(N,F('.7'));upper=F(-((-c.numerator*10**6)//c.denominator),10**6)
        rows.append(dict(n_floor=N,predecessor_barrier='7/10',current_cap=str(upper),computed_upper=str(c)))
    assert cap(46,F('.7'))<F('.432')
    assert cap(46,F('.7'))>F('.431')
    # Fourier derivative bound: ||phi'''||<=2/pi<.64 sincepi>25/8.
    assert F(333,106)>F(25,8)and F(2,1)/F(333,106)<F('.64')
    # For y=z²>=1, max(y−1)e^(−y/2)=2e^(−3/2)<1.
    assert sum((F(3,2)**j/F([1,1,2,6][j])for j in range(4)),F(0))>2
    print(json.dumps(dict(status='PASS_PREDECESSOR_SCORE_CAP',rows=rows,
       theorem='C_n <= sqrt(n/(n−1))*C_(n−1) +sqrt(n)/(15*(n−1)^(3/2)) +.08*sqrt(n)/(n−1)^2, for every integern>=2.',
       consequence='At a first failure of the .7/n barrier at an index n>=46, the predecessor still satisfies a_(n−1)<.7/(n−1), and current C_n<.432.',
       negative_controls=['false derived target.431 rejected'],
       source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       scope='Scalar validation only; the independent analytic recurrence proof is in predecessor_score_cap.tex.'),indent=2))
if __name__=='__main__':main()
