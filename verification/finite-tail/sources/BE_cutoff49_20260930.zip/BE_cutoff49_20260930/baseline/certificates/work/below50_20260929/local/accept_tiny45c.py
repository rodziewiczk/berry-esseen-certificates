"""Read-only acceptance for the fixed full-phase CONDITIONAL_TINY45_C."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,copy,sys
from tiny45c_kernel import evaluate,poisson_cubic
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
def need(b,s):
 if not b:raise ValueError(s)
def unique(rows):
 d={}
 for k,v in rows:need(k not in d,'Duplicate JSON key');d[k]=v
 return d
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def reconstruct():
 o=evaluate();need(not o['bad'],'nonpositive gates');need(all(F(v)>0 for v in o['gates'].values()),'strict rational gates')
 o['source_sha256']={n:sha256((HERE/n).read_bytes()).hexdigest()for n in ('tiny45c_kernel.py','tiny45c_normalization.py')}
 return o
def validate(o,want):need(same(o,want),'Fixed theorem, coverage, arithmetic or source mismatch')
def controls(want):
 tests=[]
 def reject(name,change):
  o=copy.deepcopy(want);change(o)
  try:validate(o,want)
  except ValueError:tests.append(name)
  else:raise ValueError('Mutation accepted: '+name)
 reject('missing_field',lambda o:o.pop('gates'))
 reject('extra_field',lambda o:o.update(extra=True))
 reject('theorem_label',lambda o:o.update(schema='CONDITIONAL_TINY44_B_V1'))
 reject('lower_index',lambda o:o['contract'].update(N='44'))
 reject('higher_noise',lambda o:o['contract'].update(lmax='17/500'))
 reject('higher_amplitude',lambda o:o['contract'].update(amplitude='41/100'))
 reject('missing_phase',lambda o:o['rows'].pop())
 reject('duplicate_phase',lambda o:o['rows'].__setitem__(1,o['rows'][0]))
 reject('reordered_phases',lambda o:o['rows'].reverse())
 reject('changed_anchor',lambda o:o['rows'][0].update(anchor='0'))
 reject('changed_tail',lambda o:o['rows'][0].update(first='0'))
 reject('changed_own_bound',lambda o:o['own'].update(negative='1'))
 reject('missing_gate',lambda o:o['gates'].pop(next(iter(o['gates']))))
 reject('zero_gate',lambda o:o['gates'].__setitem__(next(iter(o['gates'])),'0'))
 reject('negative_gate',lambda o:o['gates'].__setitem__(next(iter(o['gates'])),'-1'))
 reject('boolean_gate',lambda o:o['gates'].__setitem__(next(iter(o['gates'])),True))
 reject('changed_source',lambda o:o['source_sha256'].update({'tiny45c_kernel.py':'0'*64}))
 try:json.loads('{"schema":1,"schema":1}',object_pairs_hook=unique)
 except ValueError:tests.append('duplicate_JSON_key')
 else:raise ValueError('Duplicate JSON accepted')
 for name,args in [('negative_variance',(F(-1),F(1),F(2))),('zero_denominator',(F(1),F(2),F(2))),('negative_anchor',(F(1),F(-1),F(2)))]:
  try:poisson_cubic(*args)
  except ValueError:tests.append(name)
  else:raise ValueError('Invalid Poisson domain accepted')
 return tests
if __name__=='__main__':
 want=reconstruct();raw=(HERE/'tiny45c_certificate.json').read_bytes()
 validate(json.loads(raw,object_pairs_hook=unique),want);negative=controls(want)
 print(json.dumps(dict(status='PASS_EXACT_CONDITIONAL_TINY45_C',gates=len(want['gates']),phase_cells=6,
  negative_controls=len(negative),mutation_names=negative,minimum_score_reserve=min(float(F(r['reserve']))for r in want['rows']),
  exact_reserves={r['name']:r['reserve']for r in want['rows']},certificate_sha256=sha256(raw).hexdigest(),
  source_sha256={**want['source_sha256'],'accept_tiny45c.py':sha256(Path(__file__).read_bytes()).hexdigest()},
  scope='n>=45; p=.35..46, |H|<=1.15, theta<=.0085, inward d<=.012, |U|<=.4, every 0<lambda<=.033 and every phase. Conditional normalization/actual-law comparison only; no acquisition or new global cutoff.'),indent=2))
