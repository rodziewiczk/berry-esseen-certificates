"""Independent exact seam check. Selected theorem validity and acquisition remain dependencies."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import sys,json,copy
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
BASE=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(BASE/'root'),str(BASE/'local')]
import low47_contract as central_low
import phase_left_low47_contract as left_low
import positive_left_low47_contract as positive_low
from tiny47wide_normalization import CFG as TINY
from mid47a_normalization import CFG as CMID
from mid47a_kernel import REGIONS as CREGIONS
from left_mid47b_kernel import contexts as left_mid_contexts
from sperner47_contract import AMPLITUDES as CAMPS
from left_sperner47_contract import AMPLITUDES as LAMPS
SOURCE_FILES=['entry/sperner_feedback47_table.json','entry/left270_input47_table.json','local/conditional_input47.json','local/left270_input47_table.json','local/sperner47_contract.py','local/left_sperner47_contract.py','local/accept_sperner47_profile.py','local/accept_left_sperner47_profile.py','local/tiny47wide_normalization.py','local/tiny47wide_certificate.json','local/mid47a_normalization.py','local/mid47a_kernel.py','local/mid47a_certificate.json','local/left_mid47_normalization.py','local/left_mid47b_normalization.json','local/left_mid47b_kernel.py','local/left_mid47b_certificate.json','root/low47_contract.py','root/phase_left_low47_contract.py','root/positive_left_low47_contract.py','root/low47_kernel.py','root/phase_left_low47_kernel.py','root/positive_left_low47_kernel.py','root/low47_constructed02.json','root/phase_left_low47_constructed01.json','root/positive_left_low47_constructed02.json','root/accept_low47.py','root/accept_phase_left_low47.py','root/accept_positive_left_low47.py']
def need(ok,msg):
 if not ok:raise ValueError(msg)
def unique(rows):
 d={}
 for k,v in rows:need(k not in d,'Duplicate JSON key');d[k]=v
 return d
def read(path):return json.loads((BASE/path).read_text(),object_pairs_hook=unique)
def componentwise():
 old=read('local/conditional_input47.json')['panels'];new=central_low.read();checks=0
 for a,b in zip(old,new):
  need(a['index']==b['index']and list(map(F,a['p']))==list(map(F,b['p'])),'Same central p panel')
  for k in('T','D','theta','d0','H_minus','H_plus','rho','beta_hi','lambda_max'):
   need(F(b[k])<=F(a[k]),'Central feedback must strengthen scalar ceiling '+k);checks+=1
  for k in('beta_lo','A_lo','B_lo'):
   need(F(b[k])>=F(a[k]),'Central feedback must strengthen scalar lower bound '+k);checks+=1
  need(F(b['amplitude'])<=F(CAMPS[b['index']]),'Feedback acquired amplitude');checks+=1
 need((BASE/'entry/left270_input47_table.json').read_bytes()==(BASE/'local/left270_input47_table.json').read_bytes(),'Left acquired input exact equality')
 return checks

def atoms(points):
 p=sorted(set(points));return sorted(set(p+[(a+b)/2 for a,b in zip(p,p[1:])]))
def rect(lo,hi,ul,uh,name):
 need(lo<=hi and F('-.5')<=ul<=uh<=F('.5'),'Rectangle domain');return(lo,hi,ul,uh,name)
def prove_cover(rectangles,ceiling):
 need(ceiling>0,'Positive acquired ceiling')
 for l,h,a,b,_ in rectangles:need(0<=l<=h<=ceiling and F('-.5')<=a<=b<=F('.5'),'Rectangle outside law domain')
 ls=atoms([F(0),ceiling]+[z for r in rectangles for z in r[:2]])
 us=atoms([F('-.5'),F('.5')]+[z for r in rectangles for z in r[2:4]])
 checks=0
 for l in ls:
  for u in us:
   need(any(a<=l<=b and c<=u<=d for a,b,c,d,_ in rectangles),f'Uncovered exact cell representative lambda={l},u={u}')
   checks+=1
 return checks

def available_amp(side,index,lam):
 base=F((CAMPS if side=='central'else LAMPS)[index]);vals=[base]
 profile=((F('.05'),F('.08'),F('.35')if side=='central'else F('.375')),(F('.08'),F('.10'),F('.30')if side=='central'else F('.325')),(F('.10'),None,F('.275')if side=='central'else F('.30')))
 for lo,hi,a in profile:
  if lam>=lo and(hi is None or lam<=hi):vals.append(a)
 return min(vals)
def license_amplitude(side,index,lo,hi,A):
 pts=atoms([lo,hi]+[z for z in map(F,('.05','.08','.10'))if lo<=z<=hi])
 need(all(available_amp(side,index,x)<=A for x in pts),'Amplitude premise is not acquired throughout closed noise cell')

def inspect_low_object(path,contract_module,minimum,outer,positive=False):
 d=read(path);rows=contract_module.read();expected=[(r['index'],s)for r in rows if F(r['lambda_max'])>minimum for s in(-1,1)]
 need([(r['index'],r['sign'])for r in d['rows']]==expected,'LOW ordered row/sign coverage')
 entirely=0;total=0
 for z in d['rows']:
  c=contract_module.selected(rows[z['index']],z['sign']);proof=z['proof'];report=z['report'];pc=int(c['p_cells']);hc=int(c['H_cells']);nc=len(c['noise_intervals']);oc=int(c['outer_phase_cells'])if outer else 1
  expected_cells=pc*hc*nc*oc;need(report['feasible_cells']+report['empty_cells']==expected_cells,'LOW closed-box count')
  need(report['endpoints']==2*report['feasible_cells'],'LOW both noise endpoints')
  need(not report['failed_gates'],'LOW negative gate')
  need(proof['contract']['N']==47 and list(map(F,proof['contract']['p']))==[c['pl'],c['pu']],'LOW floor and p interface')
  scalar={k:str(v)for k,v in c.items()if type(v)in(int,F)}
  need(proof['contract']['constants']==scalar,'LOW complete scalar contract matches selected source')
  if report['feasible_cells']==0:entirely+=1;need(report['worst_score']=='None' and report['worst_score_decimal'] is None,'Empty row score must remain unavailable')
  else:need(F(report['worst_score'])<F('-.001'),'LOW strict score target')
  total+=expected_cells
 return dict(rows=len(d['rows']),boxes=total,entirely_budget_excluded_rows=entirely)

def run():
 monotone=componentwise();records=[];phasechecks=0;mid_by_index={}
 for index,bi,lo,hi,start,A,steps,sign,c,ng in left_mid_contexts():mid_by_index.setdefault(index,[]).append((bi,lo,hi,start,A,sign))
 for side,rows,amps in(('left',left_low.read(),LAMPS),('central',central_low.read(),CAMPS)):
  need(len(rows)==(38 if side=='left' else 45),'Complete probability range')
  for row in rows:
   i=row['index'];pl,pu=map(F,row['p']);ceiling=F(row['lambda_max'])
   need(TINY['N']==47 and TINY['pl']<=pl<=pu<=TINY['pu'],'Wide tiny p/index')
   for k in('theta','d0'):need(F(row[k])<=TINY[k],'Wide tiny '+k)
   need(max(F(row['H_minus']),F(row['H_plus']))<=TINY['H']and F(amps[i])<=TINY['amplitude'],'Wide tiny H/amplitude')
   rr=[rect(F(0),min(F('.05'),ceiling),F('-.5'),F('.5'),'Bernoulli at0; TINY atpositive lambda')]
   if ceiling>F('.05'):
    module=central_low if side=='central'else left_low
    for hs in(-1,1):
     c=module.selected(row,hs);need(c['N']==47,'LOW floor')
     for (lo,hi,a),A in zip(c['noise_intervals'],c['amplitude_profile']):
      license_amplitude(side,i,lo,hi,A)
      if hs==-1:rr.append(rect(lo,hi,-a,a,side+' LOW'))
    if side=='central':
     need(CMID['pl']<=pl<=pu<=CMID['pu'],'Central MID p')
     for k in('theta','d0'):need(F(row[k])<=CMID[k],'Central MID '+k)
     need(max(F(row['H_minus']),F(row['H_plus']))<=CMID['H'],'Central MID H')
     for lo,end,a,A in CREGIONS:
      hi=min(end,ceiling)
      if lo>hi:continue
      license_amplitude(side,i,lo,hi,A);rr +=[rect(lo,hi,-F('.5'),-a,'central MID'),rect(lo,hi,a,F('.5'),'central MID')]
    else:
     for bi,lo,hi,a,A,sgn in mid_by_index.get(i,[]):
      license_amplitude(side,i,lo,hi,A);rr.append(rect(lo,hi,-F('.5')if sgn<0 else a,-a if sgn<0 else F('.5'),'left MID'))
     if ceiling>F('.10'):
      for hs in(-1,1):
       c=positive_low.selected(row,hs);need(c['N']==47,'Positive LOW floor')
       for (lo,hi,a),A in zip(c['noise_intervals'],c['amplitude_profile']):
        need(a==F('.5'),'Positive phase ceiling');license_amplitude(side,i,lo,hi,A)
        if hs==-1:rr.append(rect(lo,hi,F('.29'),F('.5'),'positive left LOW'))
   n=prove_cover(rr,ceiling);phasechecks+=n;records.append(dict(side=side,index=i,p=row['p'],lambda_max=str(ceiling),rectangles=len(rr),partition_checks=n))
 need(len(records)==83,'All83 p cells')
 need(F(records[37]['p'][1])==F(records[38]['p'][0])==F('.38'),'Shared p seam')
 low={name:inspect_low_object(path,module,minimum,outer)for name,path,module,minimum,outer in[
  ('central','root/low47_constructed02.json',central_low,F('.05'),False),('left','root/phase_left_low47_constructed01.json',left_low,F('.05'),True),('positive_left','root/positive_left_low47_constructed02.json',positive_low,F('.10'),True)]}
 # Independent coverage controls: defects in rectangles must be detected.
 controls=[];base=[rect(F(0),F('.05'),F('-.5'),F('.5'),'tiny'),rect(F('.05'),F('.1'),F('-.5'),F(0),'neg'),rect(F('.05'),F('.1'),F(0),F('.5'),'pos')]
 for name,broken in [('missing_positive',base[:-1]),('noise_gap',[base[0],rect(F('.051'),F('.1'),F('-.5'),F('.5'),'late')]),('phase_gap',[base[0],base[1],rect(F('.05'),F('.1'),F('.001'),F('.5'),'pos')]),('missing_upper_endpoint',[base[0],rect(F('.05'),F('.099'),F('-.5'),F('.5'),'short')])]:
  try:prove_cover(broken,F('.1'))
  except ValueError:controls.append(name)
  else:raise ValueError('Accepted coverage mutation '+name)
 return dict(status='PASS_EXACT_SELECTED_LOCAL47_COVERAGE',mathematical_scope='Conditional composition of the selected acquired tables, amplitude bounds, and local comparison theorems; their analytic proofs and arithmetic acceptance are separate dependencies.',index_scope='Local comparisons hold for n>=47. Global descent uses47..98 and prior99 tail. At lambda=0, exact Bernoulli law and cited finite-n Bernoulli theorem apply separately.',probability_panels=83,central_scalar_monotonicity_checks=monotone,exact_partition_checks=phasechecks,rows=records,low_box_coverage=low,negative_controls=controls,resource_note='Both original and refined budgets hold for the same acquired law. No componentwise domination of the corner quadratics is assumed; their acyclic acquisition remains a separate proof edge.',source_sha256={s:sha256((BASE/s).read_bytes()).hexdigest()for s in SOURCE_FILES},checker_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
if __name__=='__main__':
 o=run();out=Path(__file__).with_name('LOCAL47_COVERAGE.json');need(not out.exists(),'Refuse overwrite');out.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({k:v for k,v in o.items()if k not in('rows','source_sha256')},indent=2))
