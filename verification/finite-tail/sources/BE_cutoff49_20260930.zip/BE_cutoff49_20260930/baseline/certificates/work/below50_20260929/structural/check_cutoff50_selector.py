"""Exact scalar selector, explicitly conditional on the local exclusion.

This checks arithmetic and the range/logic contract. It does not execute
entry/local arithmetic or certify that the remaining local premise holds.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import copy,json,sys
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent
CONTRACT={
 'schema':'CONDITIONAL_CUTOFF50_SELECTOR_V1',
 'mathematical_status':'CONDITIONAL_PENDING_COMPLETE_LOCAL_EXCLUSION',
 'ceiling':{'floor':45,'coefficient':'7/10','status':'established'},
 'forced_loss':{'first':47,'last':98,'coefficient':'19/100',
                'premise':'a_j>=0 and n(a_(j-1)-a_j)_+<=19/100 are excluded',
                'status':'required_not_certified_by_this_checker'},
 'tail':{'floor':99,'status':'independent_completed_cutoff99'},
 'target':50,'steps':4,
 'binary_left':{'n':[47,98],'p':['38/125','19/50'],'count_radius':'5/4',
                'source':'finite exact Bernoulli acceptance'},
 'binary_central':{'p':['19/50','47/100'],
                   'source_domain':['1/3','1/2']},
 'zero_noise':'attaining binary threshold is an integer count; use same strict binary bounds',
 'attainment':'fixed-index positive closed maximum, including a_j=0',
}
def need(ok,s):
 if not ok:raise ValueError(s)
def evaluate(doc):
 need(doc==CONTRACT,'Exact conditional scope; no promotion or changed hypotheses')
 k=F(doc['ceiling']['coefficient']);loss=F(doc['forced_loss']['coefficient'])
 low=doc['forced_loss']['first'];high=doc['forced_loss']['last'];steps=doc['steps'];target=doc['target']
 need(target-steps+1==low and target-steps>=doc['ceiling']['floor'],'First chain floors')
 need(doc['tail']['floor']==high+1,'Local range and independent tail meet')
 reserve50=loss*sum((F(1,j)for j in range(target-steps+1,target+1)),F(0))-k/(target-steps)
 need(reserve50>0,'Exact cutoff50 endpoint')
 slope=steps*loss-k;intercept=-steps*steps*loss
 need(slope>0 and slope*51+intercept>0,'Affine numerator for every n>=51')
 # Every finite application includes exactly four indices in the licensed range.
 for n in range(target,high+1):
  need(low<=n-steps+1<=n<=high,'Every forced-loss index is licensed')
  need(n-steps>=doc['ceiling']['floor'],'Ceiling predecessor licensed')
  need(loss*sum((F(1,j)for j in range(n-steps+1,n+1)),F(0))>k/(n-steps),'Finite exact reserve')
 ce=F('.40974')
 need(ce+k/47<F('.4247'),'Current acquisition score cap')
 need(ce+k/45<F('.4253'),'Current and two deleted score caps')
 need(F(doc['binary_left']['p'][1])==F(doc['binary_central']['p'][0]),'Binary range seam')
 need(F(doc['binary_central']['source_domain'][0])<=F(doc['binary_central']['p'][0])
      <=F(doc['binary_central']['p'][1])<=F(doc['binary_central']['source_domain'][1]),'Central published scope')
 need(F(doc['binary_left']['p'][0])<F(1,3),'Finite left input genuinely required below published range')
 return dict(reserve50=str(reserve50),affine_numerator_at51=str(slope*51+intercept),
             positive_affine_slope=str(slope),finite_target_indices=high-target+1)
def controls():
 rejected=[]
 for name,mutate in [
  ('claim_complete',lambda d:d.update(mathematical_status='PROVED_CUTOFF50')),
  ('local_floor48',lambda d:d['forced_loss'].update(first=48)),
  ('missing_final_index',lambda d:d['forced_loss'].update(last=97)),
  ('tail_gap',lambda d:d['tail'].update(floor=100)),
  ('weaker_loss',lambda d:d['forced_loss'].update(coefficient='9/50')),
  ('wrong_ceiling_floor',lambda d:d['ceiling'].update(floor=47)),
  ('three_steps',lambda d:d.update(steps=3)),
  ('cutoff49',lambda d:d.update(target=49)),
  ('omit_zero_noise',lambda d:d.pop('zero_noise')),
  ('strict_violation_only',lambda d:d.update(attainment='only a_j>0')),
  ('extend_published_scope',lambda d:d['binary_central'].update(source_domain=['.304','.5']))]:
  z=copy.deepcopy(CONTRACT);mutate(z)
  try:evaluate(z)
  except ValueError:rejected.append(name)
  else:raise AssertionError('Invalid composition accepted '+name)
 # Substantive arithmetic obstructions, independent of fixed-object identity.
 need(F('.76')/50<F('.7')/46,'Crude 4/n shortcut really fails at50')
 need(F('.19')*sum((F(1,j)for j in range(48,51)),F(0))<F('.7')/47,'Three steps really insufficient')
 need(F('.18')*sum((F(1,j)for j in range(47,51)),F(0))<F('.7')/46,'Loss .18 really insufficient at50')
 rejected.extend(['crude_endpoint_shortcut','three_step_arithmetic','loss_018_arithmetic'])
 return rejected
if __name__=='__main__':
 need(len(sys.argv)==1,'No theorem overrides')
 result=evaluate(CONTRACT);negative=controls()
 print(json.dumps(dict(status='PASS_CONDITIONAL_CUTOFF50_SELECTOR_SCALARS',
  mathematical_status=CONTRACT['mathematical_status'],
  execution_scope='Fresh rational selector arithmetic and explicit composition-contract controls only; not a proof of local exclusion.',
  contract=CONTRACT,result=result,negative_controls=negative,
  source_sha256={p.name:sha256(p.read_bytes()).hexdigest()for p in
    [Path(__file__),HERE/'cutoff50_selector.tex']}),indent=2))
