# Independent phase-resolved whole-count review

Mathematical status: the new signed phase reduction is independently derived
and checked, conditional on the acquired panel, confinement, normalization,
and retained whole-count lemmas. No mathematical defect found in the stated
formulas. Execution status: fresh exact geometry and normalization PASS.
This review does not claim final LOW score acceptance or a global cutoff.

## Sources and exact derivation

The full derivation is `root/phase_low47_proof.tex`. It was compared with
the original `root/low47_kernel.py`, the floating
`root/phase_low47_discovery_kernel.py`, and the new exact
`root/phase_left_low47_kernel.py` and its contract. The actual-count
curvature, marked transfer, and Poisson/common-background proofs were read
in full before deriving the changes.

The key exact identities are

- `delta = k-np = H/ell-u`;
- `chi = (n+1)p-k = p-H/ell+u`;
- `Var(W_k) = lambda + delta*(s1-s0)`.

The four signed H/ell corners and both phase endpoints give a valid closed
enclosure for delta. Its maximum absolute value controls conditional
variance and the entropy remainder. Its positive upper endpoint alone
controls the normal variance correction: that correction is nonpositive
when delta is nonpositive. The curvature upper coefficient is
`pu-min(H/ell)`. The two fourth-moment tail terms use the separate endpoints
`outerh` and `-outerl`. These directions preserve the actual law and include
zero H, endpoint atoms, and both nearest-count choices at half-integer ties.

No actual conditional variance lower bound is inserted in a Poisson
denominator: the frozen `ownhi*noise_lower` remains an upper-variance
envelope used algebraically as in the reviewed marked-transfer proof.
Every coefficient is frozen before the final noise variable varies.
The event and score expressions retain the requisite noise convexity;
the inverse-index coefficient is decreasing and is checked positive.

## Exact independent checks

`entry/check_phase_low47_geometry.py` imports the frozen checked normalizer,
not its discovery generator. Hashes are checked before importing the shared
left contract and its exact root routine. Fresh run:

`runs/below50_20260929/entry/phase_low47_geometry02`.

It verifies:

- all 38 acquired left panels and both phase signs: 76 configurations;
- 4,560 exact normalization gates, with the accepted amplitudes at most .375;
- 68,096 closed phase rectangles and 544,768 rational corners;
- the discovery radii .09, .13, .18, .29, .5 and the final .14, .19 radii;
- 7,442 actual-law/count cases at n=47,60,99, with unequal conditional
  variances, either variance zero, and both zero;
- 11 negative controls for wrong signed endpoints, curvature sign, tail
  endpoints, positive repair, and missing/duplicated/false empty coverage;
- a valid completely excluded row, including a resource cap equal to zero.

Gate digest:
`509403af878655dcb01edf3cbcd283fc506953cf1ac60c613e327831208964b6`.
The actual-law examples are rational centered two-point conditional laws,
not moment vectors optimized independently. They are adversarial checks,
not a replacement for the continuous derivation.

## Implementation seams to retain in final acceptance

1. Check the scale upper bound and `dd <= normalization.delta`, so the
   original finite entropy segment and exponential multiplier still apply.
2. Retain `b+outerh<2`, positive conditional variance, tail denominators,
   common distances and common radius. If a trivial common kernel `1/TL`
   is used when one distance is nonpositive, separately require the two
   common-background events to be disjoint (`alpha+beta>=0`). The exact
   kernel reviewed here instead requires positive common distances.
3. A row with `lambda_max<=.05` has empty LOW scope. Do not sort its ceiling
   with .05 and thereby construct a band above the acquired ceiling.
   Rows with larger ceilings may still have every box excluded by the
   strict budget. Such rows are valid without a numerical score maximum.
4. Verify the complete probability/sign/noise/outer-phase cover and match
   the final .14/.19 phase edges to the separate MID companions.
5. Fix the fallback for missing `noise_intervals` independently of whether
   an amplitude profile is provided. The new exact kernel does this;
   the exploratory kernel's selected calls always provided both arrays.

The final exact arithmetic source and certificate still require their own
source binding after construction; this report is not a binding of a
moving kernel file.

## Proof artifact QA

`entry/build_phase_low47/phase_low47_notes.pdf` is four pages. The successful
compile is logged in `entry/phase_low47_compile02`. There are no compile
warnings, overfull boxes or underfull boxes. All four rendered pages
`entry/qa/phase-low47-1.png` through `phase-low47-4.png` were visually
inspected; no clipping, overlap or missing glyphs was found.
