# Selected dependency map for cutoff99

Every arrow refers to one actual attaining law at its current fixed index.
The law may change between indices. Arithmetic cannot establish attainment,
contact, Fourier inversion or the actual-law reduction; those proofs are in
`paper/`. The finite hypotheses below are part of the named propositions.

| Node | Exact scope and inputs | Output / next node |
| --- | --- | --- |
| Literature | Finite iid caps; attained positive contact; finite all-threshold Gaussian bound; strict binomial theorem | Precisely stated external inputs |
| Attainment and identity | Fixed n; mean0, variance1, finite third absolute moment; positive closed orientation | Attained law, compact support, exact nonnegative defect/leakage identity |
| Uniform heat support | All real H; current score≥CE; n≥80 and decrement≤1.02 | Full support radius4.1 |
| Adaptive anchor support | 90≤n≤94, a_n≥.7/n, decrement≤1.17 | rho<1.72, full radius3.9 |
| ANCHOR90 | That supported high-score witness | Impossible; five backward steps give a94<.7/94 |
| Adaptive propagation support | 95≤n≤188, a_n≥.7/n, predecessor ceiling | decrement<.7/(n−1)≤7/940, rho<1.778029, radius3.7 |
| PROPAGATE95 | Supported high-score witness in that band | Impossible; extends ceiling to188 |
| STOP180 extension | First later ceiling failure n≥189; prior ceiling; new heat gives radius4.1⊂4.5 | Retained supported STOP180 gives a_n<.49823/n; extends .7/n forever |
| Current / three-index caps | Ceiling from94 | Own .41719 cap from95; all three .418 caps only from96 |
| ENTRY95 | n≥95, C≥CE, owncap.41719, radius4.1 | R<.77,D<.12,rho<1.15,absolute beta<.31 |
| Heat bridge95 | Prior radius4.1, those moments, decrement≤.2; every H | Radius2.5 |
| INPUT95 | Radius2.5, ENTRY95 raw/defect, owncap.41719 | Simultaneous interface below |
| Gaussian95 | n≥95, radius≤4.1,rho≤1.15,beta∈[.05,.3],H≤1.5,C≤.418,decrement≤.2 | Radius(-1.85,2.4), quantitative contact |
| Exterior95B | INPUT95 and decrement≤.19 | Full Y strip(-.49,1.49), inward displacement<.012 |
| Confinement95B | INPUT95, strip/gap, contact/leakage, both actual deleted .418 caps | lambda<.20 and full conditional amplitude<.30 |
| Normalization95B | Actual p∈[.35,.46],H≤1.15,lambda<.20,amplitude<.30 | Finite binomial/normal and cubic repair bounds |
| Scalar harmonic | Every r∈[0,1]; 80 polynomial coefficients; exact pi | 1−cos(2πr)≤23r/5; separate span.312 gives rate14.17 |
| Tiny / MID95B | True two conditional laws and normalization; all positive noise in listed regions | Strict comparison with actual binary law |
| Whole-count LOW95B | Same INPUT95 raw quadratic and one joint budget; full random cutoff/count argument | Strict comparison on complementary closed regions |
| Local conclusion | All cases and both nearest-integer choices covered; zero noise binary | Nonnegative a_n forces decrement>.19 from96 |
| Four losses | N≥99 so all four local steps licensed; .7/n ceiling | C_N<CE |

## Simultaneous INPUT95

n≥95, C≥CE, R<.75, D<.117, |H|<1.15, .35<p<.46,
rho<1.14, .075<beta<.3, theta<.0085, A>.73 and B>1.02.
In addition R<.68963+.30513|H|−.44494H² for the same law and threshold.
It gives the unweighted budget with phase rebate .199H². This quadratic
must not be replaced by a scalar ceiling in the whole-count proof.

## Complete local cover

Tiny noise: 0<lambda≤.026, every phase.
For the remaining noise, the LOW phase radius and the complementary direct
rectangle meet at the same boundary:

| Closed noise band | LOW absolute phase≤ | Direct region absolute phase≥ |
| --- | --- | --- |
| [.026,.0275] | .04 | .04 |
| [.0275,.03] | .09 | .09 |
| [.03,.08] | .13 | .13 |
| [.08,.10] | .18 | .18 |
| [.10,.12] | .25 | .25 |
| [.12,.20] | .5 | Entire phase already covered |

The first two bands and 68 later bands of width.0025 form70 closed intervals.
Exact covariance, deletion and count laws are used, including zero conditional
variance on one sign, atom collisions and cutoffs outside the binomial range.
At lambda0 there is no division or limiting argument: U=0 almost surely.

## Mathematical versus execution status

The project-specific nodes are locally derived and internally reviewed
research proofs. Their exact checks have fresh PASS logs; the package's
final verification file binds the final selected sources and both replays.
Literature nodes are externally cited theorems, not locally re-proved.
Finite actual-law examples are diagnostics; the continuous-domain acceptance
and analytic proofs are separate. No unrestricted n<99 result is inferred.
