# Independent signed-phase LOW47 review

## Analytical result

Independently read both exact kernels and contracts, the complete
`root/phase_low47_proof.tex`, and the retained whole-count and new marked
tail derivations. No analytical defect found. Final execution/source
binding is separate from this derivation and must use the fixed acceptors.

For the actual nearest count, `delta=k-np=H/ell-u` and
`chi=(n+1)p-k=p-H/ell+u`. The sign of H here is the actual sign; the law
and positive closed event are not reflected. Four corners of the signed
H/ell rectangle and both endpoints of the outer phase slice bound every
actual delta, even if p, ell, H and u are correlated. Its absolute maximum
controls own-count variances and the entropy/normal derivative remainder.
The scale lower/upper gates and contract-wide `Dstar<=normalizer.delta`
license every smaller slice.

Only the variance repair uses `max(0,delta_upper)`. The correction is
`sqrt(n)[Phi(delta/sqrt(nv))-Phi(delta/sqrt(n(v+s)))]`.
It is nonpositive when delta<=0. Otherwise differentiation in s gives
upper bound `.4*delta*s/(2*v^(3/2))`. Thus the positive-part substitution
is legitimate; replacing the absolute delta by a positive part anywhere
else would not be justified. The cubic repair remains independent of
this sign.

The normal derivative error is integrated from 0 to the actual u. Its
use of `max(abs(outer_lower),abs(outer_upper))` covers that entire path,
even when the outer phase slice itself does not contain zero.

The curvature coefficient is `pu-min(H/ell)`, the correct upper endpoint
for chi. Both numerator positive parts are increased at the upper phase
endpoint; the two positive denominators are decreased at their specified
endpoints. The contract checks chi<2 globally. In the fourth-moment tail,
the first reciprocal increases with u and the second decreases; hence
the endpoints `outer_upper` and `-outer_lower` are correct. The two near
marked tails use the same actual deleted laws and positive-distance
common-background proof as the independently reviewed central LOW.

All noise-dependent optimized choices are frozen before lambda varies.
The event and score expressions remain convex, and the inverse-index
coefficient remains decreasing with its positivity explicitly checked.
The 1/n replacement and binomial mass lower bound have the same correct
sign conditions as central LOW.

## Scopes and coverage

Base left LOW covers all 38 acquired left panels at n>=47 on the closed
noise bands above .05, with respective symmetric phase radii
`.09/.14/.19/.29/.5` at boundaries `.06/.08/.10/.12`.
It uses eight adjacent closed phase slices per noise/H cell.

The separately named positive extension covers only `u in [.29,.5]`
and `lambda in [.10,min(.12,Lambda)]`, for both signs of H. It uses four
closed phase slices. The finer H grid on panels indexed29 and higher
changes only the closed cover, not the target inequality or formulas.
Its amplitude is at most .30, supplied by the accepted left Sperner
profile, and can be lowered further by the panel's ordinary confinement.

The first three left MID bands cover the corresponding two-sided
complements. In the fourth band, MID covers only `u<=-.29`; base LOW
covers `[-.29,.29]` and the positive extension covers `[.29,.5]`.
At and above .12 base LOW has full phase range. At and below .05 the
widened TINY theorem covers every phase for positive noise. Zero noise
uses the separate binary argument in the selector. All phase endpoints
are closed, including either nearest-count choice at +/-1/2.

Rows with Lambda<=.05 have no base-LOW domain and must be skipped before
constructing noise intervals. Similarly the extra positive theorem
needs no positive-width interval when Lambda<=.10; the earlier MID and
base bands cover that shared boundary. A remaining complete row can
legitimately have no feasible boxes: every box is then excluded by the
strict resource `nd<G<=0`, including G=0. Such a row has no score maximum.
The final acceptor must preserve that distinction rather than parse its
absence as zero or omit the row.

The kernel resets the symmetric outer radius after each H loop. Its
curvature cache key includes both outer phase endpoints; the cached
factor depends on no noise amplitude. Raw quadratics use the selected H
sign, and the maximum over alternative branches is an outward bound.
The same phase charge is not subtracted twice.

This review does not turn phase arithmetic into unconditional acquisition
or a global cutoff. It retains the input table, both accepted confinement
objects, checked normalization, retained actual-count lemmas, companions,
and the final finite left binary reserve as explicit composition inputs.

## Final acceptor and composition review

Read both fixed acceptors in full. Each reconstructs the complete ordered
signed cover and compares every freshly evaluated rational report with the
fixed object. A wholly excluded row is retained with all boxes excluded,
zero evaluated endpoints and the explicit absent-score marker. The 13
rejection controls per acceptor include fixed-object integrity mutations,
duplicate JSON keys and a proposed noise domain above its acquired ceiling.
They should not be described as 13 independent mathematical tests.

Read `root/local47_composition.tex` in full. Its additional positive
fourth-band scope matches the separate contract; the claimed `.001lambda`
margin also matches the TINY and MID score gates. The finite left Bernoulli
input covers both positive and zero noise on indices47..98, and the
independent cutoff99 closes the tail. Its selector agrees with the separately
derived conditional selector. No new analytical defect was found.

The completed execution binding records the actual fixed replay counts and
source hashes. It does not rerun the expensive arithmetic, prove acquisition
by comparing hashes, or itself constitute final release approval.
