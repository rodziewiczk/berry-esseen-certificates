#!/usr/bin/env python3
"""Fixed acquisition after the separately proved left radius2.7 contraction."""
from fractions import Fraction as F
from pathlib import Path
import copy,hashlib,json,sys
import coupled_panel_core as c
def need(x,s):
 if not x:raise ValueError(s)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def unique(pairs):
 z={}
 for k,v in pairs:need(k not in z,'duplicate JSON key');z[k]=v
 return z
def load(p):return json.loads(Path(p).read_text(),object_pairs_hook=unique)
def shape(table):
 need(table['schema']=='LEFT270_INPUT47_V1'and type(table['N'])is int and table['N']==47,'fixed theorem floor')
 need(table['own_score_cap']=='4247/10000'and table['support_radius']=='27/10'and table['decrement_cap']=='19/100','fixed theorem domain')
 need(table['probability_domain']==['38/125','19/50'],'selected complete left domain')
 need(table['source_sha256']==sha('signed_resource47_table.json'),'complete preceding resource binding')
 need(table['support_checker_sha256']==sha('accept_left_radius270_47.py'),'uniform support theorem binding')
 need(type(table['panels'])is list and len(table['panels'])==38,'complete remaining left cover')
 for j,z in enumerate(table['panels']):
  need(type(z['index'])is int and z['index']==j,'unique ordered indices')
  need(list(map(F,z['p']))==[F(152+j,500),F(153+j,500)],'closed contiguous cells')
  need(len(z['quadratics'])==4,'four signed corner quadratics')
  for q in z['quadratics']:
   need(set(q)=={'A','Fplus','Fminus','Qraw','Qbudget'},'quadratic fields')
   need(F(q['A'])>0 and 0<F(q['Qraw'])<F(q['Qbudget']),'positive curvatures')
def verify(table,emit=False):
 shape(table);old=load('signed_resource47_table.json');source=[z for z in old['panels']if z['source']=='left_input47_table.json']
 need(len(source)==38,'complete previous left cover')
 for j,(z,target)in enumerate(zip(source,table['panels'])):
  need(z['index']==j and z['p']==target['p'],'same actual probability cell')
  need(F(z['rho'])<=F('1.2563')and max(abs(F(z['beta_lo'])),abs(F(z['beta_hi'])))<=F('.3926'),'acquired heat-support moment premises')
  l,u=map(F,z['p']);row=dict(pl=l,pu=u,raw=F(z['T']),D=F(z['D']),theta=F(z['theta']),rho=F(z['rho']),beta=F(z['beta_hi']))
  out=c.cell(47,F('2.7'),F('.4247'),row,steps=24)
  need(not out.get('excluded')and'quadratics'in out,'complete paired survivor')
  for a,b in [('raw','T'),('D','D'),('theta','theta'),('rho','rho'),('beta','beta_hi'),('lambda_max','lambda_max'),('inward_d_max','d0'),('Hplus','H_plus'),('Hminus','H_minus')]:need(out[a]<=F(target[b]),('upper',j,b))
  for a,b in [('beta_lo','beta_lo'),('A','A_lo'),('B','B_lo')]:need(out[a]>=F(target[b]),('lower',j,b))
  for a,b in zip(out['quadratics'],target['quadratics']):
   for key in ('A','Fplus','Fminus'):need(a[key]<=F(b[key]),('corner upper',j,key))
   for key in ('Qraw','Qbudget'):need(a[key]>=F(b[key]),('curvature lower',j,key))
  if emit:print('PASS_LEFT270_INPUT47',j,flush=True)
 return dict(status='PASS_LEFT270_INPUT47',panels=38,weighted_resources=True,heat_support_premises_acquired=True)
def controls(table):
 cases=[]
 for action in [lambda z:z['panels'].pop(),lambda z:z['panels'].reverse(),lambda z:z['panels'].insert(1,z['panels'][0]),lambda z:z['panels'][0].update(index=True),lambda z:z['panels'][0].update(p=['3/10','31/100']),lambda z:z['panels'][0]['quadratics'].pop(),lambda z:z.update(source_sha256='0'*64),lambda z:z.update(support_checker_sha256='0'*64),lambda z:z.update(support_radius='2')]:
  z=copy.deepcopy(table);action(z);cases.append(z)
 for z in cases:
  try:shape(z)
  except(ValueError,KeyError,TypeError):pass
  else:raise ValueError('malformed left270 target accepted')
 for key,value in [('T','1/100'),('lambda_max','1/100000000')]:
  z=copy.deepcopy(table);z['panels'][0][key]=value
  try:verify(z)
  except ValueError:pass
  else:raise ValueError('false arithmetic left270 target accepted')
 return len(cases)+2
if __name__=='__main__':
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed invocation')
 table=load('left270_input47_table.json');out=verify(table,True);out['negative_controls']=controls(table)
 out['table_sha256']=sha('left270_input47_table.json');out['source_sha256']={p:sha(p)for p in ('accept_left270_input47.py','accept_left_radius270_47.py','coupled_panel_core.py','signed_variance_resource.py','paired_conditional_gamma47.py','contracted_kernel.py','high_window_core.py')}
 print(json.dumps(out,sort_keys=True),flush=True)
