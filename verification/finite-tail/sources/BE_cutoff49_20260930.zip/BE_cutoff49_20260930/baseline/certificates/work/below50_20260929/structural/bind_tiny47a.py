from pathlib import Path
from hashlib import sha256
import json
B=Path(__file__).resolve().parents[3]
L=B/'work/below50_20260929/local';S=B/'work/below50_20260929/structural'
h=lambda p:sha256(p.read_bytes()).hexdigest()
f=json.loads((L/'TINY47A_FREEZE.json').read_text())
assert h(L/'TINY47A_FREEZE.json')=='d5eb9d22f71fba9f508527897614292d7c7fcdf980fe1229005e643283a2652b'
for n,v in f['sha256'].items():assert h(L/n)==v,(n,'freeze mismatch')
r=B/'runs/below50_20260929/local/tiny47a_accept01'
m=json.loads((r/'metadata.json').read_text());o=json.loads((r/'stdout.txt').read_text())
assert m['returncode']==0 and o['status']=='PASS_EXACT_CONDITIONAL_TINY47_A'
assert (o['gates'],o['phase_cells'],o['negative_controls'])==(77,6,24)
for n in ('tiny47a_kernel.py','tiny47a_normalization.py','accept_tiny47a.py','tiny47a_certificate.json'):
 assert h(L/n)==m['input_sha256'][n],(n,'executed source mismatch')
assert h(r/'stdout.txt')==m['stdout_sha256'] and h(r/'stderr.txt')==m['stderr_sha256']
files=[L/n for n in f['sha256']]+[L/'TINY47A_FREEZE.json',S/'TINY47A_REVIEW.md',Path(__file__)]+list(r.iterdir())
for name in ('shifted_quartic_actual01','quartic_uniform01'):
 rr=B/'runs/below50_20260929/local'/name;mm=json.loads((rr/'metadata.json').read_text());assert mm['returncode']==0
 for n in ('check_shifted_quartic_actual.py','check_quartic_uniform.py'):
  if n in mm['input_sha256']:assert h(L/n)==mm['input_sha256'][n]
 assert h(rr/'stdout.txt')==mm['stdout_sha256'] and h(rr/'stderr.txt')==mm['stderr_sha256']
 files+=list(rr.iterdir())
o={'schema':'INDEPENDENT_TINY47_A_REVIEW_V1','mathematical_status':'Independently rederived and reviewed conditional theorem; no defect found.','execution_status':'Selected sources match fresh exact accept01 and recorded algebra controls; final proof/PDF separately bound after acceptance.','scope':f['scope'],'score_hypothesis':'C>=.4','conclusion':'rho_B(C-C_B^+(k))<-.001lambda; no acquisition or global cutoff claim','counts':{'gates':77,'closed_phase_cells':6,'negative_controls':24},'visual_QA':'Constructor inspected all five final pages; reviewer read full proof, no second visual QA claimed.','sha256':{str(p.relative_to(B)):h(p) for p in sorted(set(files)) if p.is_file()}}
(S/'TINY47A_BINDING.json').write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps({'status':'PASS_TINY47A_REVIEW_BINDING','freeze_entries':len(f['sha256']),'bound_files':len(o['sha256']),'binding_sha256':h(S/'TINY47A_BINDING.json')}))
