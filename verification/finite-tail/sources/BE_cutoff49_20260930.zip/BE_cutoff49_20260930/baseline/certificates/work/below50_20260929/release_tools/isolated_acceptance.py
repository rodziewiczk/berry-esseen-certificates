"""Execute a declared writer unchanged in a disposable full-capsule copy."""
from pathlib import Path
from hashlib import sha256
import os, shutil, stat, subprocess, tempfile

def tree_hashes(root):
    root=Path(root).resolve();out={}
    for directory,subdirs,files in os.walk(root,followlinks=False):
        for name in subdirs+files:
            p=Path(directory)/name;mode=p.lstat().st_mode
            if stat.S_ISLNK(mode):raise ValueError('Symlink is not allowed in the frozen capsule: '+str(p))
            if not stat.S_ISDIR(mode) and not stat.S_ISREG(mode):raise ValueError('Nonregular capsule member: '+str(p))
        for name in files:
            p=Path(directory)/name;h=sha256()
            with p.open('rb') as f:
                for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
            out[p.relative_to(root).as_posix()]=h.hexdigest()
    return out

def run_isolated(root,job,outputs,command,env,stdout,stderr):
    """Outputs are explicit workspace-relative files, never wildcard paths."""
    root=Path(root).resolve();before=tree_hashes(root)
    if not outputs or len(outputs)!=len(set(outputs)):raise ValueError('Nonempty distinct declared outputs required')
    for rel in outputs:
        p=Path(rel)
        if p.is_absolute() or '..' in p.parts or '\\' in rel or rel not in before:
            raise ValueError('Missing or unsafe declared frozen output: '+rel)
    with tempfile.TemporaryDirectory(prefix='be_frozen_acceptor_') as temp:
        copy=Path(temp)/'capsule';shutil.copytree(root,copy,symlinks=False)
        copied=tree_hashes(copy)
        if copied!=before or tree_hashes(root)!=before:raise ValueError('Capsule changed while making its exact copy')
        for rel in outputs:(copy/rel).unlink()
        proc=subprocess.run(command,cwd=copy/job['cwd'],env=env,stdout=stdout,stderr=stderr)
        after=tree_hashes(copy);original_after=tree_hashes(root)
        recreated={rel:dict(expected_sha256=before[rel],actual_sha256=after.get(rel),byte_identical=after.get(rel)==before[rel]) for rel in outputs}
        same_copy=after==before;same_original=original_after==before
        details=dict(scope='Unchanged acceptor in exact full-capsule copy; only declared outputs removed before execution.',declared_outputs=list(outputs),frozen_capsule_files=len(before),input_sha256=before,regenerated_outputs=recreated,entire_copy_restored=same_copy,original_capsule_unchanged=same_original,unexpected_or_changed_paths=sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k)))
        return proc.returncode,details,proc.returncode==0 and same_copy and same_original
