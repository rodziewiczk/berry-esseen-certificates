# Concentration from the conditional gap

## Exact lemma (new; independent of the Berry–Esseen comparison)

Let independent identically distributed summands have the representation
`Y=U0+B(1+U1−U0)`, where `B` is Bernoulli(p), independent of the pair `(U0,U1)`.
Suppose `U0≤a`, `U1≥−a1`, and `c=1−a−a1>0` almost surely.
The two noises may be independently coupled without changing the marginal of Y.
For every j≥1 and every interval I of diameter strictly less than c,

`P(Y1+...+Yj ∈ I) ≤ max( Bin(j,p){k}: 0≤k≤j ).`

The statement permits any open or closed endpoints, all atoms, and zero noise.

**Proof.** Condition on all j noise pairs. The sum becomes a constant plus
`sum_i B_i w_i`, where every `w_i=1+U1_i−U0_i≥c`. The family F of subsets
whose sums lie in I is an antichain: two distinct comparable subsets differ
by at least one positive step c, exceeding the diameter of I. A uniformly
random permutation of [j] defines a maximal chain of initial subsets. A
fixed k-subset lies on this chain with probability `1/binom(j,k)`, and an
antichain meets a chain at most once. Taking expectations proves
`sum_{S∈F}1/binom(j,|S|)≤1`. Multiply each summand by its binomial level mass,
which is at most the largest level mass, and sum. Finally integrate over the
conditioned noise pairs. Convolution with any further independent summand
preserves the same concentration cap, by conditioning on that summand. ∎

Strict diameter is essential. For a Bernoulli law on {0,c}, the closed
interval [0,c] has mass one, strictly larger than either binomial level mass
when j=1 and 0<p<1. Nothing here extends the one-mode bound to diameter c.

## Uniform finite Stirling cap

For p∈[l,h], j≥J, choose any binomial mode k. The adjacent-mass ratios imply
`(j+1)p−1 ≤ k ≤ (j+1)p`. Consequently r=k/j lies in
`[rL,rR]=[l−(1−l)/J,h+h/J]`. Assume `0<rL≤rR<1` and put
`v*=min(rL(1−rL),rR(1−rR))`.
The finite Stirling inequalities `sqrt(2πm)(m/e)^m < m! <
sqrt(2πm)(m/e)^m exp(1/(12m))`, applied to j!, k!, (j−k)!, give

`sqrt(j) Bin(j,p){k} ≤ exp(1/(12j)−j D(r||p))/sqrt(2πr(1−r))`
`≤ .4 / [sqrt(v*) (1−1/(12J))].`

Here D is binary relative entropy, nonnegative by log concavity/Jensen;
`1/sqrt(2π)<.4` and `exp(x)≤1/(1−x)` for 0≤x<1. Thus any positive rational
M satisfying `M² v*(1−1/(12J))²>.16` is a strict uniform cap for `sqrt(j)`
times every binomial atom, for all j≥J and all p∈[l,h]. Both denominator
factorials have positive integer arguments because 0<rL and rR<1.

## Confinement47 replacement (conditional on its acquired interfaces)

Set J=N−2. This covers the n−1 actual summands in ν and the n−2 actual
summands left after marking/deleting a pair; conditioning on any independent
remaining conditional noise preserves the cap. It does not replace the
n−2 mode by an n−1 mode.

On the lower ray, r ranges only up to strip+d0 by the already acquired
Y-strip. The two interval widths are r−d−tau−eta and r−eta. Therefore the
strict gate `1−strip−2d0>0` puts both widths below `1−d` throughout that ray.
The upper intervals have widths tau and 2tau+d; the strict gate
`1−2d0−2tau>0` suffices. Use `QI=QJ=M` in the directed deletion bounds.
The previous combined hull bound is discarded; the independent centered
noise bounds give `ae=Fd*M*(1/l+1/(1−h))/2`.

Every lower-ray error bound is then independent of r: the interval upper
endpoints, outward directed distances, bad-pair probability, moment simplex,
and all concentration caps are unchanged as r grows. The contact lower
bound increases with derivative L>0, so checking the smallest r=amplitude
and L>0 proves the entire ray, without differentiating the minimum of error
bounds. No claim is made beyond the acquired strip.

Mathematical status: locally derived, independently reviewed lemma; numerical
scope under exact diagnostic evaluation. Strict acceptance remains separate.
