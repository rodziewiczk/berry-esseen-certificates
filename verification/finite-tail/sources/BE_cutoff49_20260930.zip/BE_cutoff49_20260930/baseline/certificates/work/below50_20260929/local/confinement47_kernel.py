"""Exact arithmetic for CONDITIONAL_CONFINEMENT47_A.

The noise ceiling is a hypothesis, not an acquisition conclusion.
Analytic reduction: confinement47_proof.tex.
"""
from fractions import Fraction as F
from math import isqrt
import hashlib,sys
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
def rootlo(q):
    assert q>0
    return F(isqrt(q.numerator*10**12//q.denominator)-1,10**6)
def rootup(q):
    assert q>0
    return F(isqrt(q.numerator*10**12//q.denominator)+1,10**6)

def evaluate(cfg):
    N=cfg['N'];T=cfg['T'];Theta=cfg['theta'];d0=cfg['d0'];H=cfg['H'];C=cfg['C'];amp=cfg['amplitude'];eta=cfg['eta'];fd=cfg['fd'];rebate=cfg['rebate'];kappa=F(997,15000)
    gates={};empty=[];feasible=[]
    def put(name,v):
        assert name not in gates;gates[name]=F(v)
    put('root_domain',1-Theta);put('probability_left',cfg['pl']);put('probability_right',F('.5')-cfg['pu'])
    put('contact_floor',C-F('.4'));put('beta_domain',cfg['beta_lo']);put('initial_gap',F('.025')-d0)
    put('support_noise',cfg['strip']-d0);put('lower_buffer_width',amp-d0-cfg['lower_buffer']-eta)
    put('lower_disjoint',1-cfg['strip']-d0+cfg['lower_buffer']+eta)
    put('upper_buffer_width',amp-d0-2*cfg['upper_buffer']);put('upper_inside_gap',1-d0-cfg['upper_buffer'])
    put('delete_distance',fd*fd-F(N,N-1)**3);put('delete_noise',fd*fd-F(N,N-2))
    put('rebate_domain',(F('.4095')-cfg['D']/15)/(2*(1+H*H/(2*N)))-rebate)
    put('positive_phase_gaussian',1-H*H/(2*N))
    put('root10_lower',10-F('3.16')**2)
    put('root10_upper',F('3.16228')**2-10)
    put('displacement_upper',F('2.041')**2-1-F('3.16228'))
    put('displacement_sum',6-F('2.25')**2)
    put('optimizer_lower',(4-2*F('.41886'))**2-10)
    put('optimizer_upper',10-(4-2*F('.41887'))**2)
    put('gaussian_lower',7-44*F('.39886')**2)
    put('gaussian_upper',2*F('3.14')*F('.4')**2-1)
    put('budget_coefficient',F('.39886')-6*kappa)
    put('minimum_rho',F('.4')*3-F('.4')*H)
    for pi in range(cfg['pc']):
        pl=cfg['pl']+(cfg['pu']-cfg['pl'])*pi/cfg['pc'];pu=cfg['pl']+(cfg['pu']-cfg['pl'])*(pi+1)/cfg['pc'];qlo=1-pu;vlo=pl*(1-pl)
        el2=(1-Theta)/(pu*(1-pu));ell=rootlo(el2);eh2=1/vlo;eh=rootup(eh2)
        ml2=(1-Theta)*vlo;ml=rootlo(ml2);sqrtv=rootlo(vlo)
        put('ell_lower:'+str(pi),el2-ell*ell);put('ell_upper:'+str(pi),eh*eh-eh2);put('moment_lower:'+str(pi),ml2-ml*ml);put('sqrtv:'+str(pi),vlo-sqrtv*sqrtv)
        cp=2*F('5.16')*(ell*(1-pu-d0))**2;cm=2*F('7.16')*(ell*(pl-d0))**2
        al=min(cp*pl*ell,cm*qlo*ell);be=min(3*F('4.16')*ell*(1-pu-d0),3*F('6.16')*ell*(pl-d0))
        dist=max(F(0),F('.41886')-pu,pl-F('.41887'));pen=ml*ell*ell*max(F(0),F('3.5')*dist-F('2.041')*d0)**2
        put('gap_coefficient:'+str(pi),al);put('variance_coefficient:'+str(pi),be)
        put('cubic_coefficient:'+str(pi),cfg['third']**2*vlo**3-(3*(1-pl)+cfg['strip'])**2)
        blo=max(cfg['beta_lo'],1-2*pu-2*(1-pu)*Theta);bhi=min(cfg['beta_hi'],1-2*pl+Theta)
        put('beta_consistency:'+str(pi),bhi-blo)
        Bmax=rootup((1-pl)/pl);put('mean_upper:'+str(pi),Bmax*Bmax-(1-pl)/pl)
        f=F('.4')*eh;epscap=2*T/(kappa*ell*min(cp,cm))
        for hi in range(cfg['hc']):
            hmin=cfg.get('H_min',F(0));hl=hmin+(H-hmin)*hi/cfg['hc'];hh=hmin+(H-hmin)*(hi+1)/cfg['hc'];budget=T-rebate*hl*hl
            if all(k in cfg for k in ('R_A','R_F','R_Q')):
                vertex=max(hl,min(hh,cfg['R_F']/(2*cfg['R_Q'])))
                budget=min(T,cfg['R_A']+cfg['R_F']*vertex-cfg['R_Q']*vertex*vertex)-rebate*hl*hl
            if 'raw_quads' in cfg:
                candidates=[]
                for qi,(qa,qf,qq) in enumerate(cfg['raw_quads']):
                    put('raw_quadratic_domain:'+str(pi)+':'+str(hi)+':'+str(qi),qq)
                    vv=max(hl,min(hh,qf/(2*qq)))
                    candidates.append(qa+qf*vv-qq*vv*vv)
                budget=min(T,max(candidates))
            for li in range(cfg['lc']):
                sl=cfg['noise_min']+(cfg['maxnoise']-cfg['noise_min'])*li/cfg['lc'];sh=cfg['noise_min']+(cfg['maxnoise']-cfg['noise_min'])*(li+1)/cfg['lc'];key=f'{pi}:{hi}:{li}'
                raw=budget/kappa-be*ell*ell*sl;cap=(raw-N*pen)/al
                if cap<=0:empty.append([key,str(cap)]);continue
                feasible.append(key)
                rho=min(cfg['rho'],(1-2*vlo)/sqrtv+cfg['third']*sh/N);cc=2*C*rho
                phi_lo=F('.39886')*(1-hh*hh/(2*N))
                signed_hi=F('.4')*hh if cfg['phase_sign']>0 else -phi_lo*hl
                signed_lo=phi_lo*hl if cfg['phase_sign']>0 else -F('.4')*hh
                mn=eh*max(F(0),(signed_hi+3*C*rho)**2/(12*F('.4'))-3*F('.4')*blo)
                lm=ell*F('.39886')*(1-hh*hh/(2*N))-mn/N
                put('negative_slope:'+key,lm)
                for upper in [False,True]:
                    tag=('upper:' if upper else 'lower:')+key;tau=cfg['upper_buffer'] if upper else cfg['lower_buffer']
                    if upper:
                        mp=eh*max(F(0),F('.4')*hh*Bmax+3*C*Bmax*(Bmax-1)-3*F('.4')*blo)
                        L=ell*F('.39886')*(1-hh*hh/(2*N))-max(mn,mp)/N
                        U=f+eh*(3*C*bhi+(F('.4')*hh+3*C*rho)**2/(12*F('.4')))/N
                        Qi=f*tau+cc;Qj=f*(2*tau+d0)+cc
                        Di=max(F(0),d0+tau+hh/ell-pl);Dj=max(F(0),1+d0+2*tau+hh/ell-pl)
                        leak=1/tau;dc=L+U
                    else:
                        tmin=-eh*(pu+tau+d0+eta)
                        U=f+eh*max(3*C*bhi,3*C*bhi+(3*F('.4')+signed_lo)*tmin+3*C*tmin*tmin)/N
                        # The actual lower interval lies entirely below this t endpoint.
                        tmax=-ell*(pl+tau+eta)
                        bv=min(tmax,-rho/2)
                        bmin=blo+rho*bv+bv*bv
                        coef=signed_hi+3*F('.4')*rho
                        vertex=min(tmax,-coef/(6*F('.4')))
                        qmin=3*F('.4')*blo+coef*vertex+3*F('.4')*vertex*vertex+3*(C-F('.4'))*min(F(0),bmin)
                        L=ell*F('.39886')*(1-hh*hh/(2*N))-eh*max(F(0),-qmin)/N
                        U=L # integrate the same lower derivative over all of I
                        put('restricted_negative_endpoint:'+key,-tmax)
                        put('restricted_negative_slope:'+key,L)
                        Qi=f*(amp-tau-eta)+cc;Qj=f*(amp-eta)+cc
                        signed_distance=-hl/eh if cfg['phase_sign']>0 else hh/ell
                        Di=max(F(0),signed_distance-pl-tau-eta);Dj=max(F(0),signed_distance+1-pl-eta)
                        leak=1/(1-cfg['strip']-2*d0);dc=U
                    Qhull=f*(1+2*tau if upper else 1+amp-eta)+cc
                    # Same remaining sum: fI+fJ is bounded on the hull.
                    # For p in[pl,pu], 1/p-1/q <= 1/pl-1/(1-pl).
                    Ecoef=fd*min(Qi/pl+Qj/qlo,Qhull/qlo+(1/pl-1/(1-pl))*Qi)/2;Dist=fd*(Qi*Di/pl+Qj*Dj/qlo);Bad=fd*Qi
                    if upper:
                        put('gap_slope:'+key,L)
                        put('allocation_positive:'+key,dc)
                    z=max((dc/pl+2*Ecoef)/(ell*cp),(dc/qlo+2*Ecoef)/(ell*cm),kappa*leak/(1-Theta))
                    bad=min(sh/(sh+N*pl*tau*tau),cap/(N*tau+cap))
                    inverse=z*raw+Dist
                    error=inverse/N-z*pen+Bad*bad
                    # NEW shared resource: tangent upper bounds to d/(n*tau+d)
                    # charge the pair failure against the SAME moment budget.
                    resource=raw-N*pen
                    vertices=[((dc/pl+2*Ecoef)/(ell*cp)*resource/N,resource/(ell*cp*pl)),
                              ((dc/qlo+2*Ecoef)/(ell*cm)*resource/N,resource/(ell*cm*qlo)),
                              (kappa*leak/(1-Theta)*resource/N,F(0))]
                    for kk in range(11):
                        ds=cap*kk/10
                        tangent_s=N*tau/(N*tau+ds)**2
                        tangent_b=ds**2/(N*tau+ds)**2
                        candidate=Dist/N+max(v+Bad*tangent_s*dd for v,dd in vertices)+Bad*tangent_b
                        error=min(error,candidate)
                    margin=L-cfg['strip']*U-error if upper else L*amp-U*(tau+eta)-error
                    put('inverse_'+tag,inverse);put('confinement_'+tag,margin)
                    if not upper:
                        ray=fd*f*(Di/pl+Dj/qlo+(1/pl+1/qlo)*epscap/2)/N+fd*f*bad
                        put('ray_slope:'+key,L-ray)
    assert len(empty)+len(feasible)==cfg['pc']*cfg['hc']*cfg['lc']
    return {'gates':gates,'empty':empty,'feasible':feasible,'contract':{k:str(v) for k,v in cfg.items()}}
