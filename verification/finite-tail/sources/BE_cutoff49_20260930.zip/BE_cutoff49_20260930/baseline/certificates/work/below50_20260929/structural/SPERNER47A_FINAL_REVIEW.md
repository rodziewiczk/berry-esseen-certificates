# Final independent review of SPERNER47A

Mathematical status: independently derived and reviewed conditional theorem;
no defect found. Execution status: selected sources match fresh strict
local/sperner47_accept01:249410 positive gates,24014 feasible plus10546
excluded boxes,20 rejection controls. The numerical entry, contact, initial
strip and common-budget premises remain explicit dependencies.

The strict-gap concentration lemma was independently proved in
BIASED_ANTICHAIN_REVIEW.md by a random-permutation chain argument. I read the
complete final integrated proof, kernel, contract, acceptor and actual-law
controls. The final kernel differs from the already reviewed diagnostic
only in its docstring. There is no hidden assumption about minimum atom mass,
positive conditional variance or independence between two different deleted
laws. The noise-pair coupling constructs each actual marginal and independent
copies before conditioning on the Bernoulli labels.

At index j any binomial mode k obeys (j+1)p-1<=k<=(j+1)p. The stated outer
bounds on k/j are valid for every j>=N-2. They lie strictly between0 and1,
so both denominator factorials are positive. Finite Stirling gives
sqrt(j)*mode<=phi(0) exp(1/(12j))/sqrt(r(1-r)); nonnegative relative entropy
has the favorable sign. Replacing phi(0) by.4 and the exponential by its
positive geometric upper bound is outward. The strict squared-root gate
licenses the rational mode cap. Existing fd checks supply sqrt(n/j), including
j=n-2 for a marked background. This index is not silently changed to n-1.

Every concentration interval has diameter strictly below the actual gap.
The lower-side reserve1-strip-2d0 proves this over the entire required range
r<=strip+d0; the upper-side reserve1-2d0-2tau proves it for both upper
intervals. Consequently the lower-side error is independent of r on that
finite range and the contact lower bound increases with positive slope L.
The proof explicitly restricts this extension to the acquired finite strip;
there is no invalid unbounded constant-cap assertion. Closed endpoints and
atoms are included, while equality of interval width and gap is excluded.

The signed deletion identities, centered half-error, both conditional laws,
restricted negative slope, common moment resource and tangent pair-failure
allocation retain their previously reviewed meanings. The removed hull
improvement is not used by the new formula. Fixed phase/noise boxes include
zero noise,H=0 and every shared boundary. Exclusion uses a strict common
budget; a zero residual is therefore excluded correctly.

The actual-law controls cover seven finite laws, including tiny atoms,
deterministic conditional noises and collisions, independently enumerate
permutation chains, and reject the false closed-width equality. The finite
mode tests supplement the uniform Stirling proof. Object mutations verify
fixed scope/source/coverage integrity; neither kind of control substitutes
for the analytical derivation.

All final freeze bytes are bound separately from run evidence. The constructor
compiled and visually inspected all six pages; this reviewer read the full
proof text and code and does not claim a second rendering inspection. This
is an improved conditional amplitude theorem, not a final score comparison
or a new global cutoff.
