#!/usr/bin/env python3
"""Exact coefficient/sign controls for the sign-free Gaussian transfer lemma.
No transcendental quadrature; the integral argument is the accompanying proof.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,sys
if not __debug__ or sys.flags.optimize:raise RuntimeError('assertions required')
def U_symbolic(z,c):
 if z*c<=0:return (abs(z)+3*abs(c),F(0),None)
 return(abs(abs(z)-3*abs(c)),36*abs(z*c),abs(z)/(2*abs(c)))
def old_U(z,c):
 assert c>=0
 if z<=0:return(-z+3*c,F(0),None)
 if c==0:return(z,F(0),None)
 return(abs(z-3*c),36*z*c,z/(2*c))
values=[F(-7,5),F(-1),F(-1,17),F(0),F(1,17),F(1),F(7,5)]
count=0
for z in values:
 for c in values:
  assert U_symbolic(z,c)==U_symbolic(-z,-c)
  if c>=0:assert U_symbolic(z,c)==old_U(z,c)
  if c<=0:assert U_symbolic(z,c)==old_U(-z,-c)
  count+=1
# Exact Gaussian coefficients after integration by parts.
assert F(945,6**3*6)==F(35,48)
assert F(105,6**2*2)==F(35,24)
assert F(15,6)==F(5,2)
assert F(3,6)==F(1,2)
assert F(251,200)*F(15,6**3*6)==F(251,17280)
assert F(251,200)*F(3,6**2*2)==F(251,4800)
assert F(943,6**3*6)!=F(35,48) # changed moment must fail
for N in [3,4,180,200,100000]:
 a0=F(N-1,2*N);lambda2=F(1,2)*F(N,N-1)**3
 assert 1/(16*a0**3)==lambda2
 assert 1/(256*a0**5)==lambda2*F(N,N-1)**2/4
 assert 1/(256*a0**5)>=lambda2/4
# Applying the old z<=0 branch to a newly admitted negative c is invalid.
z,c=F(-1),F(-1)
assert U_symbolic(z,c)!=(-z+3*c,F(0),None)
# A genuinely invalid zero-branch sign is detected.
z,c=F(1),F(-1)
assert abs(z)+3*abs(c)!=z+3*c
files=[Path(__file__),Path(__file__).with_name('fourier_replacement.tex')]
print(json.dumps({'status':'PASS_SIGNED_GAUSSIAN_COEFFICIENTS','scope':'exact finite sign/parity and coefficient controls; not transcendental quadrature or a new numerical entry target','signed_cases':count,'old_quadrant_equivalence':True,'gaussian_coefficients':['35/48','35/24','5/2','1/2','251/17280','251/4800'],'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}},indent=2))
