"""Fixed shared normalization for CONDITIONAL_LOCAL95_B; all constants rational.

The check below has no search or parameter-selection semantics. Its domain is
the actual law and contact hypotheses stated in confinement95b_proof.tex.
"""
from fractions import Fraction as F
from math import factorial
import sys
if sys.flags.optimize or not __debug__:raise RuntimeError('No optimized Python')
CFG=dict(N=95,T=F('.75'),D=F('.117'),theta=F('.0085'),d0=F('.012'),pl=F('.35'),pu=F('.46'),H=F('1.15'),C=F('.418'),rho=F('1.14'),
 amplitude=F('.30'),span=F('.312'),lmax=F('.20'),tiny=F('.026'),delta=F('1.0758'),elo=F('1.9977'),v=F('.22749'),
 left=F('.3385'),right=F('.4715'),vf=F('.2238'),entropy=F('6.449'),logder=F('1.4434'),remainder=F('.3725'),zeta=F('1.1631'),
 logcoef=F('2.3158'),logcap=F('.0479'),ef=F(10000,9521),normal_v=F('2.434'),normal_c=F('4.284'),
 sqrtmass=F('.4986'),mass=F('.7686'),cv=F('2.858'),ownlo=F('.9675'),ownhi=F('1.0325'),incoming=F('1.0626'),outer=F('1.0476'),ratio=F('1.025'),
 derivative_lo=F('.949'),derivative_hi=F('1.051'),repair=F('1.31'),repair_pos=F('1.85'),repair_multiplier=F('3.16'),rate=F('14.17'))

def check():
 c=CFG;N=c['N'];v=c['v'];delta=c['delta'];lm=c['lmax'];g={}
 def pos(k,x):
  x=F(x)
  if not x>0:raise ValueError('nonpositive gate '+k+': '+str(x))
  if k in g:raise ValueError('duplicate gate')
  g[k]=str(x)
 def atan(x):
  a=sum((-1)**j*x**(2*j+1)/(2*j+1)for j in range(20));return a,a+x**41/41
 a,b=atan(F(1,5)),atan(F(1,239));pil=16*a[0]-4*b[1];pih=16*a[1]-4*b[0]
 if not (F(120,119)-F(1,239))/(1+F(120,119)/239)==1:raise ValueError('Machin identity')
 pos('Machin_positive_angle',4*(F(1,5)-F(1,375))-F(1,239));pos('Machin_branch',1-F(4,5))
 pos('pi_lower',pil-F('3.14159'));pos('pi_upper',F(22,7)-pih)
 pos('normal_lower',1-2*pih*F('.39886')**2);pos('normal_upper',2*pil*F('.4')**2-1)
 pos('ell_lower',1-c['theta']-c['elo']**2*c['pu']*(1-c['pu']))
 pos('delta',delta-c['H']/c['elo']-F('.5'))
 pos('actual_variance',c['pl']*(1-c['pl'])-v)
 pos('segment_left',c['pl']-delta/N-c['left']);pos('segment_right',c['right']-c['pu']-delta/N)
 pos('segment_below_half',F('.5')-c['right']);pos('segment_variance',c['left']*(1-c['left'])-c['vf'])
 pos('count_positive',N*c['pl']-delta-2);pos('count_below_n',N*(1-c['pu'])-delta-2)
 pos('entropy_third',c['entropy']-(1-2*c['left'])/c['vf']**2)
 pos('log_variance_derivative',c['logder']-(1-2*c['left'])/c['vf']);pos('factorial_error',c['remainder']-1/(12*c['vf']))
 zeta=c['logder']*delta/2+c['remainder']+c['entropy']*delta**3/(6*N)
 pos('zeta_ceiling',c['zeta']-zeta);pos('sqrt_pq',c['sqrtmass']**2-c['pu']*(1-c['pu']))
 pos('mass_lower',F('.39886')/c['sqrtmass']*(1-(delta**2/(2*v)+c['zeta'])/N)-c['mass'])
 pos('mass_upper',v*(1-c['zeta']/N)**2-F('.4')**2);pos('mode_covered',delta-1)
 phase=(delta+F('.25'))/(2*v)+c['zeta']
 pos('log_variance',c['logcoef']-1/(2*v)-delta**2/(2*N*v*v))
 pos('log_ceiling',c['logcap']-(c['logcoef']*lm+phase)/N)
 if c['ef'] !=1/(1-c['logcap']):raise ValueError('exact exponential multiplier')
 pos('normal_variance',c['normal_v']-c['ef']*c['logcoef']);pos('normal_phase',c['normal_c']-c['ef']*phase)
 pos('derivative_error_lower',1-c['derivative_lo']-(c['normal_v']*lm+c['normal_c'])/N)
 pos('derivative_error_upper',c['derivative_hi']-1-(c['normal_v']*lm+c['normal_c'])/N)
 pos('variance_coefficient',c['cv']*c['pl']-1)
 pos('own_variance_upper',c['ownhi']-1-c['cv']*delta/N);pos('own_variance_lower',1-c['ownlo']-c['cv']*delta/N)
 pos('incoming_variance',c['incoming']-1-c['cv']*(delta+1)/N)
 pos('outer_variance',c['outer']-1-c['cv']*(delta+F('.5'))/N)
 denominator=1-(delta-1)/(N*c['pl']);pos('rising_denominator',denominator)
 pos('rising_ratio',c['ratio']-1-(c['pu']+delta-1)/(N*v*denominator))
 pos('rising_all_later',2-c['pu']-delta)
 vmax=c['pu']*(1-c['pu'])+lm/N
 pos('cubic_multiplier',F('.4')**2-c['repair_multiplier']**2*vmax**3)
 pos('normal_repair',4*c['repair_pos']**2*v**3-F('.4')**2)
 raw=6*c['pl']-3*c['pl']**2-F('1.5')-c['d0']-3*(1-2*v)*lm/(8*v*N)
 pos('cubic_raw',raw);pos('global_repair',c['repair']-c['repair_pos']*delta+c['repair_multiplier']*raw)
 pos('harmonic_span',F('.5')-c['span'])
 if c['span']!=c['amplitude']+c['d0']:raise ValueError('exact conditional span')
 x=F('3.14159')*c['span'];sinlo=x-x**3/6+x**5/120-x**7/5040
 pos('sine_argument',F(1)-x);pos('sine_lower',sinlo)
 pos('harmonic_rate',2*sinlo*sinlo-c['rate']*c['span']**2)
 pos('sixth_exponential_range',3-c['rate']*lm)
 pos('sixth_remainder_monotone',240-90*3+24*9-5*27)
 pos('sixth_derivative_discriminant',4*15*90-48**2)
 pos('e_upper',F(193,71)-sum(F(1,factorial(j))for j in range(9))-F(10,9*factorial(9)))
 return g
if __name__=='__main__':
 import json,hashlib
 from pathlib import Path
 g=check();print(json.dumps(dict(status='PASS_EXACT_CONDITIONAL_NORMALIZATION95_B',gates=len(g),minimum=str(min(map(F,g.values()))),config={k:str(v) for k,v in CFG.items()},gates_exact=g,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2))
