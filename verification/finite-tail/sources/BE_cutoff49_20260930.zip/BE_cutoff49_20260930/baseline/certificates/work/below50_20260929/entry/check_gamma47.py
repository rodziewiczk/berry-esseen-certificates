#!/usr/bin/env python3
"""Actual-law controls for the new conditional signed cubic inequality."""
from fractions import Fraction as F
import json,sys
import contracted_kernel as k

def need(ok,message):
 if not ok:raise ValueError(message)

def evaluate(p,noise0,noise1):
 q=1-p;law=[]
 for j,weight,noise in ((0,q,noise0),(1,p,noise1)):
  need(sum(w for _,w in noise)==1 and sum(u*w for u,w in noise)==0,'conditional centering')
  for u,w in noise:
   y=F(j)+u;need((y-p<0)if j==0 else(y-p>0),'actual sign class')
   law.append((j,y,weight*w))
 variance=sum(w*(y-p)**2 for _,y,w in law)
 third=sum(w*(y-p)**3 for _,y,w in law)
 noise=sum(w*(y-j)**2 for j,y,w in law)
 theta=noise/variance
 mean_cubic=q*(-p)**3+p*q**3
 residual=sum(w*(y-j)**2*((y-p)+2*(j-p)) for j,y,w in law)
 need(third==mean_cubic+residual,'exact conditional cubic identity')
 need(variance==p*q+noise,'variance decomposition')
 radius=max(abs(y-p)for _,y,_ in law)/k.roots(variance)[0]
 bound=k.roots((1-theta)**3*(1-2*p)**2/(p*q))[0]-(radius+2*k.roots(p/q)[1])*theta
 def is_lower(candidate):
  # Compare to the actual irrational moment by squaring with its sign,
  # rather than comparing two unrelated outward lower approximations.
  if candidate>=0:return third>=0 and candidate*candidate*variance**3<=third*third
  if third>=0:return True
  return candidate*candidate*variance**3>=third*third
 need(is_lower(bound),'actual law violates new bound')
 unpenalized=k.roots((1-theta)**3*(1-2*p)**2/(p*q))[0]
 return not is_lower(unpenalized)

def main():
 need(__debug__ and not sys.flags.optimize,'optimized Python forbidden')
 count=wrong=0
 for p in (F(1,4),F(3,10),F(1,3),F(2,5),F(9,20),F(49,100)):
  def laws(a):
   return [((F(0),F(1)),),((-a,F(1,2)),(a,F(1,2))),((-a,F(2,3)),(2*a,F(1,3))),((-2*a,F(1,3)),(a,F(2,3)))]
  for n0 in laws(p/4):
   for n1 in laws((1-p)/4):
    wrong+=evaluate(p,n0,n1);count+=1
 need(wrong>0,'missing residual penalty control never rejected')
 # The domain really excludes a zero sign class and non-centred residuals.
 rejected=0
 for p,n0,n1 in [(F(1,3),((F(1,3),F(1)),),((F(0),F(1)),)),(F(1,3),((F(-1,3),F(1,2)),(F(1,3),F(1,2))),((F(0),F(1)),))]:
  try:evaluate(p,n0,n1)
  except ValueError:rejected+=1
  else:raise ValueError('invalid decomposition accepted')
 print(json.dumps(dict(status='PASS_CONDITIONAL_GAMMA47_ACTUAL_LAWS',actual_laws=count,unpenalized_false_inequality_rejections=wrong,malformed_decomposition_controls=rejected),sort_keys=True))

if __name__=='__main__':main()
