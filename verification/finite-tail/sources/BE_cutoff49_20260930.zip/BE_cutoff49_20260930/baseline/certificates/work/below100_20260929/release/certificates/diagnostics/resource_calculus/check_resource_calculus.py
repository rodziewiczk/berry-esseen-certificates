#!/usr/bin/env python3
"""Exact polynomial and actual-law checks for the new resource-calculus lemma.

No inherited checker imports. This finite check verifies algebra identities,
not analytic expectation/coverage arguments or a replacement entry target.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import hashlib,json,sys
if not __debug__ or sys.flags.optimize: raise RuntimeError('assertions required')

def add(*polys):
 out={}
 for p in polys:
  for k,v in p.items():out[k]=out.get(k,F(0))+v
 return {k:v for k,v in out.items()if v}
def scale(p,c):return {k:v*c for k,v in p.items()if v*c}
def mul(p,q):
 out={}
 for k,v in p.items():
  for l,w in q.items():
   m=tuple(a+b for a,b in zip(k,l));out[m]=out.get(m,F(0))+v*w
 return {k:v for k,v in out.items()if v}
def power(p,n):
 out={(0,0):F(1)}
 for _ in range(n):out=mul(out,p)
 return out
X={(1,0):F(1)};A={(0,1):F(1)};one={(0,0):F(1)}
checks=[]
for j in range(2,13):
 tj={(j-2-k,k):F(k+1)for k in range(j-1)}
 lhs=add(power(X,j),scale(power(A,j),-1),scale(mul(power(A,j-1),add(X,scale(A,-1))),-j))
 rhs=mul(power(add(X,scale(A,-1)),2),tj)
 assert lhs==rhs
 # Missing final coefficient is a genuinely changed polynomial and must fail.
 bad=dict(tj);bad[(0,j-2)]+=1
 assert mul(power(add(X,scale(A,-1)),2),bad)!=lhs
 checks.append('T'+str(j))
base=power(add(X,scale(one,-1)),2)
ratios=[(add(X,scale(one,F(1,2))),add(power(X,3),scale(power(X,2),-F(3,2)),scale(one,F(1,2)))),
 (power(add(X,one),2),add(power(X,4),scale(power(X,2),-2),one)),
 (add(power(X,3),scale(power(X,2),2),scale(X,3),scale(one,F(3,2))),add(power(X,5),scale(power(X,2),-F(5,2)),scale(one,F(3,2))))]
for j,(q,rhs)in enumerate(ratios):assert mul(base,q)==rhs;checks.append('radial'+str(j))

def moments(law):
 return dict(rho=sum(p*abs(x)**3 for x,p in law),gamma=sum(p*x**3 for x,p in law),beta=sum(p*x*abs(x)for x,p in law),signed4=sum(p*x*abs(x)**3 for x,p in law))
def K(law):
 m=moments(law);return m['signed4']-3*m['beta']-F(3,2)*m['rho']*m['gamma']
def check_law(name,law):
 assert sum(p for x,p in law)==1 and all(p>0 for x,p in law)
 assert sum(x*p for x,p in law)==0 and sum(x*x*p for x,p in law)==1
 blocks=[[z for z in law if (z[0]>0)==sign]for sign in(False,True)]
 means=[sum(x*p for x,p in block)/sum(p for x,p in block)for block in blocks]
 vlaw=[(v,sum(p for x,p in block))for v,block in zip(means,blocks)]
 m=moments(law);vm=moments(vlaw);rhs=F(0);missing=F(0)
 for v,block in zip(means,blocks):
  a=abs(v)
  for xx,p in block:
   x=abs(xx);eps=1 if xx>0 else -1;w2=(xx-v)**2
   t3=x+2*a;t4=x*x+2*a*x+3*a*a
   rhs+=p*w2*(eps*(t4-3-F(3,2)*m['rho']*t3)-F(3,2)*vm['gamma']*t3)
   missing+=p*w2*eps*(t4-3-F(3,2)*m['rho']*t3)
 assert K(law)-K(vlaw)==rhs
 coarse=sum(p*xx*(abs(xx)-1)**2*(abs(xx)+2-F(3,2)*m['rho'])for xx,p in law)
 assert K(law)+3*m['rho']*m['beta']==coarse
 return {'name':name,'theta':str(sum(p*(xx-v)**2 for v,block in zip(means,blocks)for xx,p in block)),'cross_term_needed':missing!=rhs}
examples=[('symmetric_binary',[(F(-1),F(1,2)),(F(1),F(1,2))]),
 ('skew_binary',[(F(-1,2),F(4,5)),(F(2),F(1,5))]),
 ('three_point_zero',[(F(-1),F(1,3)),(F(0),F(1,2)),(F(2),F(1,6))]),
 ('four_point',[(F(-3,2),F(3,16)),(F(-1,2),F(5,16)),(F(1,2),F(5,16)),(F(3,2),F(3,16))]),
 ('near_binary',[(F(-101,100),F(199,800)),(F(-99,100),F(201,800)),(F(99,100),F(201,800)),(F(101,100),F(199,800))]),
 ('remote_tiny_atom',[(F(-8),F(1,128)),(F(0),F(63,64)),(F(8),F(1,128))])]
actual=[check_law(*e)for e in examples]
assert any(x['cross_term_needed']for x in actual)
files=[Path(__file__),Path(__file__).with_name('resource_calculus.tex')]
print(json.dumps({'status':'PASS_RESOURCE_CALCULUS_ALGEBRA','mathematical_scope':'finite polynomial identities and listed actual-law controls only','identities':checks,'actual_laws':actual,'negative_controls':'changed polynomial coefficients and dropped nonlinear cross term rejected','input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}},indent=2))
