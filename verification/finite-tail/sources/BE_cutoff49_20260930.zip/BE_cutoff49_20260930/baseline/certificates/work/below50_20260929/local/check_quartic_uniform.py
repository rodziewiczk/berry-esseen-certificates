"""Independent rational controls for the stronger all-variance quartic bound."""
from fractions import Fraction as F
import json,sys
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
A=F('.425');a=F('.4762');K=F(9)/(4*F('.4641'));den=K*a**4;T=F('1.06341')*F('.05')
cases=identities=0
for sign,b,Z,claim in [(1,-F('1.09701'),F('1.67'),F('.583')),(-1,F('.90299'),F('1.2'),F('1.082'))]:
 def exact(z,t):return (3*a*a-A*A-3*t+(2*sign*a**3+b*den-4*A*t)*z+(3*a*a*t-6*t*t)*z*z-t**3*z**4)/den
 C=(3*a*a-A*A-3*T)/den;L=2*sign/(K*a)+b-4*A*T/den;Q=(3*a*a*T-6*T*T-T**3*Z*Z)/den
 vertex=max(F(0),min(Z,-L/(2*Q)));bound=min(exact(F(0),F(0)),exact(Z,F(0)),C,C+L*Z+Q*Z*Z,C+L*vertex+Q*vertex*vertex)
 assert bound>claim
 for j in range(65):
  z=Z*j/64
  assert exact(z,T)-(C+L*z+Q*z*z)==T**3*z*z*(Z*Z-z*z)/den
  identities+=1
  for i in range(17):
   t=T*i/16;line=exact(z,F(0))*(1-t/T)+exact(z,T)*t/T
   assert exact(z,t)>=line>=min(exact(z,F(0)),exact(z,T))>=bound>claim
   cases+=1
 # A too-large own coefficient is rejected by the exact interval minorant.
 assert not bound>claim+F('.2')
print(json.dumps(dict(status='PASS_EXACT_QUARTIC_UNIFORM_CONTROLS',variance_phase_cases=cases,
 quartic_minorant_identities=identities,inflated_coefficient_rejections=2,
 scope='Independent all-variance algebra controls; the interval proof itself uses concavity and the exact quadratic minimum.')))
