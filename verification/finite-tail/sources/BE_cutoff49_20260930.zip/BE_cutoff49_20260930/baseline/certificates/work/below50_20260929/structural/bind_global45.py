"""Source/evidence binding, not a new proof or dependency rerun."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
P=Path(__file__).resolve().parents[3]
H=P/'work/below50_20260929/structural'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
docpath=P/'work/below50_20260929/root/ceiling45_dependencies.json'
doc=read(docpath)
for rel,h in doc['files'].items(): assert sha(P/rel)==h,rel
for rel in doc['executions']:
 b=P/rel; meta=read(b/'metadata.json')
 if 'jobs' in meta:
  assert len(meta['jobs'])==21 and meta['status']=='PASS_CUTOFF99_SUITE'
  rows=[(r['name']+'.',r) for r in meta['jobs']]
 else: rows=[('',meta)]
 for prefix,row in rows:
  assert row['returncode']==0
  for stream in ['stdout','stderr']:
   assert sha(b/(prefix+stream+'.txt'))==row[stream+'_sha256']
coarse='runs/below50_20260929/root_ceiling_accept01'
co=read(P/coarse/'stdout.txt')
for name,h in co['source_sha256'].items():
 assert sha(P/'work/below50_20260929/root/propagation'/name)==h,name
signed=[]
for label,obj in [('anchor45','anchor45_signed_proof.json'),('prop46','prop46_signed_proof.json')]:
 rel='runs/below50_20260929/entry/'+label+'_signed_accept01'
 meta=read(P/rel/'metadata.json')
 for name in ['signed_core.py','accept_signed_entry.py','kernel.py','high_refinement.py',obj]:
  assert sha(P/'work/below50_20260929/entry'/name)==meta['input_sha256'][name],name
 signed.append(rel)
run='runs/below50_20260929/root_ceiling45_composition02'
meta=read(P/run/'metadata.json')
assert meta['returncode']==0
for name in ['accept_ceiling45_composition.py','ceiling45_and_cutoff98.tex','ceiling45_dependencies.json','accept_predecessor_score_cap.py']:
 assert sha(P/'work/below50_20260929/root'/name)==meta['input_sha256'][name]
for stream in ['stdout','stderr']: assert sha(P/run/(stream+'.txt'))==meta[stream+'_sha256']
reserve98=sum((F(19,100*j) for j in range(95,99)),F(0))-F(7,10*94)
reserve50=sum((F(19,100*j) for j in range(47,51)),F(0))-F(7,10*46)
assert reserve98==F(4609681,10722768000)>0
assert reserve50==F(2930539,6356280000)>0
assert F('.40974')+F('.7')/95<F('.41719')
assert F('.40974')+F('.7')/93<F('.418')
assert F('.40974')+F('.7')/45<F('.4253')
extra=['work/below50_20260929/structural/GLOBAL45_COMPOSITION_REVIEW.md',
 'work/below50_20260929/structural/PREDECESSOR_CAP_REVIEW.md',
 'work/below50_20260929/structural/bind_global45.py',
 'work/below50_20260929/root/accept_ceiling45_composition.py',
 'work/below50_20260929/root/ceiling45_dependencies.json']
for name in ['metadata.json','stdout.txt','stderr.txt']: extra.append(run+'/'+name)
reviewed=[x for x in doc['files'] if x.startswith('work/')]
assert len(reviewed)==len(set(reviewed))
result=dict(schema='INDEPENDENT_CEILING45_CUTOFF98_REVIEW_V1',
 mathematical_status='Independently reviewed composition: a_n<.7/n for all n>=45 and C_n<C_E for all n>=98, conditional only on the listed established theorem dependencies. No cutoff50 claim.',
 execution_status='Fresh binding/integrity check; selected dependency executions verified against their recorded hashes, not rerun here.',
 local_floor_review={'actual_analytic_floor':95,'old_global_application_floor':96,'new_available_predecessor_cap':'.40974+.7/93<.418','own_entry_cap':'.40974+.7/95<.41719'},
 reviewed_current_sources_sha256={x:sha(P/x) for x in sorted(reviewed+extra)},
 dependency_integrity_closure=doc['files'],
 recorded_dependency_runs=doc['executions'],
 recorded_composition_run=run,
 independent_rational_reserves={'cutoff98':str(reserve98),'hypothetical_cutoff50':str(reserve50)},
 verified_selected_signed_source_runs=signed,
 limitations=['Hashes establish identity, not mathematics.','The preserved cutoff99 tail and all its analytical reductions remain explicit inputs.','Cutoff50 still needs acquired entry and complete local comparison from47.'])
(H/'GLOBAL45_COMPOSITION_BINDING.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS_GLOBAL45_REVIEW_BINDING','dependency_files':len(doc['files']),'recorded_dependency_runs':len(doc['executions']),'coarse_ceiling_source_hashes':len(co['source_sha256']),'binding_sha256':sha(H/'GLOBAL45_COMPOSITION_BINDING.json'),'reserves':result['independent_rational_reserves']},indent=2))
