"""Independent exact actual-law controls for the new signed moment bounds.

No imports from the entry constructor or acceptor. These laws are not claimed
to attain a Berry--Esseen maximum. Their purpose is sign/endpoint validation.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
assert __debug__ and not sys.flags.optimize

def binary(a):return {-a:F(1)/(1+a*a),1/a:a*a/(1+a*a)}
def mix(a,b,w):
    d={}
    for x,p in a.items():d[x]=d.get(x,F(0))+w*p
    for x,p in b.items():d[x]=d.get(x,F(0))+(1-w)*p
    return {x:p for x,p in d.items()if p}
def moments(P):
    E=lambda f:sum((p*f(x)for x,p in P.items()),F(0))
    assert sum(P.values())==1 and E(lambda x:x)==0 and E(lambda x:x*x)==1
    rho=E(lambda x:abs(x)**3);gamma=E(lambda x:x**3);beta=E(lambda x:x*abs(x))
    K=E(lambda x:x*abs(x)**3)-3*beta-F(3,2)*rho*gamma
    return rho,gamma,beta,K

def main():
    z={F(-2):F(1,8),F(0):F(3,4),F(2):F(1,8)}
    laws=[binary(F(1)),binary(F(1,2)),binary(F(2)),
          mix(binary(F(1)),binary(F(1,2)),F(999,1000)),
          mix(binary(F(2,3)),binary(F(3,4)),F(2,5)),z,
          mix(binary(F(1,10**6)),binary(F(1)),F(1,10**9)),
          mix(binary(F(1000)),binary(F(2,3)),F(1,10**12))]
    basic=boxes=events=0
    for P in laws:
        rho,gamma,beta,K=moments(P);R=max(map(abs,P))
        assert (1-beta)**3<=(1+beta)*(rho-gamma)**2;basic+=1
        low=(rho+gamma)**2/(2*(1+beta))-R*(rho-gamma)/2-3*beta-F(3,2)*rho*gamma
        high=R*(rho+gamma)/2-(rho-gamma)**2/(2*(1-beta))-3*beta-F(3,2)*rho*gamma
        assert low<=K<=high;basic+=2
        if F(0)not in P:
            p=sum(w for x,w in P.items()if x>0);q=1-p
            assert 2*p*q>=(1+beta*beta)**2/(2*rho*rho);events+=1
        if gamma<0:
            P={-x:p for x,p in P.items()};rho,gamma,beta,K=moments(P)
        for width in [F(1,10**8),F(1,1000),F(1,10)]:
            lo=max(F(1),rho-width);hi=rho+width
            gl=max(F(0),gamma-width);gh=gamma+width
            bl=max(F(-1)+F(1,10**15),beta-width);bh=min(F(1)-F(1,10**15),beta+width)
            if not bl<=beta<=bh:continue
            t=max(gl,min(gh,F(3,2)*hi*(1+bh)-lo-R*(1+bh)/2))
            kl=(lo+t)**2/(2*(1+bh))-R*(hi-t)/2-3*bh-F(3,2)*hi*t
            candidates=[gl,gh,max(gl,min(gh,lo)),max(gl,min(gh,lo+(R/2-F(3,2)*lo)*(1-bl)))]
            ku=max(R*(hi+t)/2-max(F(0),lo-t)**2/(2*(1-bl))-3*bl-F(3,2)*lo*t for t in candidates)
            assert kl<=K<=ku;boxes+=1
    rho,gamma,beta,K=moments(z)
    pp=sum(p for x,p in z.items()if x>0);pm=sum(p for x,p in z.items()if x<0)
    assert 2*pp*pm < (1+beta*beta)**2/(2*rho*rho)
    print(json.dumps(dict(status='PASS_INDEPENDENT_ACTUAL_SIGNED_MOMENT_CONTROLS',laws=len(laws),
         exact_basic_inequalities=basic,continuous_box_checks=boxes,no_zero_event_checks=events,
         rejected_unrestricted_event_claim=dict(actual_event=str(2*pp*pm),false_lower_bound=str((1+beta*beta)**2/(2*rho*rho))),
         input_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
         scope='Actual-law checks support the independently derived signed moment lemmas. The stronger opposite-sign event bound requires P(X=0)=0, as supplied by the actual gap.'),indent=2))
if __name__=='__main__':main()
