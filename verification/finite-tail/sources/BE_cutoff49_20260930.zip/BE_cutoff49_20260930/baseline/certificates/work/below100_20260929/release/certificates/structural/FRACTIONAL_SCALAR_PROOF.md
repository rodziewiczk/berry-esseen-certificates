# Exact scalar reserve

**Claim.** For every real `r` in `[0,1]`,
`1-cos(2*pi*r) <= (23/5)*r`.

For `r>=10/23`, use `1-cos<=2`. For `0<=r<=10/23`, the alternating
cosine series through degree10 is an upper bound. Indeed the ratio of
successive absolute terms after degree2 is at most
`(2*pi_upper*10/23)^2/12 < 1`, and the first omitted term is negative.

Set `pi_lower=3.141592653589793`, `pi_upper=3.141592653589794`.
Replace pi by the upper endpoint in the positive terms and by the lower
endpoint in the negative terms of the cosine upper polynomial `Q(r)`.
Then `P(r)=23/5-Q(r)/r` is a polynomial of degree9, with its removable
value at zero defined by `P(0)=23/5`.

For each of the eight closed intervals `[5j/92,5(j+1)/92]`, substitute
`r=left+(right-left)*x` and expand. The identity

`x^k = sum_{i=k}^9 binom(i,k)/binom(9,k) B_i^9(x)`

turns its ordinary coefficients into Bernstein coefficients. Every
Bernstein basis value is nonnegative on `[0,1]` and their sum is one.
All80 exact coefficients are positive, so `P>0` on the full closed
interval, including zero. Multiplication by `r>=0` proves the claim.

The pi endpoints themselves are checked using Machin's identity
`pi=16 atan(1/5)-4 atan(1/239)` and the20-term alternating arctangent
bounds, whose next positive term bounds the remainder. The tangent
calculation is rational; the angle lies in `(0,1)` and hence in the
principal tangent interval since `pi>2`.

The same check proves `3.162277660 < sqrt(10) < 3.162277661` by
integer squares. These and the pi endpoints prove
`.39886 < phi(0) < .4` and `.4095 < C_E < .40973219` by squaring
positive quantities, using `phi(0)^2=1/(2*pi)` and
`C_E^2=(3+sqrt(10))^2/(72*pi)`. In particular they also license
the weaker displayed `.3988` lower bound. All endpoint replacements
have their monotone direction checked explicitly in the code.

The fixed script `check_fractional_scalar.py` reconstructs the complete
polynomial and cover and rejects omitted, duplicated, reordered or
corrupted interval/coefficient data. It also rejects the stronger false
multiplier4. It uses Python integers and `Fraction`, with optimization
forbidden. No discovery float or omitted tail enters acceptance.

This lemma is scalar. Applying it to fractional parts and obtaining the
variance decay at support span.312 and rate14.17 are separate analytic
and exact-normalization steps in the manuscript. No older span or rate
is part of this certificate.
