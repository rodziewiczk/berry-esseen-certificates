The optional .50/.49/.475 strip scan is discovery only. Its imported
panel_exterior module was reorganized by the owner while the scan was running.
The output's source hashes were computed at completion, so that particular
module hash must not be described as a before-and-after execution binding.
The contact polynomial arithmetic was unchanged and the .50 outcome agrees
with the owner's independent recorded scan. No acceptance, final theorem or
review binding depends on this optional scan. The fixed .55 theorem is covered
by the separate frozen acceptance and PANEL_EXTERIOR50_BINDING.json.
