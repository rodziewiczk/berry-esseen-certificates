#!/usr/bin/env python3
"""Reproduce the selected finite proof obligations with source-bound logs.

The analytic reduction is in the integrated paper supplied with this supplement.
Execution is not independent mathematical verification.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import argparse,hashlib,json,os,platform,subprocess,sys,time
if sys.flags.optimize or not __debug__:raise RuntimeError("Optimized Python forbidden")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs(base):
    return {str(p.relative_to(base)):sha(p) for p in sorted(base.rglob('*'))
            if p.is_file() and p.suffix in ('.py','.json','.tex','.md')}
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--workers',type=int,default=3);a=p.parse_args()
    base=Path(__file__).resolve().parents[1];cert=base/'certificates'
    out=a.output.resolve()
    if out==base or base in out.parents:raise ValueError("Fresh logs must be outside release")
    out.mkdir(parents=True,exist_ok=False)
    config=json.loads((cert/'jobs.json').read_text());jobs=config['jobs']
    if not jobs or len({j['name']for j in jobs})!=len(jobs):raise ValueError("Missing/duplicate jobs")
    for j in jobs:
        path=(cert/j['script']).resolve()
        if cert not in path.parents or not path.is_file():raise ValueError("Invalid job path")
    before=inputs(base);start=datetime.now(timezone.utc).isoformat()
    meta=dict(status='RUNNING',cutoff=config['cutoff'],started_utc=start,
              python=sys.version,executable=sys.executable,platform=platform.platform(),
              optimization=sys.flags.optimize,input_sha256=before,jobs=[],
              trusted_stack='Unoptimized CPython standard library: exact fractions, integers and outward rational enclosures.',
              mathematical_status='Locally derived computer-assisted research proof using the separately supplied analytic reductions and literature inputs.',
              execution_status='RUNNING')
    def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    save();env=os.environ.copy();env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1'
    def run(j):
        path=cert/j['script'];cmd=[sys.executable,'-B',str(path)]+j.get('args',[])
        so=out/(j['name']+'.stdout.txt');se=out/(j['name']+'.stderr.txt');t=time.monotonic()
        with so.open('wb')as stdout,se.open('wb')as stderr:
            try:rc=subprocess.run(cmd,cwd=path.parent,env=env,stdout=stdout,stderr=stderr,timeout=1800).returncode
            except subprocess.TimeoutExpired:rc='TIMEOUT'
        row=dict(name=j['name'],kind=j.get('kind','arithmetic'),command=cmd,returncode=rc,elapsed_seconds=time.monotonic()-t,
                 stdout_sha256=sha(so),stderr_sha256=sha(se))
        try:
            raw=so.read_text()
            try:d=json.loads(raw)
            except ValueError:
                # Entry acceptors emit progress followed by one compact JSON result.
                lines=raw.splitlines(); d=json.loads(lines[-1])
                if not lines[:-1] or any(not (line.startswith('PASS ') or line.startswith('INPUT95 pass ')) for line in lines[:-1]):
                    raise ValueError('Unexpected text before final JSON')
            row['reported_status']=d.get('status')
            row['passed']=rc==0 and d.get('status')==j['expected_status']
        except (ValueError,AttributeError,UnicodeError)as e:
            row['passed']=False;row['output_error']=str(e)
        return row
    with ThreadPoolExecutor(max_workers=max(1,min(a.workers,3)))as pool:
        for row in pool.map(run,jobs):
            meta['jobs'].append(row);save();print(json.dumps(row),flush=True)
    meta['sources_unchanged']=inputs(base)==before
    meta['finished_utc']=datetime.now(timezone.utc).isoformat()
    ok=meta['sources_unchanged'] and all(j['passed']for j in meta['jobs']) and len(meta['jobs'])==len(jobs)
    meta['status']='PASS_CUTOFF'+str(config['cutoff'])+'_SUITE' if ok else 'FAILED'
    meta['execution_status']='fresh PASS' if ok else 'failed'
    save();print(json.dumps({'status':meta['status'],'jobs':len(jobs),'metadata':str(out/'metadata.json')}))
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
