#!/usr/bin/env python3
"""Continuous exact cell covers for fixed named sub100 entry contracts.

No target discovery and no file I/O. Every stage returns the bounds which a
fixed acceptor must compare strictly against its independently named targets.
"""
from fractions import Fraction as F
import kernel as k

PROFILES={
 'ANCHOR90':dict(n=90,nmax=94,R=F('3.9'),rho=F('1.72'),barrier=F('.7'),cap=F('.469'),cells=128),
 'PROPAGATE95':dict(n=95,nmax=188,R=F('3.7'),rho=F('1.778029'),barrier=F('.7'),cap=F('.469'),cells=128),
 'ENTRY95':dict(n=95,nmax=95,R=F('4.1'),rho=F('1.85'),barrier=F(0),cap=F('.41719'),cells=192),
}

def initialize(p):
 k.RADIUS=p['R'];k.K4=(k.RADIUS+1)**2/(k.RADIUS+F(1,2));k.K5=(k.RADIUS**3+2*k.RADIUS**2+3*k.RADIUS+F(3,2))/(k.RADIUS+F(1,2));k.constants()
 k.need(p['n']<=p['nmax'] and 0<=p['barrier']<3,'finite-band interface')

def stage(p,kind,raw,d):
 n,R,K,count=p['n'],p['R'],p['barrier'],p['cells'];c0=F('.4095')+K/p['nmax'];peakR=F(-1);peakD=F(-1);peakH=F(0);active=0;excluded=0;out=[]
 k.need(kind in('universal','initial','general','paired'),'named cover kind')
 if kind in('universal','initial'):
  k.need((kind=='universal')==(raw is None and d is None),'initial stage order')
  end=p['rho'] if d is None else min(p['rho'],(3+d)/(k.SL-1))
  k.need(end>1,'nonempty universal rho cover')
  event='gap'if d is not None and d<2 else'universal'
  for i in range(count):
   lo=1+(end-1)*F(i,count);hi=1+(end-1)*F(i+1,count)
   if k.score_cap(lo)<c0:excluded+=1;continue
   vals=[]
   for ep in ('lower','upper'):
    r=k.initial_cell(n,lo,hi,raw,event,ep,defect=d,score_floor=c0,own_cap=p['cap'])
    if r<0:continue
    vals.append(r);peakR=max(peakR,r)
    if raw is not None:
     b=k.initial_cell(n,lo,hi,raw,event,ep,defect=d,phase_rebate=True,score_floor=c0,own_cap=p['cap'])
     k.need(b>=0,'same moment cell exclusion agreement')
     peakD=max(peakD,15000*(b-K*lo)/(997*n))
   if vals:active+=1
   else:excluded+=1
  if raw is None:peakD=15000*(peakR-K)/(997*n)
 else:
  k.need(raw is not None and d is not None and 0<d<=F('.7'),'general previous invariants')
  geom=k.general_geometry(d)
  for i in range(count):
   lo=geom['pl']+(geom['pu']-geom['pl'])*F(i,count);hi=geom['pl']+(geom['pu']-geom['pl'])*F(i+1,count)
   z=k.general_cell(d,lo,hi,geom)
   if z is None:excluded+=1;continue
   z['Rho']=min(z['Rho'],p['rho']);z['M']=min(z['M'],1+k.K4*(z['Rho']-1));z['g']=min(z['g'],k.roots(z['M']-1)[1])
   z['Beta']=min(z['Beta'],k.roots((z['Rho']*k.roots(z['Rho']**2+8)[1]-z['Rho']**2-2)/2)[1])
   cap=min(p['cap'],F('.40974')+raw/n)
   if kind=='general':
    r=max(k.general_envelope(n,d,raw,z,cap,score_floor=c0))
    diff=max(k.general_envelope(n,d,raw,z,cap,score_floor=c0,phase_rebate=True,barrier=K))
   else:
    k.need(K==0 and d<F('.16'),'paired unsigned defect interface')
    rows=k.late_envelope(n,d,raw,z,cap);r=max(x[3] for x in rows);rmin=k.paired(n,z,d)[3];efloor=1-F(5,2)*raw/n;vals=[]
    k.need(len(rows)==4 and efloor>0,'paired four corners')
    for (A,ff,qq,_,_),rho in zip(rows,(rmin,z['Rho'],rmin,z['Rho'])):
     extra=efloor*(F('.4095')*rho-d/15)/2;k.need(extra>0,'paired conserved-phase damping');q=qq+extra
     vals.append(A+ff*ff/(4*q));peakH=max(peakH,(ff+k.roots(ff*ff+4*q*A)[1])/(2*q))
    diff=max(vals)
   peakR=max(peakR,r);peakD=max(peakD,15000*diff/(997*n));active+=1;out.append(z)
 k.need(active+excluded==count and active>0,'complete cover cardinality')
 return dict(R=peakR,D=peakD,H=peakH,active=active,excluded=excluded,moments=out)

def final_entry_bounds(p,raw,d):
 # These independent closed-cell bounds depend on the newly accepted final d,
 # rather than reusing any narrower predecessor cover.
 z=stage(p,'paired',raw,d);rows=z['moments']
 return dict(R=z['R'],D=z['D'],H=z['H'],rho=max(x['Rho']for x in rows),beta=max(x['Beta']for x in rows),M=max(x['M']for x in rows),g=max(x['g']for x in rows),theta=max(x['theta']for x in rows),A=min(x['al']for x in rows),B=min(x['bl']for x in rows))
