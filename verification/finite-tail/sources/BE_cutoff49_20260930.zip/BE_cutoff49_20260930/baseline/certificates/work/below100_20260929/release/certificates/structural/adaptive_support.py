"""Exact finite-band support under the high-score anchor contradiction."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
import uniform_support as U
assert __debug__ and not sys.flags.optimize

def target(N,last,K,R,q):
    assert type(N)is int and type(last)is int and 64<=N<=last
    assert K>0 and F('3')<=R<=F('4.5') and q>0
    c=F('.4095')+K/last
    r=F('.3031')*F('.646')/(c-F('.3031'))
    assert r>=1
    _,disc=U.sqrt_bounds((2+r*r)**2-4*(1-r*r))
    _,b=U.sqrt_bounds((disc-2-r*r)/2)
    assert 0<b<1 and (1+b*b)**2>r*r*(1-b*b)
    v=N-1;root,_=U.sqrt_bounds(F(v));_,S=U.sqrt_bounds(F(N,v))
    A=U.A;H4=U.H4
    E=U.add([0,F(3,20*v),0,0,0,F(1,100*v)],
            U.scale([-2,0,3],F(51,960*v)/root),[0,F(1,8*v*v)])
    Q=[r*F(19,50*N),3*b,F(3,2)*r,-1]
    PA=U.add(U.scale(U.add(U.mul(A,A),U.scale(U.mul(H4,H4),F(1,256*v))),F(2,5)*S**3),
             U.scale(U.mul(E,A),S**3),U.mul(U.add(U.scale(Q,c),[r*S*q]),A))
    quarter=U.add(U.scale(A,6*root),U.scale(H4,-1))
    gates=[];l=R
    while l<F('4.5'):
        h=min(F('4.5'),l+F(1,20))
        for name,p in [('A',A),('H4',H4),('quarter',quarter),('negative_C',U.scale(Q,-1)),('contact',U.scale(PA,-1))]:
            for z in U.bernstein(p,l,h):
                if z<=0:raise ValueError((name,N,last,str(K),str(R),str(q),str(l),str(z)))
                gates.append((name,str(z)))
        l=h
    cq=Q
    for j in range(4):
        z=-U.val(cq,F('4.5'))
        if z<=0:raise ValueError(('coefficient_ray',j,str(z)))
        gates.append(('coefficient_ray'+str(j),str(z)));cq=U.deriv(cq)
    ray=U.add([F(1,2)+r*S*q,F(1,5),0,F(1,15)],U.scale(Q,c))
    for j in range(4):
        z=-U.val(ray,F('4.5'))
        if z<=0:raise ValueError(('ray',j,str(z)))
        gates.append(('ray'+str(j),str(z)));ray=U.deriv(ray)
    return dict(n_band=[N,last],K=str(K),radius=str(R),slow=str(q),
                current_C_lower=str(c),rho_upper=str(r),beta_upper=str(b),
                exact_positive_gates=len(gates),gate_sha256=sha256(json.dumps(gates,separators=(',',':')).encode()).hexdigest())

def main():
    assert len(sys.argv)==1
    specs=[(80,84,'.7','3.9','1.25'),(80,84,'.7','4','1.66'),
           (80,188,'.7','3.9','.73'),(85,188,'.7','3.9','.74'),
           (90,188,'.7','3.9','.75'),(90,94,'.7','3.8','.79'),
           (90,94,'.7','3.9','1.17'),(80,188,'.9','3.9','.85'),
           (90,188,'.9','3.9','.86'),
           (90,94,'1.5','3.6','.91'),(90,94,'2','3.5','1.03'),
           (95,99,'1.5','3.51','49/94'),
           (96,99,'1','3.7','49/95'),
           (97,99,'.7','3.7','149/480'),
           (85,89,'.7','3.9','1.2'),
           (95,188,'2','3.5','2/94'),
           (95,188,'.7','3.7','7/940')]
    rows=[target(n,last,F(k),F(r),F(q))for n,last,k,r,q in specs]
    rejected=[]
    for name,args in [('reversed_band',(90,80,F('.7'),F('3.9'),F('.7'))),
                      ('false_gain',(80,188,F('.7'),F('3.9'),F('1'))),
                      ('negative_K',(80,188,F('-.7'),F('3.9'),F('.7')))]:
        try:target(*args)
        except (ValueError,AssertionError):rejected.append(name)
        else:raise AssertionError(name)
    print(json.dumps(dict(status='PASS_EXACT_FINITE_BAND_HIGH_SCORE_SUPPORT',
                         scope='Each row additionally assumes a_n>=K/n at an attained positive closed witness, with N<=n<=last. It does not supply supported stopping or a new cutoff.',
                         targets=rows,negative_controls=rejected,
                         input_sha256={p.name:sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),Path(U.__file__)]}),indent=2))
if __name__=='__main__':main()
