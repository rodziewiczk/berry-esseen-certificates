"""Fixed conditional exterior40 using one shared defect/excess budget.

All terminating decimals are exact rationals. No entry or cutoff asserted.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json,hashlib,sys
assert __debug__ and not sys.flags.optimize
def add(*ps):
    q=[F(0)]*max(map(len,ps))
    for p in ps:
        for j,c in enumerate(p):q[j]+=c
    return q
def scale(p,c):return[x*c for x in p]
def mul(p,q):
    r=[F(0)]*(len(p)+len(q)-1)
    for j,c in enumerate(p):
        for k,d in enumerate(q):r[j+k]+=c*d
    return r
def bern(p,l,r):
    n=len(p)-1
    a=[sum(p[j]*comb(j,k)*l**(j-k)*(r-l)**k for j in range(k,n+1))for k in range(n+1)]
    return[sum(a[k]*F(comb(i,k),comb(n,k))for k in range(i+1))for i in range(n+1)]

def build():
    v=[0,1,-1];bb=[1,-2,2];skew=[1,-2];c=F('1.8');gamma=F(1)
    Nb=add(scale(bb,F('3.162277660')),[-1,2],scale(v,-6))
    assert max(bern(Nb,F('.35'),F('.48')))<F('.06')
    assert 3*gamma-6*c*F('.06')>0
    cells=[];ray_gates=[]
    for sign in [-1,1]:
      for K in [F('6.162277660'),F('6.162277661')]:
        u=[F('1.6'),-1]if sign==1 else[F('.6'),1]
        P=add(scale(mul(mul(u,u),u),-K+sign),scale(mul(bb,mul(u,u)),F('1.5')*K),
              mul(mul(add(scale(skew,3*K*sign),[-3*sign]),v),u))
        E=add(scale(P,F('-.3988')),scale(mul(v,Nb),6*c),scale(v,-3*gamma))
        derivative=add(scale(mul(u,u),3*(-K+sign)),scale(mul(bb,u),3*K),mul(add(scale(skew,3*K*sign),[-3*sign]),v))
        second=add(scale(u,6*(-K+sign)),scale(bb,3*K))
        for j in range(26):
            l=F('.35')+F(j,200);r=l+F(1,200)
            coefficients=bern(E,l,r)
            assert min(coefficients)>0,('binary',sign,str(l),str(min(coefficients)))
            assert max(bern(derivative,l,r))<0
            assert max(bern(second,l,r))<0
            cells.append(dict(sign=sign,K=str(K),interval=list(map(str,[l,r])),coefficients=list(map(str,coefficients))))
    # Same-law variance transport with its negative sqrt(1-theta)*theta*rho_B term.
    assert F('1.363')**2>F(13,7)
    assert F('.9957')**2<1-F('.0085')
    price=F('1.5')*F('.40974')*F('2.5')**2*(2*F('1.363')+F('2.5')-F('.9957'))+F('2.5')*(3*F('.40974')+F('.2'))+F('1.5')
    assert price<c*F('12.321')
    K=min(3*F('4.16')*F('1.02'),3*F('6.16')*F('.73'))
    assert K-F('1.5')*F('.117')/(1-F('1.5')*F('.0085'))>0
    assert K-F('1.5')*F('.117')>F('12.321')
    # Initial inward gap; derived before concentration or confinement.
    assert F('.4749')**2<(1-F('.0085'))*F('.35')*F('.65')
    assert F('1.9977')**2*F('.46')*F('.54')<1-F('.0085')
    assert 6*F('.4749')*F('1.75')*F('1.9977')*F('.012')>F('.117')
    ef=1-F('1.15')**2/(2*40)
    assert F('.4095')*ef/2>F('.20')
    assert F('.3988')*ef/6>F('.065')
    budget_multiplier=c/F('.065')
    completed=F('.46')+F('.09')/(4*(budget_multiplier*F('.20')-F('.2')))
    assert completed<F('.465')
    reserve=gamma-(budget_multiplier*F('.75')+F('.465'))/40-F('1.155')*F('.4')
    assert reserve>F('.007')
    assert gamma-(budget_multiplier*F('.75')+F('.465'))/40-F('1.155')*F('.41')<0
    harmonic=F('.4')*sum(F(1,j)for j in range(47,51))-F('1.5')/46
    assert harmonic>0
    return dict(version='CONDITIONAL_EXTERIOR40_V1',floor=40,binary_cells=cells,
        variance_price=str(price),completed_square=str(completed),reserve=str(reserve),
        hypothetical_harmonic_47_to50=str(harmonic),
        hypotheses=dict(support=['-1.9','2.5'],p=['.35','.46'],theta='.0085',D='.117',A='.73',B='1.02',
             beta=['.075','.3'],rho='1.14',cap='.45',H='1.15',decrement='.4',T='.75',
             contact='GAUSSIAN40',budget='same-law B2'),
        conclusion='Full transformed support Y lies in(-.6,1.6); inward displacement d<.012.')

if __name__=='__main__':
    assert len(sys.argv)==1
    obj=build()
    print(json.dumps(dict(status='PASS_CONDITIONAL_EXTERIOR40',proof=obj,
         negative_controls=['decrement_.41_fails_closing_gate'],
         source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         scope='Conditional on same-law Gaussian contact, moment/gap hypotheses, exact defect decomposition and common budget. Harmonic calculation asserts no local theorem or cutoff.'),indent=2))
