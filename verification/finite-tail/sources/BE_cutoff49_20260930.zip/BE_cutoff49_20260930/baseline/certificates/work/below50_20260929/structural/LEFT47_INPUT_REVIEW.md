# Independent source review of LEFT47 acquired entry

The fresh LEFT47 input theorem is sound conditionally on the already reviewed
INITIAL47/complement chain, the actual attained oriented contact, own-score
cap.4247 and decrement<=.19. Its R3 support is supplied by the separately
reviewed LEFT_SUPPORT47_R300 theorem. No confinement or local comparison is
claimed by this entry component.

I read the complete fixed acceptor and table interface. It requires precisely
45 surviving complement source cells indexed145..189. It reruns the already
reviewed weighted local-panel kernel at R3 for32 finite steps in each cell.
The first six complete cells must be excluded; the other39 must survive and
have all four paired phase quadratics. Every resource upper bound, geometry
lower bound, signed linear coefficient and raw/budget curvature is compared
in its correct direction. Thus the remaining domain is the full closed
interval[.302,.380], with no missing boundary or singleton. The boundary.38
is also covered by the central table; overlap causes no logical issue.

The final theorem uses the same directly proved weighted nD, ntheta,
lambda and inward-gap resources reviewed in ENTRY47_PANEL_REVIEW.md; it
never obtains a weighted quantity merely by multiplying an unweighted cap.
The source object is bound by hash; schema/index/cover controls reject seven
malformed objects, and two genuine too-small arithmetic targets are rejected.
The current sources match fresh entry/left_input47_accept01. Its45 inputs,
six exclusions,39 outputs and nine controls are verified from the recorded
run. No new full arithmetic rerun is claimed by this binding.
