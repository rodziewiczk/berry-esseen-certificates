# Fixed cutoff50 certificate runner

This directory supplies a standard-library Python runner and 48 selected jobs. The files retain the workspace-shaped paths used by the proof sources. Run from a capsule containing the corresponding `work/` and `runs/` trees:

```sh
python3 -B work/below50_20260929/release_tools/run_certificates.py --output replay
```

The output directory must be new and outside the selected source directories. The runner discovers the capsule root from its own location; `--workspace-root PATH` can set it explicitly. To replay one named job, add `--only JOB_NAME`. Do not use Python `-O` or `-OO`.

## What the jobs establish

- The 35 `certificate_` jobs replay the fixed exact arithmetic acceptors, including their built-in corruption controls. They establish the numerical inequalities at each acceptor's stated scope. Their analytic reductions remain separate proof obligations.
- The 10 `control_` jobs test independent derivations, actual finite laws, or algebraic and geometric identities. Actual-law examples are adversarial checks, not continuum coverage proofs.
- `coverage_local47` independently verifies the exact closed probability/noise/phase partition and its scalar interfaces. Its read-only wrapper compares the result and source hashes with the frozen object.
- `conditional_selector50` checks the finite four-step index and decrement calculation. It requires the local theorem as an input.
- `integrity_ceiling45_composition` verifies the earlier ceiling composition and its recorded dependencies. Its historical output describes cutoff50 as conditional because it predates the later local proof. The separate final `root/accept_cutoff50_composition_v2.py` and `root/cutoff50_dependencies_v2.json` assemble the final result; they are not relabeled as part of this earlier job.

The earlier cutoff99 theorem supplies the tail beyond the newly checked finite range. Its sources, proof, recorded 21-job replay, and the dependency manifests remain required. The 48 jobs do not silently replace that inherited theorem or the published mathematical inputs.

## Logs and integrity

Each job record has exactly `name`, `cwd`, `argv`, and `source_run`. The last field identifies its earlier successful run for provenance; the runner executes each selected job afresh and records the actual new return code. Some integrity acceptors themselves verify recorded dependency logs, so the capsule must also include the files named in their fixed dependency manifests.

The runner records interpreter/version information, stdout and stderr hashes, commands, elapsed times, and hashes of `.py`, `.json`, and `.tex` files beneath selected working directories. It compares the source snapshot before and after the suite and rejects a changed snapshot. It also hashes itself and `jobs.json`. This snapshot has an explicit scope: the release manifest and per-certificate manifests cover imported or inherited files outside those directories. Hash agreement establishes byte identity, not mathematical validity.

`build_jobs.py` generated the frozen job list from successful logged commands. It is provenance tooling and is not needed for replay. `local/final_review/check_release_runner.py` supplies disposable runner controls. No mathematical certificate is inferred from these runner tests.
