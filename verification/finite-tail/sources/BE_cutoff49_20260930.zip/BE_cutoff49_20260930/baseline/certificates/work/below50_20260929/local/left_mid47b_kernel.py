"""Exact interval arithmetic for conditional LEFT_MID47_B; witnesses select valid quartic bounds."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from left_sperner47_contract import input_table,AMPLITUDES,unique
from left_mid47_normalization import check as normcheck
from mid47a_kernel import poisson,SCALES
from tiny47a_kernel import ceiling
from functools import lru_cache
from math import factorial
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
REGIONS=((F('.05'),F('.06'),F('.09'),F('.375')),(F('.06'),F('.08'),F('.14'),F('.375')),(F('.08'),F('.10'),F('.19'),F('.325')),(F('.10'),F('.12'),F('.29'),F('.30')))
def need(b,s):
 if not b:raise ValueError(s)
def digest(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def own(choice,sign,l,h,tl,th,A,c):
 need(type(choice)is int and 0<=choice<=57,'Invalid quartic witness')
 if choice==56:
  need(sign==-1,'Cantelli sign');return l*l/(th+l*l)-c['derivative_hi']*h
 if choice==57:
  need(sign==1,'Normal sign');return c['derivative_lo']*l
 a=SCALES[choice];den=F(9)/(4*F('.4641'))*a**4;vals=[];sigma=1 if sign<0 else -1;deriv=-c['derivative_hi']if sign<0 else c['derivative_lo']
 for t in(tl,th):
  co=((3*a*a*t-A*A*t-3*t*t)/den,(2*sigma*a**3-4*A*t)/den+deriv,(3*a*a-6*t)/den,F(0),-1/den)
  vals.append(sum(v*(l if v>=0 else h)**i for i,v in enumerate(co)))
 return min(vals)
@lru_cache(None)
def log_lower_series(y):return 2*sum(y**(2*j+1)/(2*j+1)for j in range(20))
@lru_cache(None)
def tail_bennett(a,V,b):
 need(a>0 and V>0 and b>0,'Bennett parameters')
 x=1+a*b/V;power=0
 while x>=2:x/=2;power+=1
 lo=power*log_lower_series(F(1,3))+log_lower_series((x-1)/(x+1))
 exponent=(b/a+V/(a*a))*lo-b/a;need(0<exponent<16,'Bennett exponent')
 small=F(exponent.numerator*10**12//exponent.denominator,10**12);need(0<=small<=exponent,'Directed exponent floor')
 return ceiling(1/(sum((small/16)**j/F(factorial(j))for j in range(17))**16))
def contexts():
 declared=json.loads((HERE/'left_mid47b_normalization.json').read_text(),object_pairs_hook=unique)
 need(declared['schema']=='LEFT_MID47B_NORMALIZATION_V1','Normalization schema')
 actual=input_table()['panels'];expected=[r['index']for r in actual if F(r['lambda_max'])>F('.05')]
 need([r['index']for r in declared['rows']]==expected,'Normalization ordered coverage')
 for row in declared['rows']:
  r=actual[row['index']];c={k:F(v)for k,v in row['constants'].items()};need(c['N']==47 and c['pl']==F(r['p'][0])and c['pu']==F(r['p'][1])and c['theta']==F(r['theta'])and c['d0']==F(r['d0'])and c['H']==max(F(r['H_minus']),F(r['H_plus']))and c['lmax']==min(F('.12'),F(r['lambda_max'])),'Normalization premises changed')
  gates=normcheck(c)
  for bi,(lo,end,start,amp)in enumerate(REGIONS):
   hi=min(end,F(r['lambda_max']))
   if lo>=hi:continue
   A=min(amp,F(AMPLITUDES[r['index']]));steps=int((F('.5')-start)*1000);need(start+F(steps,1000)==F('.5'),'Exact closed phase cover')
   for sign in((-1,)if bi==3 else(-1,1)):yield r['index'],bi,lo,hi,start,A,steps,sign,c,gates

def reconstruct(proposed=None,chooser=None):
 blocks=[];gatecount=normalcount=0;mins={};seen_normal=set();phasecount=0;minimum=None
 for index,bi,lo,hi,start,A,steps,sign,c,ng in contexts():
  key=len(blocks)
  if proposed is not None:
   need(key<len(proposed),'Missing block');choices=proposed[key]['witnesses'];need(type(choices)is list and len(choices)==steps,'Witness cover mismatch')
  else:choices=[]
  if index not in seen_normal:seen_normal.add(index);normalcount+=len(ng)
  tl=c['ownlo']*lo;th=c['ownhi']*hi;V=c['incoming']*hi;mu=V/A**2;records=[];bmin=None
  for j in range(steps):
   l=start+F(j,1000);h=start+F(j+1,1000)
   if proposed is None:choice=chooser(sign,l,h,tl,th,A,c);choices.append(choice)
   else:choice=choices[j]
   lower=own(choice,sign,l,h,tl,th,A,c)
   distance=1+l if sign<0 else 1-h;outerdist=F(1)if sign<0 else 1-h/2
   pc,anchor=poisson(mu,distance/A);first=min(pc,V/(V+distance**2),tail_bennett(A,V,distance));outer=tail_bennett(A,V,outerdist)
   need(0<outer<1,'Outer probability domain');bracket=lower-c['ratio']*(first+outer*outer/(1-outer));reserve=c['mass']*bracket-c['repair']*hi/47;values={'outer':1-outer,'bracket':bracket,'score':reserve-F('.001')*hi}
   for name,value in values.items():need(value>0,f'Nonpositive {index}/{bi}/{sign}/{j}/{name}: {value}');mins[name]=min(mins.get(name,value),value)
   minimum=reserve if minimum is None else min(minimum,reserve);bmin=reserve if bmin is None else min(bmin,reserve)
   records.append([j,choice,str(lower),str(first),str(anchor),str(outer),str(reserve)]);gatecount+=3;phasecount+=1
  blocks.append(dict(index=index,band=bi,sign=sign,noise=[str(lo),str(hi)],phase=[str(start),'1/2'],amplitude=str(A),witnesses=choices,arithmetic_sha256=digest(records),minimum_reserve=str(bmin)))
 if proposed is not None:need(len(proposed)==len(blocks),'Extra blocks')
 need(len(blocks)==217 and phasecount==74370,'Fixed phase/noise/p cover size')
 return dict(schema='CONDITIONAL_LEFT_MID47_B_V1',contract=dict(N=47,input_sha256=sha256((HERE/'left270_input47_table.json').read_bytes()).hexdigest(),phase_width='1/1000',comparison='rho_B(C-C_B)<-.001lambda',regions=[[str(x)for x in r]for r in REGIONS]),blocks=blocks,gates=gatecount+normalcount,phase_cells=phasecount,normalization_gates=normalcount,minimum_reserve=str(minimum),minimum_gates={k:str(v)for k,v in mins.items()})
