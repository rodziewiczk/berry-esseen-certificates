# Earlier support: exact hypotheses and results

This is a new support theorem, not a cutoff-50 claim. The cutoff-99 release
and its historical evidence remain unchanged.

| Result | Mathematical status | Execution status |
| --- | --- | --- |
| `e_n < .384/n` for every `n>=36` | Independently derived positive polynomial after squaring | Fixed exact scale gates pass |
| Both published finite caps in a high-score band | Direct simultaneous consequence for the same current law | Both rational denominators and the sign-moment root checked |
| Fifth-order all-threshold heat bound | New finite Taylor/Fourier proof, all real raw thresholds | 77 named basic/fifth rows pass 74,596 exact gates and 12 rejection controls |
| Unrestricted support radius3.84 from36 with decrement.19 (from40 with decrement.20) | Complete contiguous finite-band union plus an infinite tail | 10,200 exact gates and six bad-cover/false-target controls pass |
| Threshold and sign adversarial checks | Diagnostics only, not continuous-domain proof | 1,792 checks pass; largest sampled remainder/allowance is .71947 |
| Earlier supported entry or cutoff 50 | Not implied by these results | Separate work is required |

## Exact scope

Let `(P,H)` be an attained positive closed maximizing pair, with `EX=0`,
`EX^2=1`, `C=C_n>=C_E`, and `d_n=n(C_(n-1)-C_n)_+`. On a finite band
`N<=n<=L`, also suppose `C_n-C_E >= K/n`. The following rows imply that
the **complete actual support** of P lies in `(-R,R)` when `d_n<=q`.
The constants come from the same law, without a threshold bound:

`c=.4095+K/L`,

`rho < min(.3031*.646/(c-.3031), .3322*.429/(c-.3322))`.

The upper endpoint L is essential. These bounds cannot use `K/N` as a
lower bound for the excess throughout the band.

Selected fixed rows (every decimal below is exact; rho is rounded upward
here for readability):

| Band | K | rho upper | R | q, basic heat | q, fifth-order heat |
| --- | ---: | ---: | ---: | ---: | ---: |
| 42..43 | 1.5 | 1.270361 | 3.0 | 1.09 | 1.18 |
| 42..43 | 2 | 1.151054 | 2.8 | 1.40 | 1.47 |
| 45..46 | 1.5 | 1.296657 | 3.0 | .90 | .98 |
| 45..46 | 1.5 | 1.296657 | 3.1 | 1.25 | 1.34 |
| 45..46 | 2 | 1.179963 | 2.8 | 1.15 | 1.21 |
| 45..46 | 2 | 1.179963 | 3.0 | 1.93 | 2.02 |
| 45..49 | 1.5 | 1.320646 | 3.1 | 1.06 | 1.15 |
| 45..49 | 2 | 1.206555 | 3.0 | 1.66 | 1.75 |
| 45..50 | 1.5 | 1.328181 | 3.1 | 1.00 | 1.09 |
| 45..50 | 2 | 1.214952 | 3.0 | 1.58 | 1.66 |

There are also unrestricted, all-index rows without a positive K barrier:
`n>=36,R4.1,q.79`; `n>=40,R4.1,q.83`; `n>=45,R4.1,q.87`;
`n>=50,R4.1,q.90`; `n>=60,R4.1,q.95`.

The sharper fifth-order rows give `R3.9` at floors40/45/50 with
decrements `.27/.29/.31`, respectively. More usefully, a complete union
of finite index bands retains the favorable fifth coefficient and proves
`R3.84` for every `n>=36,d_n<=.19`, and for every `n>=40,d_n<=.20`.
The fixed bands are36..39,40..44,45..49,50..59,60..89,90..134,135..199,
followed by200..infinity. The second statement starts at the second band.

## The new argument

The earlier `n>=64` restriction belonged to the estimate `e_n<.38/n`.
The heat expansion itself had no such restriction. The new `.384/n`
bound starts at 36 by a fresh polynomial sign, and the coupling conditions
are checked anew on every selected support interval.

The fifth-order expansion keeps the negative term
`-(u^5-15u)/(120(n-1))*phi''''(H/sqrt(n-1))` for positive support points.
The Fourier integral and `cos w >= 1-w^2/2` give the global inequality
`phi''''(z)>=phi(0)*(3-15z^2/2)`. Combining this with the cubic/quartic
terms turns the central-threshold estimate into one completed square.
Both signs and the remaining thresholds have a separate domination gate.
The remainder is finite and explicit, of order `u^6/(n-1)^(3/2)`.

On a finite index band, the favorable fifth-order coefficient is frozen
at the **upper** endpoint and adverse coefficients at the lower one.
No monotonicity of a signed correction is assumed. For an infinite index
range, that favorable term is replaced by zero.

All coefficient conditions are polynomials after multiplication by a
proved positive denominator. The acceptance uses complete closed
Bernstein covers through radius4.5, then four exact cubic derivative
signs on the entire remaining ray. Hence tiny exterior atoms and support
accumulation points are excluded by actual contact, not by moment bounds
alone. The old full-support/contact reduction is still a required input.

## Files and fresh evidence

- `support50_proof.tex` and `build02/support50_proof.pdf`: four-page proof,
  including the complete all-index theorem and selected high-score rows.
- `heat_support50.py`: new scale and dual-cap basic heat reduction.
- `fifth_heat50.py`: fifth-order polynomial reduction.
- `support50_specs.py`: fixed finite-band statements.
- `accept_support50.py`: fixed 77-row acceptance, no target arguments.
- `accept_unrestricted_fifth50.py`: nine additional all-index support rows.
- `accept_unrestricted_cover50.py`: two complete index-cover theorems.
- `runs/below50_20260929/structural/support_accept03/`: exact fresh PASS.
- `runs/below50_20260929/structural/unrestricted_fifth_accept03/`:4,392 gates
  and three false-scope controls.
- `runs/below50_20260929/structural/unrestricted_cover_accept03/`:10,200 gates
  and six bad-cover/false-target controls.
- `runs/below50_20260929/structural/fifth_diagnostics01/`: adversarial
  floating diagnostics, explicitly not an acceptance certificate.
- `runs/below50_20260929/structural/compile03/`: clean four-page build.
  The earlier failed table-layout compile is preserved separately.

Discovery versions and their source hashes are retained in distinct runs.
The older single-cap discoveries are not silently relabeled as dual-cap
proof objects. No old accepted theorem was weakened in place.
