"""Construction only; read-only acceptance is accept_tiny47a.py."""
from pathlib import Path
from hashlib import sha256
import json
from fractions import Fraction as F
from tiny47a_kernel import evaluate
HERE=Path(__file__).resolve().parent
o=evaluate()
if o['bad'] or any(F(v)<=0 for v in o['gates'].values()):raise ValueError('Unclosed arithmetic')
o['source_sha256']={n:sha256((HERE/n).read_bytes()).hexdigest()for n in ('tiny47a_kernel.py','tiny47a_normalization.py')}
p=HERE/'tiny47a_certificate.json'
with p.open('x')as f:json.dump(o,f,indent=2);f.write('\n')
print(json.dumps(dict(status='BUILT_CONDITIONAL_TINY47_A',gates=len(o['gates']),sha256=sha256(p.read_bytes()).hexdigest())))
