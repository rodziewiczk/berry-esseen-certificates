"""Strict fixed acceptance of the complete closed LOCAL95B LOW cover."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys,copy
from normalization95b import check
from low95b_contract import contract
from low95b_kernel import evaluate
assert __debug__ and not sys.flags.optimize
def need(x,msg):
    if not x:raise ValueError(msg)
def same(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
    return a==b
def unique(rows):
    d={}
    for k,v in rows:need(k not in d,'duplicate JSON key');d[k]=v
    return d
def expected():
    check();c=contract();_,r=evaluate(c)
    need(not r['failed_gates'],'all exact gates strictly positive')
    need(r['feasible_cells']+r['empty_cells']==32*32*70,'complete rectangle cover')
    need(r['endpoints']==2*r['feasible_cells'],'two exact noise endpoints per feasible box')
    need(F(r['worst_score'])<F('-.001'),'uniform strict comparison target')
    return dict(version='LOW95_B_FIXED_V1',noise_intervals=[list(map(str,b))for b in c['noise_intervals']],
        counts={k:r[k]for k in ['gates','endpoints','feasible_cells','empty_cells','phase_envelope_cells']},
        gate_sha256=r['gate_sha256'],worst_score=r['worst_score'],target='-1/1000',
        constants={k:str(v)for k,v in c.items()if type(v)in(int,F)})
def validate(obj,want):need(same(obj,want),'exact fixed LOW95B object')
def controls(obj):
    mutations=[]
    def add(name,f):
        b=copy.deepcopy(obj);f(b);need(not same(b,obj),'nontrivial mutation');mutations.append((name,b))
    add('missing',lambda b:b.pop('gate_sha256'))
    add('extra',lambda b:b.update(extra=0))
    add('missing_band',lambda b:b['noise_intervals'].pop())
    add('duplicated_band',lambda b:b['noise_intervals'].append(b['noise_intervals'][0]))
    add('reordered',lambda b:b['noise_intervals'].reverse())
    add('endpoint',lambda b:b['noise_intervals'][0].__setitem__(0,'1/40'))
    add('wrong_hash',lambda b:b.__setitem__('gate_sha256','0'*64))
    add('wrong_score',lambda b:b.__setitem__('worst_score','-1'))
    add('changed_target',lambda b:b.__setitem__('target','0'))
    add('wrong_scope',lambda b:b['constants'].__setitem__('N','94'))
    add('bool_count',lambda b:b['counts'].__setitem__('gates',True))
    add('float_count',lambda b:b['counts'].__setitem__('gates',float(b['counts']['gates'])))
    add('wrong_cardinality',lambda b:b['counts'].__setitem__('empty_cells',b['counts']['empty_cells']+1))
    result=[]
    for name,b in mutations:
        try:validate(b,obj)
        except ValueError:result.append(name)
        else:raise ValueError('mutation accepted '+name)
    for name,raw in [('malformed','{'),('duplicate_key','{"version":1,"version":2}')]:
        try:validate(json.loads(raw,object_pairs_hook=unique),obj)
        except ValueError:result.append(name)
        else:raise ValueError('malformed input accepted '+name)
    return result
if __name__=='__main__':
    need(len(sys.argv)==1,'no adjustable acceptance options')
    here=Path(__file__).resolve().parent
    obj=json.loads((here/'low95b_certificate.json').read_text(),object_pairs_hook=unique)
    want=expected();validate(obj,want);tests=controls(want)
    print(json.dumps(dict(status='FRESH_PASS_EXACT_LOW95_B',counts=want['counts'],gate_sha256=want['gate_sha256'],
        worst_score=want['worst_score'],negative_controls=tests,
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in
          [Path(__file__),here/'low95b_contract.py',here/'low95b_kernel.py',here/'normalization95b.py',here/'low95b_certificate.json']},
        scope='Conditional actual-law LOW95B, with separate analytic count reduction, INPUT95B, confinement, normalization and tiny/MID coverage obligations.'),indent=2))
