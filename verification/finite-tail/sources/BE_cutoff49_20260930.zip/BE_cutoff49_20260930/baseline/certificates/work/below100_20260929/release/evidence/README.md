# Execution evidence

`cpython312_suite/` is the complete 21-job run on CPython 3.12.14. It binds
the final certificate arithmetic sources; only final manuscript spacing,
last-page prose and bibliography layout were edited afterwards. The final
manuscript/PDF binding and rendering record are under `review/`.

The final exact ZIP is additionally extracted and all 21 jobs are replayed
on CPython 3.9.6. That evidence is bound outside the archive by the separate
delivery verification JSON, avoiding a circular archive hash.

A fresh arithmetic PASS verifies finite numerical obligations only. The
analytic reductions, literature-input scope and assembled implication have
separate mathematical review documents.
