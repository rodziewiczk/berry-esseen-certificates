"""Independent rational product-law controls for active forward marks.
These finite examples supplement the continuum proof, not replace it.
"""
from fractions import Fraction as F
from collections import defaultdict
import json,sys
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
def two(a,b):
 a,b=F(a),F(b);return {-a:b/(a+b),b:a/(a+b)}
def conv(a,b):
 out=defaultdict(F)
 for x,p in a.items():
  for y,q in b.items():out[x+y]+=p*q
 return dict(out)
def power(law,n):
 out={F(0):F(1)}
 for _ in range(n):out=conv(out,law)
 return out
zero={F(0):F(1)}
laws=[(zero,zero),(two('.4','.001'),zero),(zero,two('.001','.4')),
 (two('.4','.001'),two('.002','.35')),
 (two('.4',F(1,10**10)),two(F(1,10**9),'.4')),
 (two('.5','.01'),two('.01','.5')),
 ({-F('.4'):F(1,100),F(0):F(59,100),F('.01'):F(2,5)},two('.01','.4'))]
marks=pairs=centers=collisions=gains=0
for u0,u1 in laws:
 for law in(u0,u1):assert sum(law.values())==1 and sum(x*p for x,p in law.items())==0
 d=max(u0)-min(u1);c=1-d;A=max(abs(x)for law in(u0,u1)for x in law)
 em=sum(max(F(0),x-y)*p*q for x,p in u0.items()for y,q in u1.items())
 s0=sum(x*x*p for x,p in u0.items());s1=sum(x*x*p for x,p in u1.items())
 for n in range(2,7):
  for k in range(1,n):
   bg=conv(power(u1,k-1),power(u0,n-k-1));a0=conv(bg,u1);a1=conv(bg,u0)
   vz=sum(x*x*p for x,p in bg.items());t=k*s1+(n-k)*s0
   assert vz==t-s0-s1
   for i in(1,2,3):
    for eta in(F(0),F('.03')):
     phases={F('-.5'),F('-.1'),F(0),F('.1'),F('.5')}
     phases.update(z+x+c*i for z in a0 for x in u0 if abs(z+x+c*i)<=F('.5'))
     phases.update(z-d+c*i for z in a0 if abs(z-d+c*i)<=F('.5'))
     phases.update(z-eta-i+A for z in a1 if abs(z-eta-i+A)<=F('.5'))
     for u in phases:
      marked=sum(max(F(0),x-y)*p*q*r for z,r in a0.items()for x,p in u0.items()for y,q in u1.items()if z+x<=u-c*i)
      fnew=sum(p for z,p in a0.items()if z<=u+d-c*i)
      fold=sum(p for z,p in a0.items()if z<=u+A-c*i)
      assert marked<=em*fnew
      if A>=d:assert fnew<=fold
      marks+=1;gains+=(em*fnew<em*fold)
      collisions+=any(z+x==u-c*i for z in a0 for x in u0)
      backward=sum(p for z,p in a1.items()if z>u+eta+i-A)
      L=u+2*d-c*i;R=u+eta+i-A-d
      if L>=R:continue
      union=sum(p for z,p in bg.items()if z<=L or z>R)
      assert fnew+backward<=union
      pairs+=1
      candidates={(L+R)/2}
      if L<0<R:
       candidates.add(max(L+F(1,1000000),min(R-F(1,1000000),-vz/L)))
       candidates.add(max(L+F(1,1000000),min(R-F(1,1000000),-vz/R)))
      for z0 in candidates:
       if not L<z0<R:continue
       rad=min(z0-L,R-z0)
       assert union<=(vz+z0*z0)/(rad*rad)<=(t+z0*z0)/(rad*rad)
       centers+=1
# Show why the restriction to active marks is essential. An unmarked U0 may
# have a large negative value, so replacing its amplitude by d is invalid.
u0=two('.4','.01');u1=zero;threshold=-F('.2');d=F('.01')
assert sum(p for x,p in u0.items()if x<=threshold)>0
assert not(0<=threshold+d)
print(json.dumps(dict(status='PASS_EXACT_ACTIVE_MARK_CONTROLS',law_pairs=len(laws),marked_inequalities=marks,
 projected_pair_inequalities=pairs,quadratic_bounds=centers,atom_collisions=collisions,
 strict_mark_gains=gains,unmarked_replacement_rejected=1)))
