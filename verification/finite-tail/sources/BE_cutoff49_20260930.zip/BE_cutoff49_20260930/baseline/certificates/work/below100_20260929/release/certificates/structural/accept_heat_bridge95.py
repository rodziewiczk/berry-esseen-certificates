"""Fixed all-H heat bridge from radius4.1 to2.5 at n>=95.

Conditional on the attained contact/predecessor identity and on one actual
law's prior support, rho and beta bounds. The finite heat estimate is proved
in uniform_support.tex and no threshold bound is used.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
import uniform_support as U
assert __debug__ and not sys.flags.optimize

def build(start=F('2.5')):
    N=95;v=N-1;r=F('1.15');b=F('.31');c=F('.4095');q=F('.2')
    root,_=U.sqrt_bounds(F(v));_,S=U.sqrt_bounds(F(N,v))
    A=U.A;H4=U.H4
    E=U.add([0,F(3,20*v),0,0,0,F(1,100*v)],
            U.scale([-2,0,3],F(51,960*v)/root),[0,F(1,8*v*v)])
    Q=[r*F(19,50*N),3*b,F(3,2)*r,-1]
    PA=U.add(U.scale(U.add(U.mul(A,A),U.scale(U.mul(H4,H4),F(1,256*v))),F(2,5)*S**3),
             U.scale(U.mul(E,A),S**3),U.mul(U.add(U.scale(Q,c),[r*S*q]),A))
    quarter=U.add(U.scale(A,6*root),U.scale(H4,-1))
    gates=[];cells=[];l=start
    while l<F('4.1'):
        h=min(F('4.1'),l+F(1,20));reserve=[]
        for name,p in [('A',A),('H4',H4),('quarter',quarter),('negative_C',U.scale(Q,-1)),('contact',U.scale(PA,-1))]:
            bs=U.bernstein(p,l,h)
            if min(bs)<=0:raise ValueError((name,str(l),str(min(bs))))
            gates.extend((name,str(z))for z in bs)
            reserve.append([name,str(min(bs))])
        cells.append(dict(interval=[str(l),str(h)],minimum_coefficients=reserve));l=h
    return dict(schema='ALL_THRESHOLD_HEAT_BRIDGE95_V1',floor=95,
                hypotheses=dict(prior_support=['-4.1','4.1'],rho_upper='1.15',beta_absolute_upper='.31',
                                decrement_upper='.2',score_lower='CE',threshold='all real H'),
                conclusion='The complete actual support is contained in(-2.5,2.5).',
                cells=cells,exact_positive_gates=len(gates),
                minimum_contact_coefficient=str(min(F(z)for name,z in gates if name=='contact')),
                gate_sha256=sha256(json.dumps(gates,separators=(',',':')).encode()).hexdigest())

def main():
    assert len(sys.argv)==1
    obj=build();assert len(obj['cells'])==32
    try:build(F('2'))
    except ValueError:pass
    else:raise AssertionError('false radius2 accepted')
    print(json.dumps(dict(status='PASS_EXACT_ALL_THRESHOLD_HEAT_BRIDGE95',proof=obj,
                         negative_controls=['false_radius2'],
                         input_sha256={p.name:sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),Path(U.__file__)]},
                         scope='Same-law conditional support only; no moment entry, global caps or cutoff inferred.'),indent=2))
if __name__=='__main__':main()
