# Independent review: INITIAL47 and probability-panel acquisition

Mathematical status: conditional analytic/source review complete; no defect
found in the selected initialization, central and complementary acquisition
components. Execution status: current executed sources match the fresh
INITIAL47 (16 controls), PREP47 (6), INPUT47 (8), complement (6), and left
support (3 false-target controls) replays. These components do not prove a
complete LOCAL47 theorem or cutoff50.

## Scope and route

INITIAL47 consumes n>=47, actual support |X|<=3.84 and CE<=C<=.4247.
Its signed cover was independently audited in INITIAL47_DELTA_REVIEW.md.
The final fresh replay covers100 closed probability cells, with all signed
moment incidences checked and the final central-gap license checked before
interpreting empty probability cells. The unused upper index98 in this
zero-barrier invocation imposes no hidden restriction on n.

PREP47 consumes that table on [.38,.48], excludes [.47,.48], and establishes
nine surviving broad cells. Their upper moment/threshold bounds and the
lower beta identity imply the selected root support47 radius-row premises.
That separate contact theorem also requires the actual oriented contact,
0<=a<=.7/n and decrement<=.19; these are explicit external premises.
Its R2.5 conclusion then supplies INPUT47, which verifies all45 closed
canonical cells on [.38,.47]. All four signed phase quadratics and both
curvatures are checked against the fixed canonical table.

The complement check covers [.25,.38] union [.48,.60] in125 closed cells.
The other probability cells are empty in the accepted INITIAL47 table.
Survivors lie in [.29,.38], with rho<1.390 and |beta|<.430. The fixed
LEFT_SUPPORT47_R300 row licenses actual support(-3,3) under decrement<=.19
and the actual attained contact. It uses30 closed fifth-order intervals
through4.5, all1448 rational gates, and the complete far rays, uniformly in H.
The temporary in-memory substitution of the two named moment constants is
restored in a finally block and exactly matches the previously proved
parameterized contact formula. It changes no source. Its three false targets
are genuine arithmetic rejections. No previous support premise is needed.

## Weighted resources

I independently checked the new all-index step. From nD<=Nd and the exact
joint central-gap bound D>=b_*+K theta with b_*>=0,K>0,

    n theta <= (Nd-n b_*)/K <= N(d-b_*)/K.

Negative residual excludes a cell even when n>N. The initial unweighted
theta bound is used only to construct b_* and other uniform geometry; it
is never multiplied by N as though it were weighted. Outward lower square
roots and an upper square root in the divisor make b_* a lower bound.

The shared shift inequality also retains its binary charge:
D>=b_*+6m(A_l+B_l)(Delta_A+Delta_B)+K theta.
Using m(Abar+Bbar)=1-theta yields both the unweighted inward-gap bound
and its N-times weighted version. The final export recomputes the resource
from the newest valid defect and previous valid geometry. Geometry does not
have to be sharp after the final defect update; being older makes it only
weaker. lambda=npq theta/(1-theta) then has the stated uniform bound.

The initial endpoint formula uses m>=sqrt((1-Theta)min pq),
A+B>=sqrt(2-d), and the shared shift bound with nonnegative charges dropped.
Every divisor is positive and the initialized lower endpoints must be
positive; a failed gate is not an exclusion. The finite iterations use only
previously licensed bounds, including moment caps. No convergence assertion
is needed.

## Phase exports and coverage

For fixed signed h=|H|, the raw upper expression is separately convex in
the score and rho rectangle. Taking four endpoint upper quadratics is
therefore valid. The signed linear coefficient uses the correct maximum
for H>=0 and negative minimum for H<=0. Upper coefficients and lower
curvatures are compared separately against the canonical table. A negative
linear coefficient causes no reversal because h>=0. The positive root is
computed with an outward upper square root and a positive curvature.
The conserved-budget curvature already includes its Gaussian phase charge;
it must not be subtracted a second time in later confinement/LOW.

The paired event and coefficient domains are explicitly checked before
use. HIGH_WINDOW50 is installed into both actual event paths and keeps all
six frequency pieces. All-index damping gates remain checked at the floor.
All covers use closed intervals with shared boundaries; no singleton is
removed. Fine cells inherit the broad upper bounds and then narrow only p.
The selected global cap is a separate premise, not inferred from a small
remainder without its exact remainder identity.

The canonical table retains its discovery provenance text. The new fixed
acceptor establishes its numerical rows conditionally on this acyclic chain;
it does not retroactively turn the original floating generation into a proof.
The accompanying binding checks source/evidence integrity and the explicit
broad-to-contact and all-p coverage seams; it does not rerun the expensive
entry arithmetic or replace the already reviewed analytic reductions.
