"""Read-only fixed acceptance for CONDITIONAL_MID47_A."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import copy,json,sys
from mid47a_kernel import evaluate,poisson_numerator,REGIONS
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
SOURCES=('mid47a_kernel.py','mid47a_normalization.py','tiny47a_kernel.py','tiny47a_normalization.py')
def need(x,s):
 if not x:raise ValueError(s)
def unique(rows):
 d={}
 for k,v in rows:need(k not in d,'Duplicate JSON key');d[k]=v
 return d
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def reconstruct():
 o=evaluate();need(not o['bad']and all(F(v)>0 for v in o['gates'].values()),'Nonpositive rational gate')
 expected=[]
 for bi,(_,_,start,_)in enumerate(REGIONS):
  for sign in(-1,1):
   for j in range(int((F('.5')-start)*1000)):
    expected.append((bi,sign,[str(start+F(j,1000)),str(start+F(j+1,1000))]))
 need([(r['band'],r['sign'],r['phase'])for r in o['rows']]==expected,'Fixed closed phase/sign cover')
 o['source_sha256']={s:sha256((HERE/s).read_bytes()).hexdigest()for s in SOURCES};return o
def validate(o,w):need(same(o,w),'Fixed scope/source/arithmetic/cover mismatch')
def controls(w):
 tests=[]
 def reject(name,f):
  x=copy.deepcopy(w);f(x)
  try:validate(x,w)
  except ValueError:tests.append(name)
  else:raise ValueError('Accepted mutation: '+name)
 reject('missing',lambda x:x.pop('rows'));reject('extra',lambda x:x.update(extra=1));reject('theorem',lambda x:x.update(schema='BAD'))
 reject('floor',lambda x:x['contract'].update(N='46'));reject('higher_noise',lambda x:x['contract'].update(lmax='.13'))
 reject('noise_gap',lambda x:x['regions'][1].__setitem__(0,'.061'));reject('wrong_amplitude',lambda x:x['regions'][0].__setitem__(3,'.4'));reject('phase_gap',lambda x:x['regions'][0].__setitem__(2,'.1'))
 reject('missing_cell',lambda x:x['rows'].pop());reject('duplicate_cell',lambda x:x['rows'].__setitem__(1,x['rows'][0]));reject('reordered',lambda x:x['rows'].reverse())
 reject('phase_sign',lambda x:x['rows'][0].update(sign=0));reject('own_value',lambda x:x['rows'][0].update(own='1'));reject('quartic_scale',lambda x:x['rows'][0].update(scale='0'))
 reject('Poisson_anchor',lambda x:x['rows'][0].update(poisson_anchor='0'));reject('first_tail',lambda x:x['rows'][0].update(first='0'));reject('Bennett_tail',lambda x:x['rows'][0].update(outer='0'));reject('scale_list',lambda x:x['scales'].pop())
 for v in('0','-1',True):reject('gate_'+str(v),lambda x,v=v:x['gates'].__setitem__(next(iter(x['gates'])),v))
 reject('source',lambda x:x['source_sha256'].__setitem__(SOURCES[0],'0'*64))
 try:json.loads('{"x":0,"x":0}',object_pairs_hook=unique)
 except ValueError:tests.append('duplicate_key')
 else:raise ValueError('Duplicate JSON accepted')
 for name,args in [('negative_mu',(F(-1),F(1))),('negative_anchor',(F(1),F(-1))),('anchor_past_tail',(F(1),F(31)))]:
  try:poisson_numerator(*args)
  except ValueError:tests.append(name)
  else:raise ValueError('Bad Poisson parameter accepted')
 return tests
if __name__=='__main__':
 want=reconstruct();raw=(HERE/'mid47a_certificate.json').read_bytes();validate(json.loads(raw,object_pairs_hook=unique),want);tests=controls(want)
 print(json.dumps(dict(status='PASS_EXACT_CONDITIONAL_MID47_A',rows=len(want['rows']),gates=len(want['gates']),negative_controls=tests,minimum_reserve=min(float(F(r['reserve']))for r in want['rows']),certificate_sha256=sha256(raw).hexdigest(),source_sha256={**want['source_sha256'],'accept_mid47a.py':sha256(Path(__file__).read_bytes()).hexdigest()},scope='n>=47,p in[.38,.47],|H|<=1.257,theta<=.0154,d<=.0181, four fixed positive-noise/phase rectangles with their stated amplitudes. This is a conditional companion score comparison; LOW/acquisition/global cutoff are separate.'),indent=2))
