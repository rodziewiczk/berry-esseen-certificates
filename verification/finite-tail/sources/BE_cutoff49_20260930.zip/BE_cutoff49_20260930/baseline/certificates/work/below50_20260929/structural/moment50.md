# MOMENT50: one common law, two sign moment sequences

## Mathematical status

Locally derived and checked analytic lemmas; no optimizer or cutoff is assumed.
`moment50.tex` proves the signed fourth/fifth penalty and three support-localizing
matrices, explains every interval substitution and singular boundary, and gives
an actual three-point law at the difficult moment triple.

At rho=1.84, beta=.62, gamma=1.60, support radius 3.84:

- m < .386166800630;
- fourth moment < 3.905131080;
- fifth absolute moment < 8.923502410;
- penalty in rho*mu4/2−eta5/4 ≤ rho³/4−penalty exceeds .03454953.

The moment triple itself is feasible and must not be rejected. Its explicit
three-point construction has support inside 2.124. The gain is a joint upper
bound on higher moments, previously relaxed independently.

## Execution status

Fresh PASS: `runs/below50_20260929/structural/moment50_accept02`.
The independent exact script checks 40 actual-law cases and 22 scalar checks or
negative controls. Tests include reflections, zero atoms, singular localizing
matrices, tiny remote atoms, atom collisions, and small closed moment boxes.
These examples supplement the analytic proof; they are not a finite-domain
proof of the universal lemmas. No entry grid or cutoff is certified by this run.

Fresh compile: `runs/below50_20260929/structural/moment50_compile01`.
PDF: `moment50_build/moment50.pdf`, four pages, no warnings or box defects.
All four pages were visually inspected.

## Audit of related entry proposals

For a central gap (−A,B), the existing exact identity gives
D=mQ+(sigma−1)T+ +(sigma+1)T−+3(T−Jo), with every residual nonnegative.
Thus the outer resource is D−mQ, not an independent copy of D.
Positive outer gaps satisfy (t−a)(rho−t) ≤ (rho−B)_+²/4;
negative gaps satisfy (R−|t|)(|t|−rho) ≤ (R−rho)²/4 whenever the
integrand is positive. Hence

3(rho J1−J2)_outer ≤ (3/8)[(rho−B)_+² T+ +(R−rho)² T−].

The endpoint lower bound obtained from
D ≥ (sigma−1)b+ +6a+ B−(sigma+5)m B² is valid when
D<(sigma−1)b+; use the positive root. The reflected formula uses
sigma+1 and sigma+7.

For central G=rho*P1−P2, differentiation gives
∂B G=B(A+B)(rho−B), so G≤G(A,rho;rho).
The latter has derivative in A equal to (rho−A)²(rho+2A)/6≥0
and second derivative in rho equal to rho²+rho*A≥0.
These facts justify a cheap endpoint enclosure before a full joint polynomial
optimization is attempted. They are conditional on the actual central gap.

## Remaining work

The entry constructor must use these inequalities on a fully covered moment
partition and integrate the resulting bounds with the Fourier remainder and
same-law defect budget. The frozen support proofs were not modified.
