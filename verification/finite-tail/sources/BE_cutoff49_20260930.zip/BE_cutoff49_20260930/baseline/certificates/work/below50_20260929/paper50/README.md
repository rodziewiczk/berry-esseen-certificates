# Cutoff 50: complete research manuscript

`build/main.pdf` is the integrated 147-page manuscript. Pages 1–8 give the main proof route, pages 9–93 contain the selected new analytic arguments, and pages 94–147 reproduce the complete cutoff-99 foundation. The unrestricted finite range below 50 remains open.

## Status

The coordinator confirmed the selected mathematical reductions, exact arithmetic replays, source bindings and final composition on 29 September 2026. This is a computer-assisted mathematical proof under the published inputs cited in the foundation. It is not a Lean formalization or an externally refereed result.

## Reproduction and provenance

- `main.tex`, `sections/`, and `fragments/` are the compiling manuscript sources.
- `sources/` contains byte-identical copies of the 35 original proof sources and the complete foundation PDF.
- `SOURCE_INVENTORY.json` maps original source paths to copied paths and SHA256 values. It distinguishes the selected Gaussian excerpt from full-body copies.
- `CUTOFF50_DEPENDENCIES.json` (V2, SHA256 `904bc8150c0f0295c022fdafea76c50e308647ea0ecb0a7ba94cc12996ef72b0`) is the coordinator's exact final composition manifest, binding 850 source/evidence files and 48 selected component/control runs. `SELECTED_JOBS.json` lists the replay jobs. The executable proof objects and logs are supplied with the complete release, rather than duplicated as printed decimal tables.
- `assemble_sources.py` regenerates the local copies and compiling fragments. It removes standalone document wrappers, scopes theorem labels, demotes headings, and applies explicit line-break fixes. These typesetting changes do not alter mathematical formulas. The general Gaussian excerpt retains arbitrary finite threshold bound h, as permitted by its displayed absolute-majorant proof.
- The newer local modules replace the old numerical constants only at the expressly proved scope. Generic old actual-count arguments retain their original labels and hypotheses.

## Build

Run `pdflatex -output-directory=build main.tex` repeatedly until references settle, or use the project's recorded LaTeX compilation wrapper. The final recorded build is `runs/below50_20260929/entry/paper50_compile09`, using TeX Live and pdflatex. It has no LaTeX warnings, undefined references, or overfull/underfull boxes.

## Verification record

`QA_REPORT.json` records the final PDF hash, rendered-page checks, preservation checks, and exact comparison with the previously inspected draft. `qa09/` contains the final 80-dpi page render. The appended foundation is an immutable dependency, including its original printed page numbers; the outer running header is disabled on the included PDF pages so the original headers and page numbers remain legible.
