"""Read-only strict acceptance for CONDITIONAL_COMPANIONS95_B_V1."""
from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,sys
from companions95b_kernel import CFG,REGIONS,TINY,validate,need,equal
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
BASE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unique(rows):
 o={}
 for k,v in rows:need(k not in o,'duplicated JSON key');o[k]=v
 return o
def reconstruct(o):
 r=validate(o,strict=True);need(not r['bad'],'no nonpositive gates')
 digest=hashlib.sha256(json.dumps(r['exact_gates'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
 return {'schema':'ACCEPTED_CONDITIONAL_COMPANIONS95_B_V1','contract':{k:str(v)for k,v in CFG.items()},
  'regions':[[str(a),str(b)]for a,b in REGIONS],'tiny_noise':str(TINY),'target_per_noise':'1/1000',
  'gates':r['gates'],'exact_gate_sha256':digest,'reserves':r['reserves'],
  'normalization_sha256':sha(BASE/'normalization95b.py'),'kernel_sha256':sha(BASE/'companions95b_kernel.py'),
  'proof_sha256':sha(BASE/'normalization_companions95b_proof.tex')}
def accept(envelope):
 need(type(envelope)is dict and set(envelope)=={'object','metadata'},'complete envelope')
 expected=reconstruct(envelope['object']);need(equal(envelope['metadata'],expected),'source-bound exact metadata')
 return expected
def main():
 need(len(sys.argv)==1,'read-only acceptor has no arguments')
 p=BASE/'companions95b_certificate.json';raw=p.read_text();o=json.loads(raw,object_pairs_hook=unique);r=accept(o)
 controls=[]
 mutations=[('missing_tiny',lambda z:z['object']['tiny'].pop()),('reordered_tiny',lambda z:z['object']['tiny'].reverse()),
  ('duplicated_tiny',lambda z:z['object']['tiny'].append(copy.deepcopy(z['object']['tiny'][0]))),
  ('wrong_tiny_bound',lambda z:z['object']['tiny'][0].update(numerator=1)),('boolean_bound',lambda z:z['object']['tiny'][0].update(numerator=True)),
  ('float_bound',lambda z:z['object']['tiny'][0].update(numerator=1.0)),('unit_bound',lambda z:z['object']['tiny'][0].update(numerator=10**6)),
  ('wrong_distance',lambda z:z['object']['tiny'][0].update(distance='3')),('wrong_variance',lambda z:z['object']['tiny'][0].update(variance='1')),
  ('missing_region',lambda z:z['object']['regions'].pop()),('reordered_regions',lambda z:z['object']['regions'].reverse()),
  ('missing_phase',lambda z:z['object']['regions'][0]['positive'].pop()),('reordered_phases',lambda z:z['object']['regions'][0]['positive'].reverse()),
  ('phase_gap',lambda z:z['object']['regions'][0]['positive'][0].update(phase=['1/10','1/5'])),
  ('missing_sign',lambda z:z['object']['regions'][0].pop('negative_first')),('weak_mid_bound',lambda z:z['object']['regions'][0]['positive'][0]['first'].update(numerator=1)),
  ('lower_floor',lambda z:z['metadata']['contract'].update(N='94')),('stronger_target',lambda z:z['metadata'].update(target_per_noise='1')),
  ('wrong_proof',lambda z:z['metadata'].update(proof_sha256='0'*64)),('wrong_source',lambda z:z['metadata'].update(kernel_sha256='0'*64)),
  ('wrong_gate_digest',lambda z:z['metadata'].update(exact_gate_sha256='0'*64)),('unconditional_claim',lambda z:z.update(unconditional=True))]
 for name,mutate in mutations:
  z=copy.deepcopy(o);mutate(z);need(not equal(z,o),'effective mutation')
  try:accept(z)
  except (ValueError,KeyError,TypeError):controls.append(name)
  else:raise ValueError('accepted mutation '+name)
 for name,s in [('malformed','{'),('truncated',raw[:-7]),('duplicate_key','{"object":null,'+raw[1:])]:
  try:accept(json.loads(s,object_pairs_hook=unique))
  except (ValueError,KeyError,TypeError):controls.append(name)
  else:raise ValueError('accepted malformed input')
 tiny=[F(v)for k,v in r['reserves'].items()if k.startswith('tiny')];mid=[F(v)for k,v in r['reserves'].items()if not k.startswith('tiny')]
 print(json.dumps({'status':'PASS_EXACT_CONDITIONAL_COMPANIONS95_B','gates':r['gates'],'tiny_cells':6,'positive_cells':sum(len(z['positive'])for z in o['object']['regions']),
  'negative_cells':len(REGIONS),'Bennett_rows':6+sum(2*len(z['positive'])+2 for z in o['object']['regions']),
  'tiny_reserve':str(min(tiny)),'mid_reserve':str(min(mid)),'target_per_noise':r['target_per_noise'],'negative_controls':controls,
  'kernel_sha256':r['kernel_sha256'],'normalization_sha256':r['normalization_sha256'],'proof_sha256':r['proof_sha256'],
  'acceptor_sha256':sha(Path(__file__)),'certificate_sha256':sha(p)},indent=2))
if __name__=='__main__':main()
