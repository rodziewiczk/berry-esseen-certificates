# Independent central LOW47 review

## Status and scope

**Mathematical status:** independently derived and reviewed conditional
whole-count comparison. Under the acquired 45 central probability panels,
their same-law raw budgets, Sperner amplitude bounds and matched noise
profiles, the LOW phase envelope gives
`rho_B (C-C_B^+(k)) < -.001 lambda` for every integer `n>=47` and every
positive noise level in the declared LOW intervals. This is not by itself
a global cutoff theorem.

**Execution status:** fresh fixed `root_low47_accept01` PASS: 74 signed
panel rows, 2,183,897 rational gates, 20,031 feasible and 17,121 excluded
boxes, 11 object/schema rejection controls. The largest endpoint score is
less than `-.0022896`. The eight panels with ceiling at most `.05` belong
entirely to the separate TINY theorem.

## Independent mathematical derivation

`low47_new_lemmas.tex` derives the three new steps without assuming a
numerical success result:

1. On a nonzero forward mark, `D_- > 0` implies `U0>U1>=-d`, permitting
   inward gap `d0` instead of the full amplitude in the deleted threshold.
   The conditioning deletes the entire independent pair. The backward
   event remains strict and all legal marks are retained.
2. The two actual deleted laws can be coupled as `Z+U1` and `Z+U0`.
   Their projected events are disjoint tails of one centered background.
   The optimal quadratic center is the midpoint clipped to
   `[-T_l/beta,T_l/alpha]`. The strict positive distance/radius gates are
   essential and present in the final kernel.
3. The centered-Poisson cubic comparison bounds both reflected tails. The
   implementation evaluates its positive-part moment by its full cubic
   expectation plus a finite nonnegative low-count correction. Replacing
   `exp(-mu)` by the reciprocal degree-24 exponential partial sum has the
   correct upper direction, even when the uncorrected cubic is negative.
   There is no discarded positive Poisson tail.

The denominator `omega_plus*lambda_low` is justified by the fixed
surrogate `T(lambda)=omega_plus*lambda`. It is **not** an asserted lower
bound on the actual conditional variance. First bound all actual
variances by this surrogate, then normalize each fixed probability upper
bound or quadratic majorant using `T(lambda)>=T_l`.

The proof also supplies the full fourth-moment tail over every mark
`i>=3`, the one-sided first-moment resource, and convexity on complete
closed noise intervals. All anchors and center choices are frozen before
varying lambda. The negative event-bracket check licenses the binomial
mass lower bound; the positive inverse-index bracket licenses `1/n<=1/47`.
Both signs are checked explicitly in the exact kernel.

## Source and coverage audit

Read the complete final `root/low47_kernel.py`, `low47_contract.py`,
`accept_low47.py`, `low47_normalization.py`, and
`low47_normalization_proof.tex`, alongside the retained actual-count proof
and the previous joint-resource LOW95 proof. No unresolved defect found.

The checked normalization independently verifies finite Stirling error,
entropy derivatives, normal derivative, the uniform legal-count mass
lower bound, mode mass upper bound, actual-count variances, incoming
ratios, signed cubic repair, normal variance repair, and harmonic rate.
Its own fresh fixed replay covers 90 configurations and 5,400 positive
rational gates with 26 malformed-input/coefficient controls. The selected
LOW generator reproduces the same amplitudes and constants. Its `.026`
field is an unused legacy descriptor; the actual LOW/TINY boundary is
explicitly `.05` in the LOW contract and is checked by the acceptance.

The LOW proof has **no finite-index exception**. Uniform mass bounds
apply for all `n>=47`; the unused finite-mass helper and its imports were
removed before the selected run. The closed phase envelopes match MID:
`.09`, `.13`, `.18`, `.29` on noise bands `[.05,.06]`, `[.06,.08]`,
`[.08,.10]`, `[.10,.12]`, followed by all phases `|u|<=.5`.
All noise edges occur in the exact grid and both adjacent closed
intervals retain them. The amplitude profile is separately certified and
uses the original acquired input; feedback resources do not assume the
conclusion of LOW.

Exact square-root rounding, nonnegative Poisson correction, rational
ceilings, actual sign-dependent raw quadratics, maximum over alternative
moment branches, same-cell phase budgets, and the strict empty-cell
exclusion were inspected. The fixed-object mutations primarily certify
object identity/schema integrity; they are not advertised as an
independent derivation of the numerical kernel.

## Adversarial checks and exposition

The independent script `check_low47_new_lemmas_actual.py` imports no
constructor module. Fresh `structural/low47_actual01` PASS covers 30
centered conditional noise pairs, including degenerate classes and a
tiny remote atom: 3,102 active-mark checks, 6,204 common-background checks,
6,204 Poisson/Cantelli checks, 68,244 rational center comparisons, and
231 exact atom collisions. Three false generalizations are rejected.
These finite actual-law tests supplement the continuous proof; they do
not replace it.

The four-page `build_low47_lemmas/low47_lemma_notes.pdf` compiled without
warnings or overfull boxes in `structural/low47_lemmas_compile01`. All
four rendered pages were personally inspected. Normalization PDF visual
QA remains the constructor's separate record, distinguished from this
reviewer's full proof/source reading.

## Dependencies retained in the claim

The input acquisition and sign-specific conserved raw budgets, including
the auxiliary Fourier reflection clarification, the Sperner confinement
and its noise profile, finite normalization, generic actual-count
transfer and curvature, harmonic scalar inequality, joint binary/shift
moment identity, and separate TINY/MID companions remain explicit.
The source binding records their selected objects and earlier review
bindings. Complete probability coverage and the global descent selector
are separate obligations owned by the coordinating agent.
