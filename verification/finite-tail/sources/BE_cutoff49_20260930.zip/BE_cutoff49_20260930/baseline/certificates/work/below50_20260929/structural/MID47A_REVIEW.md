# Independent review of MID47A and its amplitude schedule

## MID47A

Mathematical status: independently reviewed conditional comparison, no defect
found. Execution status: selected sources match fresh exact acceptance7901
gates/2620 closed phase rows/26 controls. It proves
rho_B(C-C_B^+(k))<-.001lambda under C>=.4 and the four displayed noise,
phase and amplitude rectangles, at n>=47,p[.38,.47],H1.257,theta.0154,d.0181.
It makes no acquisition, central-phase LOW or global-cutoff claim.

I read the full proof, kernel, normalization, acceptor and actual-law controls.
The shifted quartic is the already independently derived pointwise strict-event
minorant. At fixed phase magnitude r, its lower expectation plus normal
linear term is concave in variance t, with second derivative-6/(K a^4).
The actual variance lies in[ownlo*L0,ownhi*L1], so both endpoints suffice.
At either endpoint each monomial is bounded on the full nonnegative closed
phase cell using its coefficient sign. Both event orientations are correct:
W+r for a negative phase and W-r for a positive one. Maximizing these valid
lower bounds over a fixed finite scale list needs no optimization assumption.
The optional Cantelli and normal-only bounds are likewise lower bounds on
the actual own-count expression, including collisions and r=.5 ties.

The incoming first distance is1+r_l on the negative side and1-r_h on the
positive side. Later distances per count are at least1 and1-r_h/2,
respectively. The variance endpoint V uniformly dominates the actual first
incoming sum. The centered-Poisson comparison is applied directly with that
V, so no unjustified monotonicity of a chosen moving anchor is required.
Every candidate anchor has a positive denominator; each positive series tail
is rounded outward. Cantelli and Bennett are alternate upper bounds.
The remaining counts retain their full geometric Bennett sum.

Finite normalization and cubic repair match the actual conditional count
identity. The positive repair cost is evaluated at the upper noise endpoint,
and each bracket is proved positive before using the binomial mass lower
bound. The reserve>.001L1 then implies the desired>.001lambda on the whole
noise interval. There is no limiting-to-zero scaling claim in this MID
component. The complete closed phase/sign cover is reconstructed explicitly.

The finite actual-law controls compare the constructor's bound with separately
convolved true probabilities on seven laws and threshold collisions; they
also check the variance concavity identity. They are useful probability
controls, not an independent reimplementation of the numerical kernel.
Constructor visual QA covers all five final proof pages; this reviewer read
proof/source text and does not claim a second rendered inspection.

## SPERNER47 PROFILE A

The additional amplitude schedule reuses the fully independently reviewed
Sperner proof with a positive lower noise endpoint. Its resource subtraction
uses that lower endpoint, while the pair variance error uses the upper one.
Every other relevant buffer, width and contact expression is recomputed
with the proposed smaller amplitude. There is no use of an amplitude
conclusion to acquire its own input premises.

I read the complete schedule acceptor and one-page proof. Its selected fixed
table has no ceiling equal to.05,.08 or.10, so the lo>=hi skip loses no
singleton endpoint obligation. The binding independently checks this fact.
Every nonempty interval retains both endpoints, including both adjacent
amplitude conclusions at an internal boundary.98 panel/noise rectangles,
196 signs and313738 rational gates are covered. The profile licenses exactly
the amplitudes used by the four MID rows where a law can lie in those rows.
Constructor inspected the final one-page PDF; no second visual QA claimed.
