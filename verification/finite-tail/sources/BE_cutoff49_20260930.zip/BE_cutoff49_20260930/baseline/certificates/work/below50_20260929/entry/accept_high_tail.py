#!/usr/bin/env python3
"""Fixed rational acceptance for HIGH_LAGUERRE2, all x>0.

The source proof gives the positive-integral reduction. This checks every
polynomial identity and the complete unbounded derivative sign domain.
"""
from fractions import Fraction as F
from math import comb,factorial
from pathlib import Path
import json,copy,hashlib,sys
assert __debug__ and not sys.flags.optimize

def need(x,s):
 if not x:raise ValueError(s)
def trim(p):
 p=list(p)
 while len(p)>1 and p[-1]==0:p.pop()
 return p
def add(*ps):
 z=[F(0)]*max(map(len,ps))
 for p in ps:
  for i,v in enumerate(p):z[i]+=v
 return trim(z)
def mul(a,b):
 z=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):z[i+j]+=x*y
 return trim(z)
def scale(p,c):return trim([x*c for x in p])
def deriv(p):return [i*p[i]for i in range(1,len(p))]or[F(0)]
def badd(a,b):
 z=dict(a)
 for ij,c in b.items():z[ij]=z.get(ij,F(0))+c
 return {ij:c for ij,c in z.items()if c}
def bmul(a,b):
 z={}
 for (i,j),x in a.items():
  for (k,l),y in b.items():z[i+k,j+l]=z.get((i+k,j+l),F(0))+x*y
 return {ij:c for ij,c in z.items()if c}
OBJECT=dict(format='HIGH_LAGUERRE2-v1',P=[2,-4,1],D=[2,4,1],L=[3,1],R=[2,1],
 Q=[[16,20,8,1],[-20,-8,-1],[8,1],[-1]],threshold='1/4')
def verify(o):
 need(type(o)is dict and set(o)==set(OBJECT),'exact fields');need(o['format']==OBJECT['format'],'named theorem')
 for key in('P','D','L','R'):
  need(type(o[key])is list and 1<=len(o[key])<=5 and all(type(v)is int for v in o[key]),'polynomial integer vector')
 need(type(o['Q'])is list and len(o['Q'])==4 and all(type(p)is list and all(type(v)is int for v in p)for p in o['Q']),'quotient polynomial')
 need(o['threshold']=='1/4','fixed all-index domain')
 P,D,L,R=o['P'],o['D'],o['L'],o['R'];Q=o['Q']
 need([(-1)**i*v for i,v in enumerate(P)]==D,'positive denominator P(-x)')
 need(D[0]>0 and all(v>=0 for v in D),'positive denominator for x>=0')
 need(R[0]>0 and all(v>=0 for v in R),'positive rational upper bound')
 pd={(0,j):F(v)for j,v in enumerate(P)};dd={(i,0):F(v)for i,v in enumerate(D)};qq={(i,j):F(v)for j,p in enumerate(Q)for i,v in enumerate(p)}
 lhs=badd(bmul(dd,dd),{ij:-c for ij,c in bmul(pd,pd).items()});rhs=bmul({(1,0):F(1),(0,1):F(1)},qq)
 need(lhs==rhs,'pointwise positive square remainder identity')
 expectation=add(*(scale(p,factorial(j))for j,p in enumerate(Q)))
 need(expectation==mul(L,D),'integrated positive exponential moments')
 need(add(D,scale(mul([0,1],L),-1))==R,'Laplace complement identity')
 num=add(mul([1,-2],mul(R,D)),mul([0,2],add(mul(deriv(R),D),scale(mul(R,deriv(D)),-1))))
 shift=[sum(F(v)*comb(j,i)*F(1,4)**(j-i)for j,v in enumerate(num)if j>=i)for i in range(len(num))]
 need(all(v<0 for v in shift),'complete unbounded monotonicity on x>=1/4')
 return dict(derivative_numerator=[str(z)for z in num],shifted_negative_coefficients=[str(z)for z in shift],identities=4,domain='tail bound all x>0; n-uniform substitution when x_N>=1/4')
def controls():
 muts=[]
 for key in('P','D','L','R'):
  z=copy.deepcopy(OBJECT);z[key][0]+=1;muts.append(z)
 for i in range(4):
  z=copy.deepcopy(OBJECT);z['Q'][i][0]+=1;muts.append(z)
 z=copy.deepcopy(OBJECT);z.pop('L');muts.append(z)
 z=copy.deepcopy(OBJECT);z['P'][0]=True;muts.append(z)
 z=copy.deepcopy(OBJECT);z['threshold']='0';muts.append(z)
 z=copy.deepcopy(OBJECT);z['R']=[1];muts.append(z)
 for z in muts:
  try:verify(z)
  except ValueError:pass
  else:raise ValueError('mutation accepted')
 return len(muts)
if __name__=='__main__':
 need(len(sys.argv)==1,'no extra arguments');r=verify(OBJECT);r.update(status='PASS_HIGH_LAGUERRE2_EXACT',negative_controls=controls(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());print(json.dumps(r,sort_keys=True))
