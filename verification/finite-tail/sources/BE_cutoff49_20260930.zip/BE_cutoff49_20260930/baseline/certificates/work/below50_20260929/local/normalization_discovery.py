"""Outward rational constant generator for diagnostics, not an acceptor."""
from fractions import Fraction as F
from centered_confinement_kernel import rootlo,rootup
def up(x):return F(-((-x.numerator*100000)//x.denominator),100000)+F(1,100000)
def down(x):return F((x.numerator*100000)//x.denominator,100000)-F(1,100000)
def generate(base):
 c=dict(base);N=c['N'];c['lmax']=c['maxnoise'];lm=c['lmax'];c['tiny']=F('.026')
 c['elo']=rootlo((1-c['theta'])/(c['pu']*(1-c['pu'])))
 c['delta']=up(max(F(1),c['H']/c['elo']+F('.5')))
 d=c['delta'];c['v']=down(c['pl']*(1-c['pl']));v=c['v']
 c['left']=down(c['pl']-d/N);c['right']=up(c['pu']+d/N)
 c['vf']=down(c['left']*(1-c['left']))
 c['entropy']=up((1-2*c['left'])/c['vf']**2)
 c['logder']=up((1-2*c['left'])/c['vf'])
 c['remainder']=up(1/(12*c['vf']))
 c['zeta']=up(c['logder']*d/2+c['remainder']+c['entropy']*d**3/(6*N))
 c['sqrtmass']=rootup(c['pu']*(1-c['pu']))
 c['mass']=down(F('.39886')/c['sqrtmass']*(1-(d*d/(2*v)+c['zeta'])/N))
 c['logcoef']=up(1/(2*v)+d*d/(2*N*v*v))
 phase=(d+F('.25'))/(2*v)+c['zeta']
 c['logcap']=up((c['logcoef']*lm+phase)/N);c['ef']=1/(1-c['logcap'])
 c['normal_v']=up(c['ef']*c['logcoef']);c['normal_c']=up(c['ef']*phase)
 c['derivative_lo']=down(1-(c['normal_v']*lm+c['normal_c'])/N)
 c['derivative_hi']=up(1+(c['normal_v']*lm+c['normal_c'])/N)
 c['cv']=up(1/c['pl']);c['ownlo']=down(1-c['cv']*d/N);c['ownhi']=up(1+c['cv']*d/N)
 c['incoming']=up(1+c['cv']*(d+1)/N);c['outer']=up(1+c['cv']*(d+F('.5'))/N)
 den=1-(d-1)/(N*c['pl']);c['ratio']=up(1+(c['pu']+d-1)/(N*v*den))
 vmax=c['pu']*(1-c['pu'])+lm/N
 c['repair_multiplier']=down(F('.4')/rootup(vmax**3))
 c['repair_pos']=up(F('.4')/(2*rootlo(v**3)))
 raw=6*c['pl']-3*c['pl']**2-F('1.5')-c['d0']-3*(1-2*v)*lm/(8*v*N)
 c['repair']=up(c['repair_pos']*d-c['repair_multiplier']*raw)
 c['span']=c['amplitude']+c['d0'];x=F('3.14159')*c['span']
 sinlo=x-x**3/6+x**5/120-x**7/5040
 c['rate']=down(2*sinlo*sinlo/c['span']**2)
 return c
