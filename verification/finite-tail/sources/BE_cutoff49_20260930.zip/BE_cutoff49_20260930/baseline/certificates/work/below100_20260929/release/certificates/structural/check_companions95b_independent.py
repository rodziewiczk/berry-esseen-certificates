"""Independent integer enclosure and coverage check of all 740 Bennett rows.

No imports from any construction or acceptance kernel.  Unlike the primary
checker, logarithms are expanded without argument scaling and exponentials
are evaluated directly. Every intermediate is rounded downward on 10^-30.
The analytic actual-law variance and event reductions are separately reviewed.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
assert __debug__ and not sys.flags.optimize
D=10**30
A=F(3,10)
M=F('0.7686'); RATIO=F('1.025'); REPAIR=F('1.31'); N=95
INCOMING=F('1.0626'); OWNLO=F('.9675'); OWNHI=F('1.0325')
LO=F('.949'); HI=F('1.051'); CV=F('2.858')
REGIONS=[(F('.04'),F('.0275')),(F('.09'),F('.03')),
         (F('.13'),F('.08')),(F('.18'),F('.10')),(F('.25'),F('.12'))]

def down(x):return x.numerator*D//x.denominator

def row(o,b,V):
    assert type(o)is dict and set(o)=={'distance','variance','numerator'}
    assert o['distance']==str(b) and o['variance']==str(V)
    num=o['numerator']
    assert type(num)is int and 0<num<10**6 and b>0 and V>0
    # log(1+ab/V)=2 atanh(ab/(2V+ab)). All terms are nonnegative.
    y=down(A*b/(2*V+A*b)); y2=y*y//D; power=y; loglo=0
    assert 0<y<D
    for j in range(128):
        loglo+=2*(power//(2*j+1))
        power=power*y2//D
    exponent=down((b/A+V/(A*A))*F(loglo,D)-b/A)
    assert exponent>0
    term=D; exp_lower=D
    for j in range(1,65):
        term=term*exponent//(D*j)
        exp_lower+=term
    assert num*exp_lower>10**6*D
    return F(num,10**6)

def main():
    assert len(sys.argv)==1
    src=Path(__file__).resolve().parent.parent/'local'/'companions95b_certificate.json'
    raw=src.read_bytes();o=json.loads(raw)['object']
    assert set(o)=={'schema','tiny','regions'}
    assert o['schema']=='CONDITIONAL_COMPANIONS95_B_V1'
    assert len(o['tiny'])==6 and len(o['regions'])==5
    L=F('.026');V=INCOMING*L;rows=0;reserves={}
    tiny={}
    for j,z in zip(range(5,11),o['tiny']):tiny[j]=row(z,F(j,10),V);rows+=1
    specs=[('negative',F('.1674')*OWNLO,10),('positive0',F('.923')*OWNLO,9)]
    specs += [('positive'+str(j),LO*F(j,10)/L,9-j)for j in range(1,5)]
    for name,own,j in specs:
        b=tiny[j];value=M*(own-RATIO*b/(L*(1-b)))-REPAIR/N
        assert value>F('.001');reserves['tiny_'+name]=value
    positive=0
    for ri,((start,L),z)in enumerate(zip(REGIONS,o['regions'])):
        assert set(z)=={'start','end_noise','positive','negative_first','negative_outer'}
        assert z['start']==str(start)and z['end_noise']==str(L)
        count=int((F('.5')-start)*200)
        assert len(z['positive'])==count
        for i,item in enumerate(z['positive']):
            ul=start+F(i,200);uh=ul+F(1,200)
            assert set(item)=={'phase','first','outer'}and item['phase']==[str(ul),str(uh)]
            vin=L*(1+CV*(1+F('1.15')/F('1.9977')-ul)/N)
            vin=F(-((-vin.numerator*100000)//vin.denominator),100000)
            b1=row(item['first'],1-uh,vin);b2=row(item['outer'],1-uh/2,vin);rows+=2
            first=min(b1,vin/(vin+(1-uh)**2))
            value=M*(LO*ul-RATIO*(first+b2*b2/(1-b2)))-REPAIR*L/N
            assert value>F('.001')*L;reserves[f'mid_{ri}_{i}']=value/L;positive+=1
        V=INCOMING*L;t=OWNHI*L
        b1=row(z['negative_first'],1+start,V);b2=row(z['negative_outer'],F(1),V);rows+=2
        assert 2*t*start/(t+start*start)**2>HI
        own=min(r*r/(t+r*r)-HI*r for r in(start,F('.5')))
        value=M*(own-RATIO*(b1+b2*b2/(1-b2)))-REPAIR*L/N
        assert value>F('.001')*L;reserves[f'negative_{ri}']=value/L
    assert rows==740 and positive==362
    controls=[]
    for name,num in [('false_numerator',1),('boolean',True),('float',1.0),('unit',10**6)]:
        bad=dict(o['tiny'][0],numerator=num)
        try:row(bad,F(1,2),INCOMING*F('.026'))
        except AssertionError:controls.append(name)
        else:raise AssertionError('bad enclosure accepted')
    print(json.dumps(dict(status='PASS_INDEPENDENT_INTEGER_COMPANIONS95B',
          Bennett_rows=rows,positive_cells=positive,negative_cells=5,tiny_cells=6,
          smallest_per_noise_reserve=str(min(reserves.values())),negative_controls=controls,
          arithmetic='integer downward grid 10^-30; unscaled 128-term logarithm; direct degree64 exponential',
          certificate_sha256=sha256(raw).hexdigest(),source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
          scope='Independent arithmetic and complete row coverage; conditional actual-law reduction and normalization reviewed separately.'),indent=2))

if __name__=='__main__':main()
