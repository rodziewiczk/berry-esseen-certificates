"""Independent quotient-rule controls for the corrected far-negative gate."""
from fractions import Fraction as F
import json,sys
from tiny45c_kernel import evaluate
if sys.flags.optimize:raise RuntimeError('Unoptimized Python required')
o=evaluate();c=o['contract'];t=F(c['ownhi'])*F(c['lmax']);z=F(o['own']['split']);h=F(c['derivative_hi'])
checks=0
for tt in (t,F('1/1000000'),F('1/100'),F('1/20')):
 for zz in (z,F('1/2'),F(1),F(2)):
  rr=zz*tt
  quotient=(2*rr*(tt+rr*rr)-rr*rr*2*rr)/(tt+rr*rr)**2-h
  proposed=2*zz/(1+zz*zz*tt)**2-h
  assert quotient==proposed
  legacy=2*zz/(tt*(1+zz*zz*tt)**2)-h
  assert legacy!=quotient
  checks+=1
actual=2*z/(1+z*z*t)**2-h
assert F(o['gates']['negative_far_derivative'])==actual>0
# g'' has the sign of t-3r², proving its derivative is unimodal.
for rr in (F(0),z*t,F('1/2')):
 numerator=2*t*(t+rr*rr)-8*rr*rr*t
 assert numerator==2*t*(t-3*rr*rr)
print(json.dumps(dict(status='PASS_INDEPENDENT_CORRECTED_DERIVATIVE',quotient_rule_checks=checks,
 rejected_legacy_formula=checks,shape_checks=3,corrected_gate=str(actual),corrected_gate_decimal=float(actual))))
