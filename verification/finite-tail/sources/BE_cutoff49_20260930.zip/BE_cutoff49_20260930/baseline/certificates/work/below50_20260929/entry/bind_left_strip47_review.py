"""Bind the independent left-strip derivation to unchanged accepted sources."""
from pathlib import Path
import hashlib
import json
import sys

if sys.flags.optimize or not __debug__:
    raise RuntimeError('Unoptimized Python required')

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
PROJECT = BASE.parents[1]
ROOT_RUN = PROJECT / 'runs/below50_20260929/root_left_strip47_accept01'
REPLAY_RUN = PROJECT / 'runs/below50_20260929/entry/left_strip47_independent01'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def need(ok, message):
    if not ok:
        raise ValueError(message)

accepted = json.loads((ROOT_RUN / 'stdout.txt').read_text())
replay = json.loads((REPLAY_RUN / 'stdout.txt').read_text())
need(accepted == replay, 'independent replay differs from selected acceptance')
need(accepted['status'] == 'PASS_EXACT_LEFT_STRIP47', 'wrong accepted theorem')
need((accepted['panels'], accepted['cells'], accepted['controls']) == (38, 3073, 5), 'wrong accepted coverage')
need(accepted['gate_sha256'] == 'ee820b348e12dc97bcabae028593f3cbb8a530f87d0a0e92c5e57f94107ed20b', 'wrong gates')
for name, digest in accepted['source_sha256'].items():
    need(sha(BASE / name) == digest, 'changed accepted source: ' + name)
for run in (ROOT_RUN, REPLAY_RUN):
    meta = json.loads((run / 'metadata.json').read_text())
    need(meta['returncode'] == 0, 'failed run')
    need(sha(run / 'stdout.txt') == meta['stdout_sha256'], 'changed stdout')
    need(sha(run / 'stderr.txt') == meta['stderr_sha256'], 'changed stderr')
root_meta = json.loads((ROOT_RUN / 'metadata.json').read_text())
for name in ('left_strip47_proof.tex', 'panel_exterior_proof.tex', 'gaussian_exterior40.tex'):
    need(sha(BASE / 'root' / name) == root_meta['input_sha256'][name], 'changed reviewed proof: ' + name)

paths = [
    'entry/LEFT_STRIP47_REVIEW_ENTRY.md',
    'entry/bind_left_strip47_review.py',
    'root/left_strip47_proof.tex',
    'root/panel_exterior_proof.tex',
    'root/gaussian_exterior40.tex',
    'structural/LEFT270_INPUT47_BINDING.json',
    'structural/PAIRED_ORIENTATION47_BINDING.json',
] + list(accepted['source_sha256'])
out = {
    'schema': 'INDEPENDENT_LEFT_STRIP47_REVIEW_BINDING_V1',
    'mathematical_status': 'Independently derived and checked at the stated acquired-input scope; no defect found.',
    'execution_status': 'Fresh exact selected acceptance and independent replay PASS; all source bytes unchanged.',
    'hypotheses': accepted['hypotheses'],
    'conclusion': accepted['conclusion'],
    'scope_limit': 'This contact exclusion is not a local Bernoulli comparison or a cutoff theorem.',
    'panels': accepted['panels'], 'cells': accepted['cells'], 'controls': accepted['controls'],
    'gate_sha256': accepted['gate_sha256'],
    'source_sha256': {name: sha(BASE / name) for name in paths},
    'run_sha256': {
        str((run / name).relative_to(PROJECT)): sha(run / name)
        for run in (ROOT_RUN, REPLAY_RUN)
        for name in ('metadata.json', 'stdout.txt', 'stderr.txt')
    },
}
target = HERE / 'LEFT_STRIP47_BINDING_ENTRY.json'
need(not target.exists(), 'binding output already exists')
target.write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': 'PASS_LEFT_STRIP47_INDEPENDENT_BINDING', 'path': str(target.relative_to(BASE)), 'sha256': sha(target), 'gates': accepted['gate_sha256']}, indent=2))
