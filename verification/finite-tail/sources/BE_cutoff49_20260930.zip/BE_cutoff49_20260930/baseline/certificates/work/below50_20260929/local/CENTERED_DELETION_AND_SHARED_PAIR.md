# Two improvements to actual-law deletion

Mathematical status: locally derived; the centered estimate was also derived
independently by the coordinator. Execution status: fresh actual-law controls
pass in `runs/below50_20260929/local/centered_actual01`. These lemmas are
uniform mathematical statements; a new global cutoff is not asserted.

## 1. The centered signed noise estimate

Let `(Y_i,U_i)`, for `1 <= i <= m`, be independent copies of a pair, with
`E U_i = 0` and `epsilon = E|U_i| < infinity`. The variables within a pair may
be dependent. Let `A` be any interval of width `w`, with either endpoint
convention. Let `Q` dominate the probability of every interval of width `w`
for the sum of `m-1` independent copies of `Y`. Then

    |E[(sum_i U_i) 1_{x-sum_i Y_i in A}]| <= m epsilon Q / 2.

For a fixed `i`, condition on the full pair `(Y_i,U_i)`. The conditional
event probability is a function `f(Y_i)` satisfying `0 <= f <= Q`. Therefore

    E[U_i f(Y_i)] <= Q E(U_i)_+ = Q epsilon/2,

and the lower bound follows by dropping the positive part instead. Summing
the bounds proves the statement. No density, atom-size lower bound, positive
variance, or asymptotic limit is used. The statement includes every finite
`m >= 1`, with the remaining empty sum interpreted as the constant zero.
For open or half-open intervals, containment in the corresponding closed
interval gives the same concentration bound.

This is a bound for a **signed expectation**. It does not improve the bound
on `E[|sum_i U_i| 1_A]`, for which replacing epsilon by epsilon/2 is false.

## 2. Directed deletion

Write `Y=B+U`, `P(B=1)=p`, `q=1-p`, and `E(U|B)=0`. Let `m>=1`,
`Z=x-sum_{i=1}^m Y_i`, `mu=x-mp`, and `nu=Law(Z)`. For the laws obtained
by fixing one removed label, write

    T_b(A) = P(x-sum_{i=1}^{m-1}Y_i-b-U_b in A).

If `K=sum B_i`, exchangeability gives

    nu(A)-T_1(A) = E[(Z-mu+sum U_i)1_A]/(mp),
    T_0(A)-nu(A) = E[(Z-mu+sum U_i)1_A]/(mq).

Indeed `mp-K=Z-mu+sum U_i`; the identities follow by expanding
`E[K 1_A]` and `E[(m-K)1_A]`. Put `D_A=max(0,sup(A)-mu)`.
The first lemma yields

    nu(A)-T_1(A) <= D_A Q_m(w)/(mp) + epsilon Q_{m-1}(w)/(2p),
    T_0(A)-nu(A) <= D_A Q_m(w)/(mq) + epsilon Q_{m-1}(w)/(2q).

The bounds `Q_m` and `Q_{m-1}` concern their actual, separate deleted laws.
They need not use the same Berry--Esseen cap.

Suppose the conditional support implies `U_1-U_0 >= -d`. For `tau>0`
and independent actual conditional variables, set `Delta=U_1-U_0` and
`A^+=A+1+[-d,tau]`. On `Delta<=tau`, the point defining `T_0` is in
`A^+` whenever the point defining `T_1` is in `A`. Conditioning on both
conditional variables on the complementary event gives

    T_1(A)-T_0(A^+) <= Q_{m-1}(w) P(Delta>tau).

Combining the three inequalities replaces each epsilon coefficient in the
old directed asymmetric deletion inequality by epsilon/2. Since
`E Delta=0`, `Var Delta <= s/min(p,q)`, and `Delta+d >=0`,

    P(Delta>tau) <= min(s/(s+min(p,q)tau^2), d/(d+tau)).

The strict exceptional-event threshold includes the collision `Delta=tau`
in the good event. Interval endpoints and conditional atoms need no change.

## 3. Charge the pair event to the same resource

Let nonnegative resource variables `x_i` satisfy `sum x_i <= R`. Assume
linear upper bounds for the scaled transport error and displacement,

    V <= sum a_i x_i,          d_tilde <= sum b_i x_i,

with `a_i,b_i>=0`; put `q0=N tau>0`. If the pair-event coefficient is
`B>=0`, any rational choice `t>=0` gives

    V + B d_tilde/(q0+d_tilde)
    <= max_i(R a_i + B q0 R b_i/(q0+t)^2)
         + B t^2/(q0+t)^2.

One may include the zero vertex if some coefficients vanish. The exact
tangent identity is

    (q0 z+t^2)/(q0+t)^2 - z/(q0+z)
       = q0(z-t)^2/[(q0+z)(q0+t)^2] >= 0.

Apply it at `z=sum b_i x_i`; monotonicity permits the displacement upper
bound. The remaining expression is affine in the resource variables. Its
maximum over the simplex is at a vertex, proving the inequality. Taking
the smallest of finitely many rational tangent choices is valid: each
choice is separately an upper bound on the whole continuum domain.

For confinement, use the actual common moment budget with resources
`x_+=n c_+ M_+`, `x_-=n c_- M_-`, and
`x_J=n sqrt(n) L/kappa`. The bound on their sum is

    R = budget/kappa - b_* E^2 lambda_lower - N P.

The three displacement vertex values are
`R/(E c_+ p_lower)`, `R/(E c_- q_lower)`, and zero. The transport vertices
are those used in the existing moment/leakage allocation, after applying
the centered signed improvement. For all `n>=N`, replace `1/n` by `1/N`
in positive coefficients and `n tau` by `N tau`. The term `-nP` makes the
resource smaller, so replacing it by `-NP` is also outward.

This prevents spending the full resource separately on the linear error
and on the pair event. It preserves the independent Cantelli upper bound;
the minimum of the tangent estimate and the old Cantelli estimate is valid.

For the lower exterior ray, bound the error at its initial radius by the
new resource estimate. Bound the subsequent increment directly from the
original affine-in-width error for the **same law**. Its slope uses the
centered epsilon/2 bound and the old uniform bad-event cap. Thus no
derivative of the optimized minimum is required.

## 4. Current executable scope

`centered_confinement_kernel.py` changes only the two signed epsilon costs
in the preserved95B kernel. `shared_pair_confinement_kernel.py` additionally
allows an explicit initial strip and bounds the same-budget pair event by
eleven rational tangents. Both files are discovery kernels, not acceptors.
Negative gates in their pressure maps are failures of these enclosures;
they are not counterexamples to the Berry--Esseen conjecture.

The new full LOCAL50 theorem is **not established**. Its same-law interface,
support-amplitude acquisition, TINY/MID complements, and complete LOW cover
remain separate obligations. The old cutoff99 proof is unchanged.
