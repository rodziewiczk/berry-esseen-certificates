"""Bind final reviewed conditional components; no dependency rerun."""
from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parents[3];H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def bind(label,folder,run,keys,proofs,scope):
 base=P/run;data=load(base/'stdout.txt');meta=load(base/'metadata.json')
 assert meta['returncode']==0
 for stream in ['stdout','stderr']:assert sha(base/(stream+'.txt'))==meta[stream+'_sha256']
 named=data[keys]
 for name,digest in named.items():assert sha(P/folder/name)==digest,(label,name)
 for name in proofs:
  assert sha(P/folder/name)==meta['input_sha256'][name],(label,name)
 files=[P/folder/name for name in list(named)+proofs]+[H/(label+'_REVIEW.md'),Path(__file__)]+[base/name for name in ['metadata.json','stdout.txt','stderr.txt']]
 out=dict(schema='INDEPENDENT_'+label+'_REVIEW_V1',scope=scope,
 mathematical_status='Independently derived and reviewed at the exact conditional hypotheses; acquisition remains a separate obligation.',
 execution_status='Existing fresh fixed acceptance verified and bound to current sources; this binding does not rerun it.',
 source_evidence_sha256={str(p.relative_to(P)):sha(p) for p in files},recorded_fresh_acceptance=run,
 numerical_status={k:data[k] for k in ['status','controls','panels','closed_cells','formula_controls','domain_controls','identities'] if k in data})
 path=H/(label+'_BINDING.json');path.write_text(json.dumps(out,indent=2)+'\n')
 return dict(label=label,binding_sha256=sha(path),status=out['numerical_status'])
print(json.dumps(bind('HIGH_WINDOW50','work/below50_20260929/entry','runs/below50_20260929/entry/high_window_accept01','source_sha256',['high_window50_proof.tex','high_window_notes.tex','high_tail_proof.tex'],'Complete six-piece conditional high-frequency bound, wider selected windows, chord/Laguerre first piece and full finite Gaussian comparator; three named exact conditional examples.'),indent=2))
print(json.dumps(bind('PANEL_EXTERIOR50','work/below50_20260929/root','runs/below50_20260929/root_panel_exterior_accept01','sources',[],'Forty-seven fixed conditional rows imply support(Y) subset(-.55,1.55), at n>=47, slow decrement<=.19 and current excess between0 and.7/n, with all named panel moment and threshold hypotheses.'),indent=2))
