"""Fixed exact central LOW47 acceptance; no discovery module imports."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from low47_contract import read as input_rows,selected,SOURCE
from low47_kernel import evaluate
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
SHA='27897b970b65878722ed26f38486c7d4f9c1f44b0b2384c8ac4430d6fcc31605'
def need(ok,s):
    if not ok:raise ValueError(s)
def unique(items):
    d={}
    for k,v in items:need(k not in d,'Duplicate key');d[k]=v
    return d
def read(blob):
    need(sha256(blob).hexdigest()==SHA,'Fixed named LOW47 object')
    d=json.loads(blob,object_pairs_hook=unique)
    need(d['schema']=='CONDITIONAL_CENTRAL_LOW47_V1','Named theorem')
    expected=[(r['index'],s)for r in input_rows()if F(r['lambda_max'])>F('.05')for s in(-1,1)]
    need([(z['index'],z['sign'])for z in d['rows']]==expected,'Every ordered panel and phase sign')
    return d
def normalize(obj):return json.loads(json.dumps(obj,default=str))
def controls(blob):
    count=0
    for kind in ['missing','duplicate','reorder','sign','floor','amplitude','target','mark','gate','empty']:
        z=json.loads(blob)
        if kind=='missing':z['rows'].pop()
        elif kind=='duplicate':z['rows'].append(z['rows'][0])
        elif kind=='reorder':z['rows'].reverse()
        elif kind=='sign':z['rows'][0]['sign']=1
        elif kind in ('floor','amplitude','target'):
            key={'floor':'N','amplitude':'amplitude','target':'score_target'}[kind]
            z['rows'][0]['proof']['contract'][key]='0'
        elif kind=='mark':z['rows'][0]['proof']['marks'][0][-1]='0'
        elif kind=='gate':z['rows'][0]['report']['gates']=0
        else:z['rows'][0]['report']['empty_cells']+=1
        try:read(json.dumps(z).encode())
        except ValueError:count+=1
        else:raise AssertionError('Mutated LOW47 accepted')
    try:unique([('a',1),('a',2)])
    except ValueError:count+=1
    else:raise AssertionError('Duplicate key accepted')
    return count
def main():
    need(len(sys.argv)==1,'No target overrides')
    proof=HERE/'low47_constructed02.json';blob=proof.read_bytes();obj=read(blob)
    inputs=input_rows();gates=feasible=empty=0;worst=F(-100);digest=sha256()
    for z in obj['rows']:
        row=inputs[z['index']];cfg=selected(row,z['sign'])
        need(cfg['noise_intervals'][0][0]==F('.05') and cfg['noise_intervals'][-1][1]==F(row['lambda_max']),'Complete positive noise cover')
        for j,(l,h,a) in enumerate(cfg['noise_intervals']):
            if j:need(cfg['noise_intervals'][j-1][1]==l,'Noise seam')
            need(h-l<=F(1,400),'Maximum closed noise width')
        p,r=evaluate(cfg)
        need(normalize(dict(index=z['index'],sign=z['sign'],proof=p,report=r))==z,'Exact fresh replay differs from fixed object')
        gates+=r['gates'];feasible+=r['feasible_cells'];empty+=r['empty_cells']
        worst=max(worst,F(r['worst_score']));digest.update(r['gate_sha256'].encode())
        print(json.dumps(dict(index=z['index'],sign=z['sign'],status='PASS')),flush=True)
    need(gates==2183897 and feasible==20031 and empty==17121,'Complete fixed cover counts')
    files=[Path(__file__),HERE/'low47_contract.py',HERE/'low47_kernel.py',HERE/'low47_normalization.py',proof,SOURCE,
           HERE.parent/'local/confinement47_contract.py',HERE.parent/'local/sperner47_contract.py',
           HERE.parent/'local/sperner47_certificate.json',HERE.parent/'local/sperner47_profile_certificate.json']
    print(json.dumps(dict(status='PASS_EXACT_CONDITIONAL_CENTRAL_LOW47',
        mathematical_status='Conditional actual-law whole-count comparison; acquired entry, confinement, and TINY/MID remain explicit dependencies.',
        theorem='For every n>=47 in the selected acquired45 panels, noise>=.05 and within the matching LOW phase envelope imply rho_B(C-C_B)<-.001lambda.',
        rows=len(obj['rows']),gates=gates,feasible_cells=feasible,excluded_cells=empty,controls=controls(blob),
        worst_score=str(worst),gate_sha256=digest.hexdigest(),interpreter=sys.version,
        source_sha256={str(p.relative_to(HERE.parent)):sha256(p.read_bytes()).hexdigest()for p in files}),indent=2))
if __name__=='__main__':main()
