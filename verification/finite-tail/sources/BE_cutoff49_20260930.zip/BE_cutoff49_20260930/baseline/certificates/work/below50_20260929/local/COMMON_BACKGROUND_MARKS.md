# One background for the two deleted mark tails

**Mathematical status:** locally derived conditional lemma; independently rederived and reviewed by the structural auditor.
**Execution status:** floating LOW pressure run `common_background_low01`; exact actual-law controls are separate and do not certify the LOW parameter cover.

Let the two centered conditional noise laws satisfy `U0 <= a0`, `U1 >= -a1`, with `a0,a1 >= 0`, `d=a0+a1`, `c=1-d>0`, and `|U0|,|U1| <= A`. For `1 <= k <= n-1`, let

- `A0 = k U1 + (n-k-1) U0`,
- `A1 = (k-1) U1 + (n-k) U0`,
- `Z = (k-1) U1 + (n-k-1) U0`,

where each expression uses independent variables with the actual conditional marginal laws. Couple `A0=Z+U1` and `A1=Z+U0`. This only chooses a joint distribution for two already prescribed marginals.

For an integer `i>=1`, `eta>=0`, and `b_i=ci-A-d>0`, the events

`A0 <= u+A-ci` and `A1 > u+eta+i-A`

imply, respectively,

`Z <= u-b_i` and `Z > u+b_i`.

The first implication uses `U1>=-a1>=-d`. The second uses `U0<=a0<=d` and `eta+i>=ci`. These two events of the same variable Z are disjoint. Thus their probability sum is at most

`P(|Z-u| >= b_i) <= (Var(Z)+u^2)/b_i^2 <= (t+u^2)/b_i^2`,

where `t=Var(W_k)` and `Var(Z)=t-s0-s1<=t`. The closed first event and strict second event preserve the original count conventions. The quadratic Markov bound is valid with either convention at the two exterior endpoints.

On a fixed noise cell `[lambda_l,lambda_h]` with `lambda_l>0`, if `t<=omega_plus*lambda`, then the replacement for the normalized paired tail kernel is

`[1 + u^2/(omega_plus*lambda_l)] / (ci-A-d)^2`.

This may be minimized against any independently valid two-tail bound. It has no unproved independence assumption and does not maximize a separate noise law for each tail.

## Current pressure result

Adding this bound for each of the first two mark pairs to the existing floating Poisson/Cantelli discovery kernel makes the stronger hypothetical interface (`T=.55, H=.8, p=.37..45, theta=.0055, inward d=.008`) pass the full stated LOW phase/noise profile at n47, with worst normalized score below `-.06458`. This is a conditional discovery, not a new acquired local theorem or a global cutoff. The amplitude profile and MID complement must still be independently justified.

The old broader tuple (`T=.75,H=1.15`) remains unclosed. Its negative logs are retained. The copied frozen TINY45C and DIRECT45A modules are not modified by this experiment.

Fresh actual-law controls: `common_background_actual01` PASS; six actual law pairs, 3,141 inequalities, 459 collision cases, and 691 strict gains over the separate Cantelli benchmark at the same distance.
