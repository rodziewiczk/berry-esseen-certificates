# Changes from cutoff189

The new route reaches cutoff99 by establishing a .7/n ceiling at94 and
forcing four .19 losses from96 onward. It retains only supported STOP180
from the old numerical chain; the old cutoff189 theorem is not a dependency.

The reusable improvements are:

1. A Gaussian expansion uniform in the raw threshold retains its cubic and
   quartic terms together, tightening support before phase confinement.
2. Signwise Cauchy couples the third and signed second/fourth moments.
3. The conserved threshold budget is retained through the entry calculation.
4. Directed asymmetric deletion prices displacement, noise and leakage from
   one joint defect budget and confines the complete conditional support.
5. LOW keeps the unshifted binary square, uses the legal-phase maximum of
   paired Cantelli terms, and retains a sixth-order exponential reserve.

Failed early searches are retained in the workspace research logs. They are
not selected proof objects. The new target, constants and wider domains are
named explicitly rather than overwriting older successful theorem scopes.
