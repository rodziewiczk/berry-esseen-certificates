#!/usr/bin/env python3
"""Fixed exact acceptance for the new supported ANCHOR40 exclusion.

No floating arithmetic, optimizer, target selection, or network dependency.
The stronger INPUT95 uses a separate fixed 10-pass interval construction.
"""
import sys,json,copy,hashlib
from pathlib import Path
from fractions import Fraction as F
import chain_core as c
import high_refinement
high_refinement.install()
c.PROFILES={"ANCHOR40":dict(n=40,nmax=40,R=F("3.3"),rho=F(712569,574000),barrier=F("1.5"),cap=F(".469"),cells=64)}
def need(x,s):
 if not x:raise ValueError(s)
def keys(x,w):need(type(x)is dict and set(x)==set(w),'exact object fields')
def parse_f(x):
 need(type(x)is str and len(x)<128,'rational string');z=F(x);need(str(z)==x,'canonical rational');return z
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def shape(doc):
 keys(doc,('format','profiles'));need(doc['format']=='anchor40-v1','format');need(type(doc['profiles'])is list and len(doc['profiles'])==1,'profile count')
 for row,(name,p) in zip(doc['profiles'],c.PROFILES.items()):
  keys(row,('name','steps'));need(row['name']==name,'named profile order');steps=row['steps'];need(type(steps)is list and 3<=len(steps)<=32,'finite profile length');phase=-1;raw=d=None
  for j,z in enumerate(steps):
   keys(z,('kind','R','D','active','excluded'));kind=z['kind'];need(kind in('universal','initial','general','paired'),'stage kind');ph=('universal','initial','general','paired').index(kind)
   need((j==0)==(kind=='universal')and ph>=phase and ph<=phase+1,'stage order');phase=ph
   rr,dd=parse_f(z['R']),parse_f(z['D']);need(0<rr<p['n']*F('.4095'),'raw positive initialization scope')
   need(dd>0 or j==len(steps)-1 ,'negative defect only final exclusion')
   if raw is not None:need(rr<=raw and dd<=d and (rr<raw or dd<d),'strict invariant progress')
   for fld in('active','excluded'):need(type(z[fld])is int and 0<=z[fld]<=p['cells'],'integer cover counts')
   need(z['active']+z['excluded']==p['cells']and z['active']>0,'complete cover')
   raw,d=rr,dd
  need(phase==2 and len(steps)==5 and d<0 and raw<=F('1.127'),'ANCHOR40 fixed goal')
 return doc
def verify(doc,emit=False):
 shape(doc);summary={};covered=0
 for row in doc['profiles']:
  name=row['name'];p=c.PROFILES[name];c.initialize(p);raw=d=None
  for j,z in enumerate(row['steps']):
   got=c.stage(p,z['kind'],raw,d);rr,dd=F(z['R']),F(z['D'])
   need(got['active']==z['active']and got['excluded']==z['excluded'],'recorded cell coverage')
   need((raw is not None and rr==raw)or got['R']<rr,'strict raw target')
   need((d is not None and dd==d)or got['D']<dd,'strict defect target')
   covered+=p['cells'];raw,d=rr,dd
  summary[name]=dict(raw=str(raw),defect=str(d),stages=len(row['steps']))
  if emit:print('PASS',name,summary[name],flush=True)
 return summary,covered
def controls(doc):
 cases=[]
 def add(f,deep=False):
  z=copy.deepcopy(doc);f(z);cases.append((z,deep))
 add(lambda z:z.pop('format'));add(lambda z:z.update(extra=1));add(lambda z:z['profiles'].pop())
 add(lambda z:z['profiles'].append(copy.deepcopy(z['profiles'][0])));add(lambda z:z['profiles'][0].update(name='ANCHOR90'))
 add(lambda z:z['profiles'][0]['steps'][0].pop('R'));add(lambda z:z['profiles'][0]['steps'][0].update(R='nan'))
 add(lambda z:z['profiles'][0]['steps'][0].update(R='01'));add(lambda z:z['profiles'][0]['steps'][0].update(active=True))
 add(lambda z:z['profiles'][0]['steps'].insert(1,copy.deepcopy(z['profiles'][0]['steps'][0])))
 add(lambda z:z['profiles'][0]['steps'][1].update(kind='paired'))
 # This remains schema-valid, so rejection evaluates the arithmetic enclosure.
 add(lambda z:z['profiles'][0]['steps'][0].update(R='21/5'),True)
 add(lambda z:z['profiles'][0]['steps'][0].update(active=z['profiles'][0]['steps'][0]['active']-1,excluded=z['profiles'][0]['steps'][0]['excluded']+1),True)
 for z,deep in cases:
  try:verify(z)if deep else shape(z)
  except (ValueError,TypeError,ZeroDivisionError):pass
  else:raise ValueError('malformed object accepted')
 try:json.loads('{"format":1,"format":2}',object_pairs_hook=unique)
 except ValueError:pass
 else:raise ValueError('duplicate JSON key accepted')
 return len(cases)+1
if __name__=='__main__':
 need(not sys.flags.optimize,'optimized Python forbidden');path=Path(sys.argv[1]);blob=path.read_bytes();doc=json.loads(blob,object_pairs_hook=unique);summary,n=verify(doc,True);negative=controls(doc)
 print(json.dumps(dict(status='FRESH_PASS',proof_sha256=hashlib.sha256(blob).hexdigest(),profiles=summary,covered_cells=n,malformed_controls=negative),sort_keys=True),flush=True)
