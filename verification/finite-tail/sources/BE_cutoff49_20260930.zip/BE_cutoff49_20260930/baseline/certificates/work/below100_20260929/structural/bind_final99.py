"""Integrity binding after mathematical and visual review; not an acceptor.

This checks the unchanged arithmetic against suite02 and separately binds
the later 54-page manuscript. An extracted-package replay must be recorded
outside the final archive to avoid circular review/archive hashes.
"""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, sys
from PIL import Image, ImageChops
from pypdf import PdfReader

assert __debug__ and not sys.flags.optimize
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
PROJECT = BASE.parents[1]
RELEASE = BASE / 'release'
RUN = PROJECT / 'runs/below100_20260929/full_suite02'
PDF = BASE / 'final_build02/main.pdf'
RENDER = BASE / 'final_render02'
OUT = HERE / 'FINAL99_BINDING.json'

def sha(p):
    return sha256(p.read_bytes()).hexdigest()

def rel(p):
    return str(p.relative_to(PROJECT))

def closure(p):
    return {str(f.relative_to(RELEASE)): sha(f) for f in sorted(p.rglob('*'))
            if f.is_file() and f.suffix in ('.py', '.json', '.tex', '.md')}

assert not OUT.exists(), 'Do not overwrite an existing review binding'
meta = json.loads((RUN / 'metadata.json').read_text())
jobs = json.loads((RELEASE / 'certificates/jobs.json').read_text())['jobs']
assert meta['status'] == 'PASS_CUTOFF99_SUITE'
assert meta['sources_unchanged'] and meta['optimization'] == 0
assert len(meta['jobs']) == len(jobs) == 21
assert [j['name'] for j in meta['jobs']] == [j['name'] for j in jobs]
log_hashes = {rel(RUN / 'metadata.json'): sha(RUN / 'metadata.json')}
for actual, spec in zip(meta['jobs'], jobs):
    assert actual['returncode'] == 0 and actual['passed']
    assert actual['reported_status'] == spec['expected_status']
    for stream in ('stdout', 'stderr'):
        p = RUN / (actual['name'] + '.' + stream + '.txt')
        assert sha(p) == actual[stream + '_sha256']
        log_hashes[rel(p)] = sha(p)

certs = closure(RELEASE / 'certificates')
runner = RELEASE / 'tools/run_certificates.py'
arithmetic = dict(certs)
arithmetic[str(runner.relative_to(RELEASE))] = sha(runner)
prior_arithmetic = {k:v for k,v in meta['input_sha256'].items()
                    if k.startswith('certificates/') or k == 'tools/run_certificates.py'}
assert arithmetic == prior_arithmetic, 'Arithmetic closure changed after suite02'
paper = closure(RELEASE / 'paper')
assert len(paper) == 16 and all(k.endswith('.tex') for k in paper)
changed_paper = {k:{'suite02':meta['input_sha256'][k], 'final':v}
                 for k,v in paper.items() if meta['input_sha256'][k] != v}
assert set(changed_paper).issubset({
    'paper/main.tex', 'paper/sections/computation.tex',
    'paper/sections/introduction.tex', 'paper/sections/main_route.tex'})
assert sha(PDF) == '761b6f8247325aae0b75a5b0dbad02c4a1b51cb8ccf79a09f11396d91adfdfc5'
assert len(PdfReader(PDF).pages) == 54
assert {p.name for p in RENDER.glob('page-*.png')} == {f'page-{j:02d}.png' for j in range(1,55)}
same = []
page_hashes = {}
for n in range(41,55):
    p = RENDER / f'page-{n:02d}.png'
    page_hashes[rel(p)] = sha(p)
    if n < 54:
        previous = BASE / 'final_render' / p.name
        a = Image.open(previous).convert('RGB')
        b = Image.open(p).convert('RGB')
        assert a.size == b.size and ImageChops.difference(a,b).getbbox() is None
        same.append(n)
log = BASE / 'final_build02/main.log'
text = log.read_text()
assert not any(word in text for word in ('Warning', 'Overfull', 'Underfull'))
artifacts = [PDF, log, HERE / 'FINAL99_REVIEW.md', HERE / 'EXTERNAL_INPUT_REVIEW.md',
             HERE / 'FRACTIONAL_SCALAR_PROOF.md', Path(__file__).resolve()]
result = {
    'status':'REVIEWED_AND_BOUND_CUTOFF99_RESEARCH_PROOF',
    'created_utc':datetime.now(timezone.utc).isoformat(),
    'cutoff':99,
    'mathematical_status':'Locally derived and independently reviewed computer-assisted research proof using the stated cited inputs; no unresolved dependency found in the selected scope. Not Lean-formalized or externally refereed.',
    'execution_status':'Fresh suite02 PASS for all 21 jobs, all return codes/statuses/log hashes checked. The entire arithmetic closure is unchanged. Later manuscript prose/layout edits are separately bound.',
    'release_root':rel(RELEASE),
    'source_sha256':{rel(RELEASE / k):v for k,v in sorted({**arithmetic, **paper}.items())},
    'counts':{'arithmetic_source_data_files':len(arithmetic), 'manuscript_tex_files':len(paper), 'jobs':len(jobs), 'pdf_pages':54},
    'suite_metadata':rel(RUN / 'metadata.json'),
    'suite_log_sha256':log_hashes,
    'manuscript_changes_after_suite02':changed_paper,
    'artifact_sha256':{rel(p):sha(p) for p in artifacts},
    'visual_review':{
        'own_assigned_final_pages':list(range(41,55)),
        'already_reviewed_images_pixel_identical':same,
        'fresh_full_size_inspection':[54],
        'additional_prior_full_size_inspections':[41,45,46,47,49,50,51,54,55],
        'prior_page55':'Removed by the reviewed bibliography layout repair; final PDF has 54 pages.',
        'finding':'PASS: no clipping, overlap, missing glyph, unreadable equation, or orphan reference in assigned final pages. Final compilation has no warnings or overfull/underfull boxes.',
        'other_pages':'Reviewed separately by the coordinator and entry reviewer; their reports are not replaced by this record.',
        'image_sha256':page_hashes,
    },
    'external_delivery_verification':'Archive integrity, extraction and a fresh extracted 21-job replay are to be recorded separately outside the archive. This pre-packaging binding does not claim that future run.',
    'hash_scope':'Hashes establish byte identity only. FINAL99_REVIEW.md records the mathematical review and complete dependency scope.'
}
OUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status':result['status'], 'binding':rel(OUT), 'binding_sha256':sha(OUT),
                  'counts':result['counts'], 'changed_manuscript_files':list(changed_paper)}, indent=2))
