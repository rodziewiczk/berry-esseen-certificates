# Berry–Esseen cutoff 99: research proof and exact supplement

**Statement:** for every integer n ≥ 99, the unrestricted iid Berry–Esseen
constant C_n is strictly smaller than C_E=(3+√10)/(6√(2π)).
This package contains the complete project-specific proof, with cited
literature inputs, and the finite arithmetic supplement used in that proof.
The final assembled review and portable replay status are recorded separately
in the delivery verification file. No Lean formalization is asserted.

## Read the argument

Start with `paper/BE_cutoff99.pdf`, Sections 1–2. The main argument establishes
an unrestricted ceiling C_j−C_E<.7/j for j≥94. From n≥96, a nonnegative
excess would force a predecessor increase exceeding .19/n. Four increases
contradict the ceiling at every n≥99.

The appendices prove the analytic reductions, support, entry and local
comparison. `DEPENDENCY_MAP.md` records their exact scopes. The arithmetic
supplement is part of this computer-assisted proof: every continuous-domain
reduction is explained in the paper, and every finite numerical sign is
specified by the supplied rational programs and fixed proof objects.

## Reproduce

Use unoptimized CPython 3.9 or newer, standard library only:

```sh
python3 -B tools/run_certificates.py --output ../fresh-cutoff99-run
```

The output directory must be new and outside this package. The runner uses
three local processes, saves complete stdout/stderr, interpreter versions,
source hashes and return codes, and checks that the sources remain unchanged.
Do not use `-O`, `-OO` or `PYTHONOPTIMIZE`. No network, installation or paid
compute is required. Discovery programs are outside the acceptance path.

Build the paper with an existing LaTeX installation:

```sh
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

`MANIFEST.json` records the hash and byte length of every other package file.
File hashes establish byte integrity; they do not replace mathematical review.

## Literature inputs

- Shevtsova's finite iid caps .469, .3322(1+.429/rho), and .3031(1+.646/rho).
- Schulz's strict binomial estimate on p∈[1/3,2/3].
- He–Cheng, arXiv:2609.06358v1, Lemma 4.3 and Appendix A.1 equation (70):
  finite contact and Gaussian cancellation. Its asymptotic conclusion is
  not used to obtain a finite threshold.

The precise statements and links are in the manuscript. Attainment at the
critical value, all project-specific Fourier/moment/count steps, and uniform
finite remainders are proved in the package. Local laws stay tied to the same
marginal; no optimizer or conditional noise law is transferred between indices.

## Scope

This is a locally derived, internally reviewed computer-assisted research
proof. Exact arithmetic, independent arithmetic and finite actual-law tests
are distinguished in `certificates/jobs.json` and the review documents.
The full sharp iid conjecture and the remaining smaller unrestricted indices
are not resolved. Earlier cutoff189 sources and deliverables are preserved.
