"""Fixed all-index fifth-order support, without a positive excess barrier."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import sys,json
import fifth_heat50 as H
import heat_support50 as B
assert __debug__ and not sys.flags.optimize
SPECS=[(40,'3.9','.27'),(40,'4','.59'),(40,'4.1','.95'),
       (45,'3.9','.29'),(45,'4','.62'),(45,'4.1','.98'),
       (50,'3.9','.31'),(50,'4','.64'),(50,'4.1','1')]

def main():
 assert len(sys.argv)==1
 assert len(SPECS)==len(set(SPECS))==9
 rows=[H.target(n,0,F(0),F(r),F(q))for n,r,q in SPECS]
 assert all(row['n_band'][1]is None and row['barrier']=='0'for row in rows)
 for n,r,q in SPECS:
  p=H.data(n,0,F(0))
  # With no finite upper index, the favorable frozen fifth term is zero;
  # the separate data construction must have precisely this numerator.
  v=n-1;desired=B.add(B.mul(B.A,p['W']),B.scale(B.mul(B.H4,B.H4),F(1,256*v)))
  c=p['c'];rho=p['r'];b=p['b'];ell,_=B.root(F(v));_,S=B.root(F(n,v))
  E=B.add(B.scale([0,0,0,0,0,0,1],F(51,14400*v)/ell),B.scale([-2,0,3],F(51,960*v)/ell),[0,F(1,8*v*v)])
  PA=B.add(B.scale(desired,F(2,5)*S**3),B.scale(B.mul(E,p['W']),S**3),B.mul(B.scale(p['Q'],c),p['W']))
  assert PA==p['PA0']
 negative=[]
 for name,args in [('unlicensed_radius3.8',(40,0,F(0),F('3.8'),F('.27'))),
                   ('false_gain',(40,0,F(0),F('3.9'),F('.4'))),
                   ('finite_score_floor_on_infinite_band',(40,0,F('1.5'),F(3),F(1)))]:
  try:H.target(*args)
  except (AssertionError,ValueError):negative.append(name)
  else:raise AssertionError(('false target accepted',name))
 paths=[Path(__file__),Path(H.__file__),Path(B.__file__),Path(__file__).with_name('support50_proof.tex')]
 print(json.dumps({'status':'PASS_EXACT_UNRESTRICTED_FIFTH_HEAT40_V1','rows':rows,
                   'gates':sum(r['gates']for r in rows),'negative_controls':negative,
                   'scope':'For each row, all n>=N, attained positive closed C_n>=CE, d_n<=q imply complete actual support(-R,R), uniformly in every real raw H. No positive excess barrier or own-score cap.',
                   'input_sha256':{p.name:sha256(p.read_bytes()).hexdigest()for p in paths}},indent=2))
if __name__=='__main__':main()
