from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json
B=Path(__file__).resolve().parents[3];E=B/'work/below50_20260929/entry';S=B/'work/below50_20260929/structural';R=B/'work/below50_20260929/root';L=B/'work/below50_20260929/local'
h=lambda p:sha256(p.read_bytes()).hexdigest()
names=('initial47_accept01','central47_prep_accept01','central47_input_accept01','complement47_accept01','left_support47_accept01'); files=set(); summaries=[]
for name in names:
 run=B/'runs/below50_20260929/entry'/name;m=json.loads((run/'metadata.json').read_text());o=json.loads((run/'stdout.txt').read_text().splitlines()[-1]);assert m['returncode']==0
 assert h(run/'stdout.txt')==m['stdout_sha256'] and h(run/'stderr.txt')==m['stderr_sha256']
 for n,v in o['source_sha256'].items():
  p=E/n
  if not p.exists():p=S/n
  assert h(p)==v,(name,n)
  if n in m['input_sha256']:assert v==m['input_sha256'][n]
  files.add(p)
 files.update(run.iterdir());summaries.append({k:o[k] for k in ('status','negative_controls')})
initial=json.loads((E/'initial47_proof.json').read_text());prep=json.loads((E/'central47_prep_proof.json').read_text());hyp=json.loads((R/'support47_hypotheses.json').read_text());canon=json.loads((L/'conditional_input47.json').read_text())
assert prep['initial_sha256']==h(E/'initial47_proof.json')
assert all(not p['cells'] for j,p in enumerate(initial['panels']) if j<25 or j>=60)
assert len(prep['rows'])==10 and len(hyp['radius'])==10 and len(canon['panels'])==45
seams=[]
for j,z in enumerate(prep['rows']):
 if z['excluded']:assert j==9;continue
 t=hyp['radius'][j];l,u=F(z['pl']),F(z['pu']);a,b=map(F,t['p'])
 assert a<=l<u<=b
 lower=1-2*u-2*(1-u)*F(z['theta']); bl,bu=map(F,t['beta'])
 assert lower>=bl and F(z['beta'])<=bu and F(z['rho'])<=F(t['rho']) and F(z['H'])<=F(t['h'])
 seams.append(j)
for n in ('initial47_proof.json','central47_prep_proof.json','complement47_accepted.json','initial47_panel_proof.tex','confined_feedback47_proof.tex','contracted_kernel.py','contracted_panel_core.py'):files.add(E/n)
files.update([L/'conditional_input47.json',R/'support47_hypotheses.json',S/'ENTRY47_PANEL_REVIEW.md',S/'CONTRACTED_ENTRY47_REVIEW.md',S/'INITIAL47_DELTA_REVIEW.md',Path(__file__)])
# The selected proof objects match the recorded input/output bindings.
mi=json.loads((B/'runs/below50_20260929/entry/initial47_accept01/metadata.json').read_text());assert h(E/'initial47_proof.json')==mi['input_sha256']['initial47_proof.json']
for name in ('central47_prep_accept01','central47_input_accept01'):
 m=json.loads((B/'runs/below50_20260929/entry'/name/'metadata.json').read_text());assert h(E/'central47_prep_proof.json')==m['input_sha256']['central47_prep_proof.json']
out=json.loads((B/'runs/below50_20260929/entry/central47_input_accept01/stdout.txt').read_text().splitlines()[-1]);assert out['canonical_sha256']==h(L/'conditional_input47.json')
co=json.loads((E/'complement47_accepted.json').read_text());assert co['initial_sha256']==h(E/'initial47_proof.json')
for z in co['surviving_cells']:
 assert 145<=z['index']<190 and F(z['rho'])<F('1.390') and F(z['beta'])<F('.430')
o={'schema':'INDEPENDENT_ENTRY47_PANELS_REVIEW_V1','mathematical_status':'Selected conditional initial/central/complement acquisition and left-support row independently reviewed; no defect found. Contracted-radius extension analytically reviewed only, no fixed feedback acceptance claimed.','execution_status':'Five recorded fresh runs verified against current selected source hashes; no expensive arithmetic rerun claimed.','external_premises':['n>=47, attained oriented contact, CE<=C<=.4247, initial actual support |X|<=3.84','root support47 additionally needs 0<=a<=.7/n and decrement<=.19','confined feedback additionally consumes independently acquired noise confinement'],'summaries':summaries,'exact_seams':{'initial_empty_outside':[25,60],'prep_to_contact_rows':seams,'central_cover':['.38','.47'],'complement_cover':[['.25','.38'],['.48','.60']],'left_survivors':['.29','.38']},'sha256':{str(p.relative_to(B)):h(p) for p in sorted(files) if p.is_file()}}
(S/'ENTRY47_PANEL_BINDING.json').write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps({'status':'PASS_ENTRY47_PANEL_REVIEW_BINDING','files':len(o['sha256']),'prep_to_contact_seams':len(seams),'binding_sha256':h(S/'ENTRY47_PANEL_BINDING.json')}))
