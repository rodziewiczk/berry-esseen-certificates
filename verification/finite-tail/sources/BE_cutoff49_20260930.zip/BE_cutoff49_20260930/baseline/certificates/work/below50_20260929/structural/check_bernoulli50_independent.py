#!/usr/bin/env python3
"""Independent rational spot checks of the Bernoulli interval kernel.

The continuous-domain proof is reviewed in BERNOULLI50_REVIEW.md. These tests
exercise implementation semantics using Fraction arithmetic, a different pi
identity, and exact binomial recurrences; they do not replace that proof.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
from hashlib import sha256
import importlib.util,json,random,sys
assert __debug__ and not sys.flags.optimize
ROOT=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location('reviewed_bernoulli',ROOT/'root/bernoulli_reserve.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)

def sqrt_bounds(x):
    scale=10**40
    t=isqrt(x.numerator*scale*scale//x.denominator)
    return F(t,scale),F(t+1,scale)

def atan(q):
    s=sum((F((-1)**j,(2*j+1)*q**(2*j+1))for j in range(81)),F(0))
    return s-F(1,163*q**163),s
# arctan(1/2)+arctan(1/3)=pi/4: tangent is exactly one and both
# positive angles have sum <1/2+1/3<1<pi/2.
a=atan(2);c=atan(3);pi=(4*(a[0]+c[0]),4*(a[1]+c[1]))
PHI=(sqrt_bounds(1/(2*pi[1]))[0],sqrt_bounds(1/(2*pi[0]))[1])

def exp_ref(x):
    assert 0<=x<=F(1,2)
    term=F(1);s=term
    for j in range(1,32):
        term=term*x/j;s=s+term if j%2==0 else s-term
        if j==30:hi=s
    return s,hi

def cdf_ref(z):
    assert abs(z)<=1
    if z<0:
        lo,hi=cdf_ref(-z);return 1-hi,1-lo
    term=z;s=term
    for j in range(1,32):
        term=term*z*z/(2*j);s=s+term/(2*j+1) if j%2==0 else s-term/(2*j+1)
        if j==30:hi=s
    return F(1,2)+PHI[0]*s,F(1,2)+PHI[1]*hi

def binomial_ref(n,k,p):
    pm=(1-p)**n;cdf=pm
    for j in range(1,k+1):
        pm=pm*(n-j+1)*p/(j*(1-p));cdf+=pm
    return cdf,pm

def score_ref(n,k,p):
    v=p*(1-p);root=sqrt_bounds(n*v);d=k-n*p
    zs=sorted([d/root[0],d/root[1]])
    gl=cdf_ref(zs[0])[0];gh=cdf_ref(zs[1])[1]
    Fk=binomial_ref(n,k,p)[0]
    vals=[r*(Fk-g)/(1-2*v)for r in root for g in(gl,gh)]
    return min(vals),max(vals)

def encloses(i,lo,hi):
    assert i.fraction_lower()<=lo<=hi<=i.fraction_upper(),(str(i.fraction_lower()),str(lo),str(hi),str(i.fraction_upper()))

checks=0
# Constants independently checked through the 1/2 + 1/3 atan identity.
encloses(b.PHI,*PHI);checks+=1
sl,su=sqrt_bounds(F(10));encloses(b.CE,(3+sl)*PHI[0]/6,(3+su)*PHI[1]/6);checks+=1
rng=random.Random(905029)
for _ in range(120):
    v=sorted([F(rng.randint(-10000,10000),rng.randint(1,10000))for j in range(2)])
    w=sorted([F(rng.randint(-10000,10000),rng.randint(1,10000))for j in range(2)])
    x=b.I(*v);y=b.I(*w)
    encloses(x+y,v[0]+w[0],v[1]+w[1]);checks+=1
    prod=[a*c for a in v for c in w];encloses(x*y,min(prod),max(prod));checks+=1
    if w[0]>F(1,10000):
        quot=[a/c for a in v for c in w];encloses(x/y,min(quot),max(quot));checks+=1
    sq=[a*a for a in v];encloses(x.square(),F(0)if v[0]<=0<=v[1]else min(sq),max(sq));checks+=1
    if v[0]>=0:
        encloses(x.sqrt(),sqrt_bounds(v[0])[0],sqrt_bounds(v[1])[1]);checks+=1
for j in range(-40,41):
    z=F(j,40);encloses(b.cdf_point(int(z*b.S)),*cdf_ref(z));checks+=1
for j in range(21):
    z=F(j,40);encloses(b.exp_negative(b.I(z)),*exp_ref(z));checks+=1
cells=[]
for n in range(40,99,3):
    for p in [F('.35'),F('.405'),F('.46')]:
        k=int(n*p+F(1,2));lo=max(F('.35'),p-F(1,4000));hi=min(F('.46'),p+F(1,4000))
        cells.append((n,k,lo,hi))
cells += [(46,15,F('.35'),F('.35')),(50,24,F('.46'),F('.46'))]
for n,k,lo,hi in cells:
    interval,deriv=b.score_cell(n,k,lo,hi)
    for p in [lo,(3*lo+hi)/4,(lo+hi)/2,(lo+3*hi)/4,hi]:
        f,pm=binomial_ref(n,k,p);kernel=b.binomial(n,k,p)
        encloses(kernel[0],f,f);encloses(kernel[1],pm,pm);checks+=2
        sl,su=score_ref(n,k,p);encloses(interval,sl,su);checks+=1
# Reject a false interval claim: the repaired result must retain the midpoint.
n,k,lo,hi=cells[0];interval,_=b.score_cell(n,k,lo,hi)
assert interval.lo<=b.score_point(n,k,(lo+hi)/2).lo;checks+=1
print(json.dumps({'status':'PASS_INDEPENDENT_RATIONAL_DIAGNOSTICS','checks':checks,'closed_cells_tested':len(cells),
    'scope':'rational arithmetic, independent constants/CDF/binomial evaluations, point tests within reviewed continuous enclosures; not a standalone full-domain reserve certificate',
    'kernel_sha256':sha256((ROOT/'root/bernoulli_reserve.py').read_bytes()).hexdigest(),
    'review_source_sha256':sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
