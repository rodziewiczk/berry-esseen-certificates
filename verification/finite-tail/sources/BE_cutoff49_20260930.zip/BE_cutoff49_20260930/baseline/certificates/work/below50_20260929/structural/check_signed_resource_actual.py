"""Independent exact actual-law tests of sign-specific moment/resource lemmas."""
from fractions import Fraction as F
from math import isqrt
from collections import defaultdict
import json,sys
assert __debug__ and not sys.flags.optimize
S=F(3162277660,10**9)
def lower(x):return F(isqrt(x.numerator*10**24//x.denominator),10**12)
def upper(x):return lower(x)+F(1,10**12)
def bern(a):return {-a:1/(1+a*a),1/a:a*a/(1+a*a)}
def mix(a,b,w):
 out=defaultdict(F)
 for x,p in a.items():out[x]+=(1-w)*p
 for x,p in b.items():out[x]+=w*p
 return {x:p for x,p in out.items() if p}
def L(j,R,v):
 return {3:R+2*v,4:R*R+2*R*v+3*v*v,5:R**3+2*R*R*v+3*R*v*v+4*v**3}[j]
base=[bern(a)for a in map(F,('1/2','2/3','4/5','9/10'))]
laws=base+[mix(a,b,w)for a in base for b in base for w in(F(1,10**12),F(1,1000),F(1,3),F(1,2),F(999,1000))]
checks=outerchecks=identities=0
for law in laws:
 assert sum(law.values())==1 and sum(x*t for x,t in law.items())==0 and sum(x*x*t for x,t in law.items())==1
 p=sum(t for x,t in law.items()if x>0);q=1-p;m=sum(x*t for x,t in law.items()if x>0)
 ap=m/q;bp=m/p;al=min(-x for x in law if x<0);bl=min(x for x in law if x>0);R=max(abs(x)for x in law)
 tp=sum((x-bp)**2*t for x,t in law.items()if x>0);tm=sum((x+ap)**2*t for x,t in law.items()if x<0);theta=tp+tm
 assert theta==1-m*m/(p*q)
 kp=3*(S+1)*bl;km=3*(S+3)*al;r=6*m*(al+bl)*(ap-al+bp-bl)+kp*tp+km*tm
 for extra in (F(0),F(1,100),F(1,20)):
  l=max(F(1,100),p-extra);u=min(F(499,1000),p+extra);assert 0<l<=p<=u<F(1,2)
  vplus=upper((1-l)/l);vminus=upper(u/(1-u));v=l*(1-l)
  bmax={3:upper((1-2*v)**2/v),4:1/v-3,5:(1-4*v+2*v*v)/(v*lower(v))}
  for T in (theta,min(F(9,10),theta+F(1,100)),min(F(9,10),theta+F(1,10))):
   for j in (3,4,5):
    actual=sum(abs(x)**j*t for x,t in law.items());meanpart=p*bp**j+q*ap**j
    assert actual<=meanpart+L(j,R,bp)*tp+L(j,R,ap)*tm;identities+=1
    k=F(j,2)if T==0 else (2-T if j==4 else max(F(0),(1-upper((1-T)**j))/T))
    assert 1-k*T>=0
    bound=bmax[j]+r*max(F(0),(L(j,R,vplus)-k*bmax[j])/kp,(L(j,R,vminus)-k*bmax[j])/km)
    assert actual<=bound,(j,p,theta,actual,bound);checks+=1
  Tplus=sum((x**3-bl*bl*x)*t for x,t in law.items()if x>0)
  Tminus=sum(((-x)**3-al*al*(-x))*t for x,t in law.items()if x<0)
  assert Tplus<=2*m*vplus*(bp-bl)+L(3,R,vplus)*tp
  assert Tminus<=2*m*vminus*(ap-al)+L(3,R,vminus)*tm
  price=max((S-1)*vplus/(3*(al+bl)),(S+1)*vminus/(3*(al+bl)),(S-1)*L(3,R,vplus)/kp,(S+1)*L(3,R,vminus)/km)
  assert (S-1)*Tplus+(S+1)*Tminus<=r*price;outerchecks+=1
# Replacing an endpoint chord by the tangent at zero has the wrong direction.
assert (1-F(1,10))**2>1-2*F(1,10)
# The upper B replacement needs a nonnegative coefficient; reject that misuse.
assert F(2)*(-F(1,10))<F(1)*(-F(1,10))
print(json.dumps(dict(status='PASS_INDEPENDENT_SIGNED_RESOURCE_ACTUAL',laws=len(laws),moment_checks=checks,conditional_Taylor_checks=identities,outer_checks=outerchecks,scalar_false_claims=2,scope='Exact finite controls supplement independent continuum derivation. Resource r is the actual shared charge; no D approximation is assumed.')))
