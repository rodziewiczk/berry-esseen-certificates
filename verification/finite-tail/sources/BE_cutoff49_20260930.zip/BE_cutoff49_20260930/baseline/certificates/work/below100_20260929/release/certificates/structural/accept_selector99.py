"""Independent exact selector arithmetic for the candidate cutoff99 chain.

This checks only the numerical composition and index seams. It requires
the separately proved entry/support/local statements and retained STOP180.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
assert __debug__ and not sys.flags.optimize

def harmonic(l,u):return sum((F(1,j)for j in range(l,u+1)),F(0))
def close(N,k,local_floor,anchor,K,delta):
    assert N-k>=anchor and N-k+1>=local_floor
    reserve=delta*harmonic(N-k+1,N)-K/F(N-k)
    assert reserve>0
    return reserve

def main():
    assert len(sys.argv)==1
    K=F('.7');q=F('1.17');delta=F('.19');M=90;b=94
    U=F('.469')-F('.4095')
    assert q>K/F(M-1)
    initial_reserve=K/b+q*harmonic(M,b)-U
    assert initial_reserve>0
    # Same-current-law score floors used by the finite-band entry profiles.
    rho_anchor=F('.3031')*F('.646')/(F('.1064')+K/94)
    rho_propagation=F('.3031')*F('.646')/(F('.1064')+K/188)
    assert rho_anchor<F('1.72') and rho_propagation<F('1.778029')
    assert K/F(95-1)==F(7,940)
    assert 95<=188 and 188+1==189
    # After the finite band, a first barrier failure is automatically slow.
    # The new all-H support theorem supplies radius4.1, contained in STOP180's4.5.
    assert K/F(189-1)<F('1.02') and 189>=180 and 189>=80
    assert F('4.1')<F('4.5') and F('.49823')<K
    # After propagation, nonnegative indices have the broad entry support.
    assert K*F(95,94)<F('1.02') and 95>=80
    own=F('.40974')+K/95
    three=F('.40974')+K/94
    assert own<F('.41719') and three<F('.418')
    assert 96-2==94  # LOCAL95 is applied only from96.
    assert delta<F('.2') and 96>=95
    reserve=close(99,4,96,94,K,delta)
    # Uniformity: (N-4)/(N-i)=1-(4-i)/(N-i), strictly increasing.
    derivatives=[4-i for i in range(4)]
    assert min(derivatives)>0
    rejected=[]
    for name,args in [('unlicensed_LOCAL95_at95',(98,4,96,94,K,delta)),
                      ('only_three_losses',(99,3,96,94,K,delta))]:
        try:close(*args)
        except AssertionError:rejected.append(name)
        else:raise AssertionError(name)
    assert own>F('.4171')
    rejected.append('unlicensed_own_cap_.4171')
    print(json.dumps(dict(status='PASS_INDEPENDENT_SELECTOR99_ARITHMETIC',
          anchor_index=94,initial_band=[90,94],propagation_band=[95,188],
          tail_start=189,retained_tail_input='STOP180',tail_stopping_ceiling='49823/100000',
          anchor_reserve=str(initial_reserve),
          anchor_rho=str(rho_anchor),propagation_rho=str(rho_propagation),
          own_cap_at95=str(own),three_index_cap_at96=str(three),
          local_theorem_floor=95,local_application_floor=96,
          forced_loss=str(delta),final_steps=4,cutoff=99,reserve_at99=str(reserve),
          monotone_numerators=derivatives,negative_controls=rejected,
          source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
          scope='Numerical and index composition only. Requires ANCHOR90, PROPAGATE95, retained supported STOP180 for the ceiling extension from189, ENTRY95, heat bridge, INPUT95, Gaussian/exterior and the full local comparison.'),indent=2))
if __name__=='__main__':main()
