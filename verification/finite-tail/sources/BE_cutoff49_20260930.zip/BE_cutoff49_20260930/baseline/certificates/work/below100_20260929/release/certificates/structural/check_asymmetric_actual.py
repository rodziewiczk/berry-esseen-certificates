#!/usr/bin/env python3
"""Exact, independent controls for signed deletion and half-line slopes.

These controls do not assert that their finitely supported test laws attain
a Berry--Esseen maximum. The analytic statement is in the sibling TeX file.
Only the polynomial identities and rational scalar bounds are finite proof
obligations; actual-law enumeration tests the probability bookkeeping.
"""
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path


def validate(d):
    assert all(isinstance(x, F) and isinstance(v, F) and v > 0 for x, v in d.items())
    assert sum(d.values()) == 1


def two_sided(left, right):
    left, right = F(left), F(right)
    if not left and not right:
        return {F(0): F(1)}
    assert left > 0 and right > 0
    return {-left: right / (left + right), right: left / (left + right)}


def convolution(a, b):
    out = defaultdict(F)
    for x, px in a.items():
        for y, py in b.items():
            out[x + y] += px * py
    return dict(out)


def interval_mass(d, lo, hi):
    return sum((v for x, v in d.items() if lo <= x <= hi), F(0))


def concentration(d, width):
    assert width >= 0
    return max(interval_mass(d, x, x + width) for x in d)


def probability_controls():
    laws = [
        (F('1/2'), two_sided(0, 0), two_sided(0, 0)),
        (F('3/8'), two_sided(0, 0), two_sided(0, 0)),
        (F('.35'), two_sided('.49', '.001'), two_sided(0, 0)),
        (F('.46'), two_sided(0, 0), two_sided('.001', '.49')),
        (F('5/12'), two_sided('.4', '.001'), two_sided('.0005', '.4')),
        (F('2/5'), two_sided('.49', F(1, 10**9)), two_sided(F(1, 10**10), '.49')),
        (F('1/2'), two_sided('.49', '.001'), two_sided('.001', '.49')),
    ]
    identities = inequalities = collisions = signed_losses_avoided = 0
    asymmetry_gains = rare_atom_laws = 0
    for p, u0, u1 in laws:
        q = 1 - p
        validate(u0); validate(u1)
        assert sum(x * v for x, v in u0.items()) == 0
        assert sum(x * v for x, v in u1.items()) == 0
        a = max(u0); b = 1 + min(u1); d = a + 1 - b
        assert a >= 0 and 1 - b >= 0 and d >= 0
        marginal = defaultdict(F)
        pair = []
        for label, conditional, weight in [(0, u0, q), (1, u1, p)]:
            for noise, mass in conditional.items():
                y = label + noise
                marginal[y] += weight * mass
                pair.append((y, label, noise, weight * mass))
        marginal = dict(marginal)
        validate(marginal)
        epsilon = sum(abs(u) * mass for _, _, u, mass in pair)
        s = sum(u * u * mass for _, _, u, mass in pair)
        rare_atom_laws += min(marginal.values()) < F(1, 10**8)
        delta_law = defaultdict(F)
        for z0, m0 in u0.items():
            for z1, m1 in u1.items():
                delta_law[z1-z0] += m0*m1
        assert min(delta_law) >= -d
        assert sum(x*v for x, v in delta_law.items()) == 0
        summed = {F(0): F(1)}
        for m in range(1, 5):
            previous = summed
            summed = convolution(summed, marginal)
            # Preserve the complete label/noise tuples, including collisions.
            paths = []
            for row in product(pair, repeat=m):
                total_y = sum(z[0] for z in row)
                total_k = sum(z[1] for z in row)
                total_u = sum(z[2] for z in row)
                mass = F(1)
                for z in row: mass *= z[3]
                paths.append((total_y, total_k, total_u, mass))
            assert sum(z[3] for z in paths) == 1
            for x in [F('-1/2'), F(0), F('3/2')]:
                nu = {x-y: v for y, v in summed.items()}
                mu = x-m*p
                positions = sorted(nu)
                selected = sorted(set([positions[0], positions[len(positions)//3],
                                       positions[len(positions)//2], positions[-1],
                                       F('-.49'), F(0), F('.2')]))
                # Include tau equal to an actual positive conditional jump.
                taus = sorted(set([F(0), F('.03'), F('.12')] +
                                  [z for z in delta_law if z >= 0]))
                for i, lo in enumerate(selected):
                    for hi in selected[i:]:
                        w = hi-lo
                        nu_i = interval_mass(nu, lo, hi)
                        t1_i = sum(mass*u1mass for remaining, mass in previous.items()
                                   for noise, u1mass in u1.items()
                                   if lo <= x-remaining-1-noise <= hi)
                        signed_i = sum((y-mu+u)*mass
                                       for total, _, u, mass in paths
                                       for y in [x-total] if lo <= y <= hi)
                        assert nu_i-t1_i == signed_i/(m*p)
                        identities += 1
                        di = max(F(0), hi-mu)
                        if di < max(abs(lo-mu), abs(hi-mu)):
                            signed_losses_avoided += 1
                        for tau in taus:
                            jlo, jhi = lo+1-d, hi+1+tau
                            dj = max(F(0), jhi-mu)
                            nu_j = interval_mass(nu, jlo, jhi)
                            t0_j = sum(mass*u0mass for remaining, mass in previous.items()
                                       for noise, u0mass in u0.items()
                                       if jlo <= x-remaining-noise <= jhi)
                            signed_j = sum((y-mu+u)*mass
                                           for total, _, u, mass in paths
                                           for y in [x-total] if jlo <= y <= jhi)
                            assert t0_j-nu_j == signed_j/(m*q)
                            identities += 1
                            bad = sum(v for z, v in delta_law.items() if z > tau)
                            qold = concentration(previous, w)
                            assert t1_i-t0_j <= qold*bad
                            error = (di*concentration(summed, w)/(m*p)
                                     +epsilon*qold/p
                                     +dj*concentration(summed, w+d+tau)/(m*q)
                                     +epsilon*concentration(previous, w+d+tau)/q
                                     +qold*bad)
                            assert nu_i-nu_j <= error
                            inequalities += 2
                            collisions += any(z == tau for z in delta_law)
                            asymmetry_gains += tau > d
                            if tau > 0:
                                assert bad <= s/(s+min(p,q)*tau*tau)
                                assert bad <= d/(d+tau)
                                inequalities += 2
    assert rare_atom_laws and collisions and signed_losses_avoided and asymmetry_gains
    return dict(laws=len(laws), exact_identities=identities,
                exact_inequalities=inequalities, threshold_collision_checks=collisions,
                signed_distance_gains=signed_losses_avoided,
                asymmetric_width_gains=asymmetry_gains, tiny_atom_laws=rare_atom_laws)


if __name__=="__main__":
    result=probability_controls()
    result.update(status="PASS_EXACT_ASYMMETRIC_CANTELLI_ACTUAL_CONTROLS",source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),scope="Finite actual-law enumeration of directed asymmetric deletion, open bad-event threshold, Cantelli and Markov bounds. No extremizer claim.")
    print(json.dumps(result,indent=2))
