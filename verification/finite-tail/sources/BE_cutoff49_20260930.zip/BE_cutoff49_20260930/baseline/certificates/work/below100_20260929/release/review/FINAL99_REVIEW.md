# Independent review of the cutoff-99 proof

Reviewed on 29 September 2026. The final byte binding is recorded separately
in `FINAL99_BINDING.json`; this document explains the scope of the review.

## Conclusion and status

The selected manuscript and finite supplement establish the following
computer-assisted research result: for every integer `n >= 99`, the
unrestricted iid Berry--Esseen constant `C_n` is strictly below
`C_E = (3 + sqrt(10))/(6 sqrt(2 pi))`.

| Aspect | Mathematical status | Execution status |
| --- | --- | --- |
| Published finite caps and strict binomial theorem | External inputs, statements and normalization checked directly | Not replaced by a local arithmetic run |
| He--Cheng finite contact and Gaussian cancellation inputs | Supplied/cited finite results; exact scope checked against the source | Source inspection, not a new execution proof |
| New heat support, signed entry, confinement, direct comparisons, and LOW | Locally derived project-specific proofs and their reductions independently reviewed | Selected component acceptance freshly passes |
| Assembled global cutoff-99 implication | Locally derived and checked; no unresolved dependency found in the reviewed scope | Selected 21-job suite freshly passes; the final byte binding distinguishes later prose/layout edits |
| Lean or external referee verification | Not formalized and not externally refereed | Not performed |

The finite arithmetic supplement is part of this proof. A PASS, source
hash, or reviewer agreement does not replace the mathematical reductions.
This review makes no claim about the remaining unrestricted indices below
99 or the full sharp iid conjecture. The previous cutoff-189 release is
not used as a black-box tail theorem and has been preserved.

## Reviewed analytic foundations

The attainment argument preserves second moments using the third-moment
tail bound; it does not claim uniform integrability of third moments from
their bounded expectations. The maximizing raw thresholds are bounded.
Portmanteau is applied with the correct closed, moving-threshold upper
bound. The positive closed extremizer exists also at the critical value
`C_n = C_E`. Reflection first gives a positive strict discrepancy;
continuity of the Gaussian CDF then identifies the supremum used by the
positive closed attainment argument.

The finite contact input applies to an attained positive maximum `C_n>0`,
so its hypotheses include the critical case. Higher moments are used
only after contact has bounded the actual support. The compensated
Fourier identity uses the correctly signed cubic Gaussian correction,
integrable low-frequency cancellation, and decaying high-frequency
integrands. The exact defect identity retains the raw sum threshold,
the signed branch, all endpoint conventions, and the same law throughout
each fixed-index calculation. It does not transport an optimizer between
indices or use a fixed-law asymptotic estimate uniformly over laws.

The two exact budgets are kept separate. The raw remainder supplies the
density floor; the conserved budget removes a nonnegative threshold
charge. The signed moment inequalities use Cauchy on the two sign classes,
and the stronger opposite-sign probability estimate is used only after
the central gap has excluded an atom at zero. The continuous envelopes
check endpoints, the relevant clipped vertex, and the kink where needed.
The probability cells of successive refinements retain their own prior
bounds and are excluded only by a genuinely impossible inequality.

## The global dependency chain

1. On the finite band `90..94`, the barrier `a_j >= .7/j` and slow
   decrement `d_j <= 1.17` give actual support radius `3.9`. ANCHOR90
   excludes that slow witness. Five fast steps contradict the published
   cap, with exact reserve `1354541/117288500`, giving `a_94 < .7/94`.
2. For a first barrier failure in `95..188`, the preceding ceiling gives
   `d_j < .7/(j-1) <= 7/940`. Adaptive support gives radius `3.7` and
   PROPAGATE95 excludes the witness. Its moment floor correctly uses the
   upper band endpoint 188, not the lower endpoint 95.
3. At a first failure at `j >= 189`, the decrement is below `1.02`.
   All-threshold heat support gives radius `4.1`, contained in `4.5`.
   The retained supported STOP180 calculation gives
   `j a_j < .49823 < .7`. This establishes the ceiling for every `j>=94`
   without assuming a previous unrestricted cutoff.
4. The own-score cap `.41719` is available at `n>=95`. All three caps
   `C_n,C_(n-1),C_(n-2)<.418` are available only at `n>=96`. The selected
   global proof respects these different floors.
5. At `n>=96`, an attained nonnegative witness with `d_n<=.19` goes
   through radius `4.1`, ENTRY95, the threshold-free radius `2.5` heat
   bridge, INPUT95, Gaussian/exterior localization, and the complete
   conditional local comparison. Each output has been checked against
   the next statement's hypothesis; there is no entry/local circularity.
6. Positive conditional noise strictly lowers the score relative to the
   corresponding standardized binary law. Zero conditional noise makes
   the original law binary. Schulz's strict theorem applies in both
   cases, ruling out the assumed nonnegative witness.
7. Four forced losses at `N,N-1,N-2,N-3` reach an index covered by the
   ceiling for all `N>=99`. The exact reserve at 99 is
   `12229769/28609257600`. The all-later-index comparison is proved
   algebraically, rather than inferred from a finite collection of `N`.

## Actual-law local comparison and complete coverage

The conditional count representation uses independent draws from the two
actual conditional laws and an independent binomial count. Conditional
exchangeability identifies its sum law with the original iid sum. It
does not optimize conditional means, variances, or events independently.
The random cutoff is defined with constant-noise extensions at both
ends, so every integer count and both tails are present. The marked
transfer retains two genuine deleted laws. Strict and non-strict event
conventions preserve atoms, exact collisions, and zero individual
conditional variances.

The asymmetric interval extension `[-d,tau]` keeps both directed deletion
errors and their separate conditional probability denominators. Its
Cantelli and Markov bounds are charged to the same resource budget as
the coordinate displacement and conditional variance. The lower-ray
derivative uses an independent absolute-noise cap. The corrected far
endpoint includes the smoothing parameter `eta`.

Normalization has support amplitude `.30`, conditional span `.312`, and
harmonic rate `14.17`. Its cubic repair uses `C>.4`, which remains valid
when the variance exceeds one quarter. No old harmonic span or rate is
reused. The new scalar certificate proves
`1-cos(2*pi*r) <= 23*r/5` on the full closed interval `[0,1]` using 80
positive Bernstein coefficients, with exact Machin bounds for pi. The
fractional-part argument covers integer collisions without a limiting
argument.

Tiny noise covers every `0<lambda<=.026`, with six phase intervals and
a moment bound that remains useful as noise approaches zero. Five direct
MID rectangles begin at phase `.04,.09,.13,.18,.25` and end at noise
`.0275,.03,.08,.10,.12`, respectively. LOW covers the complementary
central phases on 70 closed noise bands through `.20`. Common endpoints
are included. Its all-count finite differences, second/fourth-moment
tails, and infinite geometric tails are explicitly bounded. The stronger
shared shift, paired Cantelli maximum, sixth-order exponential gain,
clipped phase budget, signed mass replacement, and monotonicity in `n`
were independently derived or checked against their exact implementation.

The supplied semantic seam checker reads literal contracts through the
AST rather than importing their kernels. It independently checks the
above interfaces, closed phase/noise union, predecessor floors, and
scalar reserves. It is supplementary to the component acceptance and
the analytic proof.

## Independent checks and repairs recorded during review

The independent Bennett implementation imports no constructor or primary
acceptance code. It rechecks all 740 rational bounds using an unscaled
128-term logarithm and direct degree-64 exponential with directed decimal
rounding. This differs from the primary scaled 20-term logarithm and
degree-16 exponential raised to the 16th power. It also checks all 362
positive, five negative, and six tiny comparison cells.

Actual-law controls include symmetric/skew Bernoulli laws, nearby
four-point laws, tiny far atoms, exact event collisions, zero noise, and
asymmetric conditional deletion. A zero-atom law explicitly refuted the
stronger opposite-sign bound without its missing no-zero hypothesis;
the selected statement includes that hypothesis. The omitted `eta`
endpoint in early confinement discovery was corrected before strict
acceptance. The missing harmonic scalar dependency was added as a new
fixed certificate before the final complete suite. These are corrections
to intermediate proof steps, not counterexamples to the main conjecture.

Malformed-object controls reject missing, duplicated, reordered or
corrupted cells and coefficients, altered targets, invalid constant
domains, an unlicensed local application at 95, and the stronger loss
`.20`. Exact acceptance reconstructs the proof objects on complete
closed cells; it does not accept discovery sampling or optimization logs.

## Reproduction and final byte binding

The selected release is `work/below100_20260929/release`. Its fixed
manifest lists 21 jobs. The fresh run
`runs/below100_20260929/full_suite02/metadata.json` reports
`PASS_CUTOFF99_SUITE`, unoptimized CPython, all 21 return codes zero,
all required reported statuses, and unchanged source inputs during that
run. Later prose, numeric spacing and bibliography layout edits changed
manuscript bytes without changing the accepted arithmetic. Suite02 is
therefore not described as a run over those later manuscript bytes.
The final binding records the selected final manuscript separately and
identifies any later complete or extracted-package replay by its own
metadata and input hashes.

The final manuscript is the 54-page `final_build02/main.pdf`. This
reviewer's assigned pages 41--54 were visually checked. Pages 41--53
are pixel-identical to the already reviewed final rendering; the
shortened final page 54 was reinspected at full size. The bibliography
now fits together on that page. No clipping, overlap, missing glyph,
unreadable equation, or unresolved reference was found in this range.
The final LaTeX log contains no warning, overfull or underfull box.
The coordinator and entry reviewer separately cover the other pages.

The principal acceptance counts are 4,544 entry cells; 1,539 INPUT95
visits; 474,376 confinement gates on 81,920 boxes; 1,906 direct-comparison
gates; and 626,074 LOW gates on 71,680 boxes. Counts are evidence of the
specified finite checks, not a substitute for their semantics or scope.

`FINAL99_BINDING.json` records hashes for the complete selected
certificate source/data closure, all 16 manuscript TeX sources, the
runner, final PDF, final run metadata/stdout/stderr, and the independently
reviewed final page images. The final rendering review is recorded there.
No unresolved mathematical obligation remains in the selected cutoff-99
chain within the cited-input policy. Formal verification and external
refereeing remain separate future work.
