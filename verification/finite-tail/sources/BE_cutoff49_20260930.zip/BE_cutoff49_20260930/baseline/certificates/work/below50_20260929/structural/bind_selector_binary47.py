from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;PROJECT=BASE.parents[1]
RUN=PROJECT/'runs/below50_20260929'
def digest(p):return sha256(p.read_bytes()).hexdigest()
def evidence(name):
 p=RUN/name;m=json.loads((p/'metadata.json').read_text())
 assert m['returncode']==0
 for s in ['stdout','stderr']:assert digest(p/(s+'.txt'))==m[s+'_sha256']
 return p,m,json.loads((p/'stdout.txt').read_text())
p,m,r=evidence('root_left_binary47_accept01')
assert(r['panels'],r['indices'],r['closed_cells'],r['controls'])==(38,52,44486,7)
assert F(r['minimum_reserve'])==F('1301/500000')
for rel,h in r['source_sha256'].items():assert digest(BASE/rel)==h
for name in ['accept_left_binary47.py','left_binary47_kernel.py','bernoulli_reserve.py','left_binary_reserves47_constructed01.json']:
 assert digest(BASE/'root'/name)==m['input_sha256'][name]
ip,im,ir=evidence('structural/left_binary47_independent01')
assert(ir['checks'],ir['closed_cells'],ir['singleton_count'])==(945,63,8)
assert digest(HERE/'check_left_binary47_independent.py')==ir['review_source_sha256']==im['input_sha256']['check_left_binary47_independent.py']
assert digest(BASE/'root/bernoulli_reserve.py')==ir['kernel_sha256']
bf=list(r['source_sha256'])+['root/left_binary47_proof.tex',
 'structural/LEFT_BINARY47_REVIEW.md','structural/BERNOULLI50_REVIEW.md',
 'structural/BERNOULLI50_BINDING.json','structural/check_left_binary47_independent.py',
 'structural/LEFT270_INPUT47_BINDING.json','structural/bind_selector_binary47.py']
records={str((BASE/x).relative_to(PROJECT)):digest(BASE/x)for x in bf}
for folder in [p,ip]:
 for s in ['metadata.json','stdout.txt','stderr.txt']:
  f=folder/s;records[str(f.relative_to(PROJECT))]=digest(f)
bout=HERE/'LEFT_BINARY47_BINDING.json';assert not bout.exists()
bout.write_text(json.dumps(dict(schema='INDEPENDENT_FINITE_LEFT_BINARY47_REVIEW_V1',
 mathematical_status='Reviewed finite positive closed-CDF Bernoulli reserve only.',
 execution_status='Fresh complete fixed acceptance PASS and independent rational diagnostics PASS.',
 scope='47<=n<=98, p in [.304,.380], |k-np|<=1.25',closed_cells=44486,
 controls=7,minimum_reserve=r['minimum_reserve'],independent_checks=945,
 sha256=records),indent=2)+'\n')
sp,sm,sr=evidence('structural/cutoff50_selector01')
assert sr['mathematical_status']=='CONDITIONAL_PENDING_COMPLETE_LOCAL_EXCLUSION'
assert len(sr['negative_controls'])==14
for name,h in sr['source_sha256'].items():assert digest(HERE/name)==h==sm['input_sha256'][name]
sf=['structural/cutoff50_selector.tex','structural/cutoff50_selector_notes.tex',
 'structural/check_cutoff50_selector.py','structural/build_cutoff50_selector/cutoff50_selector_notes.pdf',
 'structural/LEFT_BINARY47_BINDING.json','structural/GLOBAL45_COMPOSITION_REVIEW.md',
 'structural/GLOBAL45_COMPOSITION_BINDING.json','structural/PAIRED_ORIENTATION47_BINDING.json',
 'root/ceiling45_and_cutoff98.tex']
records={str((BASE/x).relative_to(PROJECT)):digest(BASE/x)for x in sf}
for rel in ['work/below100_20260929/paper99/sections/identity.tex',
 'work/below100_20260929/paper99/sections/introduction.tex',
 'work/below100_20260929/structural/FINAL99_BINDING.json']:
 records[rel]=digest(PROJECT/rel)
for folder in [sp,RUN/'structural/cutoff50_selector_compile01']:
 meta=json.loads((folder/'metadata.json').read_text());assert meta['returncode']==0
 for s in ['metadata.json','stdout.txt','stderr.txt']:
  f=folder/s;records[str(f.relative_to(PROJECT))]=digest(f)
sout=HERE/'CUTOFF50_SELECTOR_BINDING.json';assert not sout.exists()
sout.write_text(json.dumps(dict(schema='CONDITIONAL_CUTOFF50_SELECTOR_REVIEW_V1',
 mathematical_status='CONDITIONAL_PENDING_COMPLETE_LOCAL_EXCLUSION',
 execution_status='Fresh exact scalar/contract verification PASS; this does not certify the local premise.',
 selected_route='Local exclusion at47..98 plus independent cutoff99; four backward forced losses; ceiling .7/n from45.',
 negative_controls=14,scalar_reserves=sr['result'],
 visual_qa='All three rendered pages personally inspected; clean compilation.',
 sha256=records),indent=2)+'\n')
print(json.dumps(dict(status='PASS_SELECTOR_AND_LEFT_BINARY_REVIEW_BINDINGS',
 selector_status='CONDITIONAL_PENDING_COMPLETE_LOCAL_EXCLUSION',
 selector_sha256=digest(sout),left_binary_sha256=digest(bout)),indent=2))
