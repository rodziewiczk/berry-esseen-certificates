"""Exact fixed finite positive Bernoulli reserve cover."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import sys,json
import bernoulli_reserve as b
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
def calculate(verbose=False):
    b.constants();out=[];count=0;digest=sha256()
    for i in range(38):
        pl,pu=F('.304')+F(i,500),F('.304')+F(i+1,500)
        rows=[]
        for n in range(47,99):
            peak=F(-1);legal=[]
            for k in range(n):
                l=max(pl,(k-F('1.25'))/n);u=min(pu,(k+F('1.25'))/n)
                if l>u:continue
                legal.append(k);nc=max(1,int((u-l)*4000)+1)
                for j in range(nc):
                    a=l+(u-l)*F(j,nc);z=l+(u-l)*F(j+1,nc)
                    score=b.score_cell(n,k,a,z)[0].fraction_upper()
                    peak=max(peak,score);count+=1
                    digest.update(f'{i},{n},{k},{a},{z},{score}\n'.encode())
            assert legal and n*pl-F('1.25')>0 and n*pu+F('1.25')<n
            reserve=b.CE.fraction_lower()-peak
            assert reserve>0
            rows.append(dict(n=n,counts=legal,reserve=str(reserve)))
        minimum=min(F(q['reserve'])for q in rows)
        floor=F((minimum*10**6).__floor__(),10**6)
        assert floor>0
        rho=(b.I(1-2*pu*(1-pu))/b.I(pu*(1-pu)).sqrt()).fraction_lower()
        out.append(dict(index=i,p=[str(pl),str(pu)],reserve=str(floor),normalized_reserve=str(rho*floor),rows=rows))
        if verbose:print(i,float(floor),flush=True)
    return dict(schema='FINITE_LEFT_BINARY_RESERVES47_V1',mathematical_status='Finite positive Bernoulli score only; no noisy-law conclusion.',
        domain='47<=n<=98,.304<=p<=.38,integerk with|k−np|<=1.25',closed_cells=count,gate_sha256=digest.hexdigest(),panels=out)
