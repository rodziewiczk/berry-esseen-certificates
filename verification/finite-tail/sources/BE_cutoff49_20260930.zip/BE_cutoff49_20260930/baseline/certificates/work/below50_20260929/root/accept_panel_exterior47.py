"""Fixed exact conditional theorem on the 47 named rational hypothesis rows."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
from panel_exterior import from_hypotheses
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent
DIGEST='3b29577be1dca2fa39161fea524740850e51c40b01a1160879ca9715f10e8d4e'


def need(v,s):
    if not v:raise ValueError(s)


def parse(blob):
    need(hashlib.sha256(blob).hexdigest()==DIGEST,'fixed named rational hypotheses')
    obj=json.loads(blob)
    need(obj['schema']=='CONDITIONAL_PANEL_EXTERIOR47_V1','schema')
    need(obj['strip']=='11/20'and len(obj['rows'])==47,'fixed selected theorem')
    for i,h in enumerate(obj['rows']):
        need(set(h)=={'p','rho','theta','H','beta_upper'},'row fields')
        l,u=map(F,h['p'])
        need(l<=F('.38')+F(i,500)<F('.38')+F(i+1,500)<=u,
             'complete named p row')
    return obj


def main():
    need(len(sys.argv)==1,'no theorem overrides')
    blob=(HERE/'panel_exterior47_hypotheses.json').read_bytes();obj=parse(blob)
    results=[];gates=0;digest=hashlib.sha256();worst=F(-100)
    for i,h in enumerate(obj['rows']):
        out=from_hypotheses(h,F(obj['strip']))
        for sign in [-1,1]:
            rows=[z for z in out['rows']if z['sign']==sign]
            need(bool(rows),'both selected exterior intervals nonempty')
            if sign>0:
                need(F(rows[-1]['interval'][1])==F('2.5'),'positive endpoint')
                need(all(a['interval'][1]==b['interval'][0]for a,b in zip(rows,rows[1:])),
                     'positive adjacency')
            else:
                need(F(rows[-1]['interval'][0])==F('-2.5'),'negative endpoint')
                need(all(a['interval'][0]==b['interval'][1]for a,b in zip(rows,rows[1:])),
                     'negative adjacency')
        for row in out['rows']:
            bound=F(row['upper']);need(bound<F('-.097'),'strict contact reserve')
            worst=max(worst,bound);gates+=1
            digest.update((str(i)+':'+json.dumps(row,sort_keys=True)+'\n').encode())
        results.append(dict(row=i,hypotheses=out['hypotheses'],worst=out['worst']))
    need(gates==1503,'complete cell cardinality')
    controls=0
    for op in ['missing','duplicate','reorder','changed_constant']:
        bad=json.loads(blob)
        if op=='missing':bad['rows'].pop()
        elif op=='duplicate':bad['rows'].append(bad['rows'][0])
        elif op=='reorder':bad['rows'].reverse()
        else:bad['strip']='1/2'
        try:parse(json.dumps(bad).encode())
        except ValueError:controls+=1
        else:raise AssertionError('changed named hypothesis table accepted')
    # A substantively stronger target really fails the contact test.
    false=from_hypotheses(obj['rows'][0],F('1/2'))
    need(F(false['worst']['upper'])>0,'false narrower strip control')
    controls+=1
    print(json.dumps(dict(status='FRESH_PASS_CONDITIONAL_PANEL_EXTERIOR47',
        entry_status='Unacquired hypotheses; no global cutoff asserted.',
        panels=len(results),closed_cells=gates,worst_upper=str(worst),
        gate_sha256=digest.hexdigest(),controls=controls,results=results,
        sources={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()for name in
           ['accept_panel_exterior47.py','panel_exterior.py','gaussian_core.py',
            'panel_exterior47_hypotheses.json','panel_exterior_proof.tex']},
        interpreter=sys.version),indent=2))


if __name__=='__main__':main()
