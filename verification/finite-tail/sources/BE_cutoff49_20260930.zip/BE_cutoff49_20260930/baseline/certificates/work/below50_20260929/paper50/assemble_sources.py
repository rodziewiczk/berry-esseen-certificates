"""Copy preserved sources and prepare auditable, locally scoped TeX excerpts."""
from pathlib import Path
import hashlib,json,re,shutil
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
PROJECT=BASE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
GROUPS=[
 ('global','Support and the earlier global ceiling',[
  ('heat','All-threshold support through the fifth Gaussian derivative','structural/support50_proof.tex'),
  ('moment','Signed moment constraints and bounded-support localization','structural/moment50.tex'),
  ('hightail','A rational finite Gaussian-tail bound','entry/high_tail_proof.tex'),
  ('anchor40','The supported anchor at index 40','entry/anchor40_proof.tex'),
  ('ceiling40','The unrestricted ceiling from index 40','root/propagation/ceiling40.tex'),
  ('smooth','A current-score cap from its predecessor','root/predecessor_score_cap.tex'),
  ('signed','The signed entry exclusions at 45 and 46','entry/signed_entry50_proof.tex'),
  ('ceiling45','The sharper unrestricted ceiling','root/ceiling45_and_cutoff98.tex')]),
 ('entry','Complete entry and simultaneous panel resources',[
  ('window','The complete wider-window Fourier bound','entry/high_window50_proof.tex'),
  ('initial','Initialization and weighted probability panels','entry/initial47_panel_proof.tex'),
  ('feedback','Acyclic confinement feedback and contracted radii','entry/confined_feedback47_proof.tex'),
  ('gamma','A conditional lower bound for the cubic moment','entry/conditional_gamma47_proof.tex'),
  ('orientation','The Fourier-only orientation clarification','entry/paired_fourier_orientation47.tex'),
  ('signresource','Separate positive and negative variance charges','entry/signed_variance_resource47_proof.tex')]),
 ('exterior','Finite Gaussian contact and acquired exterior strips',[
  ('gaussian','The general finite Gaussian series','root/gaussian_exterior40.tex'),
  ('centralstrip','Central radius and coordinate-strip implications','root/panel_exterior_proof.tex'),
  ('leftstrip','The acquired left coordinate strip','root/left_strip47_proof.tex'),
  ('heat234','A uniform smaller central support','structural/heat47_central234.tex')]),
 ('confinement','Signed deletion and strict-gap concentration',[
  ('confinement','The first acquired confinement theorem','local/confinement47_proof.tex'),
  ('sperner','Central confinement by a strict conditional gap','local/sperner47_proof.tex'),
  ('spernerprofile','Central amplitudes above positive noise levels','local/sperner47_profile_proof.tex'),
  ('leftsperner','Left confinement by a strict conditional gap','local/left_sperner47_proof.tex'),
  ('leftprofile','Left amplitudes above positive noise levels','local/left_sperner47_profile_proof.tex')]),
 ('comparison','Complete local comparison arguments',[
  ('wholecount','The actual-law transfer for all binomial counts','@work/below100_20260929/paper99/sections/whole_count.tex'),
  ('oldlow','The conserved resource and convex endpoint envelope','@work/below100_20260929/root/low95b_proof.tex'),
  ('tails','Improved marked tails and a common background','structural/low47_new_lemmas.tex'),
  ('normal','Exact finite-binomial normalization','root/low47_normalization_proof.tex'),
  ('phase','The signed phase enclosure','root/phase_low47_proof.tex'),
  ('tiny','Full-phase comparison through noise level .05','local/tiny47wide_proof.tex'),
  ('mid','Central intermediate-noise rectangles','local/mid47a_proof.tex'),
  ('leftmid','Left intermediate-noise rectangles','local/left_mid47b_proof.tex')]),
 ('binary','Finite Bernoulli reserves and the final selector',[
  ('binarygeneric','An exact finite Bernoulli CDF enclosure','root/bernoulli_reserve40_98.tex'),
  ('binaryleft','All selected left Bernoulli reserves','root/left_binary47_proof.tex'),
  ('selector','The four-step selector and its exact interfaces','structural/cutoff50_selector.tex'),
  ('completion','The complete local and global composition','root/local47_composition.tex')])
]
def drop_command(text,name):
 # Remove a balanced single argument, including nested TeX groups.
 pat='\\'+name
 while True:
  m=re.search(re.escape(pat)+r'\s*\{',text)
  if not m:return text
  start=m.end();depth=1;i=start
  while depth and i<len(text):
   if text[i]=='{' and text[i-1]!='\\':depth+=1
   if text[i]=='}' and text[i-1]!='\\':depth-=1
   i+=1
  if depth:raise ValueError('unbalanced '+name)
  text=text[:m.start()]+text[i:]
def body(text):
 if '\\begin{document}' in text:
  text=text.split('\\begin{document}',1)[1].split('\\end{document}',1)[0]
 for cmd in ('title','author','date'):
  text=drop_command(text,cmd)
 return text.replace('\\maketitle','')
records=[];modules={}
for group,title,items in GROUPS:
 for ident,heading,name in items:
  path=PROJECT/name[1:] if name.startswith('@') else BASE/name
  raw=path.read_text()
  target=HERE/'sources'/name.lstrip('@')
  target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(path,target)
  needhash=sha(path)
  if sha(target)!=needhash:raise ValueError('copy mismatch')
  selected=body(raw)
  selection='complete proof body; document wrapper removed; labels locally scoped'
  if ident=='gaussian':
   start=raw.index('\\section{The interface and the result}')
   end=raw.index('\\begin{theorem}[Gaussian40]')
   a=raw[start:end]
   start=raw.index('\\section{A finite Gaussian expansion')
   end=raw.index('\\begin{proof}[Proof of Theorem')
   b=raw[start:end].replace('Set $h=1.15$,','Fix any finite $h\\ge0$,')
   # This proof's absolute majorant is valid for every finite h.
   s=raw[end:raw.index('Also $\\rho s_n',end)]
   s=s[s.index('For $n\\ge36$'):]
   selected=a+b+'\n\\paragraph{Scale correction.}\n'+s
   selection='contact definitions; full general finite-series derivation; scalar scale correction; h left arbitrary as permitted by the majorant proof'
  # Demote original headings under this module's appendix subsection.
  selected=re.sub(r'\\subsubsection(\*?)',r'\\paragraph\1',selected)
  selected=re.sub(r'\\subsection(\*?)',r'\\subsubsection\1',selected)
  selected=re.sub(r'\\section(\*?)',r'\\subsubsection\1',selected)
  # Suppress the duplicate initial heading while preserving its label.
  selected=re.sub(r'^\s*\\subsubsection\{[^}]*\}', '', selected, count=1)
  # A TeX row break followed by an interval must not be parsed as optional
  # vertical spacing. This changes layout only, never a mathematical symbol.
  selected=re.sub(r'\\\\(\s*)\[(?=[^\]\n]*,)',r'\\\\{}\1[',selected)
  if ident=='signed':
   selected=selected.replace(r'$E[(R-|X|)(1,|X|)^{\mathsf T}(1,|X|);\pm X>0]$.',
      r'\[E[(R-|X|)(1,|X|)^{\mathsf T}(1,|X|);\pm X>0].\]')
  if ident=='window':
   selected=selected.replace(r' c=\frac{1-\max_{u\in\{1/4,81/100\}}',
      r' \begin{gathered}c=\frac{1-\max_{u\in\{1/4,81/100\}}')
   selected=selected.replace(r'[1-u+(M+3)u^2/12]}2,\qquad',
      r'[1-u+(M+3)u^2/12]}2,\\')
   selected=selected.replace(r' s=\frac{1-(M+3)53/600}{2}.',
      r' s=\frac{1-(M+3)53/600}{2}.\end{gathered}')
  if ident=='initial':
   selected=selected.replace(r' A_l=\sqrt{(1-\Theta)l/(1-l)}-',
      r' \begin{aligned}A_l&=\sqrt{(1-\Theta)l/(1-l)}-')
   selected=selected.replace(r'\frac d{6\sqrt{(1-\Theta)\min pq}\sqrt{2-d}},\qquad',
      r'\frac d{6\sqrt{(1-\Theta)\min pq}\sqrt{2-d}},\\')
   selected=selected.replace(r' B_l=\sqrt{(1-\Theta)(1-u)/u}-',
      r' B_l&=\sqrt{(1-\Theta)(1-u)/u}-')
   selected=selected.replace(r'\frac d{6\sqrt{(1-\Theta)\min pq}\sqrt{2-d}}'+'\n'+r'\]',
      r'\frac d{6\sqrt{(1-\Theta)\min pq}\sqrt{2-d}}\end{aligned}'+'\n'+r'\]')
  modules[ident]=(heading,selected,name)
  records.append(dict(module=ident,original=str(path.relative_to(PROJECT)),copy=str(target.relative_to(HERE)),sha256=needhash,selection=selection))

label_owners={}
for ident,(_,txt,_) in modules.items():
 for lab in re.findall(r'\\label\{([^}]+)\}',txt):label_owners.setdefault(lab,[]).append(ident)
unresolved=[]
for ident,(heading,txt,name) in modules.items():
 own=set(re.findall(r'\\label\{([^}]+)\}',txt))
 txt=re.sub(r'\\label\{([^}]+)\}',lambda m:'\\label{'+ident+':'+m[1]+'}',txt)
 def resolve(m):
  lab=m[2]
  owner=ident if lab in own else label_owners.get(lab,[None])[0]
  if owner is None:unresolved.append((ident,lab));return m[0]
  return '\\'+m[1]+'{'+owner+':'+lab+'}'
 txt=re.sub(r'\\(ref|eqref|pageref|autoref)\{([^}]+)\}',resolve,txt)
 if '\\input' in txt:raise ValueError('unexpanded input in '+ident)
 header='\\subsection{'+heading+'}\\label{module:'+ident+'}\n'
 header+='\\noindent{\\footnotesize Proof source: \\path{'+name.lstrip('@')+'}.}\n\n'
 if ident=='selector':
  header+='\\noindent\\textit{Current closure.} This preserved note isolates a conditional scalar implication. Its local premise is discharged in full by the following composition module.\\par\\medskip\n'
 (HERE/'fragments'/f'{ident}.tex').write_text(header+txt.strip()+'\n')

lines=[]
for group,title,items in GROUPS:
 lines+=['\\clearpage','\\section{'+title+'}\\label{app:'+group+'}']
 if group=='comparison':
  lines+=['The first two modules reproduce the complete earlier actual-count and',
          'resource arguments, whose old numerical constants retain their stated',
          'index-95 scope. The following modules derive the replacements used at',
          'index 47. No old numerical index is changed by relabelling.']
 for ident,_,_ in items:lines.append('\\input{fragments/'+ident+'}')
(HERE/'sections/appendices.tex').write_text('\n'.join(lines)+'\n')
foundation=PROJECT/'work/below100_20260929/release/paper/BE_cutoff99.pdf'
shutil.copy2(foundation,HERE/'sources/BE_cutoff99.pdf')
records.append(dict(module='foundation99',original=str(foundation.relative_to(PROJECT)),copy='sources/BE_cutoff99.pdf',sha256=sha(foundation),selection='complete immutable PDF, 54 pages'))
(HERE/'SOURCE_INVENTORY.json').write_text(json.dumps(dict(schema='PAPER50_SOURCE_INVENTORY_V1',status='Cutoff50; selected analytic and exact arithmetic checks complete',sources=records,unresolved_cross_references=unresolved),indent=2)+'\n')
print(json.dumps(dict(status='ASSEMBLED',modules=len(modules),unresolved_cross_references=unresolved)))
