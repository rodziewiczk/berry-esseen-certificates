# Independent composition audit: ceiling45 and cutoff98

## Status and separation of conclusions

The new signed entry exclusions and support rows compose to the unrestricted
ceiling a_j=C_j−C_E<.7/j for every integer j≥45, using the separately proved
1.5/j ceiling from40 and the preserved cutoff99 theorem for j≥99.
This newly available predecessor information licenses the preserved local95
proof at its actual analytical floor95 and hence gives a fallback cutoff98.
The proposed cutoff50 remains conditional on the new full local comparison
from47; the scalar four-loss calculation alone does not supply that comparison.

**Mathematical status:** independently reviewed composition and all index/cap
seams, with named already proved support, signed-entry and local inputs.
**Execution status:** I verified that the current signed_core.py,
accept_signed_entry.py, kernel.py and high_refinement.py match the source
hashes recorded by both fresh signed acceptance runs. The parent will bind a
separate fixed global scalar/seam acceptance; this review does not replace it.

## Anchor45

The independently established ceiling a_j<1.5/j for j≥40 supplies
C45<C_E+1.5/45<.4431. Suppose a45≥.7/45. Then

d45=45(a44−a45)_+ < 45*1.5/44−.7 < .8341.

The fixed single-index support row in accept_barrier45_support.py supplies
support(−3.5,3.5), with no restriction on H, under exactly this current
barrier and decrement. ANCHOR45_K07 excludes the resulting attained witness.
This gives a45<.7/45. The current-score cap came from the already proved
coarser ceiling at45, not by incorrectly copying the preceding score cap.

## Propagation46 through98 and the tail

At a first failure n in[46,98], a_(n−1)<.7/(n−1) but a_n≥.7/n. Therefore

d_n < n*(.7/(n−1)−.7/n) = .7/(n−1) ≤ .7/45.

The current-score smoothing recurrence gives C_n<.432 from this predecessor
ceiling for every n≥46. The fixed support row for the entire band[46,98]
uses its lower index46, upper index98 and precisely this decrement ceiling;
the upper index98 is essential in the moment cap obtained from the current
barrier. It gives support(−3.5,3.5), and PROP46_K07 supplies the contradiction.

For n≥99 the preserved completed strict cutoff gives a_n<0<.7/n directly.
That older theorem does not depend on any new cutoff50/98 claim or on this
new ceiling, so there is no circular tail argument.

## Review of the signed-entry seams

The repaired central P1 maximum uses m_lower when negative and m_upper when
nonnegative. Its exact negative-maximum Bernoulli regression rejects the
previous incorrect sign branch. The shared-moment PSD matrices retain their
zero-diagonal equality cases. The dynamically nested closed cover enclosures
for rho, beta, gamma and m all have outward endpoints, and the complete fixed
cardinality is24*24*8*4=18432 in every pass.

The selected acceptor checks raw<.4*N before licensing the first unweighted
defect bound. Each later pass receives only already accepted raw/defect
ceilings, and can retain a previous valid ceiling rather than manufacture
progress. All same-cell score and conserved-phase estimates use those prior
invariants. A negative upper conserved budget contradicts its nonnegative
exact identity directly; it must not be interpreted as dividing a negative
number using a one-sided index inequality. For nonnegative budgets the
floor-index division is safe. The final negative targets therefore exclude
every surviving cell of the purported witness.

The two fixed proof objects have12 and13 passes respectively. Their fresh
checks cover221184 and239616 cells and each rejects15 malformed/false objects.
I read the complete signed-core formulas, fixed acceptor and proof supplement;
no remaining defect found at these two selected scopes.

## The old local theorem really starts at95

The preserved release's `paper/sections/local.tex` states n≥95. Its additional
caps are C_n,C_(n−1),C_(n−2)≤.418. The n≥96 restriction in the old global
argument acquired these three caps from a ceiling that previously started
only at94. It was not an analytic restriction in the local comparison.

I checked the following actual lower floors in the preserved release:

- ENTRY95 and INPUT95: n≥95, own C≤.41719.
- The heat bridge: N=95, rho≤1.15, |beta|≤.31 and decrement≤.2.
- Gaussian contact/exterior: N=95; the final exterior uses decrement≤.19.
- Confinement95B: N=95, with both deleted counts n−1 and n−2.
- Normalization, tiny/direct companions, and whole-count LOW: N=95.

The only other substantive96 references are the old global cap/selector and
its review records. The number96 also appears as an unrelated Fourier
coefficient denominator or as a cell index; those are not sample-size floors.
The old source bytes have not been edited.

The new ceiling now gives, already at local index95,

C95 < .40974+.7/95 < .41719,
C93,C94,C95 < .40974+.7/93 < .418.

Thus every predecessor cap needed for both actual deleted laws is independently
available. The old slow-step proof can start at95 unchanged: attainment,
all-H support, ENTRY95, heat bridge, INPUT95 including its quadratic raw bound,
Gaussian/exterior, both shared budgets, confinement and the full conditional
local comparison. Its lambda=0 branch remains the actual binary case, covered
by the same published strict Bernoulli theorem. Hence a_n≥0 forces d_n>.19
for every n≥95 under the new ceiling.

## Fallback cutoff98

If a_N≥0 at N≥98, apply the just-licensed forced loss at N,N−1,N−2,N−3.
Each predecessor remains positive. Then

a_(N−4) > .19*sum(1/j, j=N−3..N) > .7/(N−4),

contradicting the new ceiling since N−4≥94≥45. The exact reserve at N=98 is
positive; uniformity follows because each ratio (N−4)/(N−i), i=0,1,2,3,
increases with N. Alternatively the coarser .76/N>.7/(N−4) already suffices
throughout N≥98. No new local arithmetic is needed, but a named new global
selector must replace the old selector's deliberately narrower application
floor; its old rejection of index95 remains correct at the old hypotheses.

## What is still needed for cutoff50

At every n≥47 the new ceiling licenses all three local caps below
.40974+.7/45<.4253. Four hypothetical .19 losses at47,48,49,50 exceed .7/46,
and the same scaled harmonic comparison is increasing thereafter. This is a
valid composition target. The required full local exclusion from47 is a
separate mathematical/certificate obligation, and is not asserted here.

## Final composition-source review and binding

I read the final `root/ceiling45_and_cutoff98.tex` and
`root/accept_ceiling45_composition.py`. The manuscript uses the same anchor,
first-failure and four-loss argument above. Its final cutoff98 claim uses the
already proved tail at99, so it does not need an unproved uniform extension of
the new finite signed entry profiles. The scalar checker keeps cutoff50
explicitly hypothetical, and rejects changed application floors and cutoffs.
Its dependency checks are integrity checks against fixed named files and
successful recorded executions, not a second derivation of their mathematics.
This distinction is accurate in both its module docstring and output.

The coarser ceiling dependency was also checked at the composed source level:
`root/propagation/accept_ceiling40.py` reconstructs anchor40 and all three
adjacent propagation bands41--49,50--69,70--98 with their own upper-band moment
caps and exact support rows. Its tail is the independent cutoff99 theorem.
The fixed source uses six, five and four passes in these bands, respectively;
there is no gap at an index boundary or hidden dependence on the new .7/j
ceiling. The final source-binding check compares all nine executed coarse
ceiling sources with the hashes printed by its fresh acceptance.

`GLOBAL45_COMPOSITION_BINDING.json` records the reviewed current bytes, the
complete separately supplied dependency-integrity closure, the selected prior
execution records, and independent rational computations of both four-step
reserves. It distinguishes those recorded executions from a new execution of
the binding check. No new local95 arithmetic or cutoff99 proof is rerun by
that binding check. No remaining mathematical defect was found in this
composition at its stated scope.
