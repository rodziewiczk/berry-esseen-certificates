"""Fixed exact tiny/MID obligations for CONDITIONAL_LOCAL95_B."""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial
from normalization95b import CFG,check as normalization
N=95;REGIONS=[(F('.04'),F('.0275')),(F('.09'),F('.03')),
 (F('.13'),F('.08')),(F('.18'),F('.10')),(F('.25'),F('.12'))]
TINY=F('.026')
def need(b,s):
 if not b:raise ValueError(s)
def equal(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],v)for k,v in b.items())
 if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
 return a==b
@lru_cache(None)
def log_lower(x):
 need(x>=1,'log domain');k=0
 while x>=2:x/=2;k+=1
 y=(x-1)/(x+1)
 def atanh(z):return 2*sum(z**(2*j+1)/(2*j+1)for j in range(20))
 return k*atanh(F(1,3))+atanh(y)
@lru_cache(None)
def bennett(a,b,V,num):
 need(a>0 and b>0 and V>0,'positive Bennett domain')
 need(type(num)is int and 0<num<10**6,'integer subunit enclosure')
 L=(b/a+V/(a*a))*log_lower(1+a*b/V)-b/a
 need(L>0 and L<16,'positive exponent and scaling domain')
 # exp(L) >= [sum_{j=0}^16 (L/16)^j/j!]^16.
 lower=sum((L/16)**j/factorial(j)for j in range(17))**16
 need(num*lower>10**6,'strict rational Bennett enclosure')
 return F(num,10**6)
def beta(row,a,b,V):
 need(type(row)is dict and set(row)=={'distance','variance','numerator'},'Bennett row schema')
 need(type(row['distance'])is str and row['distance']==str(b),'fixed distance')
 need(type(row['variance'])is str and row['variance']==str(V),'fixed actual variance ceiling')
 return bennett(a,b,V,row['numerator'])
def validate(o,strict=True):
 c=CFG;g=normalization();mins={};bad={}
 def pos(k,x):
  x=F(x);need(k not in g,'duplicate gate');g[k]=str(x)
  if x<=0:bad[k]=str(x)
  if strict:need(x>0,k)
 def reserve(k,x,target):
  pos(k,x);pos(k+'_target',x-target);mins[k]=str(x)
 need(type(o)is dict and set(o)=={'schema','tiny','regions'},'top schema')
 need(o['schema']=='CONDITIONAL_COMPANIONS95_B_V1','fixed theorem')
 a=c['amplitude'];L=TINY;t=c['ownhi']*L;aa=F('2.4214');lo=c['derivative_lo'];hi=c['derivative_hi'];split=F('1.2353');neg=F('.1674');positive=F('.923')
 pos('tiny_fourth',1-aa*aa*(3*t+a*a))
 pos('tiny_positive',lo*aa/2-lo*lo/4-positive)
 pos('tiny_negative_near',aa*aa/4-hi*split-neg)
 pos('tiny_negative_far',split*split/(1+split*split*t)-hi*split-neg)
 pos('tiny_negative_far_derivative',2*split/(1+split*split*t)**2-hi)
 pos('tiny_negative_endpoint',1/(1+4*t)-hi/2-neg*t)
 pos('tiny_split',F('.5')-split*t)
 logceiling=F('1.9');V=c['incoming']*L;maxarg=1+a*F('.5')/V
 pos('tiny_log_upper',sum(logceiling**j/F(factorial(j))for j in range(16))-maxarg)
 pos('tiny_ratio_monotone',F('.5')/a-V/(a*a)*logceiling-1)
 need(type(o['tiny'])is list and len(o['tiny'])==6,'six ordered tiny distances')
 betas={j:beta(row,a,F(j,10),V)for j,row in zip(range(5,11),o['tiny'])}
 specs=[('negative',neg*c['ownlo'],10),('positive0',positive*c['ownlo'],9)]
 specs.extend(('positive'+str(j),lo*F(j,10)/L,9-j)for j in range(1,5))
 for name,own,j in specs:
  b=betas[j];bracket=own-c['ratio']*b/(L*(1-b));pos('tiny_bracket_'+name,bracket)
  reserve('tiny_reserve_'+name,c['mass']*bracket-c['repair']/N,F('.001'))
 need(type(o['regions'])is list and len(o['regions'])==len(REGIONS),'complete region cover')
 for ri,((start,L),obj) in enumerate(zip(REGIONS,o['regions'])):
  need(type(obj)is dict and set(obj)=={'start','end_noise','positive','negative_first','negative_outer'},'region schema')
  need(obj['start']==str(start)and obj['end_noise']==str(L),'fixed region')
  count=int((F('.5')-start)*200);need(type(obj['positive'])is list and len(obj['positive'])==count,'positive closed phase cover')
  hp=c['H']/c['elo'];V=c['incoming']*L
  for i,row in enumerate(obj['positive']):
   left=start+F(i,200);right=left+F(1,200)
   need(type(row)is dict and set(row)=={'phase','first','outer'},'positive phase row')
   need(equal(row['phase'],[str(left),str(right)]),'ordered closed phase cell')
   vin=(1+c['cv']*(1+hp-left)/N)*L
   # Round upward to 1e-5 before the fixed rational Bennett check.
   vin=F(-((-vin.numerator*100000)//vin.denominator),100000)
   first=min(beta(row['first'],a,1-right,vin),vin/(vin+(1-right)**2));outer=beta(row['outer'],a,1-right/2,vin)
   pos(f'phase_variance:{ri}:{i}',V-vin)
   pos(f'phase_all_counts:{ri}:{i}',1+c['cv']*(hp-left)/N)
   bracket=lo*left-c['ratio']*(first+outer*outer/(1-outer));pos(f'mid_bracket:{ri}:{i}',bracket)
   reserve(f'mid_reserve:{ri}:{i}',c['mass']*bracket-c['repair']*L/N,F('.001')*L)
  first=beta(obj['negative_first'],a,1+start,V);outer=beta(obj['negative_outer'],a,F(1),V)
  t=c['ownhi']*L
  # The derivative has at most one positive-to-negative crossing after start.
  pos(f'negative_derivative:{ri}',2*t*start/(t+start*start)**2-hi)
  own=min(r*r/(t+r*r)-hi*r for r in(start,F('.5')))
  bracket=own-c['ratio']*(first+outer*outer/(1-outer));pos(f'negative_bracket:{ri}',bracket)
  reserve(f'negative_reserve:{ri}',c['mass']*bracket-c['repair']*L/N,F('.001')*L)
 return {'gates':len(g),'bad':bad,'reserves':mins,'exact_gates':g}
