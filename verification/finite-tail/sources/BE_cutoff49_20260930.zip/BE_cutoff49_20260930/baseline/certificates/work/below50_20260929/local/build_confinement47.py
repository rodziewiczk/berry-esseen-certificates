"""Construct fixed metadata; no acceptance is inferred from writing this file."""
from accept_confinement47 import reconstruct,HERE
import json
p=HERE/'confinement47_certificate.json'
if p.exists():raise FileExistsError(p)
p.write_text(json.dumps(reconstruct(),indent=2)+'\n')
print(p)
