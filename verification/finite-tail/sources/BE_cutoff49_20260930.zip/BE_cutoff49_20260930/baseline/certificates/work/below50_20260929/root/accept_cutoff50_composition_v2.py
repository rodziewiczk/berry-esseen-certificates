"""Fixed scope/identity/recorded-execution composition check.

Analytic proofs and each arithmetic acceptor are separate obligations. This
program never describes verification of an old log as a fresh arithmetic run.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import copy,json,sys
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[2]
MANIFEST_SHA='904bc8150c0f0295c022fdafea76c50e308647ea0ecb0a7ba94cc12996ef72b0'
def need(b,s):
    if not b:raise ValueError(s)
def unique(items):
    d={}
    for k,v in items:need(k not in d,'Duplicate JSON key');d[k]=v
    return d
def parse(blob):
    need(sha256(blob).hexdigest()==MANIFEST_SHA,'Fixed complete theorem manifest')
    d=json.loads(blob,object_pairs_hook=unique)
    need(d['schema']=='CUTOFF50_COMPOSITION_V2','Named theorem')
    need(d['scope']=={'ceiling_floor':45,'ceiling_coefficient':'7/10',
         'local_first':47,'local_last':98,'forced_loss':'19/100','tail_floor':99,
         'target':50,'binary_left_p':['38/125','19/50'],'binary_count_radius':'5/4'},'Exact theorem scope')
    return d
def verify(d):
    for rel,digest in d['files'].items():
        need(sha256((PROJECT/rel).read_bytes()).hexdigest()==digest,'Current proof source '+rel)
    for job in d['jobs']:
        base=PROJECT/job['source_run'];meta=json.loads((base/'metadata.json').read_text())
        need(meta['returncode']==0,'Successful named execution '+job['name'])
        # Interpreter paths and the workspace location may differ on replay;
        # the recorded command suffix must still be the selected exact job.
        need(meta['command'][-len(job['argv']):]==job['argv'],'Recorded exact arguments '+job['name'])
        need(Path(meta['cwd']).parts[-len(Path(job['cwd']).parts):]==Path(job['cwd']).parts,'Recorded working directory')
        for stream in ('stdout','stderr'):
            need(sha256((base/(stream+'.txt')).read_bytes()).hexdigest()==meta[stream+'_sha256'],'Recorded stream integrity')
    need(len({j['name']for j in d['jobs']})==len(d['jobs']),'Distinct selected jobs')
    loss=F('19/100');ceiling=F('7/10')
    reserves=[loss*sum((F(1,j)for j in range(n-3,n+1)),F(0))-ceiling/(n-4)for n in range(50,99)]
    need(all(x>0 for x in reserves),'All49 finite four-step contradictions')
    need(reserves[0]==F(2930539,6356280000),'Exact cutoff50 reserve')
    need(F('.40974')+ceiling/47<F('.4247'),'Own score cap')
    need(F('.40974')+ceiling/45<F('.4253'),'Both deleted score caps')
    need(F('.38')>=F(1,3) and F('.47')<=F(1,2),'Published Bernoulli range')
    return reserves
def main():
    need(len(sys.argv)==1,'No theorem override')
    blob=(HERE/'cutoff50_dependencies_v2.json').read_bytes();d=parse(blob);reserves=verify(d)
    controls=0
    for change in ('omit_job','duplicate_job','change_scope','omit_file','change_hash'):
        x=copy.deepcopy(d)
        if change=='omit_job':x['jobs'].pop()
        elif change=='duplicate_job':x['jobs'].append(x['jobs'][0])
        elif change=='change_scope':x['scope']['target']=49
        elif change=='omit_file':x['files'].pop(next(iter(x['files'])))
        else:x['files'][next(iter(x['files']))]='0'*64
        try:parse(json.dumps(x).encode())
        except ValueError:controls+=1
        else:raise AssertionError('Changed composition accepted')
    # These are genuine arithmetic negative controls, not hash controls.
    need(loss_three_steps()<F('.7')/47,'Three-step shortcut must fail')
    need(F('.76')/50<F('.7')/46,'Crude endpoint shortcut must fail')
    print(json.dumps(dict(status='PASS_CUTOFF50_COMPOSITION',
        theorem='C_n < C_E for every integer n>=50, with the stated published inputs and project-specific analytic proofs.',
        mathematical_status='Complete assembled computer-assisted proof; no Lean or external referee verification asserted.',
        execution_status='Fresh exact scalar checks and integrity checks of the named fresh component runs; not an arithmetic rerun of those components.',
        selected_component_runs=len(d['jobs']),source_files=len(d['files']),finite_targets=49,
        cutoff50_reserve=str(reserves[0]),negative_controls=controls+2,
        dependency_manifest_sha256=MANIFEST_SHA,interpreter=sys.version),indent=2))
def loss_three_steps():return F('.19')*sum((F(1,j)for j in range(48,51)),F(0))
if __name__=='__main__':main()
