# Independent review of Gaussian40 and Exterior40

Reviewed sources: `root/gaussian_core.py`, `root/accept_gaussian40.py`,
`root/accept_exterior40.py`, `root/gaussian_exterior40.tex` in the same run tree.

**Mathematical status:** independently rederived conditional analytic lemmas.
No new cutoff or acquisition of the entry hypotheses follows from these files.
**Execution status:** constructor fresh PASS reported; this review independently
read the full formulas and implementation rather than wrapping the same checker.
Bindings below identify the reviewed bytes.

## Gaussian expansion and arithmetic

I rederived S(z)/z from the Gaussian integral and n=1/z scaling. The coefficient
loop is exactly the rising-factorial convolution in the displayed P_j formula.
P_0 and P_1 have the asserted signs. At z0=1/4 the absolute majorant is
(7/6)(h+r)exp((h+r)^2/6)+(h+r+h(r²+1)/8)exp(h²/8).
The e<193/71 bound and coefficientwise absolute convergence give the degree-six
remainder 4^7 B_r/n^6, uniformly in the full stated H/t box. Nothing uses a
fixed-law limit. Positive-part Bernstein maxima and absolute monomial bounds
are safe for all subsequent n; every charged error decreases with n.

The outer cubics use the upper/lower C_E and phi0 endpoints with the correct
signs on each half-line. Q<0 is checked before discarding the nonnegative
excess times Q. All 76 cells cover the two closed strips through radius 4.1,
so endpoints and support accumulation points are excluded. The 90 compact
cells cover [−2,2.5], larger than the newly proved support. The H² and H charges
use (t−1)²(t+2)≥0 and |(t²−3)²−6|≤6 there. The independent scale argument
licenses .384/n from n36 and rho*s_n<1.155 from n40.

## Binary ray and transport

I rederived both P± cubics. With v=pq, the accepted polynomial is
−.3988P±+10.8v*Nlower−3v. Its positivity and Nlower<.06 first force P±<0;
only then is phi0 replaced by its lower bound. N_B≥Nlower and sqrt(v)≤1/2
then give L_p<−1+1.8D_B. The affine dependence on K is covered by its two
rational endpoints. First and second derivatives are negative at the ray
boundary and the third derivative stays negative, so the statement covers
the entire ray, not merely the initial boundary or compact support box.

Conditional centering gives rho=s^(3/2)rho_B+A3 and beta=s*beta_B+kappa.
Substitution yields the displayed transport, including the beneficial term
−sqrt(s)*theta*rho_B. The numerical upper price uses |V|<1.363 and |X|≤2.5;
no same-law correlation is discarded in a direction that strengthens the
result. The joint defect bound first gives D_B≤D, then
D≥D_B+12.5541theta. This is sufficient for the price 1.8*12.321theta.

The raw phase/defect/excess budget is used once: n*a+.20H²+.065nD<.75.
Multiplication by 360/13 cancels the same D in the exterior inequality;
the remaining a term is nonpositive. Completing the H square gives the
stated .465/n cost. The positive reserve at n40 and delta≤.4 then excludes
all transformed exterior support. The last displacement bound follows from
D≥6m(A+B)ell*d with separately checked strict lower bounds for m and ell.

## Scope seam

Contact must be supplied at every support point of an attained positive closed
maximizer. Compact support [−4.1,4.1], rho≤1.14, beta∈[.075,.3], |H|≤1.15,
C≤.45, the binary probability/gap/variance assumptions, and the single raw
budget remain external premises. The final harmonic scalar is explicitly
hypothetical and supplies no local strict-comparison theorem.

No defect found in this conditional scope.
