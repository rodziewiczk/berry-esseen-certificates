#!/usr/bin/env python3
"""Fixed row of the independently proved uniform fifth-order support theorem.

Input moment caps come from PREP47_COMPLEMENT. This reuses the complete
closed-cell/outer-ray acceptance kernel, without changing its sources.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'structural'))
import heat_support50 as h
import fifth_heat50 as f
assert __debug__ and not sys.flags.optimize
original=h.constants
def run(rho,beta,radius,decrement):
 def constants(N,last,K):
  c,_,_,ell,S=original(N,last,K);return c,rho,beta,ell,S
 h.constants=constants
 try:return f.target(47,0,F(0),radius,decrement)
 finally:h.constants=original
if __name__=='__main__':
 assert len(sys.argv)==1
 result=run(F('1.390'),F('.430'),F(3),F('.19'))
 bad=[]
 for label,args in [('false_small_radius',(F('1.390'),F('.430'),F('2.5'),F('.19'))),('false_large_decrement',(F('1.390'),F('.430'),F(3),F(10))),('false_unrestricted_moments',(F('1.85'),F('.65'),F(3),F('.19')))]:
  try:run(*args)
  except (ValueError,AssertionError):bad.append(label)
  else:raise ValueError('false support target accepted: '+label)
 paths=[Path(__file__),Path(h.__file__),Path(f.__file__),Path(h.__file__).with_name('support50_proof.tex')]
 print(json.dumps(dict(status='PASS_LEFT_SUPPORT47_R300',scope='For every n>=47, C_n>=CE, decrement<=.19, rho<=1.390 and |beta|<=.430, every attained oriented witness has full actual support(-3,3), uniformly in H. No prior support bound is assumed.',proof=result,negative_controls=bad,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}),sort_keys=True))
