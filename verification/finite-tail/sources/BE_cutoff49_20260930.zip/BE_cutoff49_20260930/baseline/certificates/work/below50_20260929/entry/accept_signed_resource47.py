#!/usr/bin/env python3
"""Fixed refinement of the complete acquired probability cover."""
from fractions import Fraction as F
from pathlib import Path
import copy,hashlib,json,sys
import coupled_panel_core as c

def need(ok,message):
 if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def unique(pairs):
 out={}
 for key,value in pairs:need(key not in out,'duplicate JSON key');out[key]=value
 return out
def load(p):return json.loads(Path(p).read_text(),object_pairs_hook=unique)
SOURCES=('left_input47_table.json','sperner_feedback47_table.json')
def shape(table):
 need(table['schema']=='SIGNED_RESOURCE47_INPUT_V1','fixed theorem')
 need(type(table['N'])is int and table['N']==47 and table['own_score_cap']=='4247/10000','fixed floor and score cap')
 need(table['probability_domain']==['38/125','47/100'],'complete selected probability interval')
 need(table['sources']==[dict(path=p,sha256=sha(p))for p in SOURCES],'all preceding acquired source bindings')
 rows=table['panels'];need(type(rows)is list and len(rows)==83,'complete refined cover')
 for j,z in enumerate(rows):
  need(type(z['index'])is int and z['index']==j,'ordered unique indices')
  need(list(map(F,z['p']))==[F(152+j,500),F(153+j,500)],'contiguous closed refined probability cells')
  name=SOURCES[0 if j<38 else 1];index=j+1 if j<38 else j-38
  need(z['source']==name and type(z['source_index'])is int and z['source_index']==index,'preceding cell identity')
  old=load(name);parent=old['panels'][index]
  need(parent['p']==z['p'],'same actual probability cell')
  radius=F(old['support_radius'])if'support_radius'in old else F(parent['actual_radius'])
  need(F(z['actual_radius'])==radius,'same proved actual radius')
  need(len(z['quadratics'])==4,'complete signed corner cover')
  for q in z['quadratics']:
   need(set(q)=={'A','Fplus','Fminus','Qraw','Qbudget'},'quadratic fields')
   need(F(q['A'])>0 and 0<F(q['Qraw'])<F(q['Qbudget']),'positive raw and budget curvatures')
def verify(table,emit=False):
 shape(table);targets={(z['source'],z['source_index']):z for z in table['panels']};count=excluded=0
 for filename,length in zip(SOURCES,(39,45)):
  source=load(filename);need(len(source['panels'])==length,'complete prior source cover')
  for j,z in enumerate(source['panels']):
   need(z['index']==j,'source indices');l,u=map(F,z['p'])
   radius=F(source['support_radius'])if'support_radius'in source else F(z['actual_radius'])
   row=dict(pl=l,pu=u,raw=F(z['T']),D=F(z['D']),theta=F(z['theta']),rho=F(z['rho']),beta=F(z['beta_hi']))
   out=c.cell(47,radius,F('.4247'),row,steps=24);count+=1
   if filename==SOURCES[0] and j==0:
    need(out.get('excluded')is True,'complete new left-edge exclusion');excluded+=1;continue
   need(not out.get('excluded')and'quadratics'in out,'selected complete paired survivor')
   target=targets[filename,j]
   for a,b in [('raw','T'),('D','D'),('theta','theta'),('rho','rho'),('beta','beta_hi'),('lambda_max','lambda_max'),('inward_d_max','d0'),('Hplus','H_plus'),('Hminus','H_minus')]:need(out[a]<=F(target[b]),('upper target',filename,j,b))
   for a,b in [('beta_lo','beta_lo'),('A','A_lo'),('B','B_lo')]:need(out[a]>=F(target[b]),('lower target',filename,j,b))
   for actual,claim in zip(out['quadratics'],target['quadratics']):
    for key in ('A','Fplus','Fminus'):need(actual[key]<=F(claim[key]),('signed corner upper',filename,j,key))
    for key in ('Qraw','Qbudget'):need(actual[key]>=F(claim[key]),('signed curvature lower',filename,j,key))
   if emit:print('PASS_SIGNED_RESOURCE47',filename,j,flush=True)
 return dict(status='PASS_SIGNED_RESOURCE47',previous_panels=count,excluded=excluded,panels=83,weighted_resources=True)
def controls(table):
 cases=[]
 for action in [lambda z:z['panels'].pop(),lambda z:z['panels'].reverse(),lambda z:z['panels'].insert(1,z['panels'][0]),lambda z:z['panels'][0].update(index=True),lambda z:z['panels'][0].update(p=['3/10','31/100']),lambda z:z['panels'][0].update(source_index=0),lambda z:z['panels'][0].update(actual_radius='2'),lambda z:z['panels'][0]['quadratics'].pop(),lambda z:z['sources'].pop(),lambda z:z['sources'].reverse(),lambda z:z['sources'][0].update(sha256='0'*64)]:
  bad=copy.deepcopy(table);action(bad);cases.append(bad)
 for bad in cases:
  try:shape(bad)
  except(ValueError,KeyError,TypeError):pass
  else:raise ValueError('malformed signed-resource proof accepted')
 for key,value in [('T','1/100'),('lambda_max','1/100000000')]:
  bad=copy.deepcopy(table);bad['panels'][0][key]=value
  try:verify(bad)
  except ValueError:pass
  else:raise ValueError('false signed-resource target accepted')
 try:unique([('x',1),('x',2)])
 except ValueError:pass
 else:raise ValueError('duplicate JSON key accepted')
 return len(cases)+3
if __name__=='__main__':
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed invocation')
 table=load('signed_resource47_table.json');out=verify(table,True);out['negative_controls']=controls(table)
 out['table_sha256']=sha('signed_resource47_table.json')
 out['source_sha256']={p:sha(p)for p in ('accept_signed_resource47.py','coupled_panel_core.py','signed_variance_resource.py','paired_conditional_gamma47.py','contracted_kernel.py','high_window_core.py','signed_variance_resource47_proof.tex')}
 print(json.dumps(out,sort_keys=True),flush=True)
