from pathlib import Path
from hashlib import sha256
import json
B=Path(__file__).resolve().parents[3];E=B/'work/below50_20260929/entry';S=B/'work/below50_20260929/structural';r=B/'runs/below50_20260929/entry/left_input47_accept01'
h=lambda p:sha256(p.read_bytes()).hexdigest();m=json.loads((r/'metadata.json').read_text());o=json.loads((r/'stdout.txt').read_text().splitlines()[-1]);assert m['returncode']==0
assert (o['previous_cells'],o['excluded_left_cells'],o['remaining_panels'],o['negative_controls'])==(45,6,39,9)
assert h(E/'left_input47_table.json')==o['table_sha256']=='2270ab68dd18e13afb7382e046589346e4cab26721a4e48be77b66ec22aa4b9a'
files=[E/'left_input47_table.json',E/'complement47_accepted.json',S/'ENTRY47_PANEL_BINDING.json',S/'LEFT47_INPUT_REVIEW.md',Path(__file__),*r.iterdir()]
for n,v in o['source_sha256'].items():assert h(E/n)==v==m['input_sha256'][n];files.append(E/n)
for n in ('left_input47_table.json','complement47_accepted.json'):assert h(E/n)==m['input_sha256'][n]
assert h(r/'stdout.txt')==m['stdout_sha256'] and h(r/'stderr.txt')==m['stderr_sha256']
z={'schema':'INDEPENDENT_LEFT47_INPUT_REVIEW_V1','mathematical_status':'Independently reviewed conditional acquired entry on [.302,.380], no defect found. Not a local-comparison or global-cutoff theorem.','execution_status':'Selected inputs/sources match recorded fresh exact replay45 inputs,6 exclusions,39 outputs,9 controls.','sha256':{str(p.relative_to(B)):h(p) for p in sorted(set(files)) if p.is_file()}}
(S/'LEFT47_INPUT_BINDING.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps({'status':'PASS_LEFT47_INPUT_REVIEW_BINDING','files':len(z['sha256']),'binding_sha256':h(S/'LEFT47_INPUT_BINDING.json')}))
