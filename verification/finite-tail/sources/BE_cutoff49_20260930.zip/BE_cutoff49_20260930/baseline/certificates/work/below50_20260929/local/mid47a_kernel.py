"""Exact fixed MID companion, separate from discovery and acquisition."""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial
import sys
from mid47a_normalization import CFG,check as normalization
from tiny47a_kernel import bennett,ceiling,need
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
REGIONS=((F('.05'),F('.06'),F('.09'),F('.35')),(F('.06'),F('.08'),F('.13'),F('.35')),(F('.08'),F('.10'),F('.18'),F('.30')),(F('.10'),F('.12'),F('.29'),F('.275')))
SCALES=tuple(F(i,100)for i in range(10,121,2))
@lru_cache(None)
def poisson_numerator(mu,anchor):
 need(mu>0 and anchor>=0,'Poisson parameters');last=32;need(last>anchor+2,'Tail start')
 finite=sum(mu**k/F(factorial(k))*max(F(0),F(k)-anchor)**3 for k in range(last+1))
 first=mu**33/F(factorial(33))*(33-anchor)**3
 ratio=mu/F(34)*((34-anchor)/(33-anchor))**3;need(0<ratio<1,'Geometric tail')
 return (finite+first/(1-ratio))/sum(mu**k/F(factorial(k))for k in range(25))
def poisson(mu,b):
 x=b+mu;fl=x.numerator//x.denominator
 anchors=sorted(set(max(F(0),F(fl)-d)for d in(F(0),F('.25'),F('.5'),F('.75'),F(1))))
 vals=[(ceiling(poisson_numerator(mu,a)/(x-a)**3),a)for a in anchors if a<x]
 need(vals,'No legal Poisson anchor');return min(vals)
def own(sign,l,h,tl,th,A,deriv):
 K=F(9)/(4*F('.4641'));best=None
 for a in SCALES:
  den=K*a**4;vals=[]
  for t in(tl,th):
   co=((3*a*a*t-A*A*t-3*t*t)/den,(2*sign*a**3-4*A*t)/den+deriv,(3*a*a-6*t)/den,F(0),-1/den)
   vals.append(sum(v*(l if v>=0 else h)**i for i,v in enumerate(co)))
  value=min(vals)
  if best is None or value>best[0]:best=(value,str(a))
 return best
@lru_cache(None)
def tail_bennett(A,V,b):return bennett(A,V,b)
def evaluate():
 c=CFG;g={k:F(v)for k,v in normalization().items()};rows=[]
 def put(k,v):
  need(k not in g,'Duplicate gate');g[k]=F(v)
 for bi,(low,high,start,A)in enumerate(REGIONS):
  tl=c['ownlo']*low;th=c['ownhi']*high;V=c['incoming']*high;mu=V/A**2
  for sign in(-1,1):
   steps=int((F('.5')-start)*1000);need(start+F(steps,1000)==F('.5'),'Exact phase cover')
   for j in range(steps):
    l=start+F(j,1000);h=start+F(j+1,1000);key=f'{bi}:{sign}:{j}'
    lower,scale=own(1 if sign<0 else-1,l,h,tl,th,A,-c['derivative_hi']if sign<0 else c['derivative_lo'])
    if sign<0:
     value=l*l/(th+l*l)-c['derivative_hi']*h
     if value>lower:lower=value;scale='Cantelli'
     distance=1+l;outerdist=F(1)
    else:
     value=c['derivative_lo']*l
     if value>lower:lower=value;scale='normal'
     distance=1-h;outerdist=1-h/2
    pc,anchor=poisson(mu,distance/A)
    first=min(pc,V/(V+distance**2),tail_bennett(A,V,distance));outer=tail_bennett(A,V,outerdist)
    put('outer:'+key,1-outer);bracket=lower-c['ratio']*(first+outer*outer/(1-outer));put('bracket:'+key,bracket)
    reserve=c['mass']*bracket-c['repair']*high/47;put('comparison:'+key,reserve-F('.001')*high)
    rows.append(dict(band=bi,sign=sign,phase=[str(l),str(h)],own=str(lower),scale=scale,first=str(first),poisson_anchor=str(anchor),outer=str(outer),reserve=str(reserve)))
 need(len(rows)==2620,'Fixed full phase row count')
 return dict(schema='CONDITIONAL_MID47_A_V1',contract={k:str(v)for k,v in c.items()},regions=[[str(x)for x in r]for r in REGIONS],scales=[str(a)for a in SCALES],rows=rows,gates={k:str(v)for k,v in g.items()},bad={k:str(v)for k,v in g.items()if v<=0})
if __name__=='__main__':
 import json
 o=evaluate();print(json.dumps(dict(status='EXACT_MID47_DIAGNOSTIC',rows=len(o['rows']),gates=len(o['gates']),bad=o['bad'],minimum_reserve=min(float(F(r['reserve']))for r in o['rows'])),indent=2));need(not o['bad'],'Nonpositive fixed gates')
