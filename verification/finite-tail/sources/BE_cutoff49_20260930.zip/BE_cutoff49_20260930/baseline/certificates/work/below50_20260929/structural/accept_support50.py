"""Fixed exact acceptance of 77 new support rows; no cutoff asserted."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
from math import comb
import copy,json,sys
import heat_support50 as Basic
import fifth_heat50 as Fifth
from support50_specs import SPECS
assert __debug__ and not sys.flags.optimize

UNRESTRICTED=[('basic',36,36,'0','4.1','.79'),('basic',40,40,'0','4.1','.83'),
              ('basic',45,45,'0','4.1','.87'),('basic',50,50,'0','4.1','.90'),
              ('basic',60,60,'0','4.1','.95')]

def construct():
    specs=SPECS+UNRESTRICTED
    assert len(specs)==len(set(specs))==77
    rows=[]
    for method,n,last,k,r,q in specs:
        kernel=Basic if method=='basic'else Fifth
        assert method in ['basic','fifth']
        row=kernel.target(n,last,F(k),F(r),F(q))
        row['method']=method;rows.append(row)
    return {'schema':'ALL_THRESHOLD_SUPPORT36_DUAL_CAP_V1','rows':rows}

def check_object(obj,expected):
    assert type(obj)is dict and set(obj)=={'schema','rows'}
    assert type(obj['rows'])is list and len(obj['rows'])==77
    assert obj==expected, 'Object differs from the completely reconstructed fixed theorem'

def main():
    assert len(sys.argv)==1
    obj=construct();check_object(obj,obj);negative=[]
    for name,mutate in [
        ('missing_row',lambda x:x['rows'].pop()),
        ('duplicate_row',lambda x:x['rows'].__setitem__(1,copy.deepcopy(x['rows'][0]))),
        ('reordered_rows',lambda x:x['rows'].reverse()),
        ('wrong_schema',lambda x:x.update(schema='OTHER')),
        ('changed_target',lambda x:x['rows'][0].update(slow='10')),
        ('changed_gate_hash',lambda x:x['rows'][0].update(gate_sha256='0'*64)),
        ('missing_closed_cell',lambda x:x['rows'][0]['closed_cells'].pop())]:
        bad=copy.deepcopy(obj);mutate(bad)
        try:check_object(bad,obj)
        except AssertionError:negative.append(name)
        else:raise AssertionError(('Accepted malformed object',name))
    for name,kernel,args in [
        ('unproved_floor35',Basic,(35,40,F('.7'),F('3.7'),F(1))),
        ('reversed_finite_band',Fifth,(45,44,F(1),F(3),F(1))),
        ('false_strong_decrement',Fifth,(45,46,F('1.5'),F(3),F(10))),
        ('outside_positive_H4_domain',Fifth,(45,46,F('1.5'),F(2),F(1))),
        ('negative_decrement',Basic,(45,46,F('1.5'),F(3),F(-1)))]:
        try:kernel.target(*args)
        except (AssertionError,ValueError):negative.append(name)
        else:raise AssertionError(('Accepted false scope',name))
    # Independent reconstruction from Bernstein back to interval monomials.
    transformations=0
    for p in [[1,-3,2],[0,-1,0,0,3],list(range(-5,6))]:
        l=F('2.8');h=F('4.5');bb=Basic.bern(p,l,h);d=len(p)-1
        out=[F(0)]*(d+1)
        for j,c in enumerate(bb):
            for k in range(d-j+1):out[j+k]+=c*comb(d,j)*comb(d-j,k)*(-1)**k
        for k in range(d+1):
            assert out[k]==sum(F(p[j])*comb(j,k)*l**(j-k)*(h-l)**k for j in range(k,d+1))
            transformations+=1
    assert Basic.EC==F('.384')
    assert (2*Basic.EC-F(3,4))-(Basic.EC+F(1,4))/35+(Basic.EC**2-Basic.EC)/35**2-Basic.EC**2/35**3<0
    paths=[Path(__file__),Path(Basic.__file__),Path(Fifth.__file__),Path(__file__).with_name('support50_specs.py'),Path(__file__).with_name('support50_proof.tex')]
    print(json.dumps({'status':'PASS_EXACT_SUPPORT36_DUAL_CAP_AND_FIFTH_HEAT_V1',
                      'mathematical_status':'New conditional same-law support theorems, uniform in every raw threshold. No supported entry or cutoff asserted.',
                      'proof':obj,'total_gates':sum(r['gates']for r in obj['rows']),
                      'negative_controls':negative,'independent_transform_identities':transformations,
                      'input_sha256':{p.name:sha256(p.read_bytes()).hexdigest()for p in paths}},indent=2))
if __name__=='__main__':main()
