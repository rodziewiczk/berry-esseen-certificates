"""Fixed conditional DIRECT_GAUSSIAN95 theorem, exact arithmetic acceptance.

All inputs are reconstructed. Requires the analytic Taylor remainder and
attained contact identity; does not assert its hypotheses or a new cutoff.
"""
from gaussian_core import F, coefficient, bernstein, add
from fractions import Fraction
from pathlib import Path
import hashlib,json,sys
assert __debug__ and not sys.flags.optimize
N=95;H=F('1.5');RHO=F('1.15');CAP=F('.418');PRED=F('1.16')

def tail(r):
    e=F(193,71);ceil=lambda x:-((-x.numerator)//x.denominator)
    return 4**5*((H+r)*F(7,6)*e**ceil((H+r)**2/6)
           +(H+r+H*(r*r+1)/8)*e**ceil(H*H/8))
def ray_coeff(s):
    return (F(1,15)-F('.4095') if s==1 else-F('.3988')/6-F('.4095'),
            F('1.5')*F('.40974')*RHO,
            3*F('.40974')*F('.3')-F('.3988')/2 if s==1 else F('.2')-3*F('.4095')*F('.05'))
def cubic(a,b,c,u):return a*u**3+b*u*u+c*u

def build():
    P=[coefficient(j)for j in range(4)]
    assert P[0]=={(0,1):F(-1,2),(0,3):F(1,6)}
    assert PRED**2>RHO**2*F(N,N-1)
    outer=[]
    for sign,start in [(1,F('2.4')),(-1,F('1.85'))]:
        a,b,c=ray_coeff(sign);beta=F('.3')if sign==1 else-F('.05')
        for aa,bb,cc in [(a,b,c),(-1,F('1.5')*RHO,3*beta)]:
            assert cubic(aa,bb,cc,start)<0
            assert 3*aa*start**2+2*bb*start+cc<0
            assert 6*aa*start+2*bb<0 and aa<0
        l=start
        while l<F('4.1'):
            r=l+F('.05');assert r<=F('4.1')
            box=(l,r)if sign==1 else(-r,-l)
            ms=[max(F(0),max(bernstein(p,(-H,H),box)))for p in P[1:]]
            err=F('.4')*(sum(ms[j-1]/N**j for j in range(1,4))+tail(r)/N**4)
            margin=-cubic(a,b,c,l)-PRED*F('.2')-RHO*F('.38')*CAP/N-err
            assert margin>F('.007'),('outer',sign,str(l),str(margin))
            outer.append(dict(sign=sign,interval=list(map(str,[l,r])),reserve=str(margin)))
            l=r
    # Direct coefficient bounds for the first Taylor correction.
    # (3t-t^3)/4 <=1/2 since (t-1)^2(t+2)>=0 on t>=-2.
    # H4=(t^2-3)^2-6 belongs to[-6,3] on [-1.85,2.4].
    assert F('2.4')**2<6 and F('1.85')<2
    inner=[];max23=[F(0),F(0)];maxc=F(0)
    l=F('-1.85')
    constant={(0,5):F(-1,40),(0,3):F(1,4),(0,1):F(-3,8)}
    while l<F('2.4'):
        r=l+F('.05');assert r<=F('2.4')
        box=(l,r)
        for j in [2,3]:max23[j-2]=max(max23[j-2],max(bernstein(P[j],(-H,H),box)))
        maxc=max(maxc,max(bernstein(constant,(F(0),F(0)),box)))
        for sign in [-1,1]:
            # Q(t) bounded by -|t|^3+1.725t^2+.9|t| on both signs.
            ubox=(max(F(0),l),r)if l>=0 else(max(F(0),-r),-l)
            if ubox[1]>=ubox[0]:
                assert max(bernstein({(0,3):F(-1),(0,2):F('1.725'),(0,1):F('.9')},(F(0),F(0)),ubox))<2
        inner.append(list(map(str,[l,r])));l=r
    higher=F('.4')*(max23[0]/N+max23[1]/N**2+tail(F('2.4'))/N**3)
    const=F('.4')*maxc+higher+RHO*F('.38')*CAP
    assert const<F('.5'),('inner',str(const))
    assert len(outer)==79 and len(inner)==85
    return dict(version='CONDITIONAL_DIRECT_GAUSSIAN95_V1',n_floor=N,
         hypotheses=dict(prior_support=['-4.1','4.1'],rho='1.15',beta=['.05','.3'],
                          C=['CE','.418'],H='1.5',decrement='.2'),
         conclusion=dict(support=['-1.85','2.4'],contact='L_P + (.2H^2+.3|H|+.5)/n +2a+1.16d_n >0'),
         outer=outer,inner=inner,higher_charge=str(higher),constant_charge=str(const))

if __name__=='__main__':
    assert len(sys.argv)==1
    obj=build()
    # False outer-support target must fail even the leading contact test.
    a,b,c=ray_coeff(1)
    assert -cubic(a,b,c,F('2.2'))-PRED*F('.2')<0
    print(json.dumps(dict(status='PASS_CONDITIONAL_DIRECT_GAUSSIAN95',proof=obj,
          negative_controls=['false_support_2.2'],
          source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in
                         [Path(__file__),Path(__file__).with_name('gaussian_core.py')]},
          scope='Analytic Gaussian expansion and contact identity required. No moment-entry premise or cutoff is established.'),indent=2))
