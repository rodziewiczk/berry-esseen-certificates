"""Bind all48 successful clean-copy jobs, preserving the output-collision failure."""
from pathlib import Path
from hashlib import sha256
import json,sys
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'work/below50_20260929'
RUN=ROOT/'runs/below50_20260929'
def need(x,s):
    if not x:raise ValueError(s)
def h(p):return sha256(p.read_bytes()).hexdigest()
def main():
    need(__debug__ and not sys.flags.optimize,'Unoptimized interpreter')
    expected=json.loads((BASE/'release_tools/jobs.json').read_text())
    expected_by={j['name']:j for j in expected};success={};failures=[];sources=[]
    for rel in ['portable_group0_01','portable_group1_01','portable_group2_01','portable_complement_v2_01']:
        folder=RUN/rel;p=folder/'metadata.json';d=json.loads(p.read_text())
        need(d['status'] in ('PASS','FAIL'),'Replay still pending: '+rel)
        need(d['sources_unchanged'] and d['input_sha256']==d['input_sha256_after'],'Frozen sources unchanged '+rel)
        need(len(d['jobs'])==d['selected_jobs'],'Complete scheduled job group '+rel)
        for row in d['jobs']:
            name=row['name'];need(name in expected_by,'Named selected job')
            for key in ('cwd','argv','source_run'):need(row[key]==expected_by[name][key],'Exact selected arguments')
            for stream in ('stdout','stderr'):
                need(h(folder/(name+'.'+stream+'.txt'))==row[stream+'_sha256'],'Fresh stream identity')
            record=dict(name=name,run=str(folder.relative_to(ROOT)),returncode=row['returncode'],
                        stdout_sha256=row['stdout_sha256'],stderr_sha256=row['stderr_sha256'])
            if row['returncode']==0:
                need(name not in success,'One successful portable replay per job');success[name]=record
            else:failures.append(record)
        sources.append(dict(run=str(folder.relative_to(ROOT)),metadata_sha256=h(p),status=d['status'],sources_unchanged=True))
    need(set(success)==set(expected_by) and len(success)==48,'Every selected job has a successful portable replay')
    need(len(failures)==1 and failures[0]['name']=='certificate_complement47' and failures[0]['run'].endswith('portable_group0_01'),'Only known inherited output collision')
    isolated=json.loads((RUN/'portable_complement_v2_01/metadata.json').read_text())
    row=isolated['jobs'][0]
    # The V2 runner refuses PASS unless its helper compared the full copy
    # and each regenerated output; additionally inspect that evidence here.
    evidence=row.get('isolation',row.get('isolated_acceptance'))
    need(evidence is not None,'Explicit isolation evidence')
    need(evidence['entire_copy_restored'] and evidence['original_capsule_unchanged'],'Full isolated replay integrity')
    need(all(v['byte_identical'] for v in evidence['regenerated_outputs'].values()),'Exact regenerated output')
    out=dict(schema='BE_CUTOFF50_PORTABLE_REPLAY_V1',status='PASS_ALL_48_SELECTED_PORTABLE_JOBS',
        execution_scope='All48 selected jobs freshly executed from a clean workspace-shaped capsule; one output-writing job replayed unchanged in a disposable exact copy.',
        mathematical_status='Arithmetic/coverage/controls only; the complete analytic reductions are separately reviewed and included.',
        selected_jobs=48,successful_jobs=[success[j['name']]for j in expected],
        preserved_failed_attempts=failures,groups=sources,isolated_output_evidence=evidence,
        jobs_sha256=h(BASE/'release_tools/jobs.json'),
        note='The first complement invocation refused an existing generated file after its arithmetic checks. The separate isolated replay regenerated identical bytes; no verifier assertion or target was changed.')
    dest=RUN/'PORTABLE50_SUMMARY.json';need(not dest.exists(),'Refuse overwrite');dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(status=out['status'],jobs=48,summary=str(dest),sha256=h(dest))))
if __name__=='__main__':main()
