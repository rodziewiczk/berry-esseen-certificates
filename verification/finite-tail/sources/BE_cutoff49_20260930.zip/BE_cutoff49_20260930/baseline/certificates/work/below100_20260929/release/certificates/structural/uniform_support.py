"""Exact acceptance of explicit all-threshold Gaussian support candidates.

All arithmetic uses Fraction/int. The heat-semigroup reduction is proved
separately in uniform_support.tex. No execution of an inherited driver.
"""
from fractions import Fraction as F
from math import comb, isqrt
from pathlib import Path
from hashlib import sha256
import json, sys
assert __debug__ and not sys.flags.optimize

def trim(a):
    a=list(map(F,a))
    while len(a)>1 and not a[-1]:a.pop()
    return a
def add(*args):
    o=[F(0)]*max(map(len,args))
    for a in args:
        for i,x in enumerate(a):o[i]+=x
    return trim(o)
def scale(a,c):return trim([x*c for x in a])
def mul(a,b):
    o=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):o[i+j]+=x*y
    return trim(o)
def val(a,x):
    s=F(0)
    for y in reversed(a):s=s*x+y
    return s
def deriv(a):return trim([i*x for i,x in enumerate(a)][1:] or [0])
def bernstein(a,l,u):
    n=len(a)-1
    power=[sum(a[j]*comb(j,k)*l**(j-k)*(u-l)**k for j in range(k,n+1))for k in range(n+1)]
    return [sum(power[k]*F(comb(i,k),comb(n,k))for k in range(i+1))for i in range(n+1)]
def sqrt_bounds(x):
    den=10**12
    r=isqrt(x.numerator*den*den//x.denominator)
    l=F(r,den);u=F(r+1,den)
    assert l*l<=x<u*u
    return l,u

r=F(7361,4000);b=F(641563,10**6);c=F(819,2000)
A=[F(0),F(-1,2),F(0),F(1,6)]
H4=list(map(F,[3,0,-6,0,1]))
assert r==F('.3031')*F('.646')/(c-F('.3031'))
assert (1+b*b)**2>r*r*(1-b*b)

def target(N,R,q):
    assert type(N)is int and N>=64
    assert F('3.6')<=R<F('4.5') and 0<=q<=F('1.7')
    v=N-1
    root,_=sqrt_bounds(F(v));_,S=sqrt_bounds(F(N,v))
    # E after removing the positive common factor s_n^3.
    E=add([0,F(3,20*v),0,0,0,F(1,100*v)],
          scale([-2,0,3],F(51,960*v)/root),[0,F(1,8*v*v)])
    Q=[r*F(19,50*N),3*b,F(3,2)*r,-1]
    # A times the complete upper contact polynomial.
    PA=add(scale(add(mul(A,A),scale(mul(H4,H4),F(1,256*v))),F(2,5)*S**3),
           scale(mul(E,A),S**3),mul(add(scale(Q,c),[r*S*q]),A))
    quarter=add(scale(A,6*root),scale(H4,-1))
    gates=[]
    cells=[]
    l=R
    while l<F('4.5'):
        u=min(F('4.5'),l+F(1,20))
        for name,p in [('A',A),('H4',H4),('quarter',quarter),('negative_C',scale(Q,-1)),('contact',scale(PA,-1))]:
            bs=bernstein(p,l,u)
            for z in bs:
                if z<=0:raise ValueError((N,str(R),str(q),name,str(l),str(z)))
            gates.extend((name,str(z))for z in bs)
        cells.append([str(l),str(u)]);l=u
    # License replacement of C by its lower bound on the complete ray.
    cq=Q
    for j in range(4):
        z=-val(cq,F('4.5'))
        if z<=0:raise ValueError(('coefficient_ray',j,str(z)))
        gates.append(('coefficient_ray'+str(j),str(z)));cq=deriv(cq)
    # Outside4.5 the imported global Gaussian estimate gives a cubic.
    ray=add([F(1,2)+r*S*q,F(1,5),0,F(1,15)],scale(Q,c))
    for j in range(4):
        z=-val(ray,F('4.5'))
        if z<=0:raise ValueError(('ray',j,str(z)))
        gates.append(('ray'+str(j),str(z)));ray=deriv(ray)
    return dict(N=N,radius=str(R),slow=str(q),closed_cells=cells,
                exact_positive_gates=len(gates),
                minimum_contact=str(min(F(x)for name,x in gates if name=='contact')),
                gate_sha256=sha256(json.dumps(gates,separators=(',',':')).encode()).hexdigest())

def main():
    assert len(sys.argv)==1
    # Fixed explicit theorem statements, not a search over acceptance targets.
    specs=[(64,'4','3/5'),(64,'4.1','.98'),(64,'4.2','1.37'),
           (80,'4','.66'),(80,'4.1','1.02'),(80,'4.2','1.42'),
           (85,'4','.67'),(85,'4.1','1.03'),(85,'4.2','1.43'),
           (90,'3.9','.34'),(90,'4','.68'),(90,'4.1','1.04'),(90,'4.2','1.44'),
           (95,'4','.68'),(95,'4.1','1.05'),(95,'4.2','1.45')]
    answers=[target(n,F(R),F(q))for n,R,q in specs]
    controls=[]
    for name,args in [('bad_floor',(63,F(4),F('.6'))),('bad_radius',(90,F('4.6'),F('.6'))),
        ('unlicensed_ray',(90,F(4),F(2))),('negative_loss',(90,F(4),F(-1))),
        ('false_contact',(90,F(4),F('.8')))]:
        try:target(*args)
        except (AssertionError,ValueError):controls.append(name)
        else:raise AssertionError(('false target accepted',name))
    # Independent conversion back from Bernstein basis to interval power basis.
    transforms=0
    for a in [[1,-3,2],[0,-1,0,0,3],list(range(-4,5))]:
        l=F(19,5);u=F(43,10);bs=bernstein(a,l,u);degree=len(a)-1
        out=[F(0)]*(degree+1)
        for j,z in enumerate(bs):
            for k in range(degree-j+1):out[j+k]+=z*comb(degree,j)*comb(degree-j,k)*(-1)**k
        for k in range(degree+1):
            expected=sum(F(a[j])*comb(j,k)*l**(j-k)*(u-l)**k for j in range(k,degree+1))
            assert out[k]==expected;transforms+=1
    print(json.dumps(dict(status='PASS_EXACT_ALL_THRESHOLD_SUPPORT',targets=answers,
                         negative_controls=controls,transform_identities=transforms,
                         input_sha256={Path(__file__).name:sha256(Path(__file__).read_bytes()).hexdigest()},
                         mathematical_scope='Assumes the attained contact/predecessor identity, finite Shevtsova cap and HC global Gaussian ray bound. The new all-H heat estimate is derived in uniform_support.tex.'),indent=2))
if __name__=='__main__':main()
