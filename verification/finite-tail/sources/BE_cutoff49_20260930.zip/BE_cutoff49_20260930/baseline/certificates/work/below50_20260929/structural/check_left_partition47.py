"""Exact closed-rectangle coverage only; individual LOW/MID proofs are inputs."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys,copy
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
sys.path.insert(0,str(BASE/'root'))
import phase_left_low47_contract as base
import positive_left_low47_contract as extra
def need(b,s):
 if not b:raise ValueError(s)
def union_full(intervals):
 need(intervals,'Empty positive-noise phase cover')
 covered=-F(1,2)
 for l,h in sorted(intervals):
  need(l<=h and l>=-F(1,2) and h<=F(1,2),'Phase interval domain')
  need(l<=covered,'Open phase gap')
  covered=max(covered,h)
 need(covered==F(1,2),'Missing endpoint +1/2')
mid=json.loads((BASE/'local/left_mid47b_certificate.json').read_text())
need(mid['schema']=='CONDITIONAL_LEFT_MID47_B_V1','Selected MID theorem')
checks=rectangles=0;sample_case=None
for row in base.read():
 ceiling=F(row['lambda_max']);need(ceiling>0,'Positive acquired ceiling')
 for sign in (-1,1):
  pieces=[(F(0),min(ceiling,F('.05')),-F(1,2),F(1,2),'TINY')]
  if ceiling>F('.05'):
   c=base.selected(row,sign)
   pieces.extend((l,h,-a,a,'BASE_LOW')for l,h,a in c['noise_intervals'])
  if ceiling>F('.10'):
   c=extra.selected(row,sign)
   pieces.extend((l,h,F('.29'),F('.5'),'EXTRA_POSITIVE')for l,h,a in c['noise_intervals'])
  for b in mid['blocks']:
   if b['index']!=row['index']:continue
   l,h=map(F,b['noise']);ul,uh=map(F,b['phase'])
   if b['sign']<0:ul,uh=-uh,-ul
   else:need(b['band']<3,'No positive fourth MID scope')
   pieces.append((l,h,ul,uh,'MID'))
  points=sorted(set(x for r in pieces for x in r[:2]))
  need(points[0]==0 and points[-1]==ceiling,'Full positive-noise range')
  # Membership in each closed noise interval is constant on each open
  # slab between these exact boundaries. Its midpoint represents that
  # entire slab; every positive boundary is checked separately.
  trials=[x for x in points if x>0]+[(x+y)/2 for x,y in zip(points,points[1:])]
  for lam in trials:
   union_full([(l,h)for lo,hi,l,h,name in pieces if lo<=lam<=hi]);checks+=1
  rectangles+=len(pieces)
  if ceiling>F('.12') and sample_case is None:sample_case=(pieces,F('.11'))
need(sample_case is not None,'Nontrivial fourth-band complement')
negative=[]
pieces,lam=sample_case
for name,bad in [
 ('omit_positive_fourth',[(lo,hi,l,h,tag)for lo,hi,l,h,tag in pieces if tag!='EXTRA_POSITIVE']),
 ('missing_nearest_endpoint',[(lo,hi,l,min(h,F('.499')),tag)for lo,hi,l,h,tag in pieces])]:
 try:union_full([(l,h)for lo,hi,l,h,tag in bad if lo<=lam<=hi])
 except ValueError:negative.append(name)
 else:raise AssertionError('False partition accepted '+name)
try:union_full([(-F('.5'),F('.14')),(F('.141'),F('.5'))])
except ValueError:negative.append('mismatched_low_mid_edge')
else:raise AssertionError('Phase gap accepted')
files=[BASE/'root/phase_left_low47_contract.py',BASE/'root/positive_left_low47_contract.py',
 BASE/'entry/left270_input47_table.json',BASE/'local/left_mid47b_certificate.json',Path(__file__)]
print(json.dumps(dict(status='PASS_EXACT_LEFT47_CLOSED_PARTITION',
 mathematical_status='Coverage conditional on validity of the named LOW/MID/TINY components; not a final cutoff.',
 probability_panels=38,H_signs=2,rectangles=rectangles,closed_boundary_and_open_slab_checks=checks,
 negative_controls=negative,zero_noise='Separate attained-binary argument is required.',
 source_sha256={str(p.relative_to(BASE)):sha256(p.read_bytes()).hexdigest()for p in files}),indent=2))
