# Independent analytic review of the cutoff50 composition

## Result and scope

I read `root/local47_composition.tex` in full, and independently checked its composition against the acquired tables, the selected rectangle contracts, the earlier fixed-index attainment proof, the stated published Bernoulli input, the new finite left Bernoulli proof/checker, and the .7/n ceiling argument. I found no analytic composition defect.

The conclusion remains contingent on the named acquisition/support/local/finite-Bernoulli theorems and their valid fixed arithmetic acceptance. In particular, this review does not convert the still-running base-left LOW replay into a completed run, and does not independently reprove every Fourier or contact lemma. The separate coverage JSON records 84,415 exact partition checks on all83 probability panels.

## Entry and local interfaces

At any index47..98 with C_n>=C_E, the unrestricted ceiling gives the own cap .4247 and all three caps .4253. The exact rational reserves are .4247−.40974−.7/47=39/587500 and .4253−.40974−.7/45=1/225000. Thus these are strict valid caps, including the boundary n=47.

The initial and complementary signed covers are required to reduce the actual attaining law to the stated probability union. The central chain acquires the original canonical interface before confinement is fed back into the radius and moments. The left chain uses its separately acquired radius2.7/table/strip. The subsequent scalar feedback bounds imply all original scalar upper/lower premises; the checker verifies585 such implications. No ordering of the raw quadratic coefficients is asserted or needed: the original and improved resource bounds both hold for the same law by their separate acyclic acquisitions. The phase curvature already includes the conserved Gaussian charge and is not charged twice here.

The auxiliary Fourier reflection changes only the unsigned error estimate, as specified by the paired-orientation proof. It does not silently reflect the contact law, its probability, or its signed phase coefficients.

## Equality, attainment and atom endpoints

The preserved attainment proof applies at every fixed index and includes C_n=C_E. A positive maximizing sequence has bounded third moments, which gives uniform integrability of its first and second moments. Lower semicontinuity suffices for the third moment; equality at the extremum then forces the required third-moment equality. Moving thresholds are treated with closed-set Portmanteau and continuity from above. Therefore no unproved third-moment uniform integrability or varying-index compactness is used.

Reflection first identifies the same supremum of positive closed discrepancies, after taking limits from strict events. The attained positive closed maximizer then enters contact. All local comparisons retain their strict outgoing and closed incoming event conventions.

For lambda=0, U=0 almost surely. If its maximizing threshold x in Bernoulli coordinates were not an integer atom, moving x to the preceding binomial atom would keep the CDF fixed while strictly decreasing the normal CDF. Before the first atom the positive discrepancy is impossible. Consequently x=k and u=0. This is a fixed-law threshold argument, not a limiting positive-noise argument and not a division by lambda.

## Bernoulli scope below one third

The published Schulz input is used only on the central interval [.38,.47], which lies in [1/3,1/2]. It is not extended to p<1/3.

All38 left intervals [.304,.38] instead use the separate exact finite Bernoulli certificate, covering every47<=n<=98 and every integer k with |k−np|<=1.25. The count-window premise follows for each acquired row from
`max(Hplus,Hminus)^2 * pu*(1−pu)/(1−theta) < (.75)^2`.
All such counts are strictly between0 and n at n>=47. The checker retains singleton intersections and closed probability endpoints. This finite result is sufficient for both the noisy comparison law and the exactly binary zero-noise law. No left Bernoulli theorem outside the finite index range is claimed.

## Closed local partition

The central schedule joins LOW and MID at radii .09,.13,.18,.29. The left schedule joins at .09,.14,.19,.29; at the fourth left noise band, MID supplies only u<=−.29 and the extra positive LOW supplies [.29,.5]. Base LOW covers the middle interval and all phases from noise .12 upward. Wide TINY supplies every phase for0<lambda<=.05. Every interval is clipped to the actual panel ceiling. Shared p=.38, all internal noise endpoints, and both nearest-phase ties are retained.

A row wholly excluded by the strict common budget requires no score maximum. Its complete exclusion count, and the absence of feasible cells and endpoint tests, are the correct semantics. The coverage check allows precisely this case, rather than imposing an invented numerical maximum.

## Four-step descent

If a_n=C_n−C_E is nonnegative at50<=n<=98, local exclusion gives a_{n−1}>a_n+.19/n. The predecessor is then positive, so the same implication may be used three more times. The smallest local index used is n−3>=47, and the final predecessor n−4>=46 lies in the established ceiling range. Different steps may use different attaining laws; only scalar suprema are propagated.

The exact n=50 reserve is
`.19*(1/47+1/48+1/49+1/50)−.7/46 = 2930539/6356280000 >0`.
For n>=51, the elementary lower bound4/n has difference from .7/(n−4) with numerator .06n−3.04>0. This is enough to contradict the ceiling. The independent prior cutoff99 theorem supplies the tail n>=99. Thus, subject to the stated dependencies, the composition proves C_n<C_E for every n>=50, and asserts nothing new about all smaller indices.
