"""Independent exact normalization/corner/actual-law tests for PHASE LOW47.

This verifies the new reduction's domains, not the final LOW score gates.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
from math import isqrt
import json, sys
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
BOUND={
 'root/low47_normalization.py':'3312a3cb096257afa6871c346b3f62e6c832516840aabe5146d5117574bedc1d',
 'local/left_sperner47_contract.py':'4444fbd3c361ca76f21fe72f67059a9fbe44a045c45dc3b72d64b4c2813bf19e',
 'local/sperner47_kernel.py':'21249fe117c6756a7a84af481dea2c5a490f9c66013c331cc998ab6828e1bb08',
 'local/left_sperner47_certificate.json':'e1237ea24a0609d6e2e6c0fee24d9586cdf5005d30fb5cb6b38ad430e13b31f8',
 'local/left_sperner47_profile_certificate.json':'0dda88ea5e83931205270d37c59cc893385837a8f16dd4a4c240e390d0756e13',
 'entry/left270_input47_table.json':'4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a',
}
def need(ok,s):
 if not ok:raise ValueError(s)
need(__debug__ and not sys.flags.optimize,'unoptimized interpreter')
for p,d in BOUND.items():need(sha256((BASE/p).read_bytes()).hexdigest()==d,'changed input '+p)
sys.path.insert(0,str(BASE/'root'));sys.path.insert(0,str(BASE/'local'))
from low47_normalization import generate_checked,normalization_gates
from left_sperner47_contract import input_table,config,AMPLITUDES

def sqrt_bounds(x):
 need(x>0,'positive root')
 q=F(isqrt(x.numerator*10**16//x.denominator),10**8)
 return q-F(1,10**8),q+F(1,10**8)

def geometry(hs,es,us,pu):
 hl,hh=hs;el,eh=es;ul,uh=us
 need(hl<=hh and 0<el<=eh and -F(1,2)<=ul<=uh<=F(1,2),'geometry domain')
 quot=[h/e for h in hs for e in es]
 ql,qh=min(quot),max(quot)
 dl,dh=ql-uh,qh-ul
 return dict(ql=ql,qh=qh,dl=dl,dh=dh,dd=max(abs(dl),abs(dh)),
             dpositive=max(F(0),dh),a=max(abs(ul),abs(uh)),b=pu-ql,
             tail_plus=uh,tail_minus=-ul)

def validate_geometry(g,hs,es,us,pu):
 need(g==geometry(hs,es,us,pu),'changed outward phase geometry')

def cover(expected,feasible,excluded):
 need(len(feasible)==len(set(feasible)),'duplicated feasible cell')
 need(len(excluded)==len(set(excluded)),'duplicated empty cell')
 need(not set(feasible).intersection(excluded),'cell both feasible and excluded')
 need(set(feasible).union(excluded)==set(expected),'incomplete closed cover')
 need(all(F(v)<=0 for v in excluded.values()),'unjustified empty cell')
 # A score maximum exists only when feasible is nonempty.
 return None if not feasible else 'requires endpoint score checks'

def main():
 rows=input_table()['panels'];normal_count=normal_gates=boxes=corners=actual=0
 digest=sha256();reports=[]
 for row in rows:
  idx=row['index'];pl,pu=map(F,row['p']);amp=F(AMPLITUDES[idx])
  need(amp<=F('.375'),'accepted amplitude domain')
  for sign in (-1,1):
   base=config(row,sign);cfg=generate_checked(base);ng=normalization_gates(base,cfg)
   normal_count+=1;normal_gates+=len(ng)
   el=sqrt_bounds((1-cfg['theta'])/(pu*(1-pu)))[0]
   eh=sqrt_bounds(1/(pl*(1-pl)))[1]
   need(0<el<eh,'scale domain')
   for a in map(F,('.09','.13','.14','.18','.19','.29','.5')):
    for hi in range(16):
     hl,hh=cfg['H']*hi/16,cfg['H']*(hi+1)/16
     hs=(hl,hh)if sign>0 else(-hh,-hl)
     for ui in range(8):
      us=(-a+2*a*ui/8,-a+2*a*(ui+1)/8)
      g=geometry(hs,(el,eh),us,pu);boxes+=1
      need(g['dd']<cfg['delta'],'local phase exceeds normalized entropy domain')
      need(g['b']+us[1]<2,'global binomial curvature premise')
      need(1-g['dd']/(47*pl)>0,'actual variance lower bound')
      c=1-cfg['d0']
      need(c-g['a']>0 and F(5,2)*c-amp-g['a']>0,'crossing and tail domains')
      for h in hs:
       for e in (el,eh):
        for u in us:
         delta=h/e-u;chi=pu-delta
         need(g['dl']<=delta<=g['dh'] and abs(delta)<=g['dd'],'signed corner enclosure')
         need(max(F(0),delta)<=g['dpositive'],'positive repair corner')
         need(chi<=g['b']+u,'curvature sign')
         need(1/(F(5,2)*c-amp-u)**3<=1/(F(5,2)*c-amp-us[1])**3,'positive tail direction')
         need(1/(F(5,2)*c-amp+u)**3<=1/(F(5,2)*c-amp+us[0])**3,'negative tail direction')
         corners+=1
      digest.update(json.dumps([idx,sign,hi,ui,str(a),{k:str(v)for k,v in g.items()}],sort_keys=True).encode())
   reports.append(dict(index=idx,sign=sign,normalization_gates=len(ng),mass=str(cfg['mass']),delta=str(cfg['delta']),amplitude=str(amp)))
  # Actual centered two-class laws: zero variance in either class is included.
  for p in (pl,(pl+pu)/2,pu):
   v=p*(1-p)
   for n in (47,60,99):
    d=min(F(row['d0'])/4,F(row['lambda_max'])/(4*n*amp),F(row['theta'])*v/(4*amp))
    for mode in (0,1,2,3):
     # U0 in[-amp,d], U1 in[-d,amp]; their means vanish and variances are amp*d.
     s0=amp*d if mode in(0,2)else F(0);s1=amp*d if mode in(1,2)else F(0)
     s=(1-p)*s0+p*s1;lam=n*s;theta=s/(v+s)
     need(lam<=F(row['lambda_max'])and theta<=F(row['theta']),'actual-law input noise')
     floor=(n*p).numerator//(n*p).denominator
     for k in (floor,floor+1):
      delta=k-n*p
      for u in (F(-1,2),F(-1,4),F(0),F(1,4),F(1,2)):
       hquot=delta+u;sign=1 if hquot>=0 else-1
       H=F(row['H_plus'if sign>0 else'H_minus'])
       if hquot*hquot>H*H*(v+s):continue
       el=sqrt_bounds((1-F(row['theta']))/(pu*(1-pu)))[0]
       eh=sqrt_bounds(1/(pl*(1-pl)))[1]
       need(el*el<=1/(v+s)<=eh*eh,'actual scale enclosed')
       for hi in range(16):
        hl,hh=H*hi/16,H*(hi+1)/16
        if hl*hl*(v+s)<=hquot*hquot<=hh*hh*(v+s):break
       else:raise ValueError('missing actual H cell')
       hs=(hl,hh)if sign>0 else(-hh,-hl)
       ui=min(7,int((u+F(1,2))*8));us=(F(-1,2)+F(ui,8),F(-1,2)+F(ui+1,8))
       g=geometry(hs,(el,eh),us,pu)
       need(g['dl']<=delta<=g['dh'],'actual-law count shift enclosure')
       t=k*s1+(n-k)*s0
       need(t==lam+delta*(s1-s0),'actual-law exact count variance')
       need((1-g['dd']/(n*pl))*lam<=t<=(1+g['dd']/(n*pl))*lam,'actual-law variance bounds')
       need(p-delta<=g['b']+u,'actual-law curvature coefficient')
       need(max(F(0),delta)<=g['dpositive'],'actual-law signed repair')
       actual+=1
 # Negative controls target errors that a sign-symmetrized or endpoint-only rewrite can introduce.
 hs=(F(-2),F(-1));es=(F(2),F(4));us=(F(-1,2),F(-1,4));pu=F('.38')
 g=geometry(hs,es,us,pu);controls=0
 for key,value in [('ql',hs[0]/es[1]),('dd',F(0)),('dpositive',F(-1)),('b',pu+g['ql']),('tail_plus',us[0]),('tail_minus',us[1]),('a',F(1,4))]:
  bad=dict(g);bad[key]=value
  try:validate_geometry(bad,hs,es,us,pu)
  except ValueError:controls+=1
  else:raise ValueError('bad phase geometry accepted '+key)
 need(cover(['a','b'],[],{'a':F(0),'b':F(-1)})is None,'all-excluded row rejected')
 for feasible,excluded in [([],{'a':F(-1)}),(['a'],{'a':F(0),'b':F(-1)}),([] ,{'a':F(1),'b':F(-1)}),(['a','a'],{'b':F(-1)})]:
  try:cover(['a','b'],feasible,excluded)
  except ValueError:controls+=1
  else:raise ValueError('bad empty cover accepted')
 need(geometry((F(0),F(0)),es,(F(1,2),F(1,2)),pu)['dpositive']==0,'zero-H negative-delta collision')
 need(geometry((F(0),F(0)),es,(F(-1,2),F(-1,2)),pu)['dpositive']==F(1,2),'zero-H positive-delta collision')
 out=dict(status='PASS_PHASE_LOW47_GEOMETRY_AND_NORMALIZATION',scope='Independent exact phase reduction domain checks, not final LOW score acceptance',
  configurations=normal_count,normalization_gates=normal_gates,closed_phase_boxes=boxes,rational_corners=corners,actual_law_count_cases=actual,
  negative_controls=controls,all_excluded_row_control='PASS',gate_sha256=digest.hexdigest(),source_sha256={**BOUND,'entry/check_phase_low47_geometry.py':sha256(Path(__file__).read_bytes()).hexdigest()},rows=reports)
 print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
