# Independent finite Bernoulli reserve review

## Statement reviewed

For integers 40≤n≤98, .35≤p≤.46, and integer k with |k−np|≤1.1,
the positive closed-CDF standardized Bernoulli score is less than C_E−1/4000.
This is a finite Bernoulli statement. No noisy-law comparison, opposite
orientation, or unrestricted cutoff follows by itself.

Reviewed code: `root/bernoulli_reserve.py` and
`root/accept_bernoulli_reserve40_98.py`.

**Mathematical status:** independently rederived continuous-cell enclosure.
**Execution status:** fresh full-domain PASS in
`runs/below50_20260929/root_bernoulli_accept01`; I verified its recorded source
hashes still match the reviewed kernel and acceptor. Independent rational
diagnostic PASS in
`runs/below50_20260929/structural/bernoulli_independent01` (1,446 checks on
arithmetic/reference values, including 62 closed cells). These diagnostics
supplement the continuous proof; they do not claim full domain coverage alone.

## Formula derivation

Put v=p(1−p), b=1−2v, z=(k−np)/sqrt(nv),
F=Pr(Bin(n,p)≤k), and A=sqrt(nv)/b. The score is A(F−Phi(z)).

- F'=−(n−k)Pr(Bin(n,p)=k)/(1−p), obtained by telescoping the exact
  binomial derivative.
- z'=−sqrt(n)/sqrt(v)−z(1−2p)/(2v).
- A'/A=(1−2p)(1/(2v)+2/b).

These give exactly the derivative in the kernel. The endpoint enclosure for z
is valid because z strictly decreases on 0<p<1/2:
2nv+(k−np)(1−2p)=np+k(1−2p)>0.
The binomial CDF decreases with p. The pmf increases to p=k/n and decreases
thereafter, so its minimum is at an endpoint and maximum at an endpoint or
that interior mode. These facts justify every interval endpoint substitution.

With midpoint p0 and cell radius r, |score(p)−score(p0)|≤r*sup|score'|.
The original new kernel returned point+positive_error: its upper endpoint was
correct but its lower endpoint was not an interval enclosure. I reported this;
the selected kernel now returns [point.lo−error.hi,point.hi+error.hi]. The
upper reserve calculation was unchanged by this repair.

## Outward arithmetic and normal constants

The fixed-point grid has scale 10^15. Constructor bounds use floor/ceiling
integer division, multiplication tests all four endpoint products, reciprocal
requires a positive lower endpoint, and square/square-root bounds include zero
and integer-root endpoints correctly. Repeated interval operations retain all
correlations by outward inclusion, even when this is conservative.

The exponential enclosure is the degree15 lower/degree14 upper alternating
series for e^(−x), 0≤x≤1/2. The CDF enclosure is the corresponding integrated
series on 0≤z≤1, with monotonic endpoints and reflection for negative z.
The rational binomial numerator sums j=0 through k inclusive; this is the
required closed CDF, not a midpoint convention.

Machin's exact tangent identity and the positive angle branch license the pi
interval. Alternating atan remainder bounds license its endpoints. Positive
squaring proves the phi0 interval, and the sqrt10 bounds propagate to C_E.
The independent diagnostic obtains pi instead from
atan(1/2)+atan(1/3)=pi/4 and uses higher-order rational normal series and a
ratio recurrence for binomial probabilities. It checks actual values against
the fixed-point outputs rather than wrapping acceptance a second time.

## Coverage and controls

For each fixed n,k, the legal p interval is exactly
[.35,.46] intersect [(k−1.1)/n,(k+1.1)/n]. Every nonempty closed interval is
partitioned without gaps. The code includes degenerate singleton intervals;
discovery initially omitted them, and the constructor repaired that before
promotion. The four singleton cases are explicitly checked:
(46,15,.35), (65,31,.46), (66,22,.35), (86,29,.35).
The k loop covers all possibilities because .35n−1.1>0 and .46n+1.1<n.
All 59 indices are explicitly visited. Each whole-cell upper score must lie
strictly below the certified lower C_E endpoint minus 1/4000.

The final acceptor checks missing first/last/middle cells, duplicate/reordered
cells, missing/duplicate singletons, and rejects a false .001 reserve using an
actual Bernoulli point. No supplied optimization object is trusted: intervals
and score bounds are reconstructed from fixed rational formulas.

No remaining analytical or coverage defect found in the stated finite scope.
