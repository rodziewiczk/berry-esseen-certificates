"""Read-only fixed acceptance of finite Bernoulli reserves, not noisy laws."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import sys,json
from left_binary47_kernel import calculate
import bernoulli_reserve as b
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
SHA='5009df31891e569a976a9394729c01b84050053b90326527d2bf123b8c916da0'
def need(ok,s):
    if not ok:raise ValueError(s)
def unique(items):
    d={}
    for k,v in items:need(k not in d,'Duplicate key');d[k]=v
    return d
def read(blob):
    need(sha256(blob).hexdigest()==SHA,'Fixed named proof object')
    d=json.loads(blob,object_pairs_hook=unique)
    need(d['schema']=='FINITE_LEFT_BINARY_RESERVES47_V1','Named theorem')
    need(len(d['panels'])==38,'Complete probability cover')
    for i,p in enumerate(d['panels']):
        need(p['index']==i and list(map(F,p['p']))==[F('.304')+F(i,500),F('.304')+F(i+1,500)],'Probability seams')
        need([z['n']for z in p['rows']]==list(range(47,99)),'Every finite index')
    return d
def main():
    need(len(sys.argv)==1,'No target overrides')
    path=HERE/'left_binary_reserves47_constructed01.json';blob=path.read_bytes();d=read(blob)
    actual=calculate();need(actual==d,'Exact complete arithmetic replay')
    controls=0
    for name in ['missing_panel','missing_n','duplicated_panel','reordered_panel','changed_reserve','changed_n']:
        bad=json.loads(blob)
        if name=='missing_panel':bad['panels'].pop()
        elif name=='missing_n':bad['panels'][0]['rows'].pop()
        elif name=='duplicated_panel':bad['panels'].append(bad['panels'][0])
        elif name=='reordered_panel':bad['panels'].reverse()
        elif name=='changed_n':bad['panels'][0]['rows'][0]['n']=46
        else:bad['panels'][0]['reserve']='1'
        try:read(json.dumps(bad).encode())
        except ValueError:controls+=1
        else:raise AssertionError('Mutated proof accepted')
    # An actual Bernoulli law rejects an unsupported universal reserve .01.
    need(b.score_point(98,37,F('.38')).fraction_lower()>b.CE.fraction_upper()-F('.01'),'False stronger target control');controls+=1
    # License the phase range for every acquired left270 hypothesis row.
    source=HERE.parent/'entry/left270_input47_table.json'
    need(sha256(source.read_bytes()).hexdigest()=='4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a','Acquired phase input')
    for z in json.loads(source.read_text())['panels']:
        pl,pu=map(F,z['p']);ell=(b.I(1-F(z['theta']))/b.I(pu*(1-pu))).sqrt().fraction_lower()
        need(max(F(z['H_plus']),F(z['H_minus']))/ell+F('.5')<F('1.25'),'Every actual nearest count covered')
    print(json.dumps(dict(status='PASS_EXACT_LEFT_BINARY47',mathematical_status='Finite positive Bernoulli theorem; noisy comparison remains separate.',
        theorem='For47<=n<=98 and p in each declared cell, |k−np|<=1.25 implies C_B^+(n,p,k)<C_E−reserve[cell].',
        panels=38,indices=52,closed_cells=actual['closed_cells'],controls=controls,
        minimum_reserve=str(min(F(z['reserve'])for z in actual['panels'])),gate_sha256=actual['gate_sha256'],
        interpreter=sys.version,source_sha256={str(p.relative_to(HERE.parent)):sha256(p.read_bytes()).hexdigest()for p in
            [Path(__file__),HERE/'left_binary47_kernel.py',HERE/'bernoulli_reserve.py',path,source]}),indent=2))
if __name__=='__main__':main()
