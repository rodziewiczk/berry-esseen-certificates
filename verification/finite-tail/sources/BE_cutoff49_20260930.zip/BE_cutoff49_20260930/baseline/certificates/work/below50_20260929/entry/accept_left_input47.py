#!/usr/bin/env python3
"""Fixed exact acquisition of every surviving left probability panel."""
from fractions import Fraction as F
from pathlib import Path
import copy,hashlib,json,sys
import local_panel_core as c
def need(x,s):
 if not x:raise ValueError(s)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def unique(pairs):
 z={}
 for k,v in pairs:need(k not in z,'duplicate JSON key');z[k]=v
 return z
def load(p):return json.loads(Path(p).read_text(),object_pairs_hook=unique)
def shape(table):
 need(table['schema']=='LEFT47_ACQUIRED_ENTRY_V1' and type(table['N'])is int and table['N']==47,'fixed left theorem')
 need(table['own_score_cap']=='4247/10000' and table['support_radius']=='3' and table['decrement_cap']=='19/100','fixed actual support/score/decrement domain')
 need(table['probability_domain']==['151/500','19/50'],'selected left probability range')
 need(table['source_sha256']==sha('complement47_accepted.json'),'bound preceding complete complement')
 rows=table['panels'];need(type(rows)is list and len(rows)==39,'complete remaining left cover')
 for j,row in enumerate(rows):
  need(type(row['index'])is int and row['index']==j and type(row['source_index'])is int and row['source_index']==151+j,'ordered panel identities')
  need(list(map(F,row['p']))==[F(151+j,500),F(152+j,500)],'contiguous closed left cells')
  need(len(row['quadratics'])==4,'all four corners')
  for q in row['quadratics']:
   need(set(q)=={'A','Fplus','Fminus','Qraw','Qbudget'},'quadratic fields')
   need(F(q['A'])>0 and 0<F(q['Qraw'])<F(q['Qbudget']),'positive curvatures')
def verify(table,emit=False):
 shape(table);source=load('complement47_accepted.json');rows=source['surviving_cells'];need([z['index']for z in rows]==list(range(145,190)),'complete previous survivor cover')
 targets={z['source_index']:z for z in table['panels']};count=excluded=0
 for old in rows:
  row={key:F(old[key])for key in('pl','pu','raw','D','theta','rho','beta')}
  out=c.cell(47,F(3),F('.4247'),row,steps=32);i=old['index'];count+=1
  if i<151:need(out.get('excluded')is True,'complete left-edge exclusion');excluded+=1;continue
  need(not out.get('excluded') and 'quadratics'in out,'selected complete paired left output');target=targets[i]
  for a,b in [('raw','T'),('D','D'),('theta','theta'),('rho','rho'),('beta','beta_hi'),('lambda_max','lambda_max'),('inward_d_max','d0'),('Hplus','H_plus'),('Hminus','H_minus')]:need(out[a]<=F(target[b]),('left upper',i,b))
  for a,b in [('beta_lo','beta_lo'),('A','A_lo'),('B','B_lo')]:need(out[a]>=F(target[b]),('left lower',i,b))
  for a,b in zip(out['quadratics'],target['quadratics']):
   for key in('A','Fplus','Fminus'):need(a[key]<=F(b[key]),('left corner upper',i,key))
   for key in('Qraw','Qbudget'):need(a[key]>=F(b[key]),('left corner curvature',i,key))
  if emit:print('PASS_LEFT_INPUT47',i,flush=True)
 return dict(status='PASS_LEFT47_ACQUIRED_ENTRY',previous_cells=count,excluded_left_cells=excluded,remaining_panels=39,weighted_noise_resources=True)
def controls(table):
 cases=[]
 for action in [lambda z:z['panels'].pop(),lambda z:z['panels'].reverse(),lambda z:z['panels'].insert(1,z['panels'][0]),lambda z:z['panels'][0].update(index=True),lambda z:z['panels'][0].update(p=['3/10','31/100']),lambda z:z['panels'][0]['quadratics'].pop(),lambda z:z.update(source_sha256='0'*64)]:
  z=copy.deepcopy(table);action(z);cases.append(z)
 for z in cases:
  try:shape(z)
  except (ValueError,KeyError,TypeError):pass
  else:raise ValueError('malformed left proof accepted')
 for key,value in [('T','1/100'),('lambda_max','1/100000000')]:
  z=copy.deepcopy(table);z['panels'][0][key]=value
  try:verify(z)
  except ValueError:pass
  else:raise ValueError('false arithmetic left target accepted')
 return len(cases)+2
if __name__=='__main__':
 need(__debug__ and not sys.flags.optimize and len(sys.argv)==1,'fixed invocation');table=load('left_input47_table.json');out=verify(table,True);out['negative_controls']=controls(table)
 out['table_sha256']=sha('left_input47_table.json');out['source_sha256']={x:sha(x)for x in('accept_left_input47.py','local_panel_core.py','high_window_core.py','kernel.py','accept_left_support47.py')}
 print(json.dumps(out,sort_keys=True),flush=True)
