#!/usr/bin/env python3
"""Audit the fixed cutoff50 ZIP, extract it freshly, and replay global integrity.

The extracted run is the unchanged global scalar/integrity checker, not a
rerun of the48 proof jobs. Optional suite metadata documents those separately.
Requires the standard library and pypdf for a strict147-page PDF check.
"""
from pathlib import Path, PurePosixPath
from hashlib import sha256
from datetime import datetime, timezone
import argparse, json, os, re, shutil, stat, subprocess, sys, unicodedata, zipfile

PDF_SHA='b232553aec4d21e260e54a51c47896a404c88e904b31bb5bbb0158f86da115a2'
PDF_NAME='BE_cutoff50.pdf'
GLOBAL='work/below50_20260929/root/accept_cutoff50_composition_v2.py'
GLOBAL_SHA='a91ad8f4f03c9887564801de03734a6670f6808a933a74adb5c3ba2738a86261'
DEPENDENCIES='work/below50_20260929/root/cutoff50_dependencies_v2.json'
DEPENDENCIES_SHA='904bc8150c0f0295c022fdafea76c50e308647ea0ecb0a7ba94cc12996ef72b0'

def need(b,s):
    if not b: raise ValueError(s)
def stamp(): return datetime.now(timezone.utc).isoformat()
def digest(path):
    h=sha256()
    with Path(path).open('rb')as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def stream_digest(f):
    h=sha256();size=0
    for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
    return h.hexdigest(),size
def unique(items):
    d={}
    for k,v in items:need(k not in d,'Duplicate JSON key: '+k);d[k]=v
    return d
def load_bytes(blob):return json.loads(blob,object_pairs_hook=unique)
def safe_name(name,directory=False):
    need(type(name)is str and name and '\\'not in name and '\x00'not in name,'Invalid ZIP/path string')
    need(not any(ord(c)<32 or ord(c)==127 for c in name),'Control character in path')
    raw=name[:-1]if directory and name.endswith('/')else name
    need(raw and not raw.startswith('/')and ':'not in raw,'Absolute/drive path')
    parts=raw.split('/')
    need(all(p not in ('','.','..')for p in parts),'Noncanonical/traversing path')
    need(not PurePosixPath(raw).is_absolute(),'Absolute POSIX path')
    return raw

def zip_members(z):
    files={};allnames=set();prefixes={};kinds={}
    for info in z.infolist():
        need(info.orig_filename==info.filename,'ZIP filename was truncated or normalized')
        name=safe_name(info.filename,info.is_dir())
        need(info.filename not in allnames,'Duplicate ZIP member: '+info.filename);allnames.add(info.filename)
        need(not(info.flag_bits&1),'Encrypted member')
        kind=stat.S_IFMT(info.external_attr>>16)
        need(kind in (0,stat.S_IFDIR if info.is_dir()else stat.S_IFREG),'Nonregular/symlink ZIP member')
        parts=name.split('/')
        for i in range(1,len(parts)+1):
            prefix='/'.join(parts[:i]);key=unicodedata.normalize('NFC',prefix).casefold()
            need(key not in prefixes or prefixes[key]==prefix,'Case/Unicode path collision')
            prefixes[key]=prefix
            want='dir'if i<len(parts)or info.is_dir()else'file'
            need(prefix not in kinds or kinds[prefix]==want,'File/directory prefix collision')
            kinds[prefix]=want
        if not info.is_dir():
            need(name not in files,'Duplicate normalized ZIP file');files[name]=info
    need('MANIFEST.json'in files,'Root-level MANIFEST.json required')
    return files

def manifest(z,files):
    blob=z.read(files['MANIFEST.json']);d=load_bytes(blob)
    need(type(d)is dict and set(d)=={'schema','files','theorem'},'Exact release manifest fields')
    need(d['schema']=='BE_CUTOFF50_RELEASE_V1','Fixed release schema')
    need(d['theorem']=='C_n<C_E for every n>=50','Fixed theorem')
    need(type(d['files'])is dict and d['files'],'Nonempty file inventory')
    for rel,row in d['files'].items():
        need(safe_name(rel)==rel and rel!='MANIFEST.json','Manifest relative file')
        need(type(row)is dict and set(row)=={'sha256','bytes'},'Exact file metadata')
        need(type(row['sha256'])is str and re.fullmatch('[0-9a-f]{64}',row['sha256'])is not None,'Canonical SHA256')
        need(type(row['bytes'])is int and row['bytes']>=0,'Integer byte count')
    need(set(d['files'])==set(files)-{'MANIFEST.json'},'Manifest covers every ZIP file exactly once')
    for rel,row in d['files'].items():
        need(files[rel].file_size==row['bytes'],'ZIP declared size '+rel)
        with z.open(files[rel])as f:h,size=stream_digest(f)
        need(h==row['sha256']and size==row['bytes'],'ZIP byte/hash mismatch '+rel)
    need(PDF_NAME in d['files']and d['files'][PDF_NAME]['sha256']==PDF_SHA,'Fixed final PDF member')
    need(GLOBAL in d['files']and DEPENDENCIES in d['files'],'Portable global checker and manifest')
    need(d['files'][GLOBAL]['sha256']==GLOBAL_SHA,'Unchanged reviewed global checker')
    need(d['files'][DEPENDENCIES]['sha256']==DEPENDENCIES_SHA,'Fixed mathematical dependency manifest')
    return d,sha256(blob).hexdigest()

def extract_verified(z,files,root):
    need(not root.exists(),'Extraction directory must be fresh')
    root.mkdir(parents=True)
    for name,info in sorted(files.items()):
        target=root.joinpath(*name.split('/'))
        need(root in target.resolve().parents,'Extraction escaped root')
        target.parent.mkdir(parents=True,exist_ok=True)
        with z.open(info)as src,target.open('xb')as dst:shutil.copyfileobj(src,dst,1048576)

def check_tree(root,m,manifest_hash):
    actual={}
    for p in root.rglob('*'):
        need(not p.is_symlink(),'Extracted symlink')
        if p.is_file():actual[p.relative_to(root).as_posix()]=p
        else:need(p.is_dir(),'Extracted nonregular object')
    need(set(actual)==set(m['files'])|{'MANIFEST.json'},'Extracted exact file set')
    need(digest(actual['MANIFEST.json'])==manifest_hash,'Extracted manifest unchanged')
    for rel,row in m['files'].items():
        p=actual[rel];need(p.stat().st_size==row['bytes']and digest(p)==row['sha256'],'Extracted file changed '+rel)

def pdf_check(path):
    from pypdf import PdfReader
    reader=PdfReader(str(path),strict=True)
    need(not reader.is_encrypted,'Unexpected encrypted PDF')
    need(len(reader.pages)==147,'Final manuscript must have147 pages')
    # Force access to every page dictionary; a count alone can leave malformed
    # page objects unread until later.
    for page in reader.pages:
        need(float(page.mediabox.width)>0 and float(page.mediabox.height)>0,'Invalid page dimensions')
    return 147

def suite_check(paths,root,m):
    expected=load_bytes((root/DEPENDENCIES).read_bytes())['jobs']
    need(len(expected)==48 and len({x['name']for x in expected})==48,'48 distinct selected proof jobs')
    byname={x['name']:x for x in expected};seen=set();groups=[];failures=[]
    for path in paths:
        meta=load_bytes(path.read_bytes())
        need(meta['schema']in ('BE_FIXED_CERTIFICATE_SUITE_V1','BE_FIXED_CERTIFICATE_SUITE_V2')and meta['status']in ('PASS','FAIL'),'Completed portable suite group')
        need(meta['optimized']is False and meta['sources_unchanged']is True,'Unoptimized unchanged suite')
        need(type(meta['input_sha256'])is dict and meta['input_sha256'],'Nonempty suite source snapshot')
        need(meta['input_sha256']==meta['input_sha256_after'],'Exact before/after snapshots')
        need(meta['selected_jobs']==len(meta['jobs']),'Full selected group completed')
        runner='run_certificates_v2.py'if meta['schema']=='BE_FIXED_CERTIFICATE_SUITE_V2'else'run_certificates.py'
        for field,name in [('runner_sha256',runner),('job_file_sha256','jobs.json')]:
            need(any(Path(k).name==name and v['sha256']==meta[field]for k,v in m['files'].items()),'Shipped suite runner/job-list identity')
        for rel,h in meta['input_sha256'].items():
            key=rel
            if Path(rel).is_absolute():
                try:key=Path(rel).relative_to(Path(meta['workspace'])).as_posix()
                except ValueError:
                    # A runner/helper/job list can reside outside the copied
                    # workspace. It must still match a shipped same-name file.
                    need(Path(rel).name in ('run_certificates.py','run_certificates_v2.py','isolated_acceptance.py','jobs.json'),'Unbound external source '+rel)
                    need(any(Path(k).name==Path(rel).name and v['sha256']==h for k,v in m['files'].items()),'External runner not shipped identically')
                    continue
            need(key in m['files']and m['files'][key]['sha256']==h,'Suite input differs from archive '+key)
        group_failed=0
        for row in meta['jobs']:
            name=row['name'];need(name in byname,'Foreign suite job')
            need(all(row[k]==byname[name][k]for k in ('cwd','argv','source_run')),'Same selected job arguments')
            entrypoint=PurePosixPath(row['cwd'],row['argv'][0]).as_posix()
            need(entrypoint in meta['input_sha256']and meta['input_sha256'][entrypoint]==m['files'][entrypoint]['sha256'],'Selected job entrypoint in exact start snapshot')
            need(row['command'][-(len(row['argv'])+1):]==['-B',*row['argv']],'Unchanged unoptimized job command')
            for stream in ('stdout','stderr'):
                p=path.parent/(name+'.'+stream+'.txt')
                need(digest(p)==row[stream+'_sha256'],'Portable suite stream integrity')
            if row['returncode']!=0:
                # Preserve the one known initial collision. This is a failed
                # attempt, never counted as a successful proof execution.
                need(name=='certificate_complement47' and row['returncode']==1
                     and meta['schema']=='BE_FIXED_CERTIFICATE_SUITE_V1','Unexpected failed job')
                text=(path.parent/(name+'.stderr.txt')).read_text()
                need(text.rstrip().endswith('ValueError: fresh output path'),'Known existing-output refusal only')
                need(path.parent.name=='portable_group0_01','Named preserved failed group')
                failures.append(dict(name=name,metadata=str(path),returncode=1,
                    stderr_sha256=row['stderr_sha256'],reason='Existing generated output; preserved failure, not counted toward48 successes.'))
                group_failed+=1
                continue
            need(name not in seen,'Duplicate successful suite job');seen.add(name)
            if name=='certificate_complement47':
                need(meta['schema']=='BE_FIXED_CERTIFICATE_SUITE_V2','Writer must succeed in isolated V2 execution')
                need(any(Path(k).name=='isolated_acceptance.py'and v['sha256']==meta['isolation_helper_sha256']for k,v in m['files'].items()),'Shipped isolation helper identity')
                iso=row['isolated_acceptance']
                need(row['process_returncode']==0 and iso['entire_copy_restored']and iso['original_capsule_unchanged'],'Declared writer restored its exact disposable copy')
                need(iso['declared_outputs']==['work/below50_20260929/entry/complement47_accepted.json'],'Only declared acceptance output')
                need(iso['unexpected_or_changed_paths']==[],'No undeclared writer change')
                for rel,out in iso['regenerated_outputs'].items():
                    need(out['byte_identical']and out['actual_sha256']==out['expected_sha256']==m['files'][rel]['sha256'],'Recreated fixed output byte identity')
        need((meta['status']=='FAIL')==(group_failed>0),'Fair aggregate group status')
        groups.append(dict(path=str(path),sha256=digest(path),jobs=len(meta['jobs']),
                           status=meta['status'],failed_attempts=group_failed,workspace=meta['workspace']))
    need(seen==set(byname),'Exactly all48 proof jobs across supplied portable suite groups')
    need(len(failures)==1,'Exactly the separately preserved output-collision failure')
    return dict(status='PASS_48_JOBS_IN_PREVIOUS_PORTABLE_COPY',groups=groups,jobs=48,
                preserved_failed_attempts=failures,
                distinction='These are separately recorded fresh copy executions, not48 jobs rerun from this extracted ZIP.')

def main():
    need(__debug__ and not sys.flags.optimize,'Unoptimized Python required')
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--zip',dest='archive',required=True,type=Path)
    ap.add_argument('--pdf',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path)
    ap.add_argument('--extract-to',required=True,type=Path)
    ap.add_argument('--suite-metadata',action='append',default=[],type=Path)
    args=ap.parse_args()
    archive=args.archive.resolve();pdf=args.pdf.resolve();out=args.output.resolve();root=args.extract_to.resolve()
    need(not out.exists()and not root.exists(),'Fresh report and extraction paths required')
    need(root!=out and root not in out.parents,'Audit logs must be outside extracted source')
    need(archive.is_file()and pdf.is_file(),'Archive and external PDF exist')
    out.parent.mkdir(parents=True,exist_ok=True)
    so=out.with_suffix('.composition.stdout.txt');se=out.with_suffix('.composition.stderr.txt')
    need(not so.exists()and not se.exists(),'Fresh external composition streams')
    report=dict(schema='BE_CUTOFF50_ARCHIVE_AUDIT_V1',status='RUNNING',started_utc=stamp(),
                argv=sys.argv,python=sys.version,auditor_sha256=digest(Path(__file__)),
                archive=dict(path=str(archive),sha256=digest(archive)),
                external_pdf=dict(path=str(pdf),sha256=digest(pdf)),extraction=str(root),
                mathematical_scope='Integrity/portability audit of an already reviewed proof; no new analytic proof is inferred from hashes.')
    stage='archive'
    try:
        need(report['external_pdf']['sha256']==PDF_SHA,'Fixed final external PDF')
        with zipfile.ZipFile(archive)as z:
            files=zip_members(z);m,mhash=manifest(z,files)
            report['manifest']=dict(sha256=mhash,files=len(m['files']),all_files_verified=True)
            stage='extraction';extract_verified(z,files,root)
        check_tree(root,m,mhash)
        stage='PDF'
        need(digest(root/PDF_NAME)==digest(pdf)==PDF_SHA,'Included/external PDF identity')
        report['external_pdf']['pages']=pdf_check(pdf)
        report['included_pdf']=dict(member=PDF_NAME,sha256=digest(root/PDF_NAME),pages=pdf_check(root/PDF_NAME))
        stage='extracted global integrity replay'
        command=[sys.executable,'-B',Path(GLOBAL).name]
        env=os.environ.copy();env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONHASHSEED']='0'
        with so.open('xb')as stdout,se.open('xb')as stderr:
            proc=subprocess.run(command,cwd=(root/GLOBAL).parent,env=env,stdout=stdout,stderr=stderr,timeout=180)
        need(proc.returncode==0,'Extracted unchanged global checker failed')
        result=load_bytes(so.read_bytes())
        need(result['status']=='PASS_CUTOFF50_COMPOSITION'and result['selected_component_runs']==48 and result['source_files']==850,'Expected extracted global conclusion')
        need(result['dependency_manifest_sha256']==DEPENDENCIES_SHA,'Expected extracted mathematical manifest')
        report['extracted_global_replay']=dict(returncode=proc.returncode,command=command,
            cwd=str((root/GLOBAL).parent),checker_sha256=GLOBAL_SHA,stdout_sha256=digest(so),stderr_sha256=digest(se),
            result=result,scope='Fresh scalar/integrity checker only; underlying48 proof jobs not rerun from ZIP.')
        stage='optional portable suite evidence'
        report['portable_suite']=suite_check([p.resolve()for p in args.suite_metadata],root,m)if args.suite_metadata else dict(status='NOT_SUPPLIED',jobs_replayed_from_zip=0)
        stage='final immutability'
        check_tree(root,m,mhash)
        need(digest(archive)==report['archive']['sha256']and digest(pdf)==PDF_SHA,'Input files unchanged during audit')
        report.update(status='PASS_EXTRACTED_ARCHIVE_GLOBAL_INTEGRITY',sources_unchanged=True,finished_utc=stamp())
    except Exception as e:
        report.update(status='FAIL',failed_stage=stage,error=type(e).__name__+': '+str(e),finished_utc=stamp())
        out.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(dict(status='FAIL',stage=stage,error=report['error'],report=str(out))),flush=True)
        return 1
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],report=str(out),report_sha256=digest(out),
                         manifest_files=report['manifest']['files'],pdf_pages=147,
                         proof_jobs_rerun_from_zip=0,portable_suite=report['portable_suite']['status']),indent=2))
    return 0
if __name__=='__main__':sys.exit(main())
