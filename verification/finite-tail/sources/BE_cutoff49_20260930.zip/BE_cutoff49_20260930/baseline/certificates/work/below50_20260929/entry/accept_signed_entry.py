#!/usr/bin/env python3
"""Fixed exact acceptance for named new supported barrier exclusions."""
import copy,hashlib,json,sys
from pathlib import Path
from fractions import Fraction as F
import signed_core as c
PROFILES={
 'ANCHOR45_K07':dict(n=45,nmax=45,radius=F('3.5'),cap=F('.4431'),barrier=F('.7'),grid=[24,24,8,4]),
 'PROP46_K07':dict(n=46,nmax=98,radius=F('3.5'),cap=F('.432'),barrier=F('.7'),grid=[24,24,8,4]),
}
def need(v,s):
 if not v:raise ValueError(s)
def fields(o,names):need(type(o)is dict and set(o)==set(names),'exact object fields')
def rational(x):
 need(type(x)is str and len(x)<100,'rational string');r=F(x);need(str(r)==x,'canonical rational');return r
def unique(items):
 o={}
 for k,v in items:need(k not in o,'duplicate JSON key');o[k]=v
 return o
def shape(doc):
 fields(doc,('format','name','steps'));need(doc['format']=='SIGNED_ENTRY50_V1','format');need(doc['name']in PROFILES,'named fixed theorem')
 p=PROFILES[doc['name']];rows=doc['steps'];need(type(rows)is list and 1<=len(rows)<=32,'finite ordered stage list');raw=d=None
 for j,z in enumerate(rows):
  fields(z,('raw','defect','active','excluded'));r,e=rational(z['raw']),rational(z['defect'])
  # This gate precedes use of the first defect target: the initial raw
  # bound licenses removal of the unknown Gaussian weight.
  need(0<r<F('.4')*p['n'],'raw-to-unweighted-defect initialization')
  need(e>0 or (j==len(rows)-1 and e<0),'negative defect only final')
  if raw is not None:need(r<=raw and e<=d and (r<raw or e<d),'ordered invariant progress')
  need(type(z['active'])is int and type(z['excluded'])is int,'integer cover cardinalities')
  need(z['active']>0 and z['excluded']>=0 and z['active']+z['excluded']==18432,'complete fixed cover')
  raw,d=r,e
 need(d<0,'fixed exclusion goal')
 return p
def verify(doc,emit=False):
 p=shape(doc);raw=d=None;total=0
 for j,z in enumerate(doc['steps']):
  out=c.stage(p,raw,d);r,e=F(z['raw']),F(z['defect'])
  need(out['active']==z['active']and out['excluded']==z['excluded'],'recorded complete cover counts')
  need((raw is not None and r==raw)or out['R']<r,'strict raw ceiling')
  need((d is not None and e==d)or out['D']<e,'strict defect ceiling')
  # In particular, the next pass never uses the outputs from a failed pass.
  raw,d=r,e;total+=out['total']
  if emit:print('PASS',doc['name'],j,z,flush=True)
 return dict(name=doc['name'],raw=str(raw),defect=str(d),stages=len(doc['steps']),covered_cells=total)
def controls(doc):
 cases=[]
 def add(f,deep=False):
  v=copy.deepcopy(doc);f(v);cases.append((v,deep))
 add(lambda d:d.pop('format'));add(lambda d:d.update(extra=True));add(lambda d:d.update(name='UNKNOWN'))
 add(lambda d:d['steps'].pop());add(lambda d:d['steps'].reverse());add(lambda d:d['steps'].insert(1,copy.deepcopy(d['steps'][0])))
 add(lambda d:d['steps'][0].pop('raw'));add(lambda d:d['steps'][0].update(raw='nan'));add(lambda d:d['steps'][0].update(raw='01'))
 add(lambda d:d['steps'][0].update(active=True));add(lambda d:d['steps'][0].update(raw='100'))
 add(lambda d:d['steps'][-1].update(defect='1/100'))
 # Arithmetic mutations have valid shape and require a genuine stage replay.
 add(lambda d:d['steps'][0].update(raw='4'),True)
 add(lambda d:d['steps'][0].update(active=d['steps'][0]['active']-1,excluded=d['steps'][0]['excluded']+1),True)
 for v,deep in cases:
  try:verify(v)if deep else shape(v)
  except (ValueError,TypeError,ZeroDivisionError):pass
  else:raise ValueError('malformed or false proof accepted')
 try:json.loads('{"x":1,"x":2}',object_pairs_hook=unique)
 except ValueError:pass
 else:raise ValueError('duplicate keys accepted')
 return len(cases)+1
if __name__=='__main__':
 need(not sys.flags.optimize,'optimized Python forbidden');blob=Path(sys.argv[1]).read_bytes();doc=json.loads(blob,object_pairs_hook=unique);out=verify(doc,True);out.update(status='FRESH_PASS',controls=controls(doc),proof_sha256=hashlib.sha256(blob).hexdigest());print(json.dumps(out,sort_keys=True),flush=True)
