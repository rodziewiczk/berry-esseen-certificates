#!/usr/bin/env python3
"""New exact upper enclosure for the small-frequency-zero HIGH tail.

This module changes only a proved integration bound; it emits no acceptance.
The n-uniform derivative gate is explicit. All inherited event/damping gates
are still called by the original high function.
"""
from fractions import Fraction as F
import kernel as k
old_high=k.high

def improved_high(n,a,m,d0,mu4,window):
 old,terms=old_high(n,a,m,d0,mu4,window)
 b=F(9,10);rate=a*F(23,48)**2*d0*d0;x=n*rate*b*b
 # For f(x)=sqrt(x)exp(-x)(x+2)/(x*x+4*x+2), its derivative
 # has numerator 4-10x-22x²-13x³-2x⁴, negative for x>=1/4.
 if x>=F(1,4):
  k.need(4-10*x-22*x*x-13*x**3-2*x**4<0,'Laguerre tail all-index derivative')
  r=(x+2)/(x*x+4*x+2)
  bound=k.roots(F(n))[1]*k.exphi(x)*r/(2*b*b)
  newterms=list(terms);newterms[3]=min(terms[3],bound)
  return k.up(sum(newterms),10**10),tuple(newterms)
 return old,terms

def install():k.high=improved_high
