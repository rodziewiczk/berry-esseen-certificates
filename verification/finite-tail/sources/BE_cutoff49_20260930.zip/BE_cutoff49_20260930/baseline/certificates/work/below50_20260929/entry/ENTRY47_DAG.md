# Entry at index 47: current proof interfaces

All paths below are relative to `work/below50_20260929/`. No cutoff-50
theorem is asserted here. The complete local comparison remains separate.

## Common hypotheses and external edges

The object is an attained, positively oriented maximizing witness at an
integer `n >= 47`, with `C_n >= C_E` and decrement at most `.19`.
The independently composed `.7/n` ceiling from index45 supplies the own
score cap `.4247` and all three local score caps `.4253`.
The unrestricted support certificate supplies actual radius3.84.
Published finite Berry--Esseen bounds, attainment/contact, and the generic
Fourier transfer are separate analytic dependencies, not arithmetic outputs.

## Complete probability acquisition

1. `entry/accept_high_window50.py`: improved complete HIGH theorem;
   fresh `entry/high_window_accept01`, independent HIGH_WINDOW50 binding.
2. `entry/accept_initial47.py`, `initial47_proof.json`: full signed cover;
   fresh `entry/initial47_accept01`. It acquires raw `<1.885`,
   weighted `nD < 47*.590`, and the complete100 probability-cell cover.
3. Central route: `entry/accept_central47.py prep` acquires10 broad cells.
   `root/accept_support47.py` contracts the surviving central laws to
   actual radius2.5. `entry/accept_central47.py input` then acquires all45
   canonical `.002` panels in `[.38,.47]`.
   Fresh logs: `central47_prep_accept01`, `central47_input_accept01`.
4. Complement route: `entry/accept_complement47.py` checks125 cells in
   `[.25,.38] union [.48,.60]`, excluding the entire right complement
   and leaving45 cells `[.29,.38]`. Fresh `complement47_accept01`.
   `entry/accept_left_support47.py` proves actual radius3 using the
   acquired rho/beta caps; fresh `left_support47_accept01`.
   `entry/accept_left_input47.py` excludes6 further cells and acquires39
   panels `[.302,.380]`; fresh `left_input47_accept01`.

The union of the two routes covers every survivor, including shared
boundaries. INITIAL47 excludes all probability cells outside its35
nonempty cells; no unexamined probability complement is dropped.

## Acyclic central feedback

5. `root/accept_panel_exterior47.py` supplies the initial noise strip for
   the original canonical central input. The separately accepted local
   confinement theorem supplies an amplitude in each of its45 cells.
6. `entry/accept_confined_feedback47.py` uses that amplitude to derive
   smaller actual support, then refines the already acquired moments.
   Fresh `confined_feedback47_accept01`:45 panels/13 controls.
   Table: `confined_feedback47_table.json`.
7. `local/accept_sperner47.py` supplies stronger amplitudes from the
   original canonical input. It does not consume its own feedback.
   `entry/accept_sperner_feedback47.py` consumes those amplitudes and the
   first accepted feedback moments. Fresh `sperner_feedback47_accept01`:
   45 panels/14 controls. Table: `sperner_feedback47_table.json`.

The radius extension is restricted to actual local-panel calculations,
with the explicit paired gate `R > 2g`; old stopping/signed kernels are
unchanged. The conditional gamma lower bound has its own derivation and
96 actual-law controls. The final independent Sperner feedback binding is
`../structural/SPERNER_FEEDBACK47_BINDING.json`.

## Further acquired refinement

8. `entry/accept_signed_resource47.py` keeps positive and negative
   conditional variance costs separate in moment and outer-gap bounds.
   Fresh `signed_resource47_accept01`: all84 preceding panels checked,
   one left-edge exclusion,83 surviving panels covering `[.304,.47]`,
   14 controls. Table: `signed_resource47_table.json`.
   Arithmetic is fresh PASS; the independent analytic derivation found no
   defect. The final binding is
   `../structural/SIGNED_RESOURCE47_BINDING.json`.
   `signed_variance_resource47_proof.tex` supplies the full new derivation.
9. On its entire left subrange, the acquired moment bounds are
   `rho <= 1.2563`, `|beta| <= .3926`. The fixed unchanged-heat-kernel row
   `entry/accept_left_radius270_47.py` implies actual radius2.7 for every
   `n >= 47`, every H, and decrement at most `.19`.
   Fresh `left_radius270_47_accept01`:1736 gates/3 controls.
   `entry/accept_left270_input47.py` then refines all38 left cells.
   Fresh `left270_input47_accept01`:38 panels/11 controls, with the heat
   hypotheses explicitly checked against the preceding acquired table.
   Latest left table: `left270_input47_table.json`, SHA256
   `4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a`.

The current strongest selected cover is these38 left cells `[.304,.38]`
plus the45 central cells `[.38,.47]` in `signed_resource47_table.json`.
The gamma interpretation described below is an explicit analytic
dependency of the paired Fourier estimates throughout this acquisition.

`phase_resource47_discovery01.json` adds analogous K1 pricing but gives
negligible additional gain; it is discovery only and is not selected.

## Resource semantics

Every accepted table's `D` means the weighted bound `nD_actual <= 47 D`.
The accompanying `theta` remains an unweighted variance bound. The
all-index `lambda_max` is derived separately from the weighted defect
and compulsory binary charge, never by multiplying unweighted theta by47.
The inward-gap resource likewise has an independent weighted derivation.

All four signed quadratics are retained. `Qbudget` already includes the
Gaussian phase charge; do not subtract another phase charge from it.
All valid old and new resource bounds may be intersected, but confinement
must consume an already acquired table and cannot prove its own premise.

## Fourier-only orientation clarification

`paired_fourier_orientation47.tex` resolves a misleading earlier statement
of the paired routine's sign premise. Its `gamma_l` bounds `|gamma|`, not
necessarily the original signed gamma. The exact identity
`I0_{-X}(-H)=I0_X(H)` permits choosing the reflection only inside the
unsigned Fourier bound. Both odd cancellation coefficients flip together;
the cancellation norm and all even/absolute moments are unchanged.
The actual signed contact, K, J and phase data remain untouched.
Thus clipping a signed gamma lower bound at zero is valid for this purpose.
The entry constructor and independent auditor derived this clarification;
no numerical formula or acceptance target was changed. It must be included
in a complete exposition using any of these broad paired estimates.

## Final independent bindings

All current review holds are cleared with the Fourier orientation lemma
included. Final files under `../structural/`:

- `SPERNER_FEEDBACK47_BINDING.json`;
- `SIGNED_RESOURCE47_BINDING.json`;
- `LEFT270_INPUT47_BINDING.json`;
- `PAIRED_ORIENTATION47_BINDING.json`, explicitly supplementing affected
  earlier paired-Fourier acquisition reviews.

Fresh binding logs are `structural/sperner_resource47_binding01` and
`structural/final47_review_binding01`. The reviewer additionally checked
84 actual laws independently for the separate sign-resource formulas.
