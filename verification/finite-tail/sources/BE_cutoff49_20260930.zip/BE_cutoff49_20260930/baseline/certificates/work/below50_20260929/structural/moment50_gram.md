# Additional common-mean Gram lower bound

**Mathematical status:** locally derived analytic inequality for every centered,
variance-one law with finite fourth moment. It uses no support or maximizing
assumption. **Execution status:** no separate finite-domain certificate; the
proof is the two-line Cauchy calculation below. This is separate from the
frozen MOMENT50 upper-bound deliverable.

Use the moment notation of `moment50.tex`. Put

V=|X|−2m−beta*X, W=X²−1−gamma*X.

Direct expansion, using the common first moment on both signs, gives

E V²=1−4m²−beta²,
E W²=mu4−1−gamma²,
E VW=rho−2m−beta*gamma.

Cauchy therefore gives

(mu4−1−gamma²)(1−4m²−beta²) ≥ (rho−2m−beta*gamma)².

If the second factor is positive, divide by it. If it is zero, V vanishes
almost surely, so the right-hand numerator is zero. A zero denominator must
not be used to reject an actual binary law.

On a moment box with shared m∈[mL,mU], a safe denominator upper bound is
1−4mL²−min|beta|². A lower numerator is the squared distance to zero of
the interval for rho−2m−beta*gamma. Products beta*gamma are enclosed by
all four corners. The additive gamma² uses its interval minimum. Only use
this divided form when the denominator upper bound is strictly positive.
At zero, retain the exact Cauchy product inequality and equality constraint.
