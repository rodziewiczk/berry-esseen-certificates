"""Read-only replay of the frozen exact local coverage object."""
from pathlib import Path
from hashlib import sha256
import json,sys
from check_local47_coverage import run,unique,need
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
if len(sys.argv)!=1:raise ValueError('No target overrides')
p=Path(__file__).with_name('LOCAL47_COVERAGE.json');raw=p.read_bytes();want=json.loads(raw,object_pairs_hook=unique);got=run()
need(got==want,'Frozen coverage/result/source mismatch')
print(json.dumps(dict(status='PASS_READ_ONLY_EXACT_LOCAL47_COVERAGE',probability_panels=got['probability_panels'],exact_partition_checks=got['exact_partition_checks'],low_box_coverage=got['low_box_coverage'],scope=got['mathematical_scope'],object_sha256=sha256(raw).hexdigest(),checker_sha256=got['checker_sha256'],wrapper_sha256=sha256(Path(__file__).read_bytes()).hexdigest()),indent=2))
