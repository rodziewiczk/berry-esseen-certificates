from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;PROJECT=BASE.parents[1]
def digest(p):return sha256(p.read_bytes()).hexdigest()
def readj(p):return json.loads(p.read_text())
targets=[('LEFT_SPERNER47_A',122578,20),('LEFT_SPERNER47_PROFILE_A',284400,18),('TINY47_WIDE_A',77,24)]
table=readj(BASE/'entry/left270_input47_table.json')['panels']
assert len(table)==38
assert digest(BASE/'entry/left270_input47_table.json')==digest(BASE/'local/left270_input47_table.json')
assert not any(F(r['lambda_max'])in[F('.05'),F('.08'),F('.10')]for r in table)
for rows in [table,readj(BASE/'entry/sperner_feedback47_table.json')['panels']]:
 for r in rows:
  for key,ceiling in [('theta','.0154'),('d0','.0181'),('H_plus','1.393'),('H_minus','1.393')]:
   assert F(r[key])<=F(ceiling),(r['index'],key)
common=['structural/LEFT_TINY47_EXTENSIONS_REVIEW.md','structural/bind_left_tiny47_extensions.py',
 'structural/LEFT270_INPUT47_BINDING.json','structural/PAIRED_ORIENTATION47_BINDING.json',
 'structural/SPERNER47A_BINDING.json','structural/TINY47A_BINDING.json',
 'entry/LEFT_STRIP47_REVIEW_ENTRY.md','entry/LEFT_STRIP47_BINDING_ENTRY.json',
 'entry/left270_input47_table.json','entry/sperner_feedback47_table.json',
 'root/accept_left_strip47.py','root/left_strip47_proof.tex']
reports=[]
for name,gates,controls in targets:
 freeze=BASE/'local'/(name+'_FREEZE.json');doc=readj(freeze)
 records={str(freeze.relative_to(PROJECT)):digest(freeze)}
 for rel,h in doc['files'].items():
  p=BASE/'local'/rel;assert digest(p)==h,(name,rel)
  records[str(p.relative_to(PROJECT))]=h
 run=PROJECT/doc['runs']['acceptance'];m=readj(run/'metadata.json');r=readj(run/'stdout.txt')
 assert m['returncode']==0 and digest(run/'stdout.txt')==m['stdout_sha256']
 assert r['gates']==gates
 ct=r.get('negative_controls',r.get('controls'));assert(len(ct)if isinstance(ct,list)else ct)==controls
 for rel,h in r['source_sha256'].items():
  p=BASE/'local'/rel;assert digest(p)==h,(name,rel,'report source')
  if rel in m['input_sha256']:assert m['input_sha256'][rel]==h,(name,rel,'before source')
 for p in [BASE/x for x in common]+[run/x for x in ['metadata.json','stdout.txt','stderr.txt']]:
  records[str(p.relative_to(PROJECT))]=digest(p)
 out=HERE/(name+'_BINDING.json');assert not out.exists()
 out.write_text(json.dumps(dict(schema='INDEPENDENT_'+name+'_REVIEW_V1',
  mathematical_status='Conditional theorem independently reviewed; no unresolved defect in named scope.',
  execution_status='Fresh fixed exact acceptance PASS; current source hashes match constructor freeze and recorded replay.',
  scope=doc['scope'],gates=gates,controls=controls,
  visual_qa='Constructor inspected all pages; independent reviewer read all proof/code but does not claim duplicate PDF visual QA.',
  source_sha256=records),indent=2)+'\n')
 reports.append(dict(name=name,binding_sha256=digest(out),gates=gates,controls=controls))
print(json.dumps(dict(status='PASS_INDEPENDENT_LEFT_TINY47_BINDINGS',reports=reports,table_to_tiny_scope='exactly checked',no_profile_singleton_ceiling='exactly checked'),indent=2))
