# Independent review of the final left confinement and widened TINY scope

## Mathematical and execution status

All three named objects below are **conditional theorems, independently
reviewed with no unresolved defect**. Each also has a fresh fixed exact
acceptance PASS. They do not by themselves supply the final left
whole-count comparison or a global cutoff.

| Object | Mathematical conclusion | Fresh execution |
|---|---|---|
| LEFT SPERNER47 A | Every acquired left panel has its listed amplitude, at most `.375`, for all `n>=47` | 38 panels, 122,578 gates, 20 rejection controls |
| LEFT SPERNER47 PROFILE A | Additional amplitudes `.375/.325/.30` on closed noise intervals `.05-.08/.08-.10/.10-Lambda` | 90 panel/noise rectangles, 180 sign rows, 284,400 gates, 18 controls |
| TINY47 WIDE A | `rho_B(C-C_B^+(k))<-.001lambda` for all phases and `0<lambda<=.05`, under its full tuple | 77 gates, six phase cells, 24 controls |

## Left confinement and its profile

Read the complete new contract, fixed acceptors and both proof notes. The
arithmetic kernel is the identical previously reviewed Sperner kernel.
The new probability range is `[.304,.380]`, with 38 adjacent closed
`.002` panels acquired by LEFT270. The initial strip `(-.55,1.55)` is an
explicit dependency: the root fixed strip acceptance and the entry
worker's independent source/proof review are included in the binding.

The only changed analytic coefficient is the uniform cubic-moment bound
`rho<=rho_B+28s`, replacing `24s`. Its exact gate is
`28^2 [l(1-l)]^3 > [3(1-l)+.55]^2`; it follows directly from the same
conditional cubic identity and the acquired strip. Both one-sided
supports remain separated because `d0<l`. The binary-square lower
coefficient and shift coefficient used in the common moment resource
are universal in this new range; neither depends on the former `.38`
lower endpoint.

Rechecked the remaining domain-sensitive seams: mode count `j>=n-2`,
strict interval width less than the gap, internal binomial modes,
positive and negative phase orientation, restricted lower-ray slope,
upper interval disjointness, centered conditional deletion, tangent
allocation of the shared error resource, and extension across only the
acquired finite strip. The new constants are inserted into every gate;
no former concentration factor or lower probability endpoint is retained.

The profile reuses exactly the same proof on positive noise intervals.
The lower endpoint is subtracted once from the common budget and the
upper endpoint bounds the exceptional-event variance. Every selected
rectangle has its full closed 16-by-16 phase/noise cover for each sign.
I independently checked that the frozen LEFT270 table has no noise
ceiling equal to `.05`, `.08`, or `.10`. Thus its `lo>=hi` skip drops no
relevant singleton. Shared schedule boundaries retain both neighboring
closed conclusions.

## Widened TINY

The new scope is `n>=47`, `p in [.304,.47]`, `|H|<=1.393`,
`theta<=.0154`, `d<=.0181`, `|U|<=.425`, `C>=.4`, all phases, and
`0<lambda<=.05`. Compare the new kernel and normalization against the
reviewed TINY47A sources: only named scope, constants, rational quartic
witnesses and Poisson anchors changed. No inequality or endpoint
orientation changed.

The near-phase quartic still reduces by concavity in actual variance to
zero and its upper endpoint, followed by a valid quadratic minorant in
the phase/variance ratio. New rational witnesses are scale `.4784`,
splits `1.66/1.2`, and own coefficients `.514/1.036`. The corrected
Cantelli derivative remains `2z/(1+z^2 t)^2-h`. All required positive
quadratic, split and far-endpoint gates are present.

For the two noise-scaled Poisson tails, the anchors `1.25` and `1`
both have first *positive* count term at 2 (at anchor 1 the count-one
term is exactly zero). Therefore the same scaling-to-zero proof applies.
The other phase cells use individually valid fixed-variance tail bounds;
changing their finite anchors makes no additional monotonicity claim.
The complete geometric outer-count tail is unchanged.

The finite normalization proof is valid on the widened segment, with
strict legal-count and below-half gates. Its cubic repair has a positive
raw coefficient even at the new lower probability endpoint. I checked
the fixed constants' positive domains, exponential denominator and
variance factors, in addition to reading all unchanged formula gates.

Exact checks in the binding verify that both final acquired tables enter
this widened tuple: their maximum theta and inward gap are below its
ceilings, and their signed H bounds are below 1.393. The separate
confinement certificates give amplitude at most `.375`, hence below
`.425`. This is an acyclic use of acquisition and confinement.

## Evidence and limitations

The bindings verify each constructor freeze, every listed source and
proof/PDF hash, its fresh acceptance report, and corresponding run input
hashes. Full proof/source review was performed here; the constructor's
six-page, one-page and five-page visual inspections are recorded as such.
No duplicate reviewer visual QA is claimed.

Inherited actual-law and antichain controls remain relevant because the
analytic kernel is unchanged. Object mutation controls establish strict
named scope and proof-object integrity; they are not represented as an
independent derivation of the arithmetic. The existing auxiliary
Fourier-orientation clarification stays in the acquired-input dependency
chain.
