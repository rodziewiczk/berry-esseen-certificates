# Independent audit of the new HIGH integration bound

For `x>0`, put `D=x^2+4x+2` and `P_2(u)=u^2-4u+2`.
Polynomial division gives

`[D^2-P_2(u)^2]/(u+x)
 = -u^3+(x+8)u^2-(x^2+8x+20)u+(x^3+8x^2+20x+16)`.

Integrating against `exp(-u)du` on `[0,infinity)` and using the first four
factorial moments gives `(x+3)D`. The omitted residual is positive:

`Integral exp(-u)/(u+x) du
 = (x+3)/D + Integral exp(-u)P_2(u)^2/[(u+x)D^2] du`.

By nonnegative Fubini,

`Integral_0^infinity exp(-xs)/(1+s)^2 ds
 = Integral_0^infinity u exp(-u)/(x+u) du
 <= (x+2)/(x^2+4x+2)`.

For `b>0`, `kappa>0`, and `x=n*kappa*b^2`, substitution
`t^2=b^2(1+s)` therefore gives

`sqrt(n) Integral_b^infinity exp(-n*kappa*t^2)/t^3 dt
 <= sqrt(n) exp(-x)(x+2)/[2b^2(x^2+4x+2)]`.

The variable-index factor is a positive constant times
`f(x)=sqrt(x)exp(-x)(x+2)/(x^2+4x+2)`.
Its derivative, multiplied by the positive factor
`2sqrt(x)exp(x)(x^2+4x+2)^2`, is

`4-10x-22x^2-13x^3-2x^4`.

An independent exact polynomial calculation verified this identity. The
polynomial is negative at `x=1/4` and strictly decreasing thereafter.
Thus freezing the bound at the minimum index is valid for `x>=1/4`.
The worker's `high_refinement.py` correctly retains the old bound when
this condition fails and takes the minimum of two valid bounds when it
holds. It leaves all original high-function event and damping gates in
place. No flaw was found in this integration refinement. Its complete
entry use still depends on those unchanged hypotheses and the actual
continuous-cell coverage.

Mathematical status: independently derived and reviewed. Execution status:
the two polynomial identities and derivative sign at1/4 were independently
checked exactly in this task; the worker owns the fixed full acceptance.
