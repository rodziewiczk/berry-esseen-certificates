# Independent review of CONDITIONAL_TINY47_A

**Mathematical status:** independently derived and reviewed at its exact
conditional scope; no defect found. **Execution status:** the selected
arithmetic sources match the constructor's fresh exact acceptance
`local/tiny47a_accept01`: 77 positive gates, six closed phase cells and 24
rejection controls. This review does not acquire its hypotheses or prove a
new global cutoff.

## Statement and dependencies

For n>=47, p in[.38,.47], |H|<=1.257, theta<=.0154, inward gap d<=.0181,
actual centered conditional noises |U|<=.425 and every 0<lambda=ns<=.05,
the signed score C>=.4 obeys
rho_B(C-C_B^+(k))<-.001 lambda for either nearest count k.
The labels and inward endpoints are those in the proof; a0<=d<p and
b0>=1-d>p ensure their required sign alignment. Zero noise is Bernoulli,
not a strict inequality. All incoming events are closed and outgoing events
are strict, including threshold collisions and the phase endpoints.

I read the complete proof, kernel, normalization, acceptor and both separate
algebra-control sources. The retained centered-Poisson and finite-normalization
arguments were rechecked against the earlier independently reviewed TINY45C.
All exact numerical premises are checked in the selected kernel; the scope
remains conditional even when a surrounding manuscript acquires those premises.

## Independent derivation of the new argument

The sign minorant has numerator -x^4+3a^2 x^2+2a^3 x and maximum
(9+6sqrt(3))/4 after scaling. Increasing its positive denominator preserves
both its negative values for x<=0 and its bound by1 for x>0. Its value at0
is exactly0. The rational denominator gate checks both branches of the square.

For an actual sum W of independent centered noises bounded in absolute value
by A, |EW^3|<=At and EW^4<=A^2t+3t^2. Expanding the minorant at W+sigma*r
and replacing the cubic term by its adverse absolute bound gives exactly the
numerator displayed in the proof, for either sigma. No symmetry is assumed.
After r=zt and division by t, its second derivative in t is
-(12z^2+6tz^4)/(K a^4). Thus the expression lies above the chord between
variance0 and variance t*. The zero-variance endpoint is a continuous scalar
extension, not an assertion that a positive-noise law has zero variance.
At t*, replacing -z^4 by -zsplit^2 z^2 is in the lower-bound direction.
The code computes all endpoint values and the clipped quadratic vertex;
its additional positive-quadratic gate is harmless. This proves the uniform
near-phase inequalities by rational operations for every variance and phase.

At negative far phases Cantelli gives g(r)=r^2/(t+r^2)-h*r. Its derivative
at r=z*t is 2z/(1+z^2*t)^2-h, with no extra factor of t. The certified t*
value bounds this derivative below. The positive part of the derivative,
2rt/(t+r^2)^2, has one maximum, so a positive initial derivative can later
cross zero only downwards. Hence the minimum is at an interval endpoint.
The endpoint g(.5)-c*t decreases with t, so checking it at t* is sufficient.
At positive far phases f(r)>=l*r directly gives the required coefficient.
The inequalities overlap at both split points and retain strict probability
conventions at u=0 and at atoms.

## Uniform noise, count tails and repair

The first incoming centered-Poisson expectation is evaluated with positive
terms and an outward geometric remainder. For the two phase cells whose
own-count bound is proportional to lambda, the first positive term has
index2. Its scaled logarithmic derivative is
k-1-mu-3mu/(b/A+mu-j). The denominator offset b/A-j is positive, so the
subtracted terms increase with mu; the fixed endpoint gate proves scaling
uniformly down to lambda approaching0. The later Bennett tail sum scales
correctly because lambda*B'/B>1/2. Positive logarithm and exponential Taylor
bounds have the needed directions. For the other four cells the positive
constant bracket is proved first; it can then be replaced by lambda/L times
it. This sign check is essential and is present.

The normalization checks the complete count segment, factorial remainder,
normal derivative, shared conditional variance and binomial-ratio domains.
The cubic repair uses the full allowed v+s, including v+s>.25, and retains
C>=.4. The final identity conditions on one actual common marginal; omitted
outgoing count terms are nonpositive. The exact final reserve is strictly
larger than .001 on all six closed cells.

The two control programs are additional finite tests, not continuum proofs.
Their sampled algebra is independent of the acceptance imports and checks
shifted moments, actual atoms/collisions, the variance chord and quartic
minorant identity. The 24 object/domain mutations are strict equality and
parser checks; they are not described as an independent analytic verifier.

## Binding and visual status

All nine final freeze entries and selected executed source hashes were checked.
The acceptance preceded final proof layout changes; final proof/PDF bytes are
bound separately. The constructor inspected all five rendered final pages.
This reviewer checked the full proof text and source semantics, and does not
claim a second visual inspection. No selected source was edited.
