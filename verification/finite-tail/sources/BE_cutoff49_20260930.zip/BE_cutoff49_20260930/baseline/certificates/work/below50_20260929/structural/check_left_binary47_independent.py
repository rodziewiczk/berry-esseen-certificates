#!/usr/bin/env python3
"""Independent rational checks on the new finite left Bernoulli range.

The continuous-domain proof is reviewed in BERNOULLI50_REVIEW.md. These tests
exercise implementation semantics using Fraction arithmetic, a different pi
identity, and exact binomial recurrences; they do not replace that proof.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
from hashlib import sha256
import importlib.util,json,random,sys
assert __debug__ and not sys.flags.optimize
ROOT=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location('reviewed_bernoulli',ROOT/'root/bernoulli_reserve.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)

def sqrt_bounds(x):
    scale=10**40
    t=isqrt(x.numerator*scale*scale//x.denominator)
    return F(t,scale),F(t+1,scale)

def atan(q):
    s=sum((F((-1)**j,(2*j+1)*q**(2*j+1))for j in range(81)),F(0))
    return s-F(1,163*q**163),s
# arctan(1/2)+arctan(1/3)=pi/4: tangent is exactly one and both
# positive angles have sum <1/2+1/3<1<pi/2.
a=atan(2);c=atan(3);pi=(4*(a[0]+c[0]),4*(a[1]+c[1]))
PHI=(sqrt_bounds(1/(2*pi[1]))[0],sqrt_bounds(1/(2*pi[0]))[1])

def exp_ref(x):
    assert 0<=x<=F(1,2)
    term=F(1);s=term
    for j in range(1,32):
        term=term*x/j;s=s+term if j%2==0 else s-term
        if j==30:hi=s
    return s,hi

def cdf_ref(z):
    assert abs(z)<=1
    if z<0:
        lo,hi=cdf_ref(-z);return 1-hi,1-lo
    term=z;s=term
    for j in range(1,32):
        term=term*z*z/(2*j);s=s+term/(2*j+1) if j%2==0 else s-term/(2*j+1)
        if j==30:hi=s
    return F(1,2)+PHI[0]*s,F(1,2)+PHI[1]*hi

def binomial_ref(n,k,p):
    pm=(1-p)**n;cdf=pm
    for j in range(1,k+1):
        pm=pm*(n-j+1)*p/(j*(1-p));cdf+=pm
    return cdf,pm

def score_ref(n,k,p):
    v=p*(1-p);root=sqrt_bounds(n*v);d=k-n*p
    zs=sorted([d/root[0],d/root[1]])
    gl=cdf_ref(zs[0])[0];gh=cdf_ref(zs[1])[1]
    Fk=binomial_ref(n,k,p)[0]
    vals=[r*(Fk-g)/(1-2*v)for r in root for g in(gl,gh)]
    return min(vals),max(vals)

def encloses(i,lo,hi):
    assert i.fraction_lower()<=lo<=hi<=i.fraction_upper(),(str(i.fraction_lower()),str(lo),str(hi),str(i.fraction_upper()))

checks=0;cells=[];collisions=0
for n in [47,50,65,81,98]:
    for p in [F('.304'),F('.306'),F(1,3),F('.378'),F('.38')]:
        for k in [int(n*p)-1,int(n*p),int(n*p)+1]:
            lo=max(F('.304'),p-F(1,8000),(k-F('1.25'))/n)
            hi=min(F('.38'),p+F(1,8000),(k+F('1.25'))/n)
            if lo<=hi:cells.append((n,k,lo,hi))
# Explicit event-plane collisions and all genuine singleton intersections.
for n in range(47,99):
    for i in range(38):
        pl=F('.304')+F(i,500);pu=pl+F(1,500)
        for k in range(n):
            lo=max(pl,(k-F('1.25'))/n);hi=min(pu,(k+F('1.25'))/n)
            if lo==hi:cells.append((n,k,lo,hi));collisions+=1
for n,k,lo,hi in cells:
    interval,deriv=b.score_cell(n,k,lo,hi)
    for p in [lo,(3*lo+hi)/4,(lo+hi)/2,(lo+3*hi)/4,hi]:
        f,pm=binomial_ref(n,k,p);kernel=b.binomial(n,k,p)
        encloses(kernel[0],f,f);encloses(kernel[1],pm,pm);checks+=2
        sl,su=score_ref(n,k,p);encloses(interval,sl,su);checks+=1
assert b.score_point(98,37,F('.38')).fraction_lower()>b.CE.fraction_upper()-F('.01')
print(json.dumps(dict(status='PASS_INDEPENDENT_LEFT_BINARY_RATIONAL_DIAGNOSTICS',
 checks=checks,closed_cells=len(cells),singleton_count=collisions,false_reserve_controls=1,
 scope='Independent exact binomial recurrence and higher precision rational Gaussian bounds at points in new left cells; supplements the reviewed continuous enclosure.',
 kernel_sha256=sha256((ROOT/'root/bernoulli_reserve.py').read_bytes()).hexdigest(),
 review_source_sha256=sha256(Path(__file__).read_bytes()).hexdigest()),indent=2))
