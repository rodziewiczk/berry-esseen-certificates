# Independent review of two conditional local modules

## TINY45C

**Mathematical status:** independent analytical/source review complete at the
stated conditional scope. **Execution status:** fresh strict PASS, 77 gates,
six full phase cells and 21 malformed-object controls; separately checked
quotient-rule regression. Constructor compiled and visually inspected all four
final proof pages. No acquisition of the hypotheses or global cutoff follows.

I rederived the quartic sign minorant: its maximum is
(9+6sqrt(3))/4, and optimizing its scale yields (2sqrt(3)−3)t²/M.
The pointwise sign at zero is correct. The cubic centered-Poisson comparison
follows from nonnegative third/fourth derivatives, the single-summand second
moment inequality, and convexity in Poisson time; smoothing and dominated
convergence are valid with only the stated upper bound and finite variance.

The new B version had an incorrect extra factor 1/t in the far-negative
Cantelli derivative. I reported this defect. The selected C version instead
checks 2z/(1+z²*t_*)²−h>0. At the actual left endpoint r=z*t_k the derivative
is 2z/(1+z²*t_k)²−h, which is at least this checked value since t_k≤t_*.
The derivative has a single maximum, so the remaining minimum is attained at
an interval endpoint. The proof text now states this actual-variance argument
explicitly. B sources/logs are preserved; B is superseded. The analogous gate
in the preserved cutoff99 release was already correct.

I checked the finite Stirling entropy normalization, binomial ratio, own and
incoming variances, and the signed normal/cubic repair. The inward endpoint
hypotheses align B with the sign of X, and C≥.4 is retained when paying the
third-moment repair. The variance denominator is bounded at its full possible
value, including values exceeding 1/4.

For the two phase cells whose own bound scales with lambda, the first positive
Poisson index is2. Every positive summand divided by lambda increases to its
certified endpoint, since k−1−mu−3mu/(b/a+mu−j)>0 throughout. The Poisson tail
ratio decreases after index33, and the reciprocal positive exponential Taylor
polynomial gives an outward upper bound. The later incoming Bennett terms sum
geometrically. Their scaled expression B²/[lambda(1−B)] increases because
lambda*B'/B>1/2, checked with an upper logarithm bound at the largest variance.
For the other four phase cells, a positive constant bracket is established
before replacing it by its lambda/L multiple. This is the essential uniform
step for arbitrarily small noise. Every incoming event is closed and every
outgoing event is strict; the actual count identity has the correct signs.
Zero noise is a separate Bernoulli case and is not claimed to give a strict
negative comparison.

## DIRECT45A

**Mathematical status:** independent analytical/source review complete on
45≤n≤98, p∈[.25,.26], 0≤ns≤.015, |k−np|≤1.5 and every phase in[−.5,.5].
**Execution status:** constructor strict PASS, 153,861 gates, 2,639 closed cells
and 21 negative controls; constructor compiled and visually inspected all
three proof pages. This theorem requires no noise amplitude or gap bound.

The conditional count variance obeys
T_j=L*max(j/(np),(n−j)/(nq)) by one shared variance budget. Conditional Jensen
bounds the absolute third moment from below, yielding the multiplicative
factor (1+s/v)^(3/2); no sign alignment is needed. I rederived both signed
Gaussian corrections, including the favorable variance sign for delta≤0.
The density lower bound uses |delta+u|≤2 and its checked positive domain.

For negative phases, Cantelli and a completed square control the small-r
region; positivity of a concave quadratic at its two endpoints controls the
remaining interval. For positive phases each incoming Cantelli term is convex
because 3(j−k−1/2)²>T_j. Thus all phases are covered by endpoint calculations,
without replacing an actual-law event by an independent mixture.
The final multiplicative repair is used only when the score is positive;
the max with zero makes the other case immediate.

The probability cover consists of16 closed intervals with every legal k,
including degenerate intersections. The code's floor bounds deliberately
enlarge the candidate count list and then discard only empty intersections.
The fixed-point Gaussian/binomial primitive is byte-identical to the repaired
root source already independently reviewed in BERNOULLI50_REVIEW.md.
Every final numerical operation rounds outward, and the exact reconstructed
object is compared against the fixed certificate with strict type checking.

The generic cell() signature must not be interpreted as permission to increase
delta beyond1.5 or the phase range beyond.5: those values enter the hard-coded
normal derivative bound. The selected fixed theorem has precisely these values.

No remaining defect found in either selected conditional scope. The proof
hypotheses and complementary parameter regions remain separate global tasks.
