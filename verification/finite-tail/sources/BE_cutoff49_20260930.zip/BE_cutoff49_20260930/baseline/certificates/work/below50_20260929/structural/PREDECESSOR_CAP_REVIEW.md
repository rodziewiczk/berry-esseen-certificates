# Independent predecessor smoothing recurrence audit

**Mathematical status:** independently rederived universal recurrence, with only
finite third absolute moment required. No support, attainment, or monotonicity
of C_n is assumed. **Execution status:** constructor fresh scalar PASS reported;
the scalar implementation and its exact rational root directions were read.

For v=n−1, conditioning on the last summand gives a uniform discrepancy from
E Phi((H−X)/sqrt(v)) bounded by C_v*rho/sqrt(v). Taylor's theorem in X through
order two uses E X=0 and E X²=1. Its remainder is at most
phi0*rho/(6v^(3/2)), because sup|phi''|=phi0. This requires only E|X|³<infinity;
no fourth or higher moment is introduced.

The variance heat equation gives ∂v² Phi(H/sqrt(v))=F_v''''(H)/4.
Taylor's theorem over the variance interval [v,v+1] therefore costs at most
sup|phi'''|/(8v²). Gaussian Fourier inversion gives sup|phi'''|≤2/pi<.64.
Thus its cost is <.08/v², uniformly over every raw threshold H.
After multiplication by sqrt(n)/rho and rho≥1, the displayed recurrence follows.
The convolution bound was absolute, so both discrepancy branches and left
limits are covered. Taking the supremum over varying laws is legitimate because
all remainder bounds were uniform in the law and threshold.

At a first failure at index n of a_j<.7/j, the predecessor remains strictly
below .7/(n−1). Its substituted current cap decreases with n: the square-root
ratio decreases, the predecessor ceiling decreases, and sqrt(n)/(n−1)^a
is strictly decreasing for a=3/2 and a=2. The exact checker takes direct upper
roots of n/(n−1), n/(n−1)^3 and n and obtains C_n<.432 for n≥46.
It correctly rejects the false target .431.

Reported one output-text correction: the first failure is at n, not at n−1.
This did not affect the recurrence, arithmetic, or manuscript statement.
