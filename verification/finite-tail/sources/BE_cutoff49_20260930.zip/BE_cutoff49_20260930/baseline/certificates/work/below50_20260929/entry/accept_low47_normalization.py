#!/usr/bin/env python3
"""Complete fixed90-configuration normalization check for central LOW47."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import copy,json,sys
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
BOUND={
 'local/normalization_discovery.py':'836585faa44f1f3a003e6445375cd5f8d233280621b01ba4d1980232902fd541',
 'local/confinement47_contract.py':'68977fb0cb98507f39ab1d55122efcecec5ad8d65c5c2e4f47cf260e66f813c7',
 'local/confinement47_kernel.py':'59a601bf5615922e7ab1c71b22bdc25903e2f37c803eeb24d91919f370b6bfe7',
 'local/centered_confinement_kernel.py':'3f244667c8e29f8f0371b96e1c125f34899ca00ae078c361f82dc4e89f1f2a3b',
 'entry/sperner_feedback47_table.json':'4a1ea8a439e85e9f481bb6c6eb7a197ec4d35e53ceecf0ec92c3d4c96b9f618a',
}
def need(x,s):
 if not x:raise ValueError(s)
need(__debug__ and not sys.flags.optimize,'unoptimized interpreter')
for p,digest in BOUND.items():need(sha256((BASE/p).read_bytes()).hexdigest()==digest,'changed shared source '+p)
sys.path.insert(0,str(BASE/'root'));sys.path.insert(0,str(BASE/'local'))
from low47_normalization import generate_checked,normalization_gates
from confinement47_contract import config
from normalization_discovery import generate

def controls(base,cfg):
 count=0
 for key,value in [('mass',F(2)),('delta',F('0.9')),('entropy',F(0)),('logder',F(0)),('remainder',F(0)),('zeta',F(0)),('normal_v',F(0)),('normal_c',F(0)),('ratio',F(1)),('repair_multiplier',F(100)),('repair_pos',F(0)),('repair',F(-100)),('rate',F(100)),('elo',F(10)),('derivative_lo',F('1.1')),('ownhi',F('.9')),('logcap',F(1)),('v',F('.3')),('tiny',F('.03'))]:
  bad=dict(cfg);bad[key]=value
  try:normalization_gates(base,bad)
  except(ValueError,ZeroDivisionError):count+=1
  else:raise ValueError('corrupted normalization accepted '+key)
 for key,value in [('N',46),('N',True),('pl',F(0)),('H',1.0),('maxnoise',F(0)),('theta',F(1)),('amplitude',F('.7'))]:
  bad=dict(base);bad[key]=value
  try:generate_checked(bad)
  except(ValueError,ZeroDivisionError):count+=1
  else:raise ValueError('malformed normalization domain accepted '+key)
 return count

def main():
 need(len(sys.argv)==1,'fixed invocation')
 table=json.loads((HERE/'sperner_feedback47_table.json').read_text());rows=table['panels']
 need(table['N']==47 and len(rows)==45,'fixed complete panel cover')
 gates=0;digest=sha256();reports=[];first=None
 for i,row in enumerate(rows):
  need(type(row['index'])is int and row['index']==i and list(map(F,row['p']))==[F(190+i,500),F(191+i,500)],'ordered closed probability cover')
  for sign in (-1,1):
   selected=dict(row);selected['candidate_amplitude']=row['amplitude'];base=config(selected,sign)
   cfg=generate_checked(base);need(cfg==generate(base),'independently checked constants reproduce reference generator')
   report=normalization_gates(base,cfg);gates+=len(report)
   digest.update(json.dumps([i,sign,report],sort_keys=True,separators=(',',':')).encode())
   reports.append(dict(panel=i,sign=sign,gates=len(report),delta=str(cfg['delta']),mass=str(cfg['mass']),rate=str(cfg['rate'])))
   if first is None:first=(base,cfg)
 count=controls(*first)
 print(json.dumps(dict(status='PASS_LOW47_NORMALIZATION',scope='n>=47; each selected acquired central p/phase/noise/amplitude row; constants are uniform for every0<=lambda<=row.lambda_max',configurations=len(reports),gates=gates,negative_controls=count,gate_sha256=digest.hexdigest(),source_sha256={**BOUND,'root/low47_normalization.py':sha256((BASE/'root/low47_normalization.py').read_bytes()).hexdigest(),'entry/accept_low47_normalization.py':sha256(Path(__file__).read_bytes()).hexdigest()},reports=reports),sort_keys=True))
if __name__=='__main__':main()
