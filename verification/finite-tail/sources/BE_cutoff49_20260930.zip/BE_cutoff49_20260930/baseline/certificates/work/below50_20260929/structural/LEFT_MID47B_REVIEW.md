# Independent LEFT MID47 B review

**Mathematical status:** conditional comparison independently rederived
and checked; no unresolved defect. **Execution status:** fixed fresh
acceptance PASS, 217 signed blocks, 74,370 closed phase cells, 224,463
gates including 1,353 normalization gates, and 24 rejection controls.

Read the full new proof, kernel, finite normalization and fixed acceptor,
and compare with the reviewed MID47A derivation. The selected scope is
the acquired left270 p panels, n>=47, clipped noise bands
`.05-.06/.06-.08/.08-.10/.10-.12`. Their phase complements are
`|u|>=.09/.14/.19`, followed by **only** `u<=-.29` in the fourth band.
The omitted positive part of the fourth band is a separate LOW obligation.

The own-count quartic is concave in actual variance at fixed phase.
Both variance endpoints bound it from below; each monomial is then
bounded at the appropriate nonnegative phase endpoint. A certificate
may choose any one of the 56 rational scales, or the permitted
negative-phase Cantelli or positive-phase normal branch. Each chosen
witness is independently valid on its whole closed cell; optimality
is unnecessary. The witness type and allowed sign are checked exactly.

Incoming distances are correct: `1+r_lower` on negative phase and
`1-r_upper` on positive phase. For later counts the per-count distances
are `1` and `1-r_upper/2`. The linear variance envelope and Bennett
scaling give the complete geometric tail from count2 onwards. All legal
counts are retained; added illegal-count bounds are nonnegative.

The new Bennett implementation lowers its already valid positive
logarithmic exponent to the trillionth grid. Its exponential lower
polynomial remains below the true exponential, so taking its reciprocal
gives a larger, valid probability upper bound. A zero rounded exponent
produces the valid value1. The outgoing comparison explicitly rejects
an outer bound reaching1. The Poisson helper is the unchanged reviewed
positive-series truncation with a certified geometric remainder.

I verified the fixed 33 normalizer rows' extra scalar domains directly:
positive scale, variances, mass and own factor, segment strictly between
0 and1/2, logcap between0 and1, and zeta<47. In particular every repair
coefficient is positive (minimum .86013), licensing the substitution
`Krep*lambda/n<=Krep*noise_upper/47`. The normalizer's exact formula gates
give all other required bounds. The score bracket is checked positive
before multiplying the binomial mass lower bound.

The fixed reconstruction binds actual acquired p/theta/d/H/noise
premises. It uses the minimum of independently accepted ordinary and
profile amplitudes, preserving an acyclic dependency. Every claimed
phase is partitioned into closed width-.001 cells. The table has no
ceiling at an internal lower noise endpoint; no singleton is dropped.
The fourth-band negative-only convention is explicit in the theorem,
context generator and reconstructed block list.

Constructor actual-law controls supplement the proof: 7,140
inequalities, 294 atom collisions, 12 directed-rounding comparisons,
and 152 exact singleton checks. Its five-page compiled proof was
visually inspected by the constructor; this reviewer performed full
text/code review and does not claim a second PDF visual inspection.

The binding verifies current frozen sources, the fresh acceptance and
actual-law logs, and the inherited kernel/source dependencies. This is
not a proof of the complementary phase regions or the global selector.
