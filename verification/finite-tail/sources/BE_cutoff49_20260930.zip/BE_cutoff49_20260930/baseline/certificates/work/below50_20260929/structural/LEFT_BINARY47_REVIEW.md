# Independent finite left Bernoulli review

**Mathematical status:** independently reviewed finite, positive closed-CDF
Bernoulli theorem; no unresolved defect. **Execution status:** fresh fixed
root acceptance PASS on 44,486 closed cells, seven negative controls;
independent widened-domain rational diagnostics PASS.

For each of 38 closed probability cells covering `[.304,.380]`, the
selected theorem supplies a positive rational `r_I` such that
`C_B^+(n,p,k)<C_E-r_I` for every integer `47<=n<=98` and every integer
count with `|k-np|<=1.25`. The minimum reserve is exactly the declared
lower value `1301/500000=.002602`. The score is the standardized positive
closed binomial discrepancy; this does not directly bound noisy laws.

Read the complete `root/left_binary47_kernel.py`, `accept_left_binary47.py`,
`left_binary47_proof.tex`, and reread `bernoulli_reserve.py` against its
earlier independent derivation in `BERNOULLI50_REVIEW.md`. The underlying
interval kernel is byte-identical to that earlier reviewed version.
Its derivative, monotone CDF, monotone standardized threshold, unimodal
point mass, outward interval arithmetic, and alternating Gaussian
integral all hold throughout the new domain `0<p<1/2`; none required the
previous `.35` lower endpoint.

The binomial score derivative follows from
`F'=-(n-k) pi_k/(1-p)`,
`z'=-sqrt(n)/sqrt(v)-z(1-2p)/(2v)`, and
`A'/A=(1-2p)(1/(2v)+2/(1-2v))`, with
`v=p(1-p)` and `A=sqrt(nv)/(1-2v)`.
The exact midpoint plus derivative-radius enclosure bounds the whole
continuous closed cell; it is not a sampled calculation.

For each panel, n and k, the kernel intersects the p cell with
`[(k-1.25)/n,(k+1.25)/n]`. Empty intersections alone are dropped.
Equal endpoints remain singleton cells. Each nonempty intersection is
partitioned into adjacent closed intervals of width less than `1/4000`.
The inequalities `n*pl-1.25>0` and `n*pu+1.25<n` ensure the loop over
`0<=k<n` contains every possible count; every integer n from 47 through
98 is explicitly visited. No endpoint count or collision is missing.

For each panel the minimum exact reserve across all indices/counts is
rounded downward to the millionth grid. Strictness is retained because
the exact lower enclosure for C_E is strictly below C_E, even if the
reserve already lies on the rational grid. The extra stored normalized
reserve uses a lower rho_B at the upper p endpoint: rho_B decreases on
`(0,1/2)`, as follows by differentiating `v^(-1/2)-2sqrt(v)`.
If a noisy estimate is `rho_B(C-C_B)<=lambda*S`, the comparison target
is `lambda*S<rho_B*r_I`; there is no additional `1/n` factor.

The acquired left table's exact phase bounds imply
`|k-np|<=|H|/ell+1/2<1.25`. The fixed acceptor reconstructs that
implication on all 38 rows. For zero noise, an attaining positive binary
discrepancy has an integer atom threshold; the same domain applies.
The finite theorem is required below `p=1/3`, since the published binary
envelope cited in the existing manuscript has the narrower range
`[1/3,1/2]`. Beyond n=98 the selected global composition uses the
independently completed cutoff99; this finite certificate is not extended
to an unbounded index range.

Fresh independent tests in `check_left_binary47_independent.py` evaluate
binomial probabilities by a ratio recurrence and Gaussian probabilities
by longer rational series with a different arctangent identity for pi.
They pass 945 exact comparisons on 63 closed cells, including eight
singleton panel/count intersections, and reject a falsely enlarged `.01`
reserve using an actual Bernoulli point. These tests supplement the
continuous-domain argument. They do not wrap the full acceptance or
replace its complete cover.

The accompanying source binding checks the fresh root report, all current
source/proof-object hashes, before-run kernel hashes, and the independent
diagnostic log. The malformed-object controls establish scope and
integrity; their count is not presented as an independent proof of the
probability formulas.
