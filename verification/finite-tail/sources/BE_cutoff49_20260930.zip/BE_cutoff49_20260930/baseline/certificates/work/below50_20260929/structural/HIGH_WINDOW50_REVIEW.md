# Independent analytical review: prospective HIGH_WINDOW50

Status: locally rederived conditional analytical improvement; current discovery
implementation reviewed. Final fixed acceptance and acquisition are separate.
The earlier frozen HIGH sources are unchanged.

## Wider peak windows

The original actual-event proof requires an event E for independent copies with
P(E)>=a>0, distance d>=d0>0, and E[d²|E]<=m. For any 0<r<=1/2, the nonzero
cores |v|<=r fit inside the fundamental cells j+[-1/2,1/2]. Their denominators
j-r are positive, and at r=1/2 the adjacent boundaries have zero integration
measure. The inequality sin(pi|v|)>=h|v| follows from the cubic sine lower
bound, where 0<h<=333/106-(22/7)^3 r²/6. On each wing,
|sin(pi v)|>=sin(pi r)>=hr. Thus the original core Taylor/integral estimate,
S3/S5 bounds, wing total weight, zero-cell decomposition and full comparator
integral all remain valid. Extending cores below the frequency cutoff only
adds a positive integral. The current implementation uses r<=1/4, within this
larger proved range, and keeps all six pieces.

## First-frequency-piece refinement

For y=t² in[1/4,81/100], let c(y)=y/2-(M+3)y²/24. Symmetrization gives
|f(t)|^n<=exp(-n c(t²)). Concavity places c above its chord, whose slope is
s=[1-(M+3)*53/600]/2. Its value at the left endpoint is
c(1/4)=1/8-(M+3)/384. When s>0, extending the resulting majorant from
[1/2,.9] to[1/2,infinity) gives

  sqrt(n)*integral |f(t)|^n/t³ dt
  <=2 sqrt(n) exp(-n c(1/4)) rL(ns/4),
  rL(x)=(x+2)/(x²+4x+2).

This uses the separately proved rational Gaussian-tail bound already reviewed
in HIGH_REFINEMENT_REVIEW.md. Uniformity in every real n>=N follows from
2N*c(1/4)>1 and rL'(x)=-(x²+4x+6)/(x²+4x+2)²<0. Taking the minimum with
the original first term is valid. A nonpositive slope retains that original
term; no extrapolation of the chord is used to bound the characteristic
function outside its proved interval, only to integrate its majorant.

## Complete comparator integral

For the actual comparator,
|e_n(t)|<=exp(-nt²/2)*(1+n|gamma|t³/6). Consequently its full contribution
on t>=1/2 is bounded by

 sqrt(n)*exp(-n/8)*[2 rL(n/8)+|gamma|/3].

The first term is the same rational Gaussian-tail bound at kappa=1/2,b=1/2.
The ordinary Gaussian Mills inequality at b=1/2 gives integral exp(-nt²/2)dt
<=2exp(-n/8)/n, proving the second term with exactly the displayed factor1/3.
Cauchy applied to X and X²-1 gives gamma²<=M-1. If the older |gamma|<=1.85
premise is also available it may be combined by taking a minimum. The current
code uses only sqrt(M-1), safely. For real n>=5, sqrt(n)exp(-n/8), rL(n/8)
and the remaining nonnegative factors are nonincreasing.

## Current source review

Read entry/high_window_core.py against the full six-piece proof in the
preserved cutoff99 paper. Its rational slope, left-end value, coefficient
1/3, positive square-root directions, retained zero-tail refinement, and
all-index derivative gates agree with the derivations above. Its candidate
window pool may fail as a whole if an ineligible candidate violates a gate;
that is conservative and cannot create a false bound. No defect found in
this current implementation. This note does not claim a finalized acceptance
or prove the new entry hypotheses needed for a cutoff.

## Final named component review

Read the complete high_window50_proof.tex, high_window_core.py and
accept_high_window50.py, including the imported fixed Laguerre checker.
The proof supplies the complete positive-frequency partition, both zero-cell
pieces, comparator and all-index argument. The fixed checker reconstructs the
secant residual, derivative of L, Gaussian scaling factors and the Pearson
expectation; the 18 formula mutations and 11 domain mutations target the
actual checked formulas/domains. Three conditional examples pass their strict
bounds .174, .162 and .171. I checked every current executed source against the
hashes printed in the fresh entry/high_window_accept01 run. The final binding
records these bytes and proof sources. No remaining defect found at this
conditional scope. This is neither a new unconditional entry theorem nor a
cutoff result.
