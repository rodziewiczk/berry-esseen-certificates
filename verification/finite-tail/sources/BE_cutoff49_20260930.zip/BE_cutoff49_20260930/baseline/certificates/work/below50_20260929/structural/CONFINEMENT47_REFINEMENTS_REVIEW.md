# Independent derivation of three new confinement refinements

Scope: analytical formulas and corresponding blocks in
local/panel_confinement_kernel.py reviewed. No final fixed conditional
confinement acceptance or hypothesis acquisition is asserted here. In
particular the discovery-only maximum-noise acquisition gate cannot be
ignored when claiming a theorem; an independently supplied noise ceiling
must be stated as a premise of a newly named conditional theorem.

## Restricted negative-ray slope

The lower interval I=[a-r,a-d-tau-eta] lies at y<=-tau-eta because a<=d.
Consequently t=ell(y-p)<=tmax=-ell_lower*(pl+tau+eta)<0. Write the contact
correction as 3C(beta+rho*t+t²)+H*phi*t. If C in[.4,Ccap], beta>=blo and
rho<=rhoUpper, put B(t)=blo+rhoUpper*t+t² and
Bmin=min(B(t):t<=tmax). The minimizing t is min(tmax,-rhoUpper/2).
For every t in this ray,

  3C(beta+rho*t+t²)+H*phi*t
  >=1.2B(t)+signed_Hphi_upper*t
       +3(Ccap-.4)*min(0,Bmin).

The sign of t explains why an upper bound for H*phi is needed. The final
quadratic minimum is evaluated at
min(tmax,-(signed_Hphi_upper+1.2rhoUpper)/2.4). If it is negative,
ell_upper*qmin/N is a valid all-n lower correction; if nonnegative discard
it. This is exactly the code's restricted-negative-slope block. One common
lower slope L applies throughout I, so integration gives
sqrt(n)nu(I)>=L*(r-d-tau-eta), paying for d with that same L.

## Centered noise and the common hull

Both directed deletion differences contain +E[(sum U_i)1_event]. Removing
one whole pair(B_i,U_i) leaves the same background distribution for events
I and J. Conditional on the removed pair, denote their probabilities by
fI and fJ. Since U is centered, E U_+=epsilon/2, where epsilon=E|U|.
Negative marks can be discarded when upper bounding the directed noise sum.

If I and J are disjoint, fI+fJ<=Qhull for every fixed removed pair. For
p<=.5 and q=1-p,

  fI/p+fJ/q=(fI+fJ)/q+(1/p-1/q)fI.

Thus the coefficient of epsilon is at most

 fd/2 * min(QI/pl+QJ/(1-pu),
            Qhull/(1-pu)+(1/pl-1/(1-pl))*QI).

Every coefficient is nonnegative. The function1/p-1/(1-p) decreases in p,
so the outward p substitutions are correct. This proves the code's Ecoef.
Upper-interval disjointness follows from1-d0-tau>0. For the lower ray,
r<=strip+d0 and the endpoint gap is1-r+tau+eta; require this positive
throughout the actual ray. The selected small strip/gap parameters satisfy
it, but it is an explicit hypothesis for a generic implementation.

## Tangents to the same bad-pair resource

Write Dscaled=n*d>=0, R=raw-N*pen>0. Markov gives
bad<=d/(d+tau)<=Dscaled/(Dscaled+N*tau). The last function is concave on
Dscaled>=0. At an arbitrary ds>=0 its tangent has

 slope=N*tau/(N*tau+ds)^2,
 intercept=ds²/(N*tau+ds)^2.

The existing simultaneous moment/leakage budget restricts the three
nonnegative resources n*Mplus,n*Mminus and n*sqrt(n)*J to a simplex of
budget at most R. With outward p,ell bounds and n>=N, its three extreme
upper pairs(base cost,Dscaled) are exactly the code's vertices:

 ((dc/pl+2*Ecoef)*R/(ell*cp*N), R/(ell*cp*pl)),
 ((dc/(1-pu)+2*Ecoef)*R/(ell*cm*N), R/(ell*cm*(1-pu))),
 (kappa*leak*R/((1-Theta)*N),0).

All relevant cost coefficients are nonnegative. Therefore for every ds the
upper error is Dist/N+max(v+Bad*slope*Dscaled)+Bad*intercept. The zero
vertex is dominated. Taking a minimum over any fixed finite set of ds is
valid; the11-point selection is not asserted optimal and needs no optimizer
certificate. It charges the pair failure and other costs to one common
resource instead of assigning their separate maxima simultaneously.

## Further forward marked-tail refinement

Let W=A0+U0, with A0 independent of the marked pair(U0,U1), and suppose
U1>=-d. On Dminus=(U0-U1)_+>0, one has U0>U1>=-d. Hence
Dminus*1{W<=u-ci} can be nonzero only if A0<u+d-ci. Integrating the pair
then factors against P(A0<=u+d-ci). Weakening to a closed event is safe
at atoms. This replaces the forward amplitude by the inward d only.

With A0=Z+fresh U1 and A1=Z+fresh U0, conditional bounds U1>=-d,U0<=d
project the two marked events to Z<=L=u+2d-ci and Z>R=u+eta+i-A-d.
When L<R these projected events are disjoint. For any z0 in(L,R),

  P(Z<=L)+P(Z>R)
  <=(Var(Z)+z0²)/min((z0-L)²,(R-z0)²).

Use a common background centered Z and a proved variance upper t. To
optimize this quadratic family, consider the midpoint and any stationary
center -t/L lying in the interior of the left half, or -t/R lying in the
interior of the right half. Discard boundary centers with zero radius; when
a denominator L or R is zero use direct monotonicity instead. This statement
concerns a coupling of the actual deleted-law marginals; it assumes no
independence between those two deleted laws.
