"""Fixed reconstruction of conditional radius2.34; no entry acquisition."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys,copy
import heat47_central234 as K
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent
OBJECT={'schema':'CONDITIONAL_HEAT47_CENTRAL234_V1','radius':'117/50',
 'decrement':'19/100','n_floor':47,'rho':'23/20','beta_absolute':'63/250'}
SHA='5678ba9a7fa618b2f32eb222a12cd81df588bd12153882ee91fb54c90505a15b'
def need(x,s):
 if not x:raise ValueError(s)
def verify(o):
 need(type(o)is dict and o==OBJECT,'fixed exact theorem')
 need(type(o['n_floor'])is int,'integer floor')
 proof=K.reconstruct(F(o['radius']),F(o['decrement']))
 cells=proof['closed_cells']
 need(len(cells)==44 and F(cells[0][0])==F('2.34') and F(cells[-1][1])==F('4.5'),'complete new closed cover')
 need(all(F(a)<F(b)and F(b)-F(a)<=F('.05')for a,b in cells),'cell widths')
 need(all(a[1]==b[0]for a,b in zip(cells,cells[1:])),'closed adjacency')
 return proof
if __name__=='__main__':
 need(len(sys.argv)==1,'no target overrides')
 proof=verify(OBJECT);controls=0
 for key,value in [('radius','2.3'),('decrement','.2'),('n_floor',46),('rho','1.16'),('beta_absolute','.26'),('n_floor',True)]:
  obj=copy.deepcopy(OBJECT);obj[key]=value
  try:verify(obj)
  except ValueError:controls+=1
  else:raise AssertionError('changed theorem accepted')
 for radius,decrement in [(F('2.3'),F('.19')),(F('2.34'),F('.4'))]:
  try:K.reconstruct(radius,decrement)
  except ValueError:controls+=1
  else:raise AssertionError('substantively false envelope accepted')
 source=HERE.parent/'root/support47_hypotheses.json';blob=source.read_bytes()
 need(hashlib.sha256(blob).hexdigest()==SHA,'fixed canonical row source')
 rows=json.loads(blob)['exterior'];need(len(rows)==45,'complete canonical cover')
 for i,h in enumerate(rows):
  pl,pu=map(F,h['p']);th=F(h['theta']);bu=F(h['beta_upper'])
  need(0<pl<=pu<F('.5')and 0<=th<1,'canonical geometry')
  bl=(1-th)*(1-2*pu)-th
  need(0<=bl<=bu<=F('.252')and 1<=F(h['rho'])<=F('1.15'),'canonical same-law moment coverage')
  need(pl<=F('.38')+F(i,500)<F('.38')+F(i+1,500)<=pu,'canonical p cover')
 result={'status':'PASS_CONDITIONAL_HEAT47_CENTRAL234','proof':proof,
   'canonical_rows_covered':len(rows),'negative_controls':controls,
   'mathematical_status':'Locally derived conditional all-H support theorem; prior fifth-order heat/contact and far-ray lemmas required.',
   'acquisition_status':'Moment hypotheses unacquired; no cutoff50 claim.',
   'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in
       [Path(__file__),Path(K.__file__),Path(K.H.__file__),source,HERE/'heat47_central234.tex']}}
 print(json.dumps(result,indent=2))
