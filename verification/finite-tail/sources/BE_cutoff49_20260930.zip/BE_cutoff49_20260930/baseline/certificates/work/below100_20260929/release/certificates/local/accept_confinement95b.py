"""Read-only acceptance of the fixed CONDITIONAL_CONFINEMENT95_B theorem.

This rejects nonpositive gates before constructing any metadata.  Source
bindings document the trusted arithmetic implementation, not a proof of the
analytic reduction.  See confinement95b_proof.tex for that reduction.
"""
from fractions import Fraction as F
from pathlib import Path
import copy,hashlib,json,sys
from confinement95b_kernel import CFG,evaluate
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
BASE=Path(__file__).resolve().parent
FIXED={'N':95,'T':F('.75'),'D':F('.117'),'theta':F('.0085'),'d0':F('.012'),
 'pl':F('.35'),'pu':F('.46'),'H':F('1.15'),'C':F('.418'),'rho':F('1.14'),
 'beta_lo':F('.075'),'beta_hi':F('.3'),'amplitude':F('.3'),'maxnoise':F('.20'),
 'lower_buffer':F('.125'),'upper_buffer':F('.14'),'eta':F('.00001'),
 'rebate':F('.199'),'fd':F('1.017'),'third':F(23),'pc':128,'hc':16,'lc':40}
def need(test,msg):
 if not test:raise ValueError(msg)
def unique(rows):
 d={}
 for k,v in rows:need(k not in d,'duplicated JSON key');d[k]=v
 return d
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],v)for k,v in b.items())
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def reconstruct():
 need(same(CFG,FIXED),'fixed mathematical contract')
 r=evaluate();g=r['gates'];need(type(g)is dict and len(g)==474376,'fixed positive gate count')
 minima={};h=hashlib.sha256()
 for name,x in g.items():
  need(type(name)is str and type(x)is F and x>0,'strict exact gate '+name)
  h.update((name+'='+str(x)+'\n').encode())
  group=name.split(':')[0]
  if group not in minima or F(minima[group]['value'])>x:minima[group]={'name':name,'value':str(x)}
 whole={f'{i}:{j}:{k}'for i in range(128)for j in range(16)for k in range(40)}
 used=set()
 for name,value in r['empty']:
  need(type(name)is str and type(value)is str and F(value)<=0,'excluded closed box')
  need(name in whole and name not in used,'excluded coverage');used.add(name)
 for name in r['feasible']:
  need(type(name)is str and name in whole and name not in used,'feasible coverage');used.add(name)
 need(used==whole and len(r['empty'])==22786 and len(r['feasible'])==59134,'complete closed cover')
 contract={k:str(v)for k,v in FIXED.items()};need(r['contract']==contract,'kernel contract serialization')
 o={'schema':'CONDITIONAL_CONFINEMENT95_B_V1','mathematical_status':'conditional; analytic reduction in confinement95b_proof.tex',
  'contract':contract,'gates':len(g),'feasible':len(r['feasible']),'excluded':len(r['empty']),
  'gate_sha256':h.hexdigest(),'minima':minima,
  'coverage_sha256':hashlib.sha256(json.dumps([r['empty'],r['feasible']],separators=(',',':')).encode()).hexdigest(),
  'kernel_sha256':sha(BASE/'confinement95b_kernel.py'),'proof_sha256':sha(BASE/'confinement95b_proof.tex')}
 return o
def accept(o,expected):
 need(type(o)is dict and same(o,expected),'exact fixed object')
 return True
def main():
 need(len(sys.argv)==1,'read-only acceptance has no arguments')
 raw=(BASE/'confinement95b_certificate.json').read_text();o=json.loads(raw,object_pairs_hook=unique)
 e=reconstruct();accept(o,e);tests=[]
 mutations=[('missing_contract',lambda z:z.pop('contract')),('lower_floor',lambda z:z['contract'].update(N='94')),
  ('larger_budget',lambda z:z['contract'].update(T='4/5')),('smaller_amplitude',lambda z:z['contract'].update(amplitude='1/4')),
  ('missing_minimum',lambda z:z['minima'].pop(next(iter(z['minima'])))),('zero_margin',lambda z:z['minima']['confinement_lower'].update(value='0')),
  ('changed_boxcount',lambda z:z.update(feasible=z['feasible']-1)),('boolean_boxcount',lambda z:z.update(feasible=True)),
  ('float_boxcount',lambda z:z.update(feasible=float(z['feasible']))),('changed_gate_digest',lambda z:z.update(gate_sha256='0'*64)),
  ('changed_coverage_digest',lambda z:z.update(coverage_sha256='0'*64)),('changed_source',lambda z:z.update(kernel_sha256='0'*64)),
  ('changed_proof',lambda z:z.update(proof_sha256='0'*64)),('unconditional_claim',lambda z:z.update(unconditional=True))]
 for name,change in mutations:
  z=copy.deepcopy(o);change(z);need(not same(z,o),'effective mutation')
  try:accept(z,e)
  except ValueError:tests.append(name)
  else:raise ValueError('accepted mutation '+name)
 for name,text in [('malformed','{'),('truncated',raw[:-8]),('duplicate_key','{"schema":"bad",'+raw[1:])]:
  try:accept(json.loads(text,object_pairs_hook=unique),e)
  except (ValueError,TypeError,KeyError):tests.append(name)
  else:raise ValueError('accepted malformed object '+name)
 print(json.dumps({'status':'PASS_EXACT_CONDITIONAL_CONFINEMENT95_B','gates':e['gates'],'feasible':e['feasible'],'excluded':e['excluded'],
  'lower_minimum':e['minima']['confinement_lower'],'upper_minimum':e['minima']['confinement_upper'],'negative_controls':tests,
  'kernel_sha256':e['kernel_sha256'],'proof_sha256':e['proof_sha256'],'acceptor_sha256':sha(Path(__file__)),'certificate_sha256':sha(BASE/'confinement95b_certificate.json')},indent=2))
if __name__=='__main__':main()
