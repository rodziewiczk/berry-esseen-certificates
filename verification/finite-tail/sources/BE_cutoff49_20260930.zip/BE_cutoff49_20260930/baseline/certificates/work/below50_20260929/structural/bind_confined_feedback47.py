from pathlib import Path
from hashlib import sha256
import json
B=Path(__file__).resolve().parents[3];E=B/'work/below50_20260929/entry';S=B/'work/below50_20260929/structural';L=B/'work/below50_20260929/local';r=B/'runs/below50_20260929/entry/confined_feedback47_accept01'
h=lambda p:sha256(p.read_bytes()).hexdigest();m=json.loads((r/'metadata.json').read_text());o=json.loads((r/'stdout.txt').read_text().splitlines()[-1]);assert m['returncode']==0 and o['status']=='PASS_CONFINED_FEEDBACK47' and (o['panels'],o['negative_controls'])==(45,13)
t=E/'confined_feedback47_table.json';assert h(t)==o['table_sha256']==m['input_sha256'][t.name]=='360e13d125b5fb9cac6e7ee6ae0599dd796d19f8ac123794967c977c2bf4482c';table=json.loads(t.read_text())
assert table['source_sha256']==h(L/'conditional_input47.json') and table['confinement_sha256']==h(L/'confinement47_certificate.json')
files=[t,L/'conditional_input47.json',L/'confinement47_certificate.json',S/'ENTRY47_PANEL_BINDING.json',S/'CONFINEMENT47_BINDING.json',S/'CONTRACTED_ENTRY47_REVIEW.md',S/'CONFINED_FEEDBACK47_FINAL_REVIEW.md',Path(__file__),*r.iterdir()]
for n,v in o['source_sha256'].items():assert h(E/n)==v==m['input_sha256'][n];files.append(E/n)
assert h(r/'stdout.txt')==m['stdout_sha256'] and h(r/'stderr.txt')==m['stderr_sha256']
z={'schema':'INDEPENDENT_CONFINED_FEEDBACK47_REVIEW_V1','mathematical_status':'Independent analytic/source review complete for the fixed acquired central refinement; no defect found. No complete local-comparison or cutoff50 conclusion.','execution_status':'Selected sources and targets match recorded fresh PASS45 cells,13 controls.','sha256':{str(p.relative_to(B)):h(p) for p in sorted(set(files)) if p.is_file()}}
(S/'CONFINED_FEEDBACK47_BINDING.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps({'status':'PASS_CONFINED_FEEDBACK47_REVIEW_BINDING','files':len(z['sha256']),'binding_sha256':h(S/'CONFINED_FEEDBACK47_BINDING.json')}))
