"""Read-only strict acceptance for the fixed finite conditional variance theorem."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,copy,sys
from direct_variance45a_kernel import evaluate,cell,CFG
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
def need(b,s):
 if not b:raise ValueError(s)
def unique(rows):
 o={}
 for k,v in rows:need(k not in o,'duplicate JSON key');o[k]=v
 return o
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def reconstruct():
 o=evaluate();need(not o['bad'],'nonpositive strict gate')
 need(F(o['worst']['bound'])<F('2/5'),'fixed score threshold')
 need([r['n']for r in o['per_n']]==list(range(45,99)),'exact integer cover')
 o['source_sha256']={n:sha256((HERE/n).read_bytes()).hexdigest()for n in ('direct_variance45a_kernel.py','finite_count_interval.py')}
 return o
def validate(o,want):need(same(o,want),'theorem/cover/arithmetic/source mismatch')
def controls(want):
 tests=[]
 def reject(name,fn):
  o=copy.deepcopy(want);fn(o)
  try:validate(o,want)
  except ValueError:tests.append(name)
  else:raise ValueError('mutation accepted: '+name)
 reject('missing_rows',lambda o:o.pop('rows'))
 reject('extra_field',lambda o:o.update(extra=True))
 reject('wrong_schema',lambda o:o.update(schema='UNCONDITIONAL_CUTOFF45'))
 reject('larger_probability_domain',lambda o:o['contract'].update(pu='27/100'))
 reject('larger_noise',lambda o:o['contract'].update(lambda_max='1/50'))
 reject('lower_floor',lambda o:o['contract'].update(first=44))
 reject('wrong_target',lambda o:o['contract'].update(target='41/100'))
 reject('missing_index',lambda o:o['per_n'].pop())
 reject('reordered_indices',lambda o:o['per_n'].reverse())
 reject('missing_cell',lambda o:o['rows'].pop())
 reject('duplicate_cell',lambda o:o['rows'].__setitem__(1,o['rows'][0]))
 reject('reordered_cells',lambda o:o['rows'].reverse())
 reject('changed_score',lambda o:o['rows'][0].update(bound='0'))
 reject('boolean_score',lambda o:o['rows'][0].update(bound=True))
 reject('changed_gate_digest',lambda o:o.update(gate_sha256='0'*64))
 reject('changed_primitive_source',lambda o:o['source_sha256'].update({'finite_count_interval.py':'0'*64}))
 try:json.loads('{"x":1,"x":2}',object_pairs_hook=unique)
 except ValueError:tests.append('duplicate_JSON_key')
 else:raise ValueError('duplicate key accepted')
 for name,args in [('reversed_probability',(45,11,F('.26'),F('.25'),F('.015'),F('1.5'))),('zero_probability',(45,11,F(0),F('.26'),F('.015'),F('1.5'))),('invalid_count',(45,45,F('.25'),F('.26'),F('.015'),F('1.5'))),('negative_variance_ceiling',(45,11,F('.25'),F('.26'),F('-.015'),F('1.5')))]:
  try:cell(*args)
  except ValueError:tests.append(name)
  else:raise ValueError('invalid domain accepted')
 return tests
if __name__=='__main__':
 want=reconstruct();raw=(HERE/'direct_variance45a_certificate.json').read_bytes()
 validate(json.loads(raw,object_pairs_hook=unique),want);tests=controls(want)
 print(json.dumps(dict(status='PASS_EXACT_DIRECT_VARIANCE45_A',contract=CFG,gates=want['gates'],closed_cells=len(want['rows']),
  worst=want['worst'],negative_controls=len(tests),mutation_names=tests,
  certificate_sha256=sha256(raw).hexdigest(),source_sha256={**want['source_sha256'],'accept_direct_variance45a.py':sha256(Path(__file__).read_bytes()).hexdigest()},scope=want['scope']),indent=2))
