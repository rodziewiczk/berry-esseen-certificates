"""Fixed exact direct-contact exclusion for all acquired left270 panels."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
from panel_exterior import support_cell,root
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'entry/left270_input47_table.json'
SHA='4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a'
def need(x,s):
    if not x:raise ValueError(s)
def unique(items):
    d={}
    for k,v in items:
        need(k not in d,'Duplicate JSON key');d[k]=v
    return d
def read(blob):
    need(sha256(blob).hexdigest()==SHA,'Fixed acquired left table')
    d=json.loads(blob,object_pairs_hook=unique);rows=d['panels']
    need(len(rows)==38 and d['N']==47,'Complete declared rows')
    for i,z in enumerate(rows):
        need(z['index']==i and list(map(F,z['p']))==[F('.304')+F(i,500),F('.304')+F(i+1,500)],'Complete closed probability cover')
    return d
def check_panel(z,strip=F('.55')):
    pl,pu=map(F,z['p']);th,rho=F(z['theta']),F(z['rho'])
    bl,bu=F(z['beta_lo']),F(z['beta_hi']);h=max(F(z['H_plus']),F(z['H_minus']))
    need(0<pl<pu<F('.5') and 0<=th<1 and 0<=bl<=bu<1 and 1<=rho<F('1.85') and 0<h<2,'Moment/phase domains')
    ell=root((1-th)/(pu*(1-pu)));need(ell>0,'Scale positive')
    rows=[]
    for sign,start in [(-1,ell*(strip+pl)),(1,ell*(1+strip-pu))]:
        finish=F('2.7')
        if start>finish:continue
        count=max(1,int((finish-start)*80)+1)
        for j in range(count):
            a=start+(finish-start)*F(j,count);b=start+(finish-start)*F(j+1,count)
            l,r=(a,b)if sign>0 else(-b,-a)
            value=support_cell(h,rho,bl,bu,l,r)
            need(value<0,'Strict exclusion of entire closed contact cell')
            rows.append([sign,str(l),str(r),str(value)])
    need(rows,'Nonempty support check');return rows
def main():
    need(len(sys.argv)==1,'No target overrides');blob=SOURCE.read_bytes();d=read(blob)
    out=[];digest=sha256()
    for z in d['panels']:
        rows=check_panel(z);out+=rows
        digest.update(json.dumps([z['index'],rows],separators=(',',':')).encode())
    controls=0
    for kind in ['missing','duplicated','reordered','altered']:
        q=json.loads(blob)
        if kind=='missing':q['panels'].pop()
        elif kind=='duplicated':q['panels'].append(q['panels'][0])
        elif kind=='reordered':q['panels'].reverse()
        else:q['panels'][0]['theta']='0'
        try:read(json.dumps(q).encode())
        except ValueError:controls+=1
        else:raise AssertionError('Changed proof input accepted')
    try:check_panel(d['panels'][0],F('.2'))
    except ValueError:controls+=1
    else:raise AssertionError('Unsupported strip target accepted')
    need(len(out)==3073,'Full fixed closed cover')
    print(json.dumps(dict(status='PASS_EXACT_LEFT_STRIP47',mathematical_status='Conditional contact exclusion; acquisition and supportR2.7 are separate established inputs.',
        hypotheses='n>=47,actual attained positive closed contact,0<=a<=.7/n,delta<=.19,|X|<2.7,and selected acquired panel.',
        conclusion='support(Y) subset (-.55,1.55) on every p in [.304,.38]',
        panels=38,cells=len(out),controls=controls,worst_upper=str(max(F(z[3])for z in out)),
        gate_sha256=digest.hexdigest(),interpreter=sys.version,
        source_sha256={str(p.relative_to(HERE.parent)):sha256(p.read_bytes()).hexdigest()for p in [SOURCE,HERE/'accept_left_strip47.py',HERE/'panel_exterior.py',HERE/'gaussian_core.py']}),indent=2))
if __name__=='__main__':main()
