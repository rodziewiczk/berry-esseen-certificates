"""Independent exact finite controls for the strict-gap concentration lemma."""
from fractions import Fraction as F
from itertools import combinations,permutations,product
from math import comb
from collections import defaultdict
from pathlib import Path
from hashlib import sha256
import json,sys
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
def two(a,b):
 a,b=F(a),F(b)
 return {F(0):F(1)} if a==b==0 else {-a:b/(a+b),b:a/(a+b)}
def conv(a,b):
 d=defaultdict(F)
 for x,px in a.items():
  for y,py in b.items():d[x+y]+=px*py
 return dict(d)
def concentration(d,w):
 pts=sorted(d);best=F(0);total=F(0);end=0
 for i,x in enumerate(pts):
  while end<len(pts)and pts[end]<=x+w:total+=d[pts[end]];end+=1
  best=max(best,total);total-=d[x]
 return best
def mode(j,p):return max(F(comb(j,k))*p**k*(1-p)**(j-k)for k in range(j+1))
laws=[(F('1/2'),two(0,0),two(0,0)),(F('.38'),two(0,0),two(0,0)),
 (F('.302'),two('.55','.002'),two('.001','.55')),
 (F('.47'),two('.425','.003'),two('.002','.425')),
 (F('.4'),two('.55',F(1,10**9)),two(F(1,10**10),'.55')),
 (F('1/2'),two('.4','.01'),two('.01','.4')),
 (F('.46'),two(0,0),two('.001','.49'))]
checks=collisions=0
for p,u0,u1 in laws:
 d=max(u0)-min(u1);c=1-d;assert c>0
 marginal=defaultdict(F)
 for x,m in u0.items():marginal[x]+=(1-p)*m
 for x,m in u1.items():marginal[1+x]+=p*m
 dist={F(0):F(1)}
 for j in range(1,6):
  dist=conv(dist,marginal);cap=mode(j,p)
  pts=sorted(dist);widths={F(0),c/3,c/2,c-F(1,10**12)}
  widths.update(y-x for x,y in zip(pts,pts[1:]) if y-x<c)
  for w in widths:assert concentration(dist,w)<=cap;checks+=1
  collisions+=sum(w==y-x for w in widths for x,y in zip(pts,pts[1:]))
# Independently enumerate maximal chains for unequal positive weights.
lym=chains=0
for weights in [(F(1),F(1),F(1)),(F(1),F('1.2'),F('1.7'),F(2)),(F(1),F(1),F(2),F(3))]:
 j=len(weights);subsets=[frozenset(c)for k in range(j+1)for c in combinations(range(j),k)]
 values={s:sum((weights[i]for i in s),F(0))for s in subsets}
 for start in sorted(set(values.values())):
  fam={s for s in subsets if start<=values[s]<=start+F('.999')}
  assert sum((F(1,comb(j,len(s)))for s in fam),F(0))<=1;lym+=1
  for perm in permutations(range(j)):
   chain=[frozenset(perm[:k])for k in range(j+1)]
   assert len(fam.intersection(chain))<=1;chains+=1
  for p in (F('.302'),F('.38'),F('.47'),F('.5')):
   assert sum((p**len(s)*(1-p)**(j-len(s))for s in fam),F(0))<=mode(j,p);checks+=1
# Negative control: weakening strict width to <=c is false.
assert concentration({F(0):F('.6'),F(1):F('.4')},F(1))>mode(1,F('.4'))
# Exact finite checks of the uniform Stirling-derived cap, beyond selected scope.
modechecks=0
for J,l,h in [(45,F('.38'),F('.47')),(53,F('.318'),F('.466')),(45,F('.302'),F('.38'))]:
 a=l-(1-l)/J;b=h+h/J;v=min(a*(1-a),b*(1-b));bound2=F('.16')/(v*(1-F(1,12*J))**2)
 assert 0<a<=b<1
 for j in range(J,151):
  for p in (l,(l+h)/2,h):
   m=mode(j,p);assert j*m*m<bound2;modechecks+=1
print(json.dumps(dict(status='PASS_EXACT_SPERNNER_CONTROLS',laws=len(laws),probability_checks=checks,collision_checks=collisions,LYM_checks=lym,chain_checks=chains,mode_checks=modechecks,negative_controls=1,source_sha256=sha256(Path(__file__).read_bytes()).hexdigest()),indent=2))
