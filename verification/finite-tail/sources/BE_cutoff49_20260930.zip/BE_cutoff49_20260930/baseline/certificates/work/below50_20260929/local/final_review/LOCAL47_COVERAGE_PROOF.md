# Exact coverage of the selected local comparison

This note proves the domain-composition step. It does not replace the analytic proofs of the selected inequalities, the actual-law acquisition, or their exact arithmetic acceptors.

## Statement

Assume the acquired index-47 interfaces and the selected local theorems. The 38 left probability panels [.304,.380] and 45 central panels [.380,.470] cover every acquired probability value. For each actual panel, every noise value `0 < lambda <= Lambda` and every nearest phase `-1/2 <= u <= 1/2` is covered by at least one selected comparison proving the noisy score smaller than the matching Bernoulli score. At `lambda=0`, the law is exactly its Bernoulli label law and the cited Bernoulli theorem applies directly.

The comparison statements hold from index47. Their use in the proposed global descent concerns the finite range47..98, with the prior cutoff99 theorem covering the tail. This note makes no new global-cutoff claim by itself.

## Selected partition

| Side | Noise interval | LOW phase region | MID phase region |
|---|---|---|---|
| Both | `(0,.05]` | Full-phase TINY47_WIDE_A | — |
| Central | `[.05,.06]` | `|u|<=.09` | `|u|>=.09` |
| Central | `[.06,.08]` | `|u|<=.13` | `|u|>=.13` |
| Central | `[.08,.10]` | `|u|<=.18` | `|u|>=.18` |
| Central | `[.10,.12]` | `|u|<=.29` | `|u|>=.29` |
| Central | `[.12,Lambda]` | All phases | — |
| Left | `[.05,.06]` | `|u|<=.09` | `|u|>=.09` |
| Left | `[.06,.08]` | `|u|<=.14` | `|u|>=.14` |
| Left | `[.08,.10]` | `|u|<=.19` | `|u|>=.19` |
| Left | `[.10,.12]` | `|u|<=.29`, plus positive LOW `[.29,.5]` | `u<=-.29` |
| Left | `[.12,Lambda]` | All phases | — |

Intersect every row with the acquired panel ceiling. Internal shared noise/phase boundaries belong to both neighboring closed regions. In the fourth left row, the extra positive LOW theorem is essential: LEFT_MID47_B asserts only the negative phase there.

## Why the executable coverage test is exhaustive

For a fixed probability panel, let the finite family of closed noise/phase rectangles be the ones supplied by these selected contracts. Take all their noise endpoints, together with0 and Lambda; similarly take all phase endpoints, together with−1/2 and1/2. Each coordinate interval decomposes into singleton endpoints and the intervening open intervals. Membership in any closed rectangle is constant on each product of two such pieces. An exact endpoint, or the rational midpoint of an open interval, is therefore a logically complete representative of that piece.

Consequently, checking rectangle membership for every pair of these exact representatives proves coverage of the full continuum. This is a finite partition argument, not a positivity claim inferred from samples. The checker also rejects missing positive phases, an interior noise gap, an interior phase gap and an omitted upper noise endpoint.

## Interface and amplitude checks

The checker reads the selected input tables and contracts rather than repeating rounded maxima. It checks every wide-TINY premise against each acquired row: probability endpoints, both signed phase ceilings, noise fraction, inward displacement and global confined amplitude. For central MID it similarly verifies the global scalar premises. Left MID uses its separately checked per-panel finite normalizations.

For every positive-noise interval it checks that the required amplitude is licensed by the minimum of the panel's global confinement and its noise profile. At a profile seam, both adjacent conclusions hold. It verifies the two signs of H separately in each LOW contract, even though their geometric phase domains agree.

Central feedback strengthens all scalar moment and geometry bounds of the original canonical table. The exact checker verifies this componentwise, including the lower endpoint bounds and upper amplitude. It does **not** assume that corner quadratic coefficients are componentwise ordered. Original and refined budget inequalities both apply to the same acquired law through their separately proved, acyclic acquisition chains. LOW uses the selected refined resource; the original confinement retains its original resource.

The left table used locally is checked byte-for-byte against the acquired entry table. The p=.380 boundary is shared by the two complete probability covers.

## Empty-budget cells and source binding

Each selected LOW object covers its ordered probability rows and both H signs. The checker verifies that feasible cells plus cells excluded by the strict common budget equal the complete prescribed product cover, and that each feasible cell has both noise endpoints checked. An entirely excluded row has no actual-law domain left; its maximum score is appropriately unavailable. No fabricated numerical maximum or strict-score test is required for such a row.

The output records hashes of the exact tables, contracts, selected proof objects and this checker. These hashes bind the coverage audit to the selected bytes. Fresh exact arithmetic acceptance and independent mathematical review are separate evidence; hashes alone prove neither.

## Dependency order

1. The anchor/propagation and slow-decrement alternative supply the finite-index score bounds and actual-law entry hypotheses.
2. Actual-law entry, support contraction and direct contact strips acquire the left and central interfaces.
3. Original confinement and its feedback refinements acquire global amplitudes; strict-gap concentration and the accepted profiles acquire the smaller noise-dependent amplitudes.
4. Wide TINY, central MID/LOW, left MID, phase-sensitive left LOW and positive left LOW prove the score comparisons on their stated regions.
5. The exact partition above joins those regions. At zero noise, conditional centering and `E U^2=0` imply `U=0` almost surely, so the cited Bernoulli theorem applies directly.
6. The coordinator's separate finite-index descent joins the local theorem to the prior cutoff99 tail.
