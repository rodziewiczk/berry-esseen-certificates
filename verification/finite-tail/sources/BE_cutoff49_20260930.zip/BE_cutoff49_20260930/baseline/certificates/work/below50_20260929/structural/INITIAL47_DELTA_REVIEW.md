# Independent delta audit: INITIAL47 full-probability export

Read the exact diff between frozen signed_core.py and local_signed_core.py,
the complete new local module, fixed accept_initial47.py and its proof object.
The signed-moment and raw-budget algebra is unchanged from the earlier
reviewed signed core. The changes install the separately reviewed
HIGH_WINDOW50 for both high-frequency event branches and export raw/defect,
sign probability, centered conditional variance and phase bounds.

For fixed h=|H|, the endpoint expression is B(C)+L(C)h-q(C)h².
B is affine in C, q (including the conserved-phase increment) is affine in C,
and L is the maximum of absolute affine functions plus a fixed nonnegative
slope. Therefore the expression is convex in C. Its maximum over the current
closed score interval occurs at an endpoint. At each endpoint q>0 and L>=0.
Replacing B by max(0,B), using an upper square root and solving the positive
quadratic root gives a valid upper bound on h. A negative B is never used
with an incorrect outward sign; replacing it by zero only weakens the bound.
This proves the new cellH formula for both orientations of H. The nonnegative
barrier charge was omitted in that root, which is also conservative (and the
selected barrier is zero).

Let m=EXplus=EXminus and beta=EX|X|. Signwise second-moment Cauchy gives
p>=2m²/(1+beta), p<=1-2m²/(1-beta). Replacing m by its cell lower bound and
beta by the appropriate endpoint gives exactly the new pl,pu directions.
Both endpoints are in(0,1). Every one of the100 closed p-cells is intersected
with that interval, and equality ll==uu is retained, so singleton boundaries
are included. The conditional variance identity is theta=1-m²/[p(1-p)].
The maximum of p(1-p) on each closed intersection occurs at an endpoint or
at1/2 when present. This gives the implemented theta upper bound; clipping
it to zero is conservative even for an infeasible cell.

The final acceptor checks d<sqrt(10)_lower-1 before exporting empty cells as
actual p-exclusions, so every potential final witness is in the gap branch.
Every source moment cell has its rho/beta ceilings propagated to all p-cells
it touches. It validates exact panel incidence counts, the complete ordered
100-cell cover, and outward targets for every exported quantity. Cells whose
conserved budget is negative are impossible; counting them conservatively in
an export cannot discard a genuine witness.

Although the configuration uses nmax=98, its barrier K=0 makes K/nmax vanish
identically. There is no upper-index dependence in these new formulas.
The all-n conclusions inherit the already proved uniform signed/HIGH bounds
at the floor47. A uniform theta bound is exported; no n*theta bound is claimed
by this new export code. Weighted resource bounds need their own documented
retention from the original common budget.

No defect found in these changes or the fixed coverage/target validation.
This note is an analytical/code delta audit, not an assertion that the ongoing
fresh fixed acceptance has finished, nor a completed cutoff theorem.
