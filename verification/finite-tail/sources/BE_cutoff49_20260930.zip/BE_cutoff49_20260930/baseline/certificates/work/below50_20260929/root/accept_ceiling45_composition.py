"""Fixed scalar interfaces; dependency replay and analytic proof are separate.

This checks hashes and genuine recorded successful executions, not just a
printed PASS. It deliberately does not describe hash checking as a fresh
re-execution of a dependency or as a proof of an analytic reduction.
"""
from fractions import Fraction as F
from pathlib import Path
import copy, hashlib, json, sys
from accept_predecessor_score_cap import cap

assert __debug__ and not sys.flags.optimize
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]


def need(v, message):
    if not v:
        raise ValueError(message)


def scalars(floor=45, local_floor=95, cutoff=98):
    need((floor, local_floor, cutoff) == (45, 95, 98), 'fixed theorem scope')
    ce, old, new, loss = F('.40974'), F('1.5'), F('.7'), F('.19')
    need(ce + old/45 < F('.4431'), 'anchor own cap')
    need(45*old/44-new < F('.8341'), 'anchor decrement')
    need(cap(46, new) < F('.432'), 'propagation current cap')
    need(all(new/F(n-1) <= new/45 for n in range(46, 99)),
         'complete finite propagation decrement band')
    need(ce+new/45 < F('.4253'), 'three caps from47')
    need(ce+new/95 < F('.41719'), 'ENTRY95 current cap')
    need(ce+new/93 < F('.418'), 'LOCAL95 two deleted caps')
    reserve98 = loss*sum((F(1,n) for n in range(95,99)), F(0))-new/94
    reserve50 = loss*sum((F(1,n) for n in range(47,51)), F(0))-new/46
    need(reserve98 > 0 and reserve50 > 0, 'strict four-step reserves')
    need(loss*sum((F(1,n) for n in range(96,99)), F(0)) < new/95,
         'three steps do not close: negative control')
    return dict(cutoff98_reserve=str(reserve98),
                hypothetical_cutoff50_reserve=str(reserve50))


def dependencies(doc):
    need(type(doc) is dict and set(doc) == {'schema','files','executions'},
         'exact manifest fields')
    need(doc['schema'] == 'CEILING45_COMPOSITION_V1', 'fixed manifest schema')
    expected = json.loads((HERE/'ceiling45_dependencies.json').read_text())
    need(doc == expected, 'fixed complete dependency list')
    for rel, digest in doc['files'].items():
        need(hashlib.sha256((PROJECT/rel).read_bytes()).hexdigest() == digest,
             'dependency bytes: '+rel)
    for rel in doc['executions']:
        base = PROJECT/rel
        meta = json.loads((base/'metadata.json').read_text())
        if 'jobs' in meta:
            need(meta['status'] == 'PASS_CUTOFF99_SUITE' and len(meta['jobs']) == 21,
                 'complete earlier suite')
            records = [(row['name']+'.', row) for row in meta['jobs']]
        else:
            records = [('', meta)]
        for prefix, row in records:
            need(row['returncode'] == 0, 'dependency execution return code')
            for stream in ('stdout','stderr'):
                need(hashlib.sha256((base/(prefix+stream+'.txt')).read_bytes()).hexdigest()
                     == row[stream+'_sha256'], 'recorded stream integrity')
    return len(doc['files']), len(doc['executions'])


def main():
    need(len(sys.argv) == 1, 'no target overrides')
    doc = json.loads((HERE/'ceiling45_dependencies.json').read_text())
    nfiles, nruns = dependencies(doc)
    out = scalars()
    rejected = 1  # substantive three-step obstruction above
    for args in [(44,95,98),(45,94,98),(45,95,97),(45,47,50)]:
        try:
            scalars(*args)
        except ValueError:
            rejected += 1
        else:
            raise AssertionError('changed theorem accepted')
    for mutation in ['missing','duplicate','changed_hash']:
        bad = copy.deepcopy(doc)
        if mutation == 'missing':
            bad['executions'].pop()
        elif mutation == 'duplicate':
            bad['executions'].append(bad['executions'][0])
        else:
            bad['files'][next(iter(bad['files']))] = '0'*64
        try:
            dependencies(bad)
        except ValueError:
            rejected += 1
        else:
            raise AssertionError('mutated dependency list accepted')
    out.update(status='PASS_CEILING45_AND_CUTOFF98_SCALAR_COMPOSITION',
        mathematical_status='Analytic composition in ceiling45_and_cutoff98.tex; each analytic dependency remains separately required.',
        execution_status='Fresh scalar and dependency-integrity PASS; underlying named executions are verified existing fresh runs, not rerun by this checker.',
        cutoff50_status='Not proved: unrestricted entry and local47 remain missing.',
        dependency_files=nfiles, verified_prior_executions=nruns,
        negative_controls=rejected, actual_interpreter=sys.version)
    print(json.dumps(out,indent=2))


if __name__ == '__main__':
    main()
