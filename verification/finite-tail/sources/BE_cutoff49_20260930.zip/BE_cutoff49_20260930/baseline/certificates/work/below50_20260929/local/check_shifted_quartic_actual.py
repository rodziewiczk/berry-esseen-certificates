"""Independent exact controls of both shifted quartic own-count inequalities."""
from fractions import Fraction as F
from collections import defaultdict
import json,sys
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
def two(a,b):
 a,b=F(a),F(b);return {-a:b/(a+b),b:a/(a+b)}
def conv(a,b):
 out=defaultdict(F)
 for x,p in a.items():
  for y,q in b.items():out[x+y]+=p*q
 return dict(out)
zero={F(0):F(1)}
laws=[zero,two('.4','.001'),two('.001','.4'),two('.4',F(1,10**9)),two(F(1,10**9),'.4'),two('.4','.4'),{-F('.4'):F(1,100),F(0):F(59,100),F('.01'):F(2,5)}]
K=F(9)/(4*F('.4641'));moment=pointwise=near=collision=0
for law in laws:
 assert sum(law.values())==1 and sum(x*p for x,p in law.items())==0
 A=max(abs(x)for x in law);W=zero
 for n in range(1,7):
  W=conv(W,law);t=sum(x*x*p for x,p in W.items());third=sum(x**3*p for x,p in W.items());fourth=sum(x**4*p for x,p in W.items())
  assert abs(third)<=A*t and fourth<=A*A*t+3*t*t
  for a in map(F,('.1','.25','.5','1')):
   den=K*a**4
   rs={F(0),F('.001'),F('.02'),F('.05'),F('.1'),F('.5')}
   rs.update(abs(x)for x in W if abs(x)<=F('.5'))
   for r in rs:
    for sign in(-1,1):
     exact=(-fourth-4*sign*r*third-6*r*r*t-r**4+3*a*a*(t+r*r)+2*a**3*sign*r)/den
     relaxed=(-A*A*t-3*t*t-4*r*A*t-6*r*r*t-r**4+3*a*a*(t+r*r)+2*a**3*sign*r)/den
     actual=sum(p for x,p in W.items()if x+sign*r>0)
     assert relaxed<=exact<=actual
     moment+=1;collision+=(-sign*r in W)
     for x in W:
      y=x+sign*r;poly=(-y**4+3*a*a*y*y+2*a**3*y)/den
      assert poly<=(1 if y>0 else 0);pointwise+=1
   if t==0:continue
   for factor in(F(1),F('1.1'),F(2)):
    ts=factor*t;c0=(3*a*a-A*A-3*ts)/den
    for z in map(F,('0','.1','.5','1','1.5','2')):
     r=z*t
     for sign in(-1,1):
      Q=c0+(2*a**3*sign-4*A*ts)*z/den-6*ts*ts*z*z/den-ts**3*z**4/den
      lower=(-A*A*t-3*t*t-4*r*A*t-6*r*r*t-r**4+3*a*a*(t+r*r)+2*a**3*sign*r)/(den*t)
      assert Q<=lower
      near+=1
print(json.dumps(dict(status='PASS_EXACT_SHIFTED_QUARTIC_ACTUAL_CONTROLS',laws=len(laws),moment_bounds=moment,
 pointwise_bounds=pointwise,variance_uniform_bounds=near,collision_cases=collision,
 scope='Finite actual-law tests of both signs and all-variance algebra; continuum proof is separate.')))
