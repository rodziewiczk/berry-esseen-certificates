"""Fixed exact phase-resolved left LOW47 acceptance."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import sys,json
from phase_left_low47_contract import read as inputs,selected,SOURCE
from phase_left_low47_kernel import evaluate
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
HERE=Path(__file__).resolve().parent
NAME='phase_left_low47_constructed01.json'
SHA='13aad768ba5f8d543d74fd74ae282b4a1ad689c62bffe1f62ed1267f58db1321'
SCHEMA='CONDITIONAL_PHASE_LEFT_LOW47_V1'
LOWER=F('.05')
EXPECTED=(66,15125118,136048,159376)
def need(ok,s):
    if not ok:raise ValueError(s)
def unique(items):
    d={}
    for k,v in items:need(k not in d,'Duplicate JSON key');d[k]=v
    return d
def read(blob):
    need(sha256(blob).hexdigest()==SHA,'Fixed named proof object')
    d=json.loads(blob,object_pairs_hook=unique);need(d['schema']==SCHEMA,'Named theorem')
    expected=[(r['index'],s)for r in inputs()if F(r['lambda_max'])>LOWER for s in(-1,1)]
    need([(r['index'],r['sign'])for r in d['rows']]==expected,'Complete signed row coverage')
    return d
def controls(blob):
    passed=0
    for name in ['missing','duplicate','reorder','sign','floor','amplitude','noise','hash','feasible','excluded','false_empty']:
        d=json.loads(blob)
        if name=='missing':d['rows'].pop()
        elif name=='duplicate':d['rows'].append(d['rows'][0])
        elif name=='reorder':d['rows'].reverse()
        elif name=='sign':d['rows'][0]['sign']=1
        elif name in('floor','amplitude','noise'):
            key={'floor':'N','amplitude':'amplitude','noise':'noise'}[name];d['rows'][0]['proof']['contract'][key]='0'
        elif name=='hash':d['rows'][0]['report']['gate_sha256']='0'*64
        elif name=='false_empty':d['rows'][-1]['report']['feasible_cells']=0
        else:d['rows'][-1]['report'][name+'_cells']=-1
        try:read(json.dumps(d).encode())
        except ValueError:passed+=1
        else:raise AssertionError('Changed proof accepted')
    try:unique([('schema',1),('schema',2)])
    except ValueError:passed+=1
    else:raise AssertionError('Duplicate key accepted')
    for r in inputs():
        if F(r['lambda_max'])<=LOWER:
            try:selected(r,-1)
            except (AssertionError,ValueError):passed+=1
            else:raise AssertionError('Artificial noise interval beyond acquired ceiling')
            break
    return passed
def main():
    need(len(sys.argv)==1,'No target overrides')
    path=HERE/NAME;blob=path.read_bytes();d=read(blob);table=inputs()
    gates=feasible=excluded=emptyrows=0;worst=None;digest=sha256()
    for row in d['rows']:
        cfg=selected(table[row['index']],row['sign']);bands=cfg['noise_intervals']
        need(bands[0][0]==LOWER and bands[-1][1]==cfg['maxnoise'],'Complete noise scope')
        for j,(l,h,a)in enumerate(bands):
            need(LOWER<=l<h<=cfg['maxnoise']and h-l<=F(1,400),'Closed noise cell')
            if j:need(bands[j-1][1]==l,'Noise seam')
        p,r=evaluate(cfg)
        actual=json.loads(json.dumps(dict(index=row['index'],sign=row['sign'],proof=p,report=r),default=str))
        need(actual==row,'Exact fresh arithmetic replay')
        total=cfg['p_cells']*cfg['H_cells']*len(bands)*cfg['outer_phase_cells']
        need(r['feasible_cells']+r['empty_cells']==total,'Full phase/noise cover')
        if r['feasible_cells']==0:
            need(r['empty_cells']==total and r['endpoints']==0 and r['worst_score']=='None','Entire row excluded by strict resource');emptyrows+=1
        else:
            need(r['endpoints']==2*r['feasible_cells'],'Both noise endpoints')
            score=F(r['worst_score']);worst=score if worst is None else max(worst,score)
        gates+=r['gates'];feasible+=r['feasible_cells'];excluded+=r['empty_cells'];digest.update(r['gate_sha256'].encode())
        print(json.dumps(dict(index=row['index'],sign=row['sign'],status='PASS')),flush=True)
    need((len(d['rows']),gates,feasible,excluded)==EXPECTED,'Complete fixed cover counts')
    files=[Path(__file__),HERE/'phase_left_low47_contract.py',HERE/'phase_left_low47_kernel.py',HERE/'low47_normalization.py',HERE/'low47_kernel.py',path,SOURCE,
      HERE.parent/'local/left_sperner47_contract.py',HERE.parent/'local/left_sperner47_certificate.json',HERE.parent/'local/left_sperner47_profile_certificate.json']
    print(json.dumps(dict(status='PASS_EXACT_PHASE_LEFT_LOW47',
        theorem='On acquired left270 panels, n>=47,.05<=lambda<=Lambda and the selected closed nearest-phase envelope imply rho_B(C-C_B)<-.001lambda.',
        mathematical_status='Conditional same-law comparison; entry, confinement, normalization and whole-count lemmas are explicit dependencies.',
        rows=len(d['rows']),gates=gates,feasible_cells=feasible,excluded_cells=excluded,entirely_excluded_rows=emptyrows,
        controls=controls(blob),worst_score=str(worst),worst_decimal=float(worst),gate_sha256=digest.hexdigest(),interpreter=sys.version,
        source_sha256={str(p.relative_to(HERE.parent)):sha256(p.read_bytes()).hexdigest()for p in files}),indent=2))
if __name__=='__main__':main()
