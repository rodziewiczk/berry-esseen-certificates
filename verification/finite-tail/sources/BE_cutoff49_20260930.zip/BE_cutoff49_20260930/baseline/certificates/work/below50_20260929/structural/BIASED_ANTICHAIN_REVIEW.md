# A biased antichain concentration bound for the actual labeled law

**Mathematical status:** independently derived finite lemma. **Execution
status:** no numerical mode bound or confinement acceptance is asserted here.

Let Y=U0+B(1+U1-U0), with B Bernoulli(p), independent of a coupling of the
actual conditional noises U0,U1. Suppose U0<=a, U1>=-(d-a), and c=1-d>0.
For j independent copies and every interval I of diameter w<c,

    P(sum_{i=1}^j Y_i in I) <= max_{0<=k<=j} binom(j,k)p^k(1-p)^(j-k).

The interval may be closed; atoms at either endpoint are allowed. The same
bound holds after adding an independent random variable to the sum.

## Proof without a cited combinatorial input

Choose independent noise pairs across coordinates, independent of all j
labels. Each coordinate has exactly the specified actual Y marginal. After
conditioning on all pairs, the sum is a fixed base plus the subset sum of
steps ci=1+U1_i-U0_i>=c. If S is a proper subset of T, their sums differ by
at least c>w, so the subsets whose sums fall in I form an antichain F.

Take a uniformly random permutation of the j coordinates and its chain of
prefix subsets. Each fixed subset S appears with probability
|S|!(j-|S|)!/j!=1/binom(j,|S|). A chain contains at most one member of F.
Taking expectations yields

    sum_{S in F} 1/binom(j,|S|) <=1.

For independent Bernoulli(p) labels the conditional interval probability is
sum_{S in F} p^|S|(1-p)^(j-|S|). Grouping by |S| expresses this as a
nonnegative combination of the binomial level masses, with coefficient sum
at most1. This proves the bound, independently of the conditioned noise
pairs. Integrating removes the conditioning. Conditioning on an additional
independent summand proves the convolution statement. Degenerate p=0,1
are immediate with mode mass1; j=0 likewise has the trivial bound1.

## Necessary scope restrictions

The strict width condition cannot be replaced by w<=c for closed intervals:
a single deterministic step c and interval[0,c] contain both label outcomes,
so their probability1 exceeds max(p,1-p) for0<p<1. Open/half-open conventions
can admit equality in some cases, but the selected closed-interval theorem
uses w<c throughout and needs an exact positive width reserve.

For a deleted or marked law, j counts only the Bernoulli labels remaining
random after conditioning. If a residual law has m iid Y summands, use mode
m. A common background with m-1 iid Y plus an independent conditional U
licenses mode m-1; the sharper mode m must not be substituted.

An unbounded lower-ray extension cannot retain the single-mode cap after its
interval width reaches c. Either keep the previously proved affine
concentration extension, or restrict the ray parameter to the already
acquired finite Y strip and prove every relevant interval width remains<c
on that entire finite range. For general larger widths, partition the
interval into finitely many pieces of diameter strictly below c and sum the
individual mode caps; this is a different bound and requires its own seam.
The lemma supplies a new concentration input, not automatically a stronger
confinement theorem or any acquisition of gap endpoints.
