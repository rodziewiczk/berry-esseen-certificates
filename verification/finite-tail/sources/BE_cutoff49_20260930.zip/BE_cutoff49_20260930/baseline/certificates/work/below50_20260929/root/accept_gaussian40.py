"""Fixed conditional Gaussian40; exact rational reconstruction, not a cutoff.

Analytic expansion and contact identity are stated in gaussian_exterior40.tex.
"""
from gaussian_core import F, coefficient, bernstein
from pathlib import Path
import hashlib,json,sys
assert __debug__ and not sys.flags.optimize
N=40;H=F('1.15');RHO=F('1.14');CAP=F('.45');PRED=F('1.155')

def tail(r):
    e=F(193,71);ceil=lambda x:-((-x.numerator)//x.denominator)
    return 4**7*((H+r)*F(7,6)*e**ceil((H+r)**2/6)
           +(H+r+H*(r*r+1)/8)*e**ceil(H*H/8))

def abs_poly(p,r):return sum(abs(c)*H**a*r**b for (a,b),c in p.items())
def bounds(P,l,r):
    return [max(F(0),max(bernstein(P[j],(-H,H),(l,r)))) for j in range(1,4)]+[abs_poly(P[j],max(abs(l),abs(r))) for j in (4,5)]
def ray_coeff(sign):
    return (F(1,15)-F('.4095') if sign==1 else-F('.3988')/6-F('.4095'),
            F('1.5')*F('.40974')*RHO,
            3*F('.40974')*F('.3')-F('.3988')/2 if sign==1 else F('.2')-3*F('.4095')*F('.075'))
def cubic(a,b,c,u):return a*u**3+b*u*u+c*u

def build():
    P=[coefficient(j)for j in range(6)]
    assert P[0]=={(0,1):F(-1,2),(0,3):F(1,6)}
    assert P[1]=={(2,1):F(3,4),(2,3):F(-1,4),(1,4):F(1,8),(1,2):F(-3,4),(1,0):F(3,8),(0,5):F(-1,40),(0,3):F(1,4),(0,1):F(-3,8)}
    assert PRED**2>RHO**2*F(N,N-1)
    # e_n<.384/n from36, checked without taking an unrounded square root.
    x=F(1,36);k=F('.384')
    assert (2*k-F(3,4))-(k+F(1,4))*x+(k*k-k)*x*x-k*k*x**3>0
    outer=[]
    for sign,start in [(1,F('2.5')),(-1,F('1.9'))]:
        a,b,c=ray_coeff(sign);beta=F('.3')if sign==1 else-F('.075')
        for aa,bb,cc in [(a,b,c),(-1,F('1.5')*RHO,3*beta)]:
            assert cubic(aa,bb,cc,start)<0
            assert 3*aa*start**2+2*bb*start+cc<0
            assert 6*aa*start+2*bb<0 and aa<0
        for j in range(int(20*start),82):
            l=F(j,20);r=l+F(1,20)
            ms=bounds(P,l,r)if sign==1 else bounds(P,-r,-l)
            err=F('.4')*(sum(ms[j-1]/N**j for j in range(1,6))+tail(r)/N**6)
            margin=-cubic(a,b,c,l)-PRED*F('.4')-RHO*F('.384')*CAP/N-err
            assert margin>0,('outer',sign,str(l),str(margin))
            outer.append(dict(sign=sign,interval=list(map(str,[l,r])),reserve=str(margin)))
    # Prove the contact on the larger closed interval[-2,2.5].
    # (3t-t^3)/4<=1/2 since(t-1)^2(t+2)>=0.
    # H4=(t^2-3)^2-6 lies in[-6,6] on that interval.
    assert (F('2.5')**2-3)**2-6<6
    inner=[];highermax=[F(0)]*4;maxc=F(0)
    constant={(0,5):F(-1,40),(0,3):F(1,4),(0,1):F(-3,8)}
    for j in range(-40,50):
        l=F(j,20);r=l+F(1,20);ms=bounds(P,l,r)
        for k in range(2,6):highermax[k-2]=max(highermax[k-2],ms[k-1])
        maxc=max(maxc,max(bernstein(constant,(F(0),F(0)),(l,r))))
        ul,ur=(l,r)if l>=0 else(-r,-l)
        assert max(bernstein({(0,3):F(-1),(0,2):F('1.71'),(0,1):F('.9')},(F(0),F(0)),(ul,ur)))<2
        inner.append(list(map(str,[l,r])))
    higher=F('.4')*(sum(highermax[j-2]/N**(j-1)for j in range(2,6))+tail(F('2.5'))/N**5)
    const=F('.4')*maxc+higher+RHO*F('.384')*CAP
    assert const<F('.46'),('inner',str(const))
    assert len(outer)==76 and len(inner)==90
    return dict(version='CONDITIONAL_GAUSSIAN40_V1',n_floor=N,
         hypotheses=dict(prior_support=['-4.1','4.1'],rho='1.14',beta=['.075','.3'],
                          C=['CE','.45'],H='1.15',decrement='.4'),
         conclusion=dict(support=['-1.9','2.5'],contact='L_P+(.2H^2+.3|H|+.46)/n+2a+1.155d_n>0'),
         outer=outer,inner=inner,higher_charge=str(higher),constant_charge=str(const))

if __name__=='__main__':
    assert len(sys.argv)==1
    obj=build()
    a,b,c=ray_coeff(1)
    assert -cubic(a,b,c,F('2.3'))-PRED*F('.4')<0
    assert F(obj['constant_charge'])>F('.45')
    print(json.dumps(dict(status='PASS_CONDITIONAL_GAUSSIAN40',proof=obj,
          negative_controls=['false_support_2.3','false_contact_constant_.45'],
          source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in
                         [Path(__file__),Path(__file__).with_name('gaussian_core.py')]},
          scope='Analytic Gaussian expansion and contact identity required. No entry premise or cutoff asserted.'),indent=2))
