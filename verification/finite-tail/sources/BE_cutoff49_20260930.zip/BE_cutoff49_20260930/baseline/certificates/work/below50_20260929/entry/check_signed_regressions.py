#!/usr/bin/env python3
"""Exact checks of signed interval multiplication, including negative maxima."""
from fractions import Fraction as F
import json

def P1(a,b):return b**3/3+a*b*b/2-a**3/6
# Feasible standardized binary law, within D<2 and the actual gap gate.
a,b,m=F(3,2),F(2,3),F(6,13);pp,qq=F(9,13),F(4,13)
assert pp*b-qq*a==0 and pp*b*b+qq*a*a==1
v=P1(a,b);assert v==F(-169,1296)
ml,mu=F(23,50),F(1,2)
old=mu*v;fixed=ml*v;actual=m*v
assert actual==F(-13,216) and old<actual<=fixed
rho=F(97,78);sigmaLo=F(3162277660,10**9);sigmaHi=F(3162277661,10**9)
assert (97*sigmaHi-151)/78<2<(sigmaLo-1)*rho
# A generic maximum of the central cubic must use the corresponding mean
# endpoint. All values below range over exact complete corner enclosures.
checks=0
for v in (F(-10),F(-1),F(0),F(1),F(10)):
 upper=v*(mu if v>=0 else ml);lower=v*(ml if v>=0 else mu)
 for mm in (ml,m,mu):assert lower<=mm*v<=upper;checks+=1
print(json.dumps(dict(status='FRESH_PASS',actual_binary_negative_maximum=str(P1(a,b)),checks=checks,old_bound_rejected=True)))
