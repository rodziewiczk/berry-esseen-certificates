"""Frozen whole-count LOCAL95B LOW arithmetic reduction.

This reconstructs the declared closed domain and proves every endpoint gate.
The generic count reduction and the three new steps are proved in low95b_proof.tex.
Confinement, normalization, and tiny/MID companions are separate INPUT95B dependencies.
"""
from fractions import Fraction as F
from math import isqrt
import hashlib, json, sys
if sys.flags.optimize or not __debug__:
    raise RuntimeError('Optimized Python is forbidden')

CONTRACT = {
    'schema':'WHOLE_COUNT_LOCAL95_B_V1','N':95,'T':'3/4',
    'p':['7/20','23/50'],'H':'23/20','D':'117/1000','theta':'17/2000',
    'd0':'3/250','noise':['13/500','1/5'],'p_cells':32,'H_cells':32,
    'phase_cells':64,'noise_bands':70,
    'phase_radii':['1/25','9/100','13/100','9/50','1/4','1/2'],
    'mass_floor':'3843/5000','amplitude':'3/10','score_target':'-1/1000',
    'root_grid':1000000,
}

def rootlo(x):
    if x < 0: raise ValueError('negative radicand')
    return F(isqrt(x.numerator*10**12//x.denominator),10**6)

def rootup(x):
    return rootlo(x)+F(1,10**6)

def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',',':')).encode()

def evaluate(cfg):
    pc=int(cfg.get("p_cells",16)); hc=int(cfg.get("H_cells",64)); a0=cfg.get("phase0",F(".14"))
    N=cfg["N"]; T=cfg["T"]; pl0=cfg["pl"]; pu0=cfg["pu"]
    theta=cfg['theta']; d0=cfg["d0"]; c=1-d0; amp=cfg['amplitude']
    mass=cfg["mass"]; H=cfg["H"]; maxnoise=cfg['maxnoise'];bands=int(cfg['bands'])
    failures={}
    contract={**CONTRACT,"schema":"WHOLE_COUNT_LOCAL95_B_V1","N":N,"T":str(T),"p":[str(pl0),str(pu0)],"H":str(H),"D":str(cfg["D"]),"d0":str(d0),"p_cells":pc,"H_cells":hc,"phase_radii":CONTRACT["phase_radii"],"mass_floor":str(mass),"constants":{k:str(v) for k,v in cfg.items() if type(v) in (int,F)}}
    choices=[]; gate_count=0; endpoint_count=0; empty_count=0
    digest=hashlib.sha256(); minima={}; maxima={}; phase_cache={}
    def gate(name,value):
        nonlocal gate_count
        value=F(value)
        if value<=0:
            raise ArithmeticError((name,str(value)))
        gate_count+=1
        group=name.split(':',1)[0]
        if group not in minima or value<minima[group]: minima[group]=value
        digest.update((name+'='+str(value)+'\n').encode())
    gate('c_domain_lower',c-F(1,2)); gate('c_domain_upper',1-c)
    gate('D_domain',cfg['D']) # D bound is an independent entry hypothesis.
    gate('midpoint_fourth_domain',F(5,2)*c-amp-F(1,2))
    gate('global_curvature_a',2-(pu0+H/cfg['elo']+F(1,2)))
    for pi in range(pc):
        pl=pl0+(pu0-pl0)*pi/pc; pu=pl0+(pu0-pl0)*(pi+1)/pc
        ell2=(1-theta)/(pu*(1-pu)); ell=rootlo(ell2)
        gate('ell_lower:'+str(pi),ell2-ell*ell)
        cv=1/pl; v=pl*(1-pl)
        cp=2*F('5.16')*(ell*(1-pu-d0))**2
        cm=2*F('7.16')*(ell*(pl-d0))**2
        mcell=rootlo((1-theta)*v)
        # NEW shared-shift identity: D >= m ell²[(6+2sqrt10)(p-pE)²
        # +6d(1-d)] + beta*theta. Both terms use one common iid marginal.
        al=6*mcell*ell**2*(1-d0)
        be=min(3*F('4.16')*ell*(1-pu-d0),3*F('6.16')*ell*(pl-d0))
        dist=max(F(0),F('.41886')-pu,pl-F('.41887'))
        pen=F('12.32455532')*mcell*ell**2*dist**2
        repair=cfg['repair_multiplier']*(6*pl-3*pl*pl-F('1.5')-d0-3*(1-2*v)*maxnoise/(8*v*N))
        gate('repair:'+str(pi),repair)
        for bi in range(bands):
            if 'noise_intervals'in cfg:low,high,a=cfg['noise_intervals'][bi]
            else:
                low=cfg['noise_start']+bi*cfg['noise_step']; high=low+cfg['noise_step']
                a=next(F(r)for end,r in cfg['phases'] if low<F(end))
            for hj in range(hc):
                key=f'{pi}:{bi}:{hj}'
                hl=H*hj/hc; hh=H*(hj+1)/hc; dd=hh/ell+a
                ownlo=1-cv*dd/N; ownhi=1+cv*dd/N
                budget=T
                if all(k in cfg for k in ("R_A","R_F","R_Q")):
                    qa,qf,qq=(cfg[k] for k in ("R_A","R_F","R_Q"))
                    gate("phase_quadratic:"+key,qq)
                    vertex=max(hl,min(hh,qf/(2*qq)))
                    budget=min(T,qa+qf*vertex-qq*vertex*vertex)
                cap=(15000*(budget-cfg['rebate']*hl*hl)/997-N*pen-be*ell*ell*low)/al
                if cap<=0:
                    empty_count+=1; digest.update(('empty:'+key+'='+str(cap)+'\n').encode()); continue
                gate('cap_monotonic:'+key,cv*N*low-cap*cap)
                gate('variance_lower:'+key,ownlo)
                t=ownhi*low; b1=c-amp; b2=2*c-amp
                # NEW endpoint maximum: F'(u) has the sign of
                # u*[4b²(b²+t)-(b²+t+u²)²].  If b>a and t<b²-a²,
                # this is positive on 0<u<=a. Convexity is unnecessary.
                gate('first_pair_monotone:'+key,b1*b1-a*a-t)
                gate('second_pair_monotone:'+key,b2*b2-a*a-t)
                finite_kernel=sum(1/((b-u)**2+t) for b in (b1,b2) for u in (a,-a))
                # All indices >=3: fourth moments, then convex midpoint sum.
                tail_kernel=(amp*amp+3*ownhi*high)*sum(1/(3*c*(F(5,2)*c-amp-u)**3) for u in (a,-a))
                kernel=finite_kernel+tail_kernel
                z=min(F('.849'),rootup(ownhi*kernel*cv*cap/(cv*N*low+cap*cap)))
                gate('mark_positive:'+key,z); gate('mark_upper:'+key,F('.85')-z)
                # Closed rational phase cells; each bound dominates the whole cell.
                cachekey=(pi,hj,a)
                if cachekey not in phase_cache:
                    b=pu+hh/ell; candidates=[]
                    for ui in range(64):
                        ul=-a+2*a*ui/64; uh=-a+2*a*(ui+1)/64
                        rising=max(F(0),b+uh-1)/(c-uh)**2
                        falling=max(F(0),b+uh)/(c+min(ul,c/3))**2
                        candidates.append(rising+falling)
                    phase_cache[cachekey]=max(candidates)
                third=rootup(amp*amp+3*ownhi*high)
                gate('third_root:'+key,third*third-amp*amp-3*ownhi*high)
                curvature=ownhi/v*(phase_cache[cachekey]+third/(2*c-F(1,2))**3)
                rate=cfg['rate']*ownlo
                gate('harmonic_domain:'+key,3-rate*high)
                gain=F(5,23)*(rate**3*low**2/6-rate**4*low**3/24+rate**5*low**4/120-rate**6*low**5/720)
                gate('harmonic_gain:'+key,gain)
                normal=cfg['ef']*((2*dd*a+a*a)/(2*v)+cfg['logder']*dd/2+cfg['remainder']+cfg['entropy']*dd**3/(6*N))
                for lam in (low,high):
                    suffix=key+':'+str(lam)
                    harmonic=F(5,23)*rate-F(5,46)*rate*rate*lam+gain
                    bracket=z+ownhi*kernel/z*cv*cap/(cv*N*lam+cap*cap)-harmonic
                    inv=curvature+cfg['normal_v']*a+normal*a/lam+cfg['repair_normal']*dd-repair
                    gate('negative_event:'+suffix,-bracket)
                    gate('inverse_n_positive:'+suffix,inv)
                    score=mass*bracket+inv/N
                    gate('strict_score:'+suffix,-F(1,1000)-score)
                    endpoint_count+=1
                    if 'score' not in maxima or score>maxima['score']: maxima['score']=score
                choices.append([pi,bi,hj,str(z)])
    if len(choices)*2!=endpoint_count or len(choices)+empty_count!=pc*bands*hc:
        raise ArithmeticError('incomplete closed cover')
    proof={'schema':contract['schema'],'contract':contract,'marks':choices}
    report={'status':'PASS_EXACT_WHOLE_COUNT_LOCAL95_B', 'failed_gates':failures,'gates':gate_count,
        'endpoints':endpoint_count,'feasible_cells':len(choices),'empty_cells':empty_count,
        'phase_envelope_cells':len(phase_cache)*64,'gate_sha256':digest.hexdigest(),
        'worst_score':str(maxima['score']),'worst_score_decimal':float(maxima['score']),
        'minimum_reserves':{k:str(v) for k,v in minima.items()},
        'scope':'Conditional LOW95B only; INPUT95B, whole-noise confinement, fixed normalization, generic actual-count reduction and direct companions are separate dependencies.'}
    return proof,report
