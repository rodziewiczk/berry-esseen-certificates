"""Fixed complete index covers: R3.84 at n>=36/q.19 and n>=40/q.20."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import copy,json,sys
import fifth_heat50 as H
import heat_support50 as B
assert __debug__ and not sys.flags.optimize
BANDS=[(36,39),(40,44),(45,49),(50,59),(60,89),(90,134),(135,199),(200,0)]
SPECS=[(36,F('.19'),BANDS),(40,F('.20'),BANDS[1:])]

def verify_cover(bands,start):
 assert bands and bands[0][0]==start and bands[-1][1]==0
 for j,(lo,hi)in enumerate(bands):
  assert type(lo)is int and type(hi)is int and lo>=36
  if j+1<len(bands):assert lo<=hi and hi+1==bands[j+1][0]
  else:assert hi==0

def main():
 assert len(sys.argv)==1
 targets=[]
 for n,q,bands in SPECS:
  verify_cover(bands,n)
  rows=[H.target(lo,hi,F(0),F('3.84'),q)for lo,hi in bands]
  targets.append({'floor':n,'decrement':str(q),'radius':'96/25','complete_integer_index_cover':bands,'rows':rows})
 negative=[]
 for name,mutate in [('index_gap',lambda x:x.pop(2)),('reordered_bands',lambda x:x.reverse()),
                     ('missing_infinite_tail',lambda x:x.pop()),('duplicate_band',lambda x:x.insert(1,x[0]))]:
  bad=copy.deepcopy(BANDS);mutate(bad)
  try:verify_cover(bad,36)
  except AssertionError:negative.append(name)
  else:raise AssertionError(('bad cover accepted',name))
 for name,args in [('excessive_decrement',(40,44,F(0),F('3.84'),F('.21'))),
                   ('false_radius',(40,44,F(0),F('3.8'),F('.19')))]:
  try:H.target(*args)
  except (AssertionError,ValueError):negative.append(name)
  else:raise AssertionError(('false target accepted',name))
 paths=[Path(__file__),Path(H.__file__),Path(B.__file__),Path(__file__).with_name('support50_proof.tex')]
 print(json.dumps({'status':'PASS_EXACT_ALL_INDEX_SUPPORT384_FROM36_V1','targets':targets,
                   'gates':sum(r['gates']for t in targets for r in t['rows']),
                   'negative_controls':negative,
                   'scope':'For every n>=36 (respectively40), attained positive closed C_n>=CE and d_n<=.19 (respectively.20) imply full actual support(-3.84,3.84), uniformly in all H. Finite contiguous index bands plus an independently certified infinite tail; no positive excess barrier or score cap.',
                   'input_sha256':{p.name:sha256(p.read_bytes()).hexdigest()for p in paths}},indent=2))
if __name__=='__main__':main()
