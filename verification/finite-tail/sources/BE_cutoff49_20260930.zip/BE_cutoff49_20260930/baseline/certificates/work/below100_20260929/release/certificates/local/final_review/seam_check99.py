"""Supplementary exact semantic seam check for the selected cutoff-99 chain.

This independently checks contracts, closed rectangular coverage and index
arithmetic. It does not execute or replace the component proof kernels, the
actual-law analytic reduction, attainment, or the retained STOP180 proof.
All supplied artifacts are read-only. No theorem parameter is adjustable.
"""
from fractions import Fraction as F
from pathlib import Path
import ast,copy,hashlib,json,sys
if sys.flags.optimize or not __debug__:raise RuntimeError('Unoptimized Python required')
BASE=Path(__file__).resolve().parents[2]
LOCAL=BASE/'local';ROOT=BASE/'root';ENTRY=BASE/'entry';STRUCT=BASE/'structural'
PROJECT=BASE.parents[1]
STOP=BASE/'stop'
if not STOP.is_dir():
 # Construction-workspace fallback only. The exported certificate layout
 # contains BASE/stop and never reads outside its own package.
 STOP=PROJECT/'work/below201_20260929/release/certificates/stop'
SOURCES={}
def need(b,msg):
 if not b:raise ValueError(msg)
def unique(rows):
 d={}
 for k,v in rows:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read(path):
 raw=path.read_bytes()
 try:key=str(path.relative_to(BASE))
 except ValueError:key='retained_source/'+str(path.relative_to(PROJECT))
 SOURCES[key]=hashlib.sha256(raw).hexdigest();return raw.decode()
def obj(path):return json.loads(read(path),object_pairs_hook=unique)
def literal(n):
 """Read only explicit rational contract expressions; never execute source."""
 if isinstance(n,ast.Constant):return n.value
 if isinstance(n,(ast.List,ast.Tuple)):return [literal(x)for x in n.elts]
 if isinstance(n,ast.Dict):return {literal(k):literal(v)for k,v in zip(n.keys,n.values)}
 if isinstance(n,ast.UnaryOp)and isinstance(n.op,ast.USub):return -literal(n.operand)
 if isinstance(n,ast.BinOp):
  a,b=literal(n.left),literal(n.right)
  if isinstance(n.op,ast.Add):return a+b
  if isinstance(n.op,ast.Sub):return a-b
  if isinstance(n.op,ast.Mult):return a*b
  if isinstance(n.op,ast.Div):return F(a)/F(b)
  if isinstance(n.op,ast.Pow):return a**b
 if isinstance(n,ast.Call)and isinstance(n.func,ast.Name):
  if n.func.id=='F':return F(*[literal(x)for x in n.args])
  if n.func.id=='dict'and not n.args:return {k.arg:literal(k.value)for k in n.keywords}
 raise ValueError('nonliteral contract syntax '+ast.dump(n))
def tree(path):return ast.parse(read(path),filename=str(path))
def assignment(t,name):
 found=[]
 for n in ast.walk(t):
  if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id==name for x in n.targets):found.append(n.value)
 need(len(found)==1,'unique assignment '+name);return literal(found[0])
def keyword(t,name):
 found=[n.value for n in ast.walk(t)if isinstance(n,ast.keyword)and n.arg==name]
 need(len(found)==1,'unique keyword '+name);return literal(found[0])
def top_keyword(t,name):
 found=[]
 for n in ast.walk(t):
  if isinstance(n,ast.Return)and isinstance(n.value,ast.Call):
   found += [k.value for k in n.value.keywords if k.arg==name]
 need(len(found)==1,'unique return keyword '+name);return literal(found[0])
def canonical(d):return {k:str(v)for k,v in d.items()}
def gather():
 read(Path(__file__).resolve())
 inp=tree(ENTRY/'accept_input95.py');chain=tree(ENTRY/'chain_core.py');entry_accept=tree(ENTRY/'accept_entry95.py')
 gaussian=tree(ROOT/'accept_gaussian95.py');exterior=tree(ROOT/'accept_exterior95b.py');heat=tree(STRUCT/'accept_heat_bridge95.py')
 cn=tree(LOCAL/'confinement95b_kernel.py');norm=tree(LOCAL/'normalization95b.py');rootnorm=tree(ROOT/'normalization95b.py')
 comp=tree(LOCAL/'companions95b_kernel.py');lowtree=tree(ROOT/'low95b_contract.py')
 support=tree(STRUCT/'uniform_support.py');adaptive=tree(STRUCT/'adaptive_support.py')
 for p in [ROOT/'low95b_kernel.py',ROOT/'low95b_proof.tex',LOCAL/'confinement95b_proof.tex',LOCAL/'normalization_companions95b_proof.tex',ENTRY/'entry95_proof.tex',STRUCT/'uniform_support.tex',STOP/'accept_stop180.py',STOP/'verify_seam.py',STOP/'exact_stop45_late58.py']:
  read(p)
 return {'input_contract':assignment(inp,'CONTRACT'),'input_upper':assignment(inp,'upper'),'input_lower':assignment(inp,'lower'),
  'entry_goals':assignment(entry_accept,'goals'),'entry_chains':obj(ENTRY/'entry_chains_v2.json'),
  'component_floors':dict(gaussian=assignment(gaussian,'N'),heat=top_keyword(heat,'floor'),exterior=top_keyword(exterior,'floor')),
  'profiles':assignment(chain,'PROFILES'),'gaussian':top_keyword(gaussian,'hypotheses'),'gaussian_output':top_keyword(gaussian,'conclusion'),
  'heat':top_keyword(heat,'hypotheses'),'heat_output':top_keyword(heat,'conclusion'),'exterior':top_keyword(exterior,'hypotheses'),
  'confinement':assignment(cn,'CFG'),'confinement_object':obj(LOCAL/'confinement95b_certificate.json'),
  'normalization':assignment(norm,'CFG'),'root_normalization':assignment(rootnorm,'CFG'),
  'regions':assignment(comp,'REGIONS'),'tiny':assignment(comp,'TINY'),'companions':obj(LOCAL/'companions95b_certificate.json'),
  'low':obj(ROOT/'low95b_certificate.json'),'low_raw':{k:keyword(lowtree,k)for k in ['R_A','R_F','R_Q']},
  'support_specs':assignment(support,'specs'),'adaptive_specs':assignment(adaptive,'specs'),
  'stop':obj(STOP/'stop180_certificate.json'),
  'selection':dict(anchor=94,local_floor=95,application_floor=96,cutoff=99,steps=4,barrier=F('.7'),loss=F('.19'))}
def verify(d):
 gates={};coverage=[]
 def check(name,b):need(b,name);gates[name]='true'
 def pos(name,x):check(name,x>0);gates[name]=str(x)
 inp=d['input_contract'];up=d['input_upper'];lo=d['input_lower'];p=d['profiles'];c=d['confinement'];norm=d['normalization'];sel=d['selection']
 check('ENTRY95_all_index_K_zero',p['ENTRY95']['barrier']==0 and p['ENTRY95']['n']==95)
 check('ENTRY_to_INPUT_score_cap',F(inp['cap'])==p['ENTRY95']['cap']==F('.41719'))
 check('ENTRY_to_INPUT_raw',F(inp['raw'])==F('.77'))
 check('ENTRY_to_INPUT_defect',F(inp['defect'])==F('.12'))
 entryrow=d['entry_chains']['profiles'][-1]
 check('selected_ENTRY_profile',entryrow['name']=='ENTRY95')
 check('ENTRY_final_raw_to_INPUT',F(entryrow['steps'][-1]['R'])<=F(inp['raw']))
 check('ENTRY_final_defect_to_INPUT',F(entryrow['steps'][-1]['D'])<=F(inp['defect']))
 heat=d['heat'];check('heat_all_thresholds',heat['threshold']=='all real H')
 check('heat_prior_radius',list(map(F,heat['prior_support']))==[-p['ENTRY95']['R'],p['ENTRY95']['R']])
 check('ENTRY_heat_moment_interface',F(heat['rho_upper'])>=d['entry_goals']['rho']and F(heat['beta_absolute_upper'])>=d['entry_goals']['beta'])
 check('heat_to_INPUT_radius',d['heat_output']=='The complete actual support is contained in(-2.5,2.5).'and F(inp['radius'])==F('2.5'))
 check('INPUT_uniform_index',inp['n']==c['N']==95)
 for name,floor in d['component_floors'].items():check('component_floor_'+name,floor==95)
 mapping={'R':'T','D':'D','H':'H','p_upper':'pu','rho':'rho','beta_upper':'beta_hi','theta':'theta'}
 for a,b in mapping.items():check('INPUT_confinement_upper_'+a,up[a]<=c[b])
 for a,b in {'p_lower':'pl','beta_lower':'beta_lo'}.items():check('INPUT_confinement_lower_'+a,lo[a]>=c[b])
 ga=d['gaussian'];ext=d['exterior']
 check('heat_support_fits_direct_Gaussian',F(inp['radius'])<=F(ga['prior_support'][1]))
 check('INPUT_Gaussian_phase',up['H']<=F(ga['H']))
 check('INPUT_Gaussian_rho',up['rho']<=F(ga['rho']))
 check('INPUT_Gaussian_beta',lo['beta_lower']>=F(ga['beta'][0])and up['beta_upper']<=F(ga['beta'][1]))
 check('Gaussian_exterior_support',list(map(F,d['gaussian_output']['support']))==list(map(F,ext['support'])))
 for a,b in {'T':'R','D':'D','H':'H','rho':'rho','theta':'theta'}.items():check('INPUT_exterior_upper_'+a,up[b]<=F(ext[a]))
 for a in ['A','B']:check('INPUT_exterior_lower_'+a,lo[a]>=F(ext[a]))
 check('INPUT_exterior_probability',lo['p_lower']>=F(ext['p'][0])and up['p_upper']<=F(ext['p'][1]))
 check('INPUT_exterior_beta',lo['beta_lower']>=F(ext['beta'][0])and up['beta_upper']<=F(ext['beta'][1]))
 check('common_C_cap',c['C']==F(ext['cap'])==F(ga['C'][1])==norm['C'])
 pos('gap_m_lower',(1-up['theta'])*lo['p_lower']*(1-lo['p_lower'])-F('.4749')**2)
 pos('gap_ell_lower',1-up['theta']-F('1.9977')**2*up['p_upper']*(1-up['p_upper']))
 pos('inward_gap_from_shared_shift',6*F('.4749')*(lo['A']+lo['B'])*F('1.9977')*c['d0']-up['D'])
 pos('common_rebate',(F('.4095')-c['D']/15)/(2*(1+c['H']**2/(2*c['N'])))-c['rebate'])
 check('confinement_metadata_contract',d['confinement_object']['contract']==canonical(c))
 for field,name in [('kernel_sha256','confinement95b_kernel.py'),('proof_sha256','confinement95b_proof.tex')]:
  check('confinement_binding_'+field,d['confinement_object'][field]==hashlib.sha256((LOCAL/name).read_bytes()).hexdigest())
 check('confinement_closed_boxes',d['confinement_object']['feasible']+d['confinement_object']['excluded']==c['pc']*c['hc']*c['lc'])
 for a in ['N','T','D','theta','d0','pl','pu','H','C','rho','amplitude']:check('confinement_normalization_'+a,c[a]==norm[a])
 check('confinement_noise_to_normalization',c['maxnoise']==norm['lmax'])
 check('conditional_span',norm['span']==norm['amplitude']+norm['d0'])
 check('root_local_normalization_equal',d['root_normalization']==norm)
 low=d['low'];lowc={k:F(v)for k,v in low['constants'].items()}
 for a,b in norm.items():check('LOW_normalization_'+a,F(b)==lowc[a])
 check('LOW_rebate',lowc['rebate']==c['rebate'])
 for key,entrykey,islower in [('R_A','quad_A',False),('R_F','quad_F',False),('R_Q','quad_Q',True)]:
  entry=(lo if islower else up)[entrykey];check('INPUT_LOW_raw_'+key,d['low_raw'][key]==lowc[key]and(entry>=lowc[key]if islower else entry<=lowc[key]))
 meta=d['companions']['metadata'];body=d['companions']['object']
 for field,name in [('kernel_sha256','companions95b_kernel.py'),('normalization_sha256','normalization95b.py'),('proof_sha256','normalization_companions95b_proof.tex')]:
  check('companion_binding_'+field,meta[field]==hashlib.sha256((LOCAL/name).read_bytes()).hexdigest())
 check('companions_normalization',meta['contract']==canonical(norm))
 check('tiny_declared_noise',d['tiny']==norm['tiny']==F(meta['tiny_noise']))
 check('companions_declared_regions',meta['regions']==[[str(a),str(b)]for a,b in d['regions']])
 check('same_strict_comparison_target',F(meta['target_per_noise'])==-F(low['target'])==F('.001'))
 check('positive_noise_target',F(low['worst_score'])<F(low['target'])<0)
 check('tiny_six_phase_cells',len(body['tiny'])==6 and [F(z['distance'])for z in body['tiny']]==[F(j,10)for j in range(5,11)])
 check('all_declared_regions_present',len(body['regions'])==len(d['regions'])==5)
 for i,((start,end),region)in enumerate(zip(d['regions'],body['regions'])):
  check('region_endpoints_'+str(i),F(region['start'])==start and F(region['end_noise'])==end)
  check('both_phase_signs_'+str(i),'negative_first'in region and 'negative_outer'in region)
  rows=region['positive'];want=int((F('.5')-start)*200)
  check('positive_cell_count_'+str(i),len(rows)==want)
  for j,row in enumerate(rows):check(f'closed_phase:{i}:{j}',list(map(F,row['phase']))==[start+F(j,200),start+F(j+1,200)])
 bands=[list(map(F,row))for row in low['noise_intervals']]
 expected=[[F('.026'),F('.0275'),F('.04')],[F('.0275'),F('.03'),F('.09')]]
 for i in range(68):
  a=F('.03')+F(i,400);b=a+F(1,400);r=F('.13')if a<F('.08')else F('.18')if a<F('.10')else F('.25')if a<F('.12')else F('.5')
  expected.append([a,b,r])
 check('fixed_complete_LOW_bands',bands==expected)
 check('tiny_LOW_closed_join',bands[0][0]==d['tiny'])
 check('top_noise_endpoint',bands[-1][1]==c['maxnoise'])
 for i,(a,b,r)in enumerate(bands):
  pos('noise_width:'+str(i),b-a);check('phase_radius:'+str(i),0<r<=F('.5'))
  if i:check('closed_noise_seam:'+str(i),a==bands[i-1][1])
  covers=[j for j,(start,end)in enumerate(d['regions'])if start<=r and b<=end]
  check('complete_phase_union:'+str(i),r==F('.5')or bool(covers))
  coverage.append({'noise':[str(a),str(b)],'LOW_phase':['-'+str(r),str(r)],'MID_regions':covers,'complete_by_LOW':r==F('.5')})
 counts=low['counts'];check('LOW_closed_box_count',counts['feasible_cells']+counts['empty_cells']==32*32*70)
 check('LOW_two_noise_endpoints',counts['endpoints']==2*counts['feasible_cells'])
 # Independent scalar and index seams; the analytic selector lemma is separate.
 K=sel['barrier'];delta=sel['loss'];A=sel['anchor'];N=sel['cutoff'];steps=sel['steps']
 check('selected_anchor_band',[p['ANCHOR90']['n'],p['ANCHOR90']['nmax']]==[90,A])
 check('selected_propagation_band',[p['PROPAGATE95']['n'],p['PROPAGATE95']['nmax']]==[95,188])
 check('selected_common_barrier',p['ANCHOR90']['barrier']==p['PROPAGATE95']['barrier']==K)
 check('anchor_support_row',[90,94,'.7','3.9','1.17']in d['adaptive_specs'])
 check('propagation_support_row',[95,188,'.7','3.7','7/940']in d['adaptive_specs'])
 check('uniform_support_row',[80,'4.1','1.02']in d['support_specs'])
 pos('anchor_loss_exceeds_barrier_crossing',F('1.17')-K/89)
 pos('anchor_harmonic_reserve',K/A+F('1.17')*sum((F(1,j)for j in range(90,A+1)),F(0))-(F('.469')-F('.4095')))
 pos('anchor_actual_rho',p['ANCHOR90']['rho']-F('.3031')*F('.646')/(F('.1064')+K/94))
 pos('propagation_actual_rho',p['PROPAGATE95']['rho']-F('.3031')*F('.646')/(F('.1064')+K/188))
 pos('propagation_decrement',F(7,940)-K/95)
 stop=d['stop'];check('retained_STOP180',stop['n_min']==180 and stop['retain_general_budget']is True)
 ratio=F(stop['profiles'][-1]['stages'][-1]['ratio']);check('retained_STOP180_final_ratio',ratio==F('.49823'))
 check('finite_band_then_STOP_overlap',188+1>=stop['n_min'])
 pos('tail_support_radius',F('4.5')-F('4.1'));pos('tail_first_failure_slow',F('1.02')-K/188);pos('tail_barrier_exclusion',K-ratio)
 check('ENTRY_current_cap_earliest_index',p['ENTRY95']['n']>=A)
 pos('ENTRY_own_cap',p['ENTRY95']['cap']-F('.40974')-K/p['ENTRY95']['n'])
 check('local_theorem_floor',sel['local_floor']==c['N']==95)
 check('local_application_needs_two_predecessors',sel['application_floor']>=sel['local_floor']and sel['application_floor']-2>=A)
 pos('three_index_score_cap',c['C']-F('.40974')-K/(sel['application_floor']-2))
 check('selected_slow_loss',0<delta<=F(ext['decrement'])<=F(ga['decrement'])and delta<=F(heat['decrement_upper']))
 check('four_loss_target_indices',N-steps>=A and N-steps+1>=sel['application_floor'])
 reserve=delta*sum((F(1,j)for j in range(N-steps+1,N+1)),F(0))-K/(N-steps)
 pos('four_loss_reserve_at_99',reserve)
 check('all_later_indices_monotone',all(steps-i>0 for i in range(steps)))
 return {'gates':len(gates),'exact_gates':gates,'phase_noise_cover':coverage,'selected_reserve':str(reserve)}
def main():
 need(len(sys.argv)==1,'fixed semantic check accepts no parameters')
 d=gather();r=verify(d);negative=[]
 mutations=[('noise_gap',lambda x:x['low']['noise_intervals'][1].__setitem__(0,'7/250')),
  ('missing_noise_band',lambda x:x['low']['noise_intervals'].pop()),('missing_negative_phase',lambda x:x['companions']['object']['regions'][0].pop('negative_first')),
  ('phase_gap',lambda x:x['companions']['object']['regions'][0]['positive'][0].update(phase=['1/20','3/50'])),
  ('missing_MID_bridge',lambda x:x['regions'].pop(0)),('wrong_raw_quadratic',lambda x:x['low']['constants'].update(R_A='1/2')),
  ('unlicensed_local_at95',lambda x:x['selection'].update(application_floor=95)),('only_three_losses',lambda x:x['selection'].update(steps=3)),
  ('false_cutoff98',lambda x:x['selection'].update(cutoff=98)),('unlicensed_loss_point20',lambda x:x['selection'].update(loss=F('.2'))),
  ('STOP_too_late',lambda x:x['stop'].update(n_min=190)),('STOP_insufficient_ceiling',lambda x:x['stop']['profiles'][-1]['stages'][-1].update(ratio='4/5'))]
 for name,mutate in mutations:
  x=copy.deepcopy(d);mutate(x)
  try:verify(x)
  except (ValueError,KeyError,TypeError):negative.append(name)
  else:raise ValueError('accepted seam corruption '+name)
 result={'status':'PASS_EXACT_SUPPLEMENTARY_SEAMS99','mathematical_status':'Conditional semantic composition only; component mathematics and fresh acceptance are independent obligations.',
  'gates':r['gates'],'negative_controls':negative,'local_theorem_floor':95,'local_application_floor':96,'cutoff':99,'forced_loss':'19/100','steps':4,
  'reserve_at99':r['selected_reserve'],'phase_noise_cover':r['phase_noise_cover'],'exact_gates':r['exact_gates'],'source_sha256':SOURCES,
  'requires':['attainment and branch/reflection reduction','actual-law Fourier and contact identities','finite Shevtsova caps and CE brackets','Schulz binary theorem including zero noise','all component strict acceptance runs','retained supported STOP180 analytic proof and exact certificate']}
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
