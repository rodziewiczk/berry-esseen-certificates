# Independent structural work and review for the sub100 attempt

This is a working review. It does not claim a cutoff below100 before the
remaining entry, local comparison and global composition are accepted.
The preserved cutoff189 release has not been modified.

| Item | Mathematical status | Execution status |
| --- | --- | --- |
| Uniform all-threshold heat estimate | Independently derived; parent read its proof | Exact support rows freshly pass in `support02` |
| Finite-band high-score support | Derived from current-law score lower bound and finite caps | `adaptive04` freshly passes |
| Radius4.1 to2.5 bridge at95 | Independently derived, with explicit hypotheses | 32 closed cells and864 rational gates pass in `heat_bridge95_02` |
| Multi-step and ceiling-ladder selectors | Independently derived conditional scalar lemmas | `selectors01` passes the named conditional scenarios |
| New signed moment and phase-rebate entry formulas | Independently derived and reviewed, including fixed complete-cell reductions | Eight actual laws pass `signed_actual01`; fixed entry/INPUT fresh PASS in worker runs `accept_entry95_02`, `accept_input95_03` |
| Gaussian95 and exterior95B | Source formulas, common budget, transport and initial displacement independently reviewed | Parent's fresh runs inspected; final binding pending |
| Asymmetric amplitude.30 confinement | Full derivation and strict acceptor reviewed; endpoint correction made | Worker `confinement95b_accept02`:474376 gates and17 controls freshly pass |
| Normalization and five tiny/MID companions | Independent derivation and source review complete | Worker `companions95b_accept02`:1906 gates and25 controls freshly pass; independent arithmetic below |
| Whole-count LOW95B | Three strengthened steps independently derived; fixed kernel, contract, acceptance and proof reviewed | `root/accept_low95b_01`:626074 gates and15 controls freshly pass; all recorded root input hashes remain current |
| Selected four-loss selector99 | Exact conditional scalar lemma, correct application floor96 | `selector99_02` below binds STOP180 tail extension |

## New proof and executable deliverables

`uniform_support.tex` is the full finite heat proof, the support polynomial
reduction, the threshold-free radius2.5 bridge, the harmonic selector, and
the finite-band ceiling ladder. `proof_note.tex` is its standalone wrapper.

The finite heat expansion retains its cubic and quartic terms together.
Its remainder follows from ordinary Taylor formulas in translation and
variance and explicit Gaussian derivative norms. Thus it needs no bound on
the raw or standardized threshold. Both signs of the support point are
covered, and the exact support tests cover closed intervals rather than
sampled points. The old all-threshold Gaussian inequality is used only on
the rays beyond4.5; its contact coefficient and complete cubic derivatives
are explicitly tested there.

Selected new support consequences include:

- For every n>=80, an attained nonnegative witness with d_n<=1.02 has
  actual support in(-4.1,4.1), without further moment localization.
- On90<=n<=94 under a_n>=.7/n, d_n<=1.17 gives radius3.9.
- On95<=n<=188 under a_n>=.7/n, d_n<=.7/94 gives radius3.7.
- For n>=95, prior radius4.1, rho<=1.15, |beta|<=.31 and d_n<=.2 give
  radius2.5. Neither H nor the current score needs an additional upper cap.

The finite-band endpoint is essential: a_n>=K/n implies
C_n>.4095+K/U on a band n<=U. Replacing U by the lower endpoint would
reverse the relevant inequality. After a K/n ceiling exists, a hypothetical
first barrier failure has d_n<K/(n-1); it does not require the much larger
initial stopping threshold. This is why a single propagation profile can
cover95 through188.

## Composition seam

The current selected architecture uses anchor94 and propagation from95.
The three score caps for LOCAL95 are therefore licensed only when the local
theorem is applied at n>=96: its earliest predecessor is94. A current-law
cap at95 is valid for entry and the heat bridge. It must not be mislabeled
as a three-index cap at95.

If the new local theorem forces d_n>.19 for n>=96, four losses from N=99
reach index95 and contradict the .7/n ceiling. The harmonic expression is
uniform thereafter because every (N-4)/(N-i) increases with N. The exact
reserve is12229769/28609257600. The supported propagation covers95..188.
For every later index, a first .7/n barrier failure has d_n<.7/(n-1)<1.02;
the all-H heat theorem supplies radius4.1, and the retained supported
STOP180 at radius4.5 gives a_n<.49823/n<.7/n. Thus the selected route
needs no retained full cutoff189 local comparison.

## Entry review

Both signwise fourth moment inequalities follow by Cauchy on each sign and
the pointwise bound x^4<=R x^3. Their continuous lower envelope is convex
in gamma and its upper envelope is concave below gamma=rho_l, affine above;
the stated vertices, kink and endpoints cover the full gamma interval.
The beta cubic has the correct decreasing sign. The stronger opposite-sign
event bound requires no atom atzero. The code applies it only after D<2
has supplied an actual central gap; the prose was corrected to state this.
A variance-one law with masses1/8,3/4,1/8 at-2,0,2 explicitly refutes the
same event bound without that hypothesis.

The conserved budget B is distinct from raw R. Subtracting its exact
nonnegative phase correction strengthens the quadratic damping without
replacing the raw invariant used for the density floor. The initial raw
ceiling must be below N*.4095 before turning it into the unweighted defect
bound; the fixed acceptor now checks this initialization scope. The new
barrier term -K*rho is affine and preserves the convex endpoint reduction.
Moment-exclusion sentinels must be recorded as excluded cells, rather than
used as negative remainder bounds.

## Gaussian, exterior and confinement review

Gaussian95 uses the correctly signed positive and negative cubics, the
radius4.1 Taylor cover, H<=1.5, and the .2H²+.3|H|+.5 correction. Its
exterior contract requires beta>=.05; the threshold-free heat bridge has
the weaker absolute beta bound and can therefore precede a refinement.

Exterior95's binary polynomials, whole-ray derivatives, same-law transport
price, common budget multiplier24, and completed-square closing reserve
were read and independently checked. The geometry calculation's additional
beta>=.05 assumption must be carried in its headline hypotheses. Its exact
reported coordinate defect is below.011 even though the earlier source
asserted only the weaker.025; the numerical statement should match its
recorded rational gate.

The amplitude.30 confinement correctly uses both directed deletion errors,
the asymmetric interval extension[-d,tau], both conditional probabilities,
Cantelli plus the one-sided Markov bound, and one shared allocation for
coordinate gap, absolute noise and leakage. The upper interval begins at
the actual contact b and includes its atom. The lower ray derivative uses
an independent n*epsilon cap and does not differentiate the max allocation.
The rho23 and central-square penalty coefficients were independently
derived. The lower derivative interval originally omitted eta from its
far endpoint; this was reported and the worker added eta before preparing
strict acceptance. Explicit positive gap-slope and allocation gates were
also added to make the proof order transparent.

## Normalization, companions and whole-count review

The normalization includes the wider v+s range explicitly. The favorable
cubic multiplier3.16 uses C>.4, and its square gate is valid even when
v+s>1/4. The positive normal repair1.85, binomial mode/own-count mass,
variance recursion and ratio1.025 all use the actual conditional laws.
The support span is.312, giving harmonic rate14.17. No older span or
rate is silently substituted.

The first incoming MID count uses the minimum of two valid bounds,
Bennett and Cantelli. The later counts retain the complete geometric
Bennett tail. Their positive and negative phase cells cover the five
declared rectangles. The tiny-noise proof uses a fourth-moment lower
bound on E|W| and the monotonicity of B/[lambda(1-B)] to cover every
positive noise approaching zero. Its negative-phase function has one
possible local maximum after the initial endpoint, so endpoint minima
are valid. Strict and closed event distinctions include atoms.

The primary Bennett checker computes a20-term scaled logarithm lower
bound and a16th-degree exponential lower bound raised to power16.
Independently, `check_companions95b_independent.py` imports no constructor
or acceptance code and uses an unscaled128-term logarithm and direct
degree64 exponential, rounding every intermediate downward on10^-30.
It rechecks all740 bounds, all362 positive and5 negative phase cells,
and the6 tiny cells. Fresh `companions_independent01` passes with minimum
per-noise reserve503959007270509/87909770000000000; four malformed bound
controls reject. This is an independent arithmetic implementation, not
a claim that arithmetic can replace the reviewed actual-law reduction.

The new LOW shared shift uses the exact unshifted binary square and
6m ell^2 d(1-d), retaining the same variance residual. The cell alpha,
binary penalty and variance coefficient are charged against one budget.
The paired Cantelli maximum follows from the sign of its exact derivative
under b^2-a^2-t>0. The sixth-order exponential correction divided by noise
increases up to rate*noise=3; freezing it at the lower endpoint preserves
the convex score envelope. The clipped raw quadratic, nd cap, two endpoint
tests, signed lower-mass substitution, positive inverse-n coefficient and
all-n monotonicity agree between proof and implementation. The small
explicit square gate for12.32455532 was added after review.

## Remaining work

Read and bind the final assembled global manuscript, coverage/selector,
and source-bound full-suite metadata. A successful support or confinement
check does not by itself prove binary optimality or the requested cutoff.
