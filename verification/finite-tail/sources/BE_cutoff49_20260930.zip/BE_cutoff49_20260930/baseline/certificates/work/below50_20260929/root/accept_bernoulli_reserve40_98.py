"""Fixed finite positive-branch Bernoulli reserve; rigorous integer intervals."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
import bernoulli_reserve as b
assert __debug__ and not sys.flags.optimize

def count_domain(n,k):
    l=max(F('.35'),(k-F('1.1'))/n)
    h=min(F('.46'),(k+F('1.1'))/n)
    return None if l>h else(l,h)
def partition(l,h):
    assert l<=h
    count=int((h-l)*2000)+1
    return [(l+(h-l)*F(j,count),l+(h-l)*F(j+1,count))for j in range(count)]
def verify_cover(cells,l,h):
    assert cells and cells[0][0]==l and cells[-1][1]==h
    if l==h:assert cells==[(l,h)];return
    for j,(a,z)in enumerate(cells):
        assert a<z and z-a<=F(1,2000)
        if j:assert cells[j-1][1]==a
def controls():
    out=[];l,h=F('.35'),F('.46');good=partition(l,h)
    bad=[('missing_first',good[1:]),('missing_last',good[:-1]),('missing_middle',good[:3]+good[4:]),
         ('duplicate',good[:2]+[good[1]]+good[2:]),('reorder',list(reversed(good)))]
    for name,cells in bad:
        try:verify_cover(cells,l,h)
        except AssertionError:out.append(name)
        else:raise AssertionError(('bad cover',name))
    try:verify_cover([],l,l)
    except AssertionError:out.append('missing_singleton')
    else:raise AssertionError('empty singleton accepted')
    try:verify_cover([(l,l),(l,l)],l,l)
    except AssertionError:out.append('duplicate_singleton')
    else:raise AssertionError('duplicate singleton accepted')
    # A false reserve is rejected at a concrete actual Bernoulli law.
    point=b.score_point(98,41,F('0.421593'))
    assert point.fraction_lower()>b.CE.fraction_upper()-F('0.001')
    out.append('false_reserve_.001')
    return out

def main():
    assert len(sys.argv)==1
    constants=b.constants();digest=sha256();rows=[];points=[];total=0
    for n in range(40,99):
        peak=F(-1);count=0;legal=[]
        for k in range(n):
            domain=count_domain(n,k)
            if domain is None:continue
            l,h=domain;cells=partition(l,h);verify_cover(cells,l,h)
            legal.append(k)
            if l==h:points.append([n,k,str(l)])
            for lo,hi in cells:
                score,_=b.score_cell(n,k,lo,hi)
                upper=score.fraction_upper();margin=b.CE.fraction_lower()-upper
                assert margin>F(1,4000),('reserve',n,k,str(lo),str(hi),str(margin))
                peak=max(peak,upper);count+=1
                digest.update(('%d,%d,%s,%s,%s\n'%(n,k,lo,hi,upper)).encode())
        # k<0 or k>=n are impossible in the stated threshold/probability range.
        assert F('.35')*n-F('1.1')>0 and F('.46')*n+F('1.1')<n
        assert legal==list(range(min(legal),max(legal)+1))
        total+=count
        rows.append(dict(n=n,closed_cells=count,score_upper=str(peak),reserve_lower=str(b.CE.fraction_lower()-peak)))
    assert points==[[46,15,'7/20'],[65,31,'23/50'],[66,22,'7/20'],[86,29,'7/20']]
    files=[Path(__file__),Path(b.__file__)]
    print(json.dumps(dict(status='PASS_FINITE_BERNOULLI_RESERVE_40_98',
      theorem='For40<=n<=98,.35<=p<=.46 andintegerk with|k−np|<=1.1, C_B^+(n,p,k)<CE−1/4000.',
      direction='positive closedCDF branch only',constants=constants,closed_cells=total,
      singleton_cells=points,rows=rows,negative_controls=controls(),gate_sha256=digest.hexdigest(),
      trusted_arithmetic='Python unbounded integers, Fraction, isqrt; every interval operation rounds outward at10^−15.',
      source_sha256={p.name:sha256(p.read_bytes()).hexdigest()for p in files},
      scope='Finite Bernoulli theorem. It does not imply the same score bound for noisy laws or an unrestricted cutoff.'),indent=2))
if __name__=='__main__':main()
