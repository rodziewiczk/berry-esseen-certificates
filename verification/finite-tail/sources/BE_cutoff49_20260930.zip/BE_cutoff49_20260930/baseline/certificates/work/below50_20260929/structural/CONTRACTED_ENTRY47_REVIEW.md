# Independent contracted-radius and cubic-sign review

The named CONFINED_FEEDBACK47 analytic extension is valid for the local
panel calculation with1<=R<=6 and the additional paired gate R>2g.
This is an analytical review; the recorded45-row discovery is not promoted
here to a fixed accepted theorem. Existing accepted sources are unchanged.

I compared contracted_kernel.py with kernel.py: only the named docstring,
radius guard and strengthened paired guard differ. The panel copy only
changes its import and documentation. For t>=0 the moment weight
w=(t-1)^2(t+1/2) has Ew=rho-1; the two numerators have expectations mu4-1
and eta5-1. Their quotient derivatives given in the proof are nonnegative
on the whole half-line, including0. Therefore the radius-ratio bounds
remain valid below2.3. The local Taylor, central-gap, conditional rectangle,
Bernstein and actual-event bounds use only actual support and their explicit
checked positivity/monotonicity gates. There is no additional2.3 floor in
that path. The general sixth-order bound already replaces R by max(R,2g).
The paired signed Pearson derivation needs R>2g; the new guard makes the
previous automatic hypothesis explicit. A failed guard rejects; it cannot
silently authorize use of a smaller radius. This extension is not a license
to apply the old initial signed-cover or stopping theorem at a changed scope.

From proved |U|<=a and p in[l,u],
|X|<=max(u+a,1-l+a)/sqrt(min_[l,u]pq), because s>=0.
Thus weak R2.5 entry -> acquired confinement -> actual smaller R -> tighter
entry is an acyclic finite chain. The final stronger table cannot be used
to justify the confinement premises that produced its radius.

## Additional gamma lower bound

For sign labels, V=E[X|sign X] and W=X-V, expansion gives exactly

    gamma=EV^3+E[sign(X) W^2 (|X|+2|V|)].

The positive-class residual is nonnegative. On the negative class,
|V|=sqrt((1-theta)p/(1-p))<=sqrt(u/(1-u)), so the remaining residual is
at least -(R+2sqrt(u/(1-u)))theta. For p<1/2,
EV^3=(1-theta)^(3/2)(1-2p)/sqrt(p(1-p)) decreases in both p and theta.
Hence the proposed lower bound at endpoints u,Theta is valid. It may raise
the lower gamma endpoint in the paired coefficient rectangle after all its
existing moment/order/denominator gates are rechecked. No modification of
the already valid phase quadratic is needed. This observation alone is not
an accepted numerical improvement.
