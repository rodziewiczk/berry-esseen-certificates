"""Independent exact actual-law tests for the variance-only count reduction."""
from fractions import Fraction as F
from math import comb
from collections import defaultdict
import json,sys
if sys.flags.optimize:raise RuntimeError('Unoptimized Python required')
def need(b,s):
 if not b:raise ValueError(s)
def valid(d):
 need(sum(d.values())==1 and all(v>0 for v in d.values()),'probability law')
 need(sum(x*v for x,v in d.items())==0,'conditional centering')
def two(a,b):
 a,b=F(a),F(b)
 return {-a:b/(a+b),b:a/(a+b)}
def conv(d,e):
 o=defaultdict(F)
 for x,p in d.items():
  for y,q in e.items():o[x+y]+=p*q
 return dict(o)
def power(d,n):
 o={F(0):F(1)}
 for _ in range(n):o=conv(o,d)
 return o
Z={F(0):F(1)}
laws=[(F('1/4'),Z,Z),(F('.26'),two('.01','.01'),Z),
 (F('.25'),Z,two('.001','.1')),(F('.255'),two('.5','.5'),two('.5','.5')),
 (F('.25'),two(100,F(1,10**9)),Z),(F('.26'),Z,two(F(1,10**10),100)),
 (F('.25'),two('.001','.4'),two('.4','.001'))]
identities=bounds=variances=jensens=collisions=0
for p,u0,u1 in laws:
 valid(u0);valid(u1);q=1-p;v=p*q
 s0=sum(x*x*r for x,r in u0.items());s1=sum(x*x*r for x,r in u1.items());s=q*s0+p*s1
 law=defaultdict(F)
 for b,d,w in ((0,u0,q),(1,u1,p)):
  for x,r in d.items():law[b+x]+=w*r
 raw=sum(abs(x-p)**3*r for x,r in law.items())
 need(raw>=v*(1-2*v),'conditional Jensen');jensens+=1
 for n in range(1,6):
  actual=power(law,n);ps=[F(comb(n,j))*p**j*q**(n-j)for j in range(n+1)]
  conditionals=[conv(power(u0,n-j),power(u1,j))for j in range(n+1)]
  for j,d in enumerate(conditionals):
   tv=sum(x*x*r for x,r in d.items());cap=n*s*max(F(j,n)/p,F(n-j,n)/q)
   need(tv==(n-j)*s0+j*s1<=cap,'actual conditional variance');variances+=1
  for k in range(n):
   phases={F('-.5'),F('-.1'),F(0),F('.1'),F('.5')}
   phases.update(x-k for x in actual if abs(x-k)<=F('.5'))
   for u in phases:
    cdf=sum(r for x,r in actual.items()if x<=k+u);bcdf=sum(ps[:k+1])
    outgoing=sum(ps[j]*sum(r for x,r in conditionals[j].items()if x>u+k-j)for j in range(k+1))
    incoming=sum(ps[j]*sum(r for x,r in conditionals[j].items()if x<=u+k-j)for j in range(k+1,n+1))
    need(cdf-bcdf==incoming-outgoing,'exact count identity');identities+=1
    tk=n*s*max(F(k,n)/p,F(n-k,n)/q)
    loss=(u*u/(tk+u*u)if u<0 else F(0))
    inc=F(0)
    for j in range(k+1,n+1):
     tj=n*s*max(F(j,n)/p,F(n-j,n)/q)
     inc+=ps[j]*tj/(tj+(j-k-u)**2)
    need(cdf-bcdf<=inc-ps[k]*loss,'closed incoming/strict outgoing envelope');bounds+=1
    collisions+=k+u in actual
# Independent polynomial checks for the negative phase envelope.
scalar=0
for m in map(F,('.4','.6','.8')):
 for c in map(F,('.5','.65','.8')):
  for t in map(F,('.001','.01','.03')):
   r0=2*c*t/m
   if r0>=F('.5')or m*r0<=c*(t+r0*r0)or m/2<=c*(t+F('1/4')):continue
   cost=c*c*(t+r0*r0)/(4*m)
   for r in [F(i,200)for i in range(101)]+[r0]:
    need(m*r*r/(t+r*r)-c*r>=-cost,'negative phase envelope');scalar+=1
rejected=0
for d in ({F(1):F(1)},{F(-1):F('1/4'),F(1):F('1/4')},{F(-1):F('1/4'),F(1):F('3/4')}):
 try:valid(d)
 except ValueError:rejected+=1
 else:raise ValueError('invalid conditional law accepted')
print(json.dumps(dict(status='PASS_EXACT_ACTUAL_VARIANCE_CONTROLS',laws=len(laws),count_identities=identities,
 count_inequalities=bounds,variance_checks=variances,Jensen_checks=jensens,collisions=collisions,
 scalar_envelope_controls=scalar,malformed_law_rejections=rejected,
 scope='Finite actual-law tests including zero noise, far-away tiny atoms and collisions; continuum proof supplied separately.'),indent=2))
