from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;PROJECT=BASE.parents[1]
def digest(p):return sha256(p.read_bytes()).hexdigest()
freeze=BASE/'local/LEFT_MID47_B_FREEZE.json';d=json.loads(freeze.read_text());hashes={str(freeze.relative_to(PROJECT)):digest(freeze)}
for rel,h in d['files'].items():
 p=BASE/'local'/rel;assert digest(p)==h,(rel,'freeze');hashes[str(p.relative_to(PROJECT))]=h
for key in ['acceptance','controls','compile']:
 folder=PROJECT/d['runs'][key];m=json.loads((folder/'metadata.json').read_text());assert m['returncode']==0
 for s in ['stdout','stderr']:assert digest(folder/(s+'.txt'))==m[s+'_sha256']
 for s in ['metadata.json','stdout.txt','stderr.txt']:
  p=folder/s;hashes[str(p.relative_to(PROJECT))]=digest(p)
 if key=='acceptance':
  r=json.loads((folder/'stdout.txt').read_text())
  assert(r['blocks'],r['phase_cells'],r['gates'],r['normalization_gates'],len(r['negative_controls']))==(217,74370,224463,1353,24)
  for rel,h in r['source_sha256'].items():
   assert digest(BASE/'local'/rel)==h
   if rel in m['input_sha256']:assert m['input_sha256'][rel]==h
 # Current source hashes are frozen even for dependencies not in the cwd
 # snapshot; explicit source fields in the acceptance cover their bytes.
rows=json.loads((BASE/'local/left_mid47b_normalization.json').read_text())['rows']
for row in rows:
 c={k:F(v)for k,v in row['constants'].items()}
 assert c['N']==47 and 0<c['pl']<c['pu']<F('.5') and 0<c['left']<c['right']<F('.5')
 assert 0<c['logcap']<1 and 0<c['zeta']<47 and c['repair']>0
 assert all(c[k]>0 for k in ['elo','v','vf','mass','ownlo','derivative_lo','ratio'])
table=json.loads((BASE/'entry/left270_input47_table.json').read_text())['panels']
assert not any(F(r['lambda_max'])in[F('.05'),F('.06'),F('.08'),F('.10')]for r in table)
for rel in ['structural/LEFT_MID47B_REVIEW.md','structural/bind_left_mid47b.py',
 'structural/LEFT270_INPUT47_BINDING.json','structural/LEFT_SPERNER47_A_BINDING.json',
 'structural/LEFT_SPERNER47_PROFILE_A_BINDING.json','structural/MID47A_BINDING.json']:
 p=BASE/rel;hashes[str(p.relative_to(PROJECT))]=digest(p)
out=HERE/'LEFT_MID47B_BINDING.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='INDEPENDENT_LEFT_MID47B_REVIEW_V1',
 mathematical_status='Reviewed conditional signed comparison with explicitly negative-only fourth band; no unresolved defect.',
 execution_status='Fresh exact fixed acceptance and actual-law controls PASS.',
 scope=d['scope'],blocks=217,phase_cells=74370,gates=224463,controls=24,
 extra_fixed_domains='All33 normalizer domains and positive repair coefficients checked; no singleton ceiling at an internal lower noise endpoint.',
 visual_qa='Constructor five-page PDF QA; reviewer full proof/source reading only.',
 sha256=hashes),indent=2)+'\n')
print(json.dumps(dict(status='PASS_INDEPENDENT_LEFT_MID47B_BINDING',sha256=digest(out)),indent=2))
