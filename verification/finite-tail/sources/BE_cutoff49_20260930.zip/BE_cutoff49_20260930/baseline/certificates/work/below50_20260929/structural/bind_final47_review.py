from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json
B=Path(__file__).resolve().parents[3];S=B/'work/below50_20260929/structural';E=B/'work/below50_20260929/entry';L=B/'work/below50_20260929/local';h=lambda p:sha256(p.read_bytes()).hexdigest()
def save(name,status,files,extra=None):
 o={'schema':name+'_REVIEW_V1','mathematical_status':status,'sha256':{str(p.relative_to(B)):h(p)for p in sorted(set(files))if p.is_file()}}
 if extra:o.update(extra)
 p=S/(name+'_BINDING.json');p.write_text(json.dumps(o,indent=2)+'\n');return p
# Attach the missing auxiliary Fourier orientation to all affected current reviews.
names=['ENTRY47_PANEL','LEFT47_INPUT','CONFINED_FEEDBACK47','SPERNER_FEEDBACK47','SIGNED_RESOURCE47','GLOBAL45_COMPOSITION']
files=[S/(n+'_BINDING.json')for n in names]+[S/'PAIRED_REFLECTION47_AUDIT.md',E/'paired_fourier_orientation47.tex',E/'build_paired_orientation47/paired_orientation47_notes.pdf',Path(__file__)]
orientation=save('PAIRED_ORIENTATION47','Signed-gamma prose omission repaired by independently derived auxiliary Fourier reflection. Existing arithmetic/targets unchanged. This explicit lemma supplements every listed earlier review; no original signed contact/phase quantity is reflected.',files,{'affected_review_bindings':names,'execution_status':'Analytical clarification; no numerical acceptance rerun required or claimed.'})
# Bind both fixed local objects and their selected recorded source closures.
localspec=[('MID47A','MID47A_FREEZE.json','3558f4005cf2ef59de5c642d15ca5b9cddfbe515ce6553b7e33e8d7f7091de01','mid47a_accept01'),('SPERNER47_PROFILE_A','SPERNER47_PROFILE_A_FREEZE.json','c7a2bf7d052a055f67f4ccd5208198d8c6c06ec671eb9b0f74f7d7338c3fe054','sperner47_profile_accept02')]
outputs=[orientation]
canon=json.loads((L/'conditional_input47.json').read_text());assert all(F(z['lambda_max'])not in(F('.05'),F('.08'),F('.10'))for z in canon['panels'])
for name,fn,expect,run in localspec:
 freeze=L/fn;assert h(freeze)==expect;doc=json.loads(freeze.read_text());files=[freeze,S/'MID47A_REVIEW.md',S/'SPERNER47A_BINDING.json',S/'TINY47A_BINDING.json',Path(__file__)]
 for n,v in doc['files'].items():assert h(L/n)==v;files.append(L/n)
 r=B/'runs/below50_20260929/local'/run;m=json.loads((r/'metadata.json').read_text());o=json.loads((r/'stdout.txt').read_text());assert m['returncode']==0
 for n,v in o['source_sha256'].items():assert h(L/n)==v==m['input_sha256'][n]
 assert h(r/'stdout.txt')==m['stdout_sha256'] and h(r/'stderr.txt')==m['stderr_sha256'];files+=list(r.iterdir())
 if name=='MID47A':
  assert(o['rows'],o['gates'],len(o['negative_controls']))==(2620,7901,26)
  rr=B/'runs/below50_20260929/local/mid47a_actual01';mm=json.loads((rr/'metadata.json').read_text());assert mm['returncode']==0 and h(L/'check_mid47a_actual.py')==mm['input_sha256']['check_mid47a_actual.py'];files+=list(rr.iterdir())
 else:assert(o['rows'],o['gates'])==(196,313738)
 outputs.append(save(name,'Independent full analytical/source review complete at the fixed conditional scope; no defect. No whole-count LOW or global cutoff conclusion.',files,{'execution_status':'Selected sources match fresh exact acceptance; final freeze/PDF and constructor visual QA distinguished.'}))
# Bind the final left refinement, including its support theorem and orientation.
r=B/'runs/below50_20260929/entry/left270_input47_accept01';m=json.loads((r/'metadata.json').read_text());o=json.loads((r/'stdout.txt').read_text().splitlines()[-1]);assert m['returncode']==0 and(o['panels'],o['negative_controls'])==(38,11)
t=E/'left270_input47_table.json';assert h(t)==o['table_sha256']==m['input_sha256'][t.name]=='4b7bb259e469ee57ca6a61d89fd0b3385443508129138899fe597fd82dc9521a';doc=json.loads(t.read_text());assert doc['source_sha256']==h(E/'signed_resource47_table.json')and doc['support_checker_sha256']==h(E/'accept_left_radius270_47.py')
files=[t,E/'signed_resource47_table.json',S/'SIGNED_RESOURCE47_BINDING.json',S/'LEFT270_INPUT47_REVIEW.md',orientation,Path(__file__),*r.iterdir()]
for n,v in o['source_sha256'].items():assert h(E/n)==v==m['input_sha256'][n];files.append(E/n)
assert h(r/'stdout.txt')==m['stdout_sha256']and h(r/'stderr.txt')==m['stderr_sha256']
outputs.append(save('LEFT270_INPUT47','Independent complete conditional acquired-entry review on[.304,.380]; no defect. Explicit paired orientation attached. No final local comparison or cutoff50 conclusion.',files,{'execution_status':'Current inputs/sources match fresh38-panel/11-control replay.'}))
print(json.dumps({'status':'PASS_FINAL47_REVIEW_BINDINGS','bindings':{p.name:h(p)for p in outputs}}))
