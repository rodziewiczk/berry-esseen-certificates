#!/usr/bin/env python3
"""Two fixed all-H support rows for the conditional K=.7 barrier route.

Requires the same attained contact inequality as support50_proof.tex. This
checker acquires no anchor and proves no moment or unrestricted cutoff claim.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
import fifth_heat50 as H
assert __debug__ and not sys.flags.optimize
SPECS=((45,45,F('.7'),F('3.5'),F('.8341')),
       (46,98,F('.7'),F('3.5'),F('.7')/45))

def build():
    assert F(45)*F('1.5')/44-F('.7')<F('.8341')
    assert all(F('.7')/(n-1)<=F('.7')/45 for n in range(46,99))
    rows=[H.target(*s)for s in SPECS]
    assert [r['n_band']for r in rows]==[[45,45],[46,98]]
    for r in rows:
        assert r['closed_cells'][0][0]=='7/2' and r['closed_cells'][-1][1]=='9/2'
        assert all(r['closed_cells'][j][1]==r['closed_cells'][j+1][0]for j in range(len(r['closed_cells'])-1))
    controls=0
    for bad in [(45,45,F('.7'),F('3.0'),F('.8341')),
                (46,98,F('.7'),F('3.0'),F('.7')/45),
                (45,45,F('.7'),F('3.5'),F('2'))]:
        try:H.target(*bad)
        except(ValueError,AssertionError):controls+=1
        else:raise AssertionError('false support control accepted')
    return dict(schema='CONDITIONAL_BARRIER45_SUPPORT_V1',rows=rows,negative_controls=controls,
       theorem='At an attained positive closed maximizing pair with a_n>=.7/n and the row decrement ceiling, the full support lies in(-3.5,3.5), uniformly in every raw threshold H.',
       anchor45_decrement_derivation='a44<1.5/44 and a45>=.7/45 imply d45<45*1.5/44−.7<.8341.',
       propagation_decrement_derivation='At first .7/n barrier failure after45, d_n<.7/(n−1)<=.7/45.',
       dependencies=['attained contact/predecessor inequality','two published Shevtsova bounds','He–Cheng finite Gaussian far-ray bound','support50_proof.tex fifth-order identity and interval semantics'])

if __name__=='__main__':
    assert len(sys.argv)==1
    obj=build()
    here=Path(__file__).resolve().parent
    obj['source_sha256']={name:sha256((here/name).read_bytes()).hexdigest()for name in
        ['accept_barrier45_support.py','fifth_heat50.py','heat_support50.py','support50_proof.tex']}
    print(json.dumps(dict(status='PASS_CONDITIONAL_BARRIER45_SUPPORT',proof=obj),indent=2))
