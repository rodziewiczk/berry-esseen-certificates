# Final independent review: CONDITIONAL_CONFINEMENT47_A

Read the complete final theorem, proof, contract, selected input table,
strict acceptor and kernel. The arithmetic changes beyond the independently
reviewed discovery kernel only remove the unused maximum-noise acquisition
gate and add the lower-ray disjointness gate. The strict theorem explicitly
assumes its per-panel noise ceiling; it does not pretend to prove that ceiling.

The exact beta and cubic identities match one common law, conditional
centering and its two sign classes. The squared root enclosures and
positive coefficient gates license every division and sign substitution.
Both signs of H, H=0, zero noise, support atoms and interval boundary points
are covered. The contact inequalities use the correct closed/half-open
CDF conventions and include the atom at b in the upper comparison.

The three new analytical ingredients are independently derived in
CONFINEMENT47_REFINEMENTS_REVIEW.md: the restricted-negative-ray slope;
the epsilon/2 centered-noise and common-hull estimate; and the tangent
allocation of the exceptional pair event to the same moment budget.
The theorem's proof matches these derivations. Its lower-ray extension
bounds increments in the original affine width bound for the same law,
not an unjustified derivative of a minimum of several error bounds.
The moment/simplex resource for leakage is n^(3/2)*L/kappa, with the
correct factor1/(1-Theta) when converting it to J.

The 45 probability panels form an exact adjacent closed cover of[.38,.47].
For each panel both signs use16 closed phase cells and24 closed noise cells.
All34560 boxes occur exactly once in the per-sign cover lists;10546 are
excluded by the strict common budget and24014 survive. The fixed checker
requires all248960 rational gates positive and matches exact reconstructed
coverage, source hashes, gate digests and minima. All20 recorded mutation
controls target fixed scope, complete coverage, input integrity or arithmetic
metadata. Their strength is not confused with an independent mathematical
proof; that is the separate review above.

Fresh arithmetic run: runs/below50_20260929/local/confinement47_accept01.
Final proof layout was subsequently changed only to wrap a filename.
CONFINEMENT47A_FREEZE.json binds that final proof and five-page PDF; the
constructor reports a clean final compile and personal inspection of all
five rendered pages. This audit independently checked the proof text and
current arithmetic source bytes; it does not claim a second visual inspection.

Mathematical status: no defect found in the conditional theorem at its
complete explicit hypotheses. Execution status: fresh exact constructor PASS
verified and bound. Acquisition of the table, initial strip, deleted-law
concentration bounds and the final score comparison remain separate
obligations; no cutoff50 is claimed by this component.
