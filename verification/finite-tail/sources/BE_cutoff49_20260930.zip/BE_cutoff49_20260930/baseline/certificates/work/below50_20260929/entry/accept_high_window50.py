#!/usr/bin/env python3
"""Fixed exact checks for the analytic HIGH_WINDOW50 refinement.

The companion proof supplies the integral and actual-event reductions. This
driver checks their polynomial identities and deterministic implementation
domains; the three numerical rows are named conditional examples only.
"""
from fractions import Fraction as F
from pathlib import Path
import copy,hashlib,json,sys
import kernel as k
import accept_high_tail as lag
import high_window_core as new
assert __debug__ and not sys.flags.optimize
OBJECT={
 'format':'HIGH_WINDOW50-v1','window_max':'1/4',
 'u_endpoints':['1/4','81/100'],'secant_sum':'53/50',
 'rational_numerator':[2,1],'rational_denominator':[2,4,1],
 'rational_derivative':[-6,-4,-1],
 'first_prefactor':2,'first_exponent':['1/8','-1/384'],
 'first_argument_divisor':4,'comparator_exponent_divisor':8,
 'comparator_rational_multiplier':2,'comparator_gamma_divisor':3,
 'comparator_floor':5,
 'examples':[
  [45,'12/25','25/6','9/5','3/2','87/500'],
  [47,'12/25','25/6','19/10','3/2','81/500'],
  [50,'9/20','40/9','9/5','2','171/1000']]
}
def need(x,s):
 if not x:raise ValueError(s)
def verify(o):
 need(type(o)is dict and set(o)==set(OBJECT),'complete exact object')
 need(o['format']==OBJECT['format'],'theorem name')
 # Parse only rational strings and integer vectors, rejecting bool-as-int.
 for key in ('window_max','secant_sum'):
  need(type(o[key])is str,'rational string')
 for key in ('u_endpoints','first_exponent'):
  need(type(o[key])is list and len(o[key])==2 and all(type(x)is str for x in o[key]),'ordered rational endpoints')
 for key in ('rational_numerator','rational_denominator','rational_derivative'):
  need(type(o[key])is list and all(type(x)is int for x in o[key]),'integer polynomial')
 for key in ('first_prefactor','first_argument_divisor','comparator_exponent_divisor','comparator_rational_multiplier','comparator_gamma_divisor','comparator_floor'):
  need(type(o[key])is int,'integer formula scalar')
 w=F(o['window_max']);u,v=map(F,o['u_endpoints'])
 need(w==F(1,4) and 0<w<F(1,2),'selected disjoint window domain')
 need(u==F(1,4) and v==F(81,100) and u<v,'complete first-frequency interval')
 need(F(o['secant_sum'])==u+v,'secant slope endpoint sum')
 # c(y)-[c(u)+s(y-u)]=(M+3)(y-u)(v-y)/24.
 yminus=[-u,F(1)];vminus=[v,F(-1)]
 prod=lag.mul(yminus,vminus)
 need(prod==[-u*v,u+v,F(-1)],'concave quadratic secant residual')
 need(list(map(F,o['first_exponent']))==[u/2,-u*u/24],'first exponential at u')
 need(o['first_prefactor']==1/(2*u) and o['first_argument_divisor']==1/u,'first integral scaling')
 R,D=o['rational_numerator'],o['rational_denominator']
 need(R==lag.OBJECT['R'] and D==lag.OBJECT['D'],'accepted positive Laguerre fraction')
 deriv=lag.add(lag.mul(lag.deriv(R),D),lag.scale(lag.mul(R,lag.deriv(D)),-1))
 need(deriv==o['rational_derivative'] and all(x<0 for x in deriv),'complete positive-ray derivative sign')
 need(o['comparator_exponent_divisor']==2/u and o['comparator_rational_multiplier']==1/(2*u),'Gaussian comparator exact scaling')
 need(o['comparator_gamma_divisor']==6*F(1,2),'Mills gamma multiplier')
 need(o['comparator_floor']==5 and 2*o['comparator_floor']/o['comparator_exponent_divisor']>1,'comparator all-index monotonicity')
 # Pearson: E[(X^2-1-gamma X)^2]=M-1-gamma^2>=0.
 # Checking the expansion after EX=0, EX^2=1, EX^3=gamma.
 square=lag.bmul({(2,0):F(1),(0,0):F(-1),(1,1):F(-1)},{(2,0):F(1),(0,0):F(-1),(1,1):F(-1)})
 pearson={}
 for (xdegree,gdegree),coefficient in square.items():
  if xdegree==1:continue
  key=(1,gdegree) if xdegree==4 else (0,gdegree+(1 if xdegree==3 else 0))
  pearson[key]=pearson.get(key,F(0))+coefficient
 pearson={key:value for key,value in pearson.items()if value}
 need(pearson=={(1,0):F(1),(0,0):F(-1),(0,2):F(-1)},'Pearson exact expectation expansion')
 k.constants();lag.verify(lag.OBJECT)
 one,best=new.install(k)
 need(type(o['examples'])is list and len(o['examples'])==3,'fixed example cover')
 need(o['examples']==OBJECT['examples'],'named conditional numerical targets')
 results=[]
 for row in o['examples']:
  n=row[0];a,m,d,M,target=map(F,row[1:]);bound,terms=best(n,a,m,d,M,F(9,100))
  need(len(terms)==6 and all(x>0 for x in terms),'all six pieces retained')
  need(bound<target,'fixed conditional numerical bound')
  results.append({'N':n,'bound':str(bound),'target':str(target),'six_terms':[str(x)for x in terms]})
 return {'conditional_examples':results,'windows':'0<r<=1/4','identities':11,'all_index_scope':'Every displayed term is evaluated at N only after its positive damping and monotonicity gates pass.'}
def controls():
 bad=[]
 for key in ('secant_sum','window_max'):
  z=copy.deepcopy(OBJECT);z[key]='1/2';bad.append(z)
 for key in ('first_prefactor','first_argument_divisor','comparator_exponent_divisor','comparator_rational_multiplier','comparator_gamma_divisor','comparator_floor'):
  z=copy.deepcopy(OBJECT);z[key]+=1;bad.append(z)
 for key in ('rational_numerator','rational_denominator','rational_derivative'):
  z=copy.deepcopy(OBJECT);z[key][0]+=1;bad.append(z)
 z=copy.deepcopy(OBJECT);z['u_endpoints'].reverse();bad.append(z)
 z=copy.deepcopy(OBJECT);z['u_endpoints'][1]=z['u_endpoints'][0];bad.append(z)
 z=copy.deepcopy(OBJECT);z['examples'].reverse();bad.append(z)
 z=copy.deepcopy(OBJECT);z['examples'].pop();bad.append(z)
 z=copy.deepcopy(OBJECT);z['examples'].append(z['examples'][0]);bad.append(z)
 z=copy.deepcopy(OBJECT);z.pop('first_exponent');bad.append(z)
 z=copy.deepcopy(OBJECT);z['first_prefactor']=True;bad.append(z)
 for z in bad:
  try:verify(z)
  except (ValueError,TypeError,IndexError):pass
  else:raise ValueError('invalid formula object accepted')
 one,_=new.install(k);base=[47,F(12,25),F(25,6),F(19,10),F(3,2),F(1,4)]
 domain=[(0,4),(0,F(47)),(1,F(0)),(1,F(11,10)),(2,F(0)),(3,F(0)),(3,F(13)),(4,F(9,10)),(4,F(12)),(5,F(0)),(5,F(251,1000))]
 for i,x in domain:
  row=base[:];row[i]=x
  try:one(*row)
  except ValueError:pass
  else:raise ValueError('invalid numerical domain accepted')
 return {'formula_controls':len(bad),'domain_controls':len(domain)}
if __name__=='__main__':
 need(len(sys.argv)==1,'no extra arguments')
 out=verify(OBJECT);out.update(controls());out['status']='PASS_HIGH_WINDOW50_EXACT'
 out['source_sha256']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()for name in('accept_high_window50.py','high_window_core.py','accept_high_tail.py','kernel.py')}
 print(json.dumps(out,sort_keys=True))
