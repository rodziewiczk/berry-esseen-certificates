# Independent final cutoff-50 composition review

## Result and scope

The selected mathematical dependency chain has no unresolved edge found in
this review. With its stated published inputs, the assembled argument gives
`C_n < C_E` for every integer `n >= 50`. It does not prove the full sharp iid
conjecture at all smaller indices. The proof is computer assisted; neither
Lean formalization nor an external referee review is asserted.

This review combines the previously recorded independent derivations and
component source reviews with a final review of the global composition,
48 selected jobs, proof/data inventory, and fixed composition checker. The
companion JSON binds exact sources and recorded execution evidence. Archive
extraction and final PDF delivery checks are separate packaging obligations.

## The noncircular dependency chain

1. **Independent foundation and tail.** The preserved cutoff-99 proof obtains
   its own `.7/n` ceiling from index94 using ANCHOR90, finite propagation
   through188, and the supported STOP180 theorem thereafter. Its local95
   comparison then forces four losses. It uses none of the new index40/45/47
   results. The complete preserved manuscript, certificate sources, final
   review and both 21-job execution records are included. The extracted
   replay has all21 jobs successful and unchanged sources. Therefore using
   this theorem to close `n >= 99` here is not circular.
2. **Earlier unrestricted ceilings.** The selected ceiling40 checker includes
   ANCHOR40, its independently derived heat-support row, and the contiguous
   finite propagation bands41--49,50--69,70--98. The old99 tail supplies the
   remaining indices. The sharper `.7/n` ceiling then uses ANCHOR45 and the
   first-failure PROP46 exclusion through98. The predecessor smoothing cap
   supplies `.432` without assuming monotonicity of `C_n`. At index45 the
   earlier `1.5/n` ceiling supplies `.4431` and decrement less than `.8341`.
   Both needed support rows are selected. Thus the sharper ceiling is
   available before any new local47 comparison.
3. **Unrestricted local entry.** At a hypothetical index47--98 with
   `C_n >= C_E` and decrement at most `.19`, the ceiling supplies current
   cap `.4247` and current/two-deleted caps `.4253`. Fixed-index attainment
   includes equality at `C_E` and gives a positive closed attaining pair.
   The unrestricted all-threshold radius3.84 support and full signed
   INITIAL47 cover apply to that same pair. Higher moments are used only
   after support has been established.
4. **Central acquisition is acyclic.** PREP47 first supplies the hypotheses
   of the radius2.5 contact contraction. INPUT47 then acquires the original
   45 central panels. Original confinement supplies the first contracted
   radius, which licenses first feedback. The stronger Sperner confinement
   consumes the already acquired original input, and second feedback uses
   that separately established amplitude. It does not assume its own
   improved output to prove confinement. The componentwise implications
   from later scalar bounds to earlier premises are explicitly checked.
   The optional all-H radius2.34 theorem is retained but not essential to
   this selected route.
5. **Left acquisition is acyclic.** The complete complement of the central
   probability range is first refined from INITIAL47. Acquired moment caps
   license radius3.0 support and the first left input. Signed variance
   resource refinement, followed by its proved radius2.7 contraction,
   leaves38 contiguous panels `[.304,.38]`. Their exterior strip and
   Sperner amplitudes are proved before any final comparison. The final
   central comparison uses its own acquired second-feedback table, while
   the left comparison uses its own left270 table; quadratics are never
   borrowed across probability panels.
6. **Signed Fourier orientation is included.** The auxiliary paired Fourier
   estimate may orient by `|gamma|` because simultaneous reflection flips
   both odd coefficients and the auxiliary threshold, preserving the
   integral and its bound in `|H|`. The actual law, positive closed branch,
   signed beta, contact coefficients and phase data stay unchanged. The
   explicit orientation proof repairs the earlier prose seam and is in
   the manifest and manuscript. Original signed `gamma >= 0` is not assumed.
7. **Every positive-noise phase is covered.** Wide TINY covers all phases for
   `0 < lambda <= .05`. Above that, central LOW plus central MID cover all
   phases. Base left LOW has radii `.09/.14/.19/.29/.5`; left MID covers
   both complements in the first three noise bands and only the negative
   complement in `.10--.12`. The extra positive left LOW covers
   `u in [.29,.5]` in that fourth band. Every interval is clipped at its
   actual panel ceiling. Exact partition checking retains all closed
   endpoints, both signs of H, and both nearest-count choices at ties.
   Resource-excluded boxes, including the one wholly excluded base-left
   row and two wholly excluded positive-left rows, remain in the cover.
8. **Binary comparison and zero noise.** Central probabilities lie inside
   the published Bernoulli theorem's domain `[1/3,1/2]`. The separately
   accepted finite Bernoulli theorem covers the left range for47--98 and
   `|k-np| <= 1.25`; the acquired shift bound implies this count condition.
   No published theorem is extended below `p=1/3`. At zero conditional
   variance the law is binary; an attained positive closed maximum occurs
   at a binomial atom. The same binary bounds then apply directly. No
   positive-noise division or limiting argument is used at zero.
9. **The final selector.** The complete local comparison forces
   `a_(j-1) > a_j + .19/j` whenever47<=j<=98 and `a_j>=0`. Four successive
   applications keep the needed predecessors positive without assuming
   monotonicity or a common optimizer across indices. Their sum contradicts
   `a_(n-4)<.7/(n-4)` for50<=n<=98. At50 the exact reserve is
   `2930539/6356280000`; for n>=51 the simpler affine-numerator estimate
   is positive. The independent old99 tail closes infinity.

## Checker semantics and source inventory

Read both `accept_cutoff50_composition.py` and its named V2 successor in
full. Their theorem scope is fixed; the V2 change does not alter arithmetic,
jobs, mathematical targets or proof sources. The checker performs fresh
scalar and file/log-integrity checks. It does **not** rerun the48 underlying
jobs, and does not infer analytic reductions from a printed PASS. Its five
manifest mutation tests are integrity controls; the other two controls are
genuine false scalar shortcuts. These categories should remain distinct.

The48 selected jobs include every essential new arithmetic stage listed
above. The preserved old99 arithmetic is an explicit prior dependency,
supported by its independently completed21-job replays, rather than being
misdescribed as another new job. The harmonic fractional-part scalar proof
and its exact old99 acceptance are retained. All selected job entrypoints
match their recorded start snapshots. A conservative static check finds
155 local-import edges and no missing local module family in the manifest.
This static check supplements, rather than replaces, semantic review and
the per-component bindings.

Some old run working-directory snapshots contain subsequently edited
neighboring files. The observed differences are proofs subsequently bound
by analytical review, an unrelated regression-control script at the old
signed-entry runs, and LOW modules unrelated to the finite-binary job.
None changes an arithmetic dependency of the corresponding selected job.
The selected regression-control job has its own successful updated run.
The exact discrepancies are recorded in the companion JSON for auditability.

The inventory intentionally retains historical and optional proof notes.
They are not all premises of the selected theorem. In particular, an old
TINY45B candidate has a recorded derivative defect and is superseded; the
selected wide TINY theorem uses the independently reviewed corrected
shifted-quartic argument. The selected job list and this dependency chain,
not mere presence in the capsule, identify the accepted route.

## V1 layout mismatch and V2 repair

The original V1 manifest was successfully checked, but became stale when
`paper50/build/main.pdf` was rebuilt. Independent final inspection detected
that mismatch. V2 removes exactly26 draft-layout artifacts: that PDF and
the25 PNGs for draft pages41--65. Its850 remaining file/hash pairs are
identical to V1; there are no added or altered mathematical files. Its48
jobs and exact scope are identical. The V2 checker differs only in the
manifest filename, fixed manifest hash and schema. Final PDF bytes must
therefore be bound separately after the last build; V1 is retained as a
historical record and must not be represented as a current PDF binding.

All draft pages41--65 were personally visually inspected and found clean.
This review does not silently transfer that QA to changed final page bodies.

## Conclusion

No missing mathematical dependency, uncovered local case, invalid scalar
selector, or circular use of cutoff99 was found in the selected route.
Fresh component arithmetic and independent analytical reviews jointly
support the cutoff-50 conclusion at the stated scope. Final package and
PDF byte verification should be recorded separately, with any new failure
preserved rather than overwriting its provenance.
