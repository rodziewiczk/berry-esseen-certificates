# Cutoff50: coordinator's mathematical review

## Statement and boundary

For each integer n≥50, the unrestricted normalized iid Berry–Esseen
constant C_n is strictly below C_E=(3+sqrt(10))/(6sqrt(2pi)). The proof
uses the cited published finite bounds, finite contact/Fourier inputs,
and Bernoulli theorem, with the complete project-specific arguments
and exact rational certificates. It is not a Lean formalization and
has not received an external referee's review. The unrestricted finite
range below50 and the full sharp conjecture remain open.

Mathematical status: locally derived and checked computer-assisted proof,
with explicitly cited external theorem inputs.

Execution status: all48 selected component/coverage/control runs and the
final V2 composition have fresh successful runs. The portable capsule
has a further full replay; its final outcome is recorded separately in
the release verification file, not assumed in this review.

## What was personally read and reconciled

The coordinator read the original actual-count transfer, all-count
curvature and harmonic proof, the active-forward-mark and shared-background
improvements, the centered-Poisson cubic derivation, exact finite
normalization, strict-gap antichain confinement, the shifted-quartic
small- and intermediate-noise arguments, the signed conditional variance
resource, paired Fourier orientation, acquired support and moment
refinement, the left strip and finite Bernoulli calculation, and the
final exact coverage and four-step composition. Independent reviewers
derived the new lemmas and the seams separately; their agreement is
not treated as a substitute for those proofs.

The new source `root/local47_composition.tex` states and proves the
complete local exclusion and the global theorem. The main manuscript
explains this route before giving all selected proof modules and the
unaltered complete cutoff99 foundation.

## Acyclic dependency graph

1. Published finite iid bounds and fixed-index attainment/contact give
   the unrestricted initial framework. Equality C_n=C_E is included.
2. The independently completed cutoff99 tail, initial anchor and
   first-failure propagation give a_n<1.5/n from40.
3. The anchor45, all-threshold support and first-failure propagation46–98
   sharpen this to a_n<.7/n from45. No new local47 result is used here.
4. For47≤n≤98, a_n≥0 and decrement≤.19 supply the current/deleted
   score caps and support. A complete signed initialization and all
   probability complements acquire every surviving panel.
5. Prior-table confinement → smaller support → refined entry is used
   only in this order. The final input is38 left panels[.304,.38] and
   45 central panels[.38,.47]. Budgets refer to the same actual law.
6. Exterior contact strips and biased antichain confinement give global
   and noise-dependent amplitude bounds. Conditional variance remains
   weighted in n; no fixed-law limiting argument is substituted.
7. Wide TINY covers all0<lambda≤.05. MID and three LOW certificates
   cover every remaining closed phase/noise rectangle. The fourth left
   MID band covers only negative phase; extra positive LOW is essential.
8. Central Bernoulli comparison uses the published theorem within its
   domain. Exact finite bounds cover the left range below1/3 for47–98.
   Zero noise is handled as an attained binary law, without division.
9. Thus a_j≥0 forces a_(j−1)>a_j+.19/j for47≤j≤98. Four successive
   applications contradict the ceiling for50≤n≤98; prior99 closes the tail.

Every global step uses unrestricted scalar suprema, not a common
optimizer across different indices. No monotonicity of C_n is assumed.

## Executable interfaces and negative controls

The three selected LOW checks verify20,259,757 exact gates in total.
Every finite box is either strictly excluded by its resource or receives
both endpoint checks. One entire base-left row and two entire positive
rows are empty by the strict resource; their score maxima remain
unavailable rather than being replaced by fabricated zeros.

The independent coverage checker verifies84,415 exact partition
representatives and585 central feedback implications. Representatives
are justified by membership being constant on the cells cut out by all
rectangle endpoints; this is exhaustive interval coverage, not sampled
positivity. It rejects phase gaps, noise gaps and omitted endpoints.

Fixed proof-object mutation controls, exact actual-law checks (including
zero conditional variances, tiny noise, asymmetry and threshold collisions),
and independent finite Bernoulli diagnostics are in the selected runner.
Diagnostics remain supplementary; continuous-domain arithmetic and
analytic derivations are separate obligations.

## Packaging correction

The first composition manifest inadvertently followed a draft-layout QA
record and bound the changing manuscript build PDF and25 draft images.
Its integrity check correctly rejected the promoted PDF. The separately
named V2 manifest removes exactly those26 layout artifacts, retaining
all850 mathematical source/evidence files and all48 selected jobs.
No formula, arithmetic target, accepted object or theorem scope changed.
The final manuscript is bound separately by the release verification.
The prior V1 record is historical, not the final acceptance interface.

## Remaining research

The argument does not settle unrestricted sample sizes below50. It also
does not claim that50 is the optimal cutoff or that the new estimates
cannot be strengthened. A formal proof-assistant development and external
mathematical review are distinct future tasks.
