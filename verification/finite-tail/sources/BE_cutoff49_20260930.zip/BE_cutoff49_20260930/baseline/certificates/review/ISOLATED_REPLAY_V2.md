# Portable replay of the declared writer

The original 48-job list and V1 runner remain unchanged. During replay, `accept_complement47.py` correctly rejected its already-existing output `complement47_accepted.json`. Its arithmetic had run, but that process was a failed replay and remains recorded as such.

`run_certificates_v2.py` keeps the same job list and adds one explicit writer declaration. The helper `isolated_acceptance.py` hashes every regular file in the capsule, rejects symlinks and special files, and makes a byte-identical full copy in a temporary directory. It verifies the copy and source tree before executing. In the copy alone it removes the one declared output, then executes the original acceptor with its assertions and target unchanged. It requires child exit zero, exact regeneration of the frozen output, restoration of the entire copied tree, and an unchanged original capsule. Any added, missing or modified file rejects the replay. The temporary copy is discarded afterward.

The output directory must be outside the capsule when this writer is selected. All 47 other selected jobs use the original read-only replay path. This is a packaging adaptation, not a change to a mathematical statement, numerical bound, program, or proof object. It does not patch source at runtime.

Example:

```sh
python3 -B work/below50_20260929/release_tools/run_certificates_v2.py \
  --workspace-root PATH_TO_CAPSULE \
  --only certificate_complement47 \
  --output PATH_OUTSIDE_CAPSULE
```

`WRITER_AUDIT_V2.json` binds all 48 selected entry scripts and an overapproximation of 101 locally imported modules. There are three write sites: the complement output and two guarded discovery/main blocks that the selected jobs do not invoke. The coverage checker already has a separate read-only wrapper. No selected active path overwrites an input.

Seven disposable controls in `local/final_review/check_isolated_runner_v2.py` exercise exact regeneration, wrong/missing output, an undeclared mutation, child failure, unsafe output placement, and symlink rejection. They leave their original test capsules unchanged. These controls check runner behavior, not the mathematical reduction.
