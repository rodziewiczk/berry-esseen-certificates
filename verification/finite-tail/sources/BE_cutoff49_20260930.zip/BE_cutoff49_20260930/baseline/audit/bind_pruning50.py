"""Bind the independently read source scopes, scalar run, and pruning note."""
from pathlib import Path
from hashlib import sha256
import json
import sys
assert __debug__ and not sys.flags.optimize
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
OLD=ROOT/'work/below50_20260929'
FOUND=ROOT/'work/below100_20260929/release/paper'
items=[
 HERE/'check_short_selector50.py',HERE/'pruning50.tex',HERE/'DEPENDENCY_PRUNING.md',
 HERE/'scalar_accept02/stdout.json',HERE/'scalar_accept02/metadata.json',
 HERE/'compile02/metadata.json',HERE/'build02/pruning50.pdf',
 ROOT/'work/optimized301_20260927/sources/He_Cheng_2609.06358v1.pdf',
 ROOT/'work/optimized301_20260927/sources/He_Cheng_2609.06358v1.txt',
 FOUND/'BE_cutoff99.pdf',
]
items += [FOUND/'sections'/f'{x}.tex' for x in
          ('introduction','identity','entry','entry95','localization','computation','whole_count')]
items += [OLD/x for x in (
 'root/local47_composition.tex','root/predecessor_score_cap.tex',
 'root/ceiling45_and_cutoff98.tex','root/propagation/ceiling40.tex',
 'root/accept_support47.py','root/panel_exterior_proof.tex','root/left_strip47_proof.tex',
 'root/low47_normalization_proof.tex','root/phase_low47_proof.tex',
 'root/low47_kernel.py','root/phase_left_low47_kernel.py','root/positive_left_low47_kernel.py',
 'root/cutoff50_dependencies_v2.json',
 'entry/initial47_panel_proof.tex','entry/local_signed_core.py','entry/accept_initial47.py',
 'entry/local_panel_core.py','entry/contracted_panel_core.py','entry/sperner_panel_core.py',
 'entry/coupled_panel_core.py','entry/paired_fourier_orientation47.tex',
 'entry/confined_feedback47_proof.tex','entry/high_window50_proof.tex',
 'local/tiny47wide_proof.tex','local/mid47a_proof.tex','local/left_mid47b_proof.tex',
 'local/confinement47_contract.py',
)]
assert len(items)==len(set(items)) and all(x.is_file()for x in items)
metadata=json.loads((HERE/'scalar_accept02/metadata.json').read_text())
scalar=json.loads((HERE/'scalar_accept02/stdout.json').read_text())
assert metadata['return_code']==0 and metadata['before']==metadata['after']
assert scalar['status']=='PASS_SHORT50_SCALAR_SEAMS'
assert len(scalar['positive_gates'])==14 and len(scalar['rejected_controls'])==11
files={str(p.relative_to(ROOT)):{'sha256':sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in sorted(items)}
out=dict(schema='SHORT50_INDEPENDENT_PRUNING_REVIEW_V1',
 mathematical_status='Independent analytic derivation and source-scope audit. Finite-base/least-failure composition is proved conditional on the unchanged entry/local component theorems, whose fresh release replay is separate.',
 execution_status='Fresh exact scalar acceptance:14 positive gates,11 false claims rejected; exact INITIAL47 nmax syntax checks. No expensive entry/local certificate replay claimed.',
 source_inspection='The source list binds the all-index interfaces, actual-Bernoulli comparison scopes, finite-base restrictions, and generic foundation fragments read for this audit.',
 external_input=dict(title='Jona Schulz, The optimal Berry-Esseen constant in the binomial case',year=2016,url='https://d-nb.info/1197702695/34',theorem='Theorem1, printedpage1, PDFpage11',scope='Every0<p<1 and every integern>=1: normalized discrepancy is strictly belowC_E. Narrower[1/3,2/3] applies onlytoitssecond,sharperenvelope.',method='Official thesis PDF inspected with web tool on2026-09-30; no local downloaded copy/hash claimed.'),
 quality=dict(pdf_pages=3,pdf='work/short50_20260930/audit/build02/pruning50.pdf',rendered_pages_inspected=[1,2,3],latex_warnings=False,visual_defects_found=False),
 removed_jobs=['certificate_ceiling40','integrity_ceiling45_composition','certificate_left_binary47','control_left_binary_independent','conditional_selector50','certificate_central_strip47'],
 remaining_generic_foundation='A.1–A.4;B.1–B.7; predecessor-contact formula; genericE.1–E.4; arithmeticH.1–H.2, with old numerical results omitted and retained delta lemmas supplied.',files=files)
(HERE/'PRUNING50_BINDING.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS_PRUNING50_REVIEW_BINDING','files':len(files),'sha256':sha256((HERE/'PRUNING50_BINDING.json').read_bytes()).hexdigest()}))
