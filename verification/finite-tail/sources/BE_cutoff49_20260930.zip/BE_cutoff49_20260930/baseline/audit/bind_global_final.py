"""Bind the final reviewed sources/PDF; the argument is the announced PDF hash."""
import json
import re
import sys
from pathlib import Path
from hashlib import sha256
from pypdf import PdfReader

assert __debug__ and not sys.flags.optimize
assert len(sys.argv) == 2 and re.fullmatch(r'[0-9a-f]{64}', sys.argv[1])
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = ROOT / 'work/short50_20260930'
PAPER = BASE / 'paper'
def digest(p): return sha256(p.read_bytes()).hexdigest()
pdf = PAPER / 'build/main.pdf'
assert digest(pdf) == sys.argv[1] and len(PdfReader(str(pdf), strict=True).pages) == 52
log = (PAPER / 'build/main.log').read_text()
assert not any(x in log for x in ('Warning', 'Overfull', 'Underfull', 'undefined'))
prior = json.loads((HERE / 'VISUAL_QA30_40_PRELIMINARY.json').read_text())
assert prior['inspected_pages'] == list(range(30, 41))
final_images = []
for name, h in prior['pages'].items():
    p = PAPER / 'finalqa06' / Path(name).name
    assert digest(p) == h
    final_images.append(p)
items = [Path(__file__), HERE / 'GLOBAL_FINAL_REVIEW.md', pdf, PAPER / 'build/main.log',
         HERE / 'VISUAL_QA30_40_PRELIMINARY.json']
items += final_images
items += [PAPER / 'RENDER_COMPARISON.json']
items += [PAPER / 'main.tex'] + sorted((PAPER / 'sections').glob('*.tex'))
items += [BASE / 'entry' / name for name in ('resource_entry.tex', 'entry_formula_atlas.tex', 'unsigned_formula_card.tex')]
items += [BASE / 'local/local_comparison.tex']
for name in ('PRUNING50_BINDING.json', 'LOCAL_CONSOLIDATION_BINDING.json', 'ENTRY_CONSOLIDATION_BINDING.json'):
    p = HERE / name
    binding = json.loads(p.read_text())
    # Check the mathematical-source files remain exactly those reviewed.
    for path, rec in binding['files'].items():
        if path.endswith('.tex') and path.startswith('work/short50_20260930/'):
            assert digest(ROOT / path) == rec['sha256']
    items.append(p)
run = ROOT / 'runs/short50_20260930/finite_base01'
meta = json.loads((run / 'metadata.json').read_text())
result = json.loads((run / 'stdout.txt').read_text())
assert meta['returncode'] == 0 and digest(run / 'stdout.txt') == meta['stdout_sha256']
assert result['status'] == 'PASS_FINITE_BASE_40_45_WITHOUT_TAIL' and result['closed_cells'] == 704
for name, h in meta['input_sha256'].items():
    p = BASE / 'finite' / name
    assert digest(p) == h
    items.append(p)
items += [run / name for name in ('metadata.json', 'stdout.txt', 'stderr.txt')]
items = sorted(set(items))
out = dict(
    schema='SHORT50_FINAL_INDEPENDENT_REVIEW_V1',
    mathematical_status='Independent complete analytic source review; no unresolved defect found. Depends on the explicitly cited external inputs and selected exact arithmetic.',
    execution_status='Fresh independent scalar seams and recorded finite-base/consolidation successes bound. Separate retained-job replay and portable archive verification are owned by the coordinator.',
    theorem='C_n<C_E for every integer n>=50, with no prior cutoff theorem or eventual-tail premise.',
    pdf=dict(sha256=digest(pdf), pages=52),
    visual_review=dict(pages=list(range(30,41)), result='All eleven full pages inspected, clean.',
        prior_pdf_sha256=prior['pdf_sha256'], final_page_images_identical=True),
    files={str(p.relative_to(ROOT)): {'sha256': digest(p), 'bytes': p.stat().st_size} for p in items},
)
target = HERE / 'FINAL_SHORT50_BINDING.json'
assert not target.exists()
target.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'status':'PASS_FINAL_SHORT50_INDEPENDENT_REVIEW','files':len(items),'sha256':digest(target)}))
