"""Bind the independently read enclosure proof; no expensive replay implied."""
import json
import sys
from pathlib import Path
from hashlib import sha256

assert __debug__ and not sys.flags.optimize
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
NEW = ROOT / 'work/short50_20260930/entry'
OLD = ROOT / 'work/below50_20260929'
RUN = ROOT / 'runs/short50_20260930/entry/validate_schedule03'
def digest(p): return sha256(p.read_bytes()).hexdigest()

expected = {
    'resource_entry.tex': 'cfefa5fc57a273f3039c499003bb8ddd179debf2e2a5208020c80e8c713c5f6e',
    'entry_formula_atlas.tex': '6f96560368181bab01038541371c9e19fc22d898f0d193e47f8a1764085bb5ed',
    'unsigned_formula_card.tex': 'e210dbe7773ffd68bcc6a6d9055b91b347de677ed6044db773e8187eccedfca5',
}
for name, h in expected.items(): assert digest(NEW / name) == h
meta = json.loads((RUN / 'metadata.json').read_text())
assert meta['returncode'] == 0 and digest(RUN / 'stdout.txt') == meta['stdout_sha256']
data = json.loads((RUN / 'stdout.txt').read_text())
assert data['status'] == 'PASS_STRUCTURAL_ENTRY_SCHEDULE_ONLY'
assert data['checks'] == 17897 and len(data['negative_controls']) == 14
assert data['scope']['upper_index'] is None and data['scope']['weighted_excess_cap'] == '7/10'
assert data['final_left_panels'] == 38 and data['final_central_panels'] == 45
for name, h in expected.items(): assert data['new_sources'][name] == h

items = [Path(__file__), HERE / 'ENTRY_CONSOLIDATION_REVIEW.md',
         RUN / 'metadata.json', RUN / 'stdout.txt', RUN / 'stderr.txt']
items += [NEW / name for name in expected]
items += [NEW / 'schedule.json', NEW / 'SOURCE_MAP_INPUTS.json']
schedule = json.loads((NEW / 'schedule.json').read_text())
for node in schedule['nodes']:
    for name, h in node['objects'].items():
        p = OLD / name
        assert digest(p) == h
        items.append(p)
# These sources implement the frozen formulas audited in the new text.
items += [OLD / 'entry' / (name + '.py') for name in (
    'kernel', 'local_signed_core', 'local_panel_core', 'contracted_kernel',
    'contracted_panel_core', 'sperner_panel_core', 'coupled_panel_core',
    'high_window_core', 'high_refinement', 'signed_variance_resource',
    'paired_conditional_gamma47')]
items += [OLD / 'local' / (name + '.py') for name in (
    'confinement47_kernel', 'confinement47_contract', 'sperner47_kernel', 'sperner47_contract')]
items += [OLD / 'entry' / (name + '.py') for name in (
    'accept_initial47', 'accept_central47', 'accept_complement47', 'accept_left_input47',
    'accept_confined_feedback47', 'accept_sperner_feedback47', 'accept_signed_resource47',
    'accept_left270_input47')]
sources = json.loads((NEW / 'SOURCE_MAP_INPUTS.json').read_text())['sources']
for rec in sources:
    p = ROOT / rec['path']
    assert digest(p) == rec['sha256']
    items.append(p)
items = sorted(set(items))
assert all(p.is_file() for p in items)
out = dict(
    schema='SHORT50_ENTRY_INDEPENDENT_REVIEW_V1',
    mathematical_status='Complete independent analytical source review with all reported scope/interface corrections resolved.',
    execution_status='Fresh structural schedule validation03:17897 checks and14 negative controls. Expensive arithmetic replay is separate, not claimed here.',
    scope=data['scope'],
    provenance_note='Older proof fragments listed in SOURCE_MAP_INPUTS are read-only provenance; their numerical cutoff conclusions are not premises of the new theorem.',
    visual_scope='Final integrated PDF inspection is separate; no stale standalone PDF is bound here.',
    files={str(p.relative_to(ROOT)): {'sha256': digest(p), 'bytes': p.stat().st_size} for p in items},
)
target = HERE / 'ENTRY_CONSOLIDATION_BINDING.json'
assert not target.exists()
target.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'status': 'PASS_ENTRY_CONSOLIDATION_REVIEW_BINDING', 'files': len(items), 'sha256': digest(target)}))
