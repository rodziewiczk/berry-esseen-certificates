"""Bind independently reviewed mathematics and its unmodified selected sources."""
import json
import sys
from hashlib import sha256
from pathlib import Path

assert __debug__ and not sys.flags.optimize
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
NEW = ROOT / 'work/short50_20260930/local'
OLD = ROOT / 'work/below50_20260929'
RUN = ROOT / 'runs/short50_20260930/local/consolidation04'
def digest(p): return sha256(p.read_bytes()).hexdigest()

assert digest(NEW / 'local_comparison.tex') == '0294c8578b10c3e43b366c1a48350bf1fb69703ec7c6b1917dd9604daab2b69d'
meta = json.loads((RUN / 'metadata.json').read_text())
data = json.loads((RUN / 'stdout.txt').read_text())
assert meta['returncode'] == 0
assert digest(RUN / 'stdout.txt') == meta['stdout_sha256']
assert data['status'] == 'PASS_LOCAL_CONSOLIDATION_INTERFACES'
assert (data['probability_panels'], data['exact_partition_checks'], data['scalar_coefficients']) == (83, 84415, 80)
assert data['harmonic_monotonicity_bernstein'] == ['48', '30', '132/5', '51/5']
assert len(data['recorded_components']) == 6
source_manifest = json.loads((NEW / 'LOCAL_SOURCE_MANIFEST.json').read_text())
items = [HERE / 'LOCAL_CONSOLIDATION_REVIEW.md', Path(__file__), NEW / 'local_comparison.tex',
         NEW / 'local_comparison_standalone.tex', NEW / 'CERTIFICATE_MAP.md',
         NEW / 'LOCAL_SOURCE_MANIFEST.json', RUN / 'metadata.json', RUN / 'stdout.txt', RUN / 'stderr.txt']
for name, expected in source_manifest['files'].items():
    p = OLD / name
    assert digest(p) == expected
    items.append(p)
for component in data['recorded_components']:
    run = ROOT / component['recorded_run']
    p = run / 'metadata.json'
    assert digest(p) == component['metadata_sha256'] and component['recorded_exit'] == 0
    items.append(p)
items = sorted(set(items))
out = {
    'schema': 'SHORT50_LOCAL_INDEPENDENT_REVIEW_V1',
    'mathematical_status': 'Independent complete analytical review, conditional only on the explicitly acquired local hypotheses and unchanged selected arithmetic certificates.',
    'execution_status': 'Fresh consolidation04 interface/coverage/scalar checks; original six expensive acceptances preserved and source-bound, not rerun here.',
    'scope': 'Actual signed score C < C_B uniformly for n>=47 and every acquired positive-noise cell; zero noise is exact Bernoulli. No finite upper-index premise.',
    'visual_scope': 'No new PDF layout inspection asserted in this mathematical binding.',
    'files': {str(p.relative_to(ROOT)): {'sha256': digest(p), 'bytes': p.stat().st_size} for p in items},
}
target = HERE / 'LOCAL_CONSOLIDATION_BINDING.json'
assert not target.exists()
target.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'status': 'PASS_LOCAL_CONSOLIDATION_REVIEW_BINDING', 'files': len(items), 'sha256': digest(target)}))
