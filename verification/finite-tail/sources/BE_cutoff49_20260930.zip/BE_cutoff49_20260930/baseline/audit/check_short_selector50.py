#!/usr/bin/env python3
"""Independent scalar seams for the finite-base/first-failure cutoff50 route.

This is a scalar acceptance, not a replay of entry or local certificates.
The associated note explicitly lists those mathematical dependencies.
No discovery module, old scalar checker, or proof kernel is imported.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import ast
import hashlib
import json
import sys


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def root_upper(x):
    need(isinstance(x, F) and x >= 0, 'nonnegative rational root')
    m = 10**12
    k = isqrt((x.numerator*m*m)//x.denominator)
    need(F(k*k, m*m) <= x < F((k+1)**2, m*m), 'exact root bracket')
    return F(k+1, m)


def predecessor_cap(n, barrier):
    return (root_upper(F(n, n-1))*(F('.40974')+barrier/(n-1))
            + root_upper(F(n, (n-1)**3))/15
            + F('.08')*root_upper(F(n))/(n-1)**2)


def main():
    need(__debug__ and not sys.flags.optimize, 'unoptimized Python')
    need(len(sys.argv) == 1, 'fixed scalar theorem; no target arguments')
    gates = {}

    def positive(name, x):
        need(x > 0, name)
        gates[name] = str(x)

    # These checks restrict previously accepted finite-band implications.
    # They do not assume or use an infinite ceiling or the old cutoff99.
    need(40*(F('.469')-F('.4095'))-F('1.5') == F('.88'), 'anchor40 decrement')
    need(set(range(41, 46)) <= set(range(41, 50)), 'only first propagation40 row needed')
    positive('anchor45_current_cap', F('.4431')-F('.40974')-F('1.5')/45)
    positive('anchor45_decrement', F('.8341')-(45*F('1.5')/44-F('.7')))
    positive('first_failure46_current_cap', F('.432')-predecessor_cap(46,F('.7')))
    need(set(range(46,51)) <= set(range(46,99)), 'finite signed propagation scope')
    need(F('.7')/45 < F('.19'), 'propagation decrement below local loss')
    positive('base_current_cap', F('.4247')-F('.40974')-F('.7')/47)
    positive('base_all_three_caps', F('.4253')-F('.40974')-F('.7')/45)
    four = F('.19')*sum((F(1,j) for j in range(47,51)), F(0))
    positive('four_losses_at_50', four-F('.7')/46)

    # At the least later failure C_(n-1)<CE<=C_n, so delta_n=0.
    # s=sqrt(n/(n-1)) <= sqrt(51/50) < 101/100; 1/sqrt(n-1)<1/7.
    # n(s-1)=s^2/(s+1) increases with s, hence decreases with n.
    su = F(101,100)
    positive('root51_upper', su*su-F(51,50))
    positive('inverse_root50_upper', F(50)-49)
    positive('scale_term_upper', F('.51')-su*su/(su+1))
    excess = F('.40974')*F('.51') + su**3*(F(1,15)+F('.08')/7)
    positive('least_failure_weighted_excess', F('.29')-excess)
    positive('least_failure_exterior_seam', F('.7')-F('.29'))
    positive('least_failure_current_cap', F('.4247')-F('.40974')-F('.29')/51)
    positive('least_failure_deleted49_cap', F('.4253')-F('.40974')-F('.7')/49)
    positive('strict_predecessor_cap', F('.4253')-F('.40974'))

    # Audit the apparent INITIAL47 finite upper endpoint algebraically.
    # Find the same fixed workspace either in the research checkout or in a
    # portable capsule's sibling certificates/ directory. No target override.
    marker = Path('work/below50_20260929/entry/local_signed_core.py')
    candidates = [q for parent in Path(__file__).resolve().parents
                  for q in (parent, parent/'certificates')]
    roots = [q for q in candidates if (q/marker).is_file()]
    need(bool(roots), 'fixed source workspace present')
    root = roots[0]
    signed = root/'work/below50_20260929/entry/local_signed_core.py'
    initial = root/'work/below50_20260929/entry/accept_initial47.py'
    tree = ast.parse(signed.read_text())
    occurrences = [n for n in ast.walk(tree) if isinstance(n, ast.Subscript)
                   and isinstance(n.slice, ast.Constant) and n.slice.value == 'nmax']
    need(len(occurrences) == 2, 'reviewed nmax occurrence count')
    # One guard compares floor <= upper label; the only arithmetic occurrence
    # is exactly K/p['nmax'], with selected barrier K=0.
    divisions = [n for n in ast.walk(tree) if isinstance(n,ast.BinOp)
                 and isinstance(n.op,ast.Div) and isinstance(n.right,ast.Subscript)
                 and isinstance(n.right.slice,ast.Constant) and n.right.slice.value=='nmax']
    need(len(divisions)==1 and isinstance(divisions[0].left,ast.Name)
         and divisions[0].left.id=='K', 'only arithmetic nmax occurrence is K/nmax')
    init_tree=ast.parse(initial.read_text())
    assigned=[n.value for n in init_tree.body if isinstance(n,ast.Assign)
              and any(isinstance(t,ast.Name) and t.id=='P' for t in n.targets)]
    need(len(assigned)==1 and isinstance(assigned[0],ast.Call), 'fixed INITIAL47 contract')
    keys={k.arg:k.value for k in assigned[0].keywords}
    need(ast.dump(keys['barrier'])==ast.dump(ast.parse('F(0)',mode='eval').body), 'zero barrier')
    need(isinstance(keys['n'],ast.Constant) and keys['n'].value==47, 'fixed floor47')

    controls = []
    # Each deliberately false proposed shortcut must be rejected.
    tests = {
        'three_losses_suffice': F('.19')*sum((F(1,j)for j in range(48,51)),F(0))>F('.7')/47,
        'anchor45_false_decrement': 45*F('1.5')/44-F('.7') < F('.83'),
        'anchor45_false_cap': F('.40974')+F('1.5')/45 < F('.443'),
        'prop46_false_cap': predecessor_cap(46,F('.7')) < F('.431'),
        'false_root51': F('1.009')**2 > F(51,50),
        'false_scale_price': F('.5') > su*su/(su+1),
        'false_weighted_excess_target': excess < F('.28'),
        'false_current_target': F('.40974')+F('.29')/51 < F('.415'),
        'false_base_three_caps': F('.40974')+F('.7')/45 < F('.4252'),
        'fifth_base_local_index46': 46 >= 47,
        'wrong_Schulz_scope_needed': F('.304') >= F(1,3),
    }
    for label,claim in tests.items():
        try: need(claim,label)
        except ValueError: controls.append(label)
        else: raise ValueError('false control accepted: '+label)
    def source_key(p):
        try:return str(p.relative_to(root))
        except ValueError:return '@auditor/'+p.name
    sources={source_key(p):hashlib.sha256(p.read_bytes()).hexdigest()
             for p in (signed,initial,Path(__file__).resolve())}
    print(json.dumps(dict(status='PASS_SHORT50_SCALAR_SEAMS',positive_gates=gates,
        weighted_excess_upper=str(excess),four_loss_reserve=str(four-F('.7')/46),
        rejected_controls=controls,source_sha256=sources,
        mathematical_status='Locally derived scalar implication, conditional on the explicitly listed finite entry and all-index local comparison theorems.',
        execution_scope='Exact scalar arithmetic and INITIAL47 nmax syntax audit only. No entry/local certificate replay or published theorem verification is claimed.'),indent=2))


if __name__=='__main__':main()
