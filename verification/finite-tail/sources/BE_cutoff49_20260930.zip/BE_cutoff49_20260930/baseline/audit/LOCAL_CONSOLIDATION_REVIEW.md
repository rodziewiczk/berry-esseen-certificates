# Independent review of the consolidated local comparison

## Result and scope

**Mathematical status:** independently read and checked. The consolidated proof gives the same six actual-law comparisons as the selected cutoff-50 certificates, uniformly for every integer `n >= 47`, conditional on the acquired row, support, amplitude, and shared resource hypotheses. No upper index bound, Bernoulli reserve, or cutoff-99 conclusion enters these comparisons.

**Execution status:** `consolidation04` freshly checked the 83 row interfaces, 84,415 exact coverage pieces, 80 harmonic scalar coefficients and the sixth-order gain coefficients. The six expensive certificate acceptances are preserved prior successful executions, not rerun by this review. The parent is separately replaying the retained arithmetic closure.

The reviewed mathematical source is `local_comparison.tex`, SHA256 `0294c8578b10c3e43b366c1a48350bf1fb69703ec7c6b1917dd9604daab2b69d`.

## Independent analytical checks

1. Direct subtraction proves the master identity for the actual closed CDF and the actual signed Bernoulli score. The outgoing count event is strict and the incoming event closed. Either nearest integer works at a tie.
2. The finite Stirling, entropy and derivative bounds give the stated mass, own-count variance, incoming-count and repair constants. The cubic absolute-moment expansion is licensed by the positive gap on every selected row. Only the positive signed binomial displacement needs the normal variance repair.
3. The shifted quartic is a pointwise sign-probability minorant. Its expansion about `r = z t`, concavity in variance, and the quadratic minorant of its fourth-degree phase term give valid closed-cell bounds. The negative far-phase Cantelli calculation uses the corrected derivative. Positive far phases use the positive normal increment. There is no division by zero noise.
4. The centered-Poisson comparison follows from the stated semigroup/Taylor argument. The infinite nearest-count bound includes the finite positive series and its geometric remainder. The LOW cubic identity instead uses the exact full cubic moment and the finite correction for negative low-count terms. Dividing by a lower endpoint of the chosen variance proxy is safe; it does not assert a lower bound on the actual variance.
5. The whole-count crossing argument retains both conditional laws. The active forward mark has the smaller inward threshold. Deleting the two different noises leaves the same background law, permitting the quadratic bound outside the asymmetric interval. No independence of the two deleted laws is asserted.
6. The conditional interpolation curvature, actual phase relation, first-moment displacement, harmonic estimate and cubic/normal repair use one common marginal. The harmonic scalar polynomial is an upper bound for `1-cos`, with the directed degree-ten coefficients displayed explicitly.
7. The lower variance factor must be positive. The final source explicitly requires `omega_- > 0`, as the selected normalizer gates already do. Thus the sixth-order exponential gain has positive rate. The derivative polynomial on `[0,3]` has Bernstein coefficients `48,30,132/5,51/5`, all positive.
8. Negative bracket and nonnegative inverse-index terms are checked before replacing the mass and index by their conservative bounds. Convex noise endpoint reduction is applied only after all its coefficients are frozen. Entirely excluded rows need no fabricated score maximum.
9. The six scope regions cover the full central/left phase and noise domains, retaining seam endpoints. Zero noise is the exact Bernoulli law. Schulz Theorem 1 applies to every probability in `(0,1)` and every positive integer index, so it closes both zero and positive noise without the finite-left Bernoulli calculation.

## Corrections resolved during review

The harmonic polynomial was clarified as an upper bound for `1-cos`, not for the cosine. The already checked positive lower variance factor was made an explicit premise. These are corrected in the bound source. No arithmetic target or accepted object changed.

The binding records current mathematical sources and the selected six-object source closure. It deliberately makes no final-layout claim for a PDF compiled before the last one-sentence premise edit. The constructor's later compile and visual QA are separate evidence.
