# Independent cutoff-50 dependency pruning

## Result

The older cutoff-99 theorem is unnecessary. Establish the excess ceiling only for indices 45–50, prove the bound at 50 with four local losses, and exclude the first later failure using the elementary smoothing recurrence. The complete derivation is `pruning50.tex`.

At that least failure, the recurrence gives the especially useful bound

`n(C_n−C_E) < 75975113/262500000 < .29`.

This supplies both the current-score cap and the `.7/n` hypothesis of the direct exterior tests. It is insufficient to check only the current cap; the signed exterior bound explicitly prices the excess as `.7/n`.

| Result | Mathematical status | Execution status |
|---|---|---|
| Schulz strict Bernoulli theorem for every p in (0,1), every n≥1 | External published theorem, exact statement inspected | Official source inspected; not locally re-proved |
| Finite-base and least-failure composition | Locally derived and independently checked, conditional on the existing entry/local component theorems | Exact scalar checker freshly passes; heavy certificates not rerun here |
| INITIAL47 has no effective upper index | Source and analytic scope checked: K=0 cancels the only arithmetic nmax use | Exact AST/source check passes |
| All six selected local comparisons compare actual C_B | Complete theorem/interface read and prior independent proof audits | Existing selected arithmetic unchanged |
| Qualitative eventual theorem alone bridges a missing finite range | Refuted as a logical inference | Explicit scalar counterexample below |

## Correct published scopes

Schulz, *The optimal Berry–Esseen constant in the binomial case* (2016), Theorem 1, printed page 1 (PDF page 11):

<https://d-nb.info/1197702695/34>

The normalized binomial discrepancy is strictly below `C_E` for every probability in `(0,1)` and every positive integer sample size. The additional restriction `[1/3,2/3]` belongs to a sharper envelope in the second part of the theorem. It does not restrict the first part. No finite left-binomial comparison or count-window verification is needed once the local result compares to the actual binomial score.

The supplied He–Cheng v1 Theorem 1.1 is **non-strict**: eventually `C_n≤C_E`, uniformly over laws. Its explicit bound is enormous; it is not a theorem asserting `C_n<C_E`. Its contact Lemma 4.3 does apply to any attained positive extremal value and includes the equality case needed here. The new composition needs no eventual theorem at all.

For the logical obstruction, choose an arbitrary integer `M>100`. Set `a_M=.35/M`, all other `a_n=-.001` for `n<M+1`, and `a_n=0` for `n≥M+1`. This sequence obeys an eventual nonpositive tail, the positive ceiling `.7/n`, and every local implication on 47–98 vacuously. Nevertheless it violates the desired strict bound at M. This is a scalar counterexample to the inference, not a counterexample involving actual Berry–Esseen constants.

## All-index audit

1. `entry/accept_initial47.py` already advertises n≥47. In `local_signed_core.py`, `nmax` occurs twice: the floor-versus-label format guard, and `c0=.4095+K/nmax`. The selected contract has `K=0`. All Fourier bounds apply at the worst floor N=47 and were proved uniformly for n≥N.
2. `local_panel_core.py`, `contracted_panel_core.py`, `sperner_panel_core.py`, and `coupled_panel_core.py` have no actual upper-index parameter. Their defect updates retain `nD≤Nd`; the binary charge yields `nθ≤N(d−b)/K`. This is the required weighted inequality, rather than multiplying an unweighted variance cap by the floor.
3. The support and exterior modules price all positive n-dependent errors at N=47. Their actual upper-index input is absent. They do require `0≤a_n≤.7/n` and `δ_n≤.19`, both supplied at the least failure.
4. Confinement, count normalization, TINY, MID and all three LOW modules have scopes n≥47. The finite interval 47–98 entered only the last composition through its unnecessarily limited Bernoulli certificate.
5. Each selected comparison is `rho_B(C−C_B^+(n,p,k))<−.001λ`. None substitutes the narrower Schulz envelope `G(p)` for the actual score. At λ=0 the law is exactly binary, so the all-p external theorem applies directly. Fixed-index attainment, including equality, remains essential.

## Finite dependencies actually used for the base

- ANCHOR40, with the preceding global finite cap and decrement `<.88`.
- Only the `[41,49]` support/entry propagation row, restricted to indices 41–45. Rows `[50,69]` and `[70,98]` are unused.
- ANCHOR45 and its support row.
- PROP46 and its support row, restricted to 46–50; using the original weaker high-index moment cap on this subset is valid.
- The complete all-index local47 interface at 47–50.
- Four local losses and the ceiling at 46.

No positive or strict assertion from cutoff99 is used. At a later least failure the two predecessor caps come from already established strictness, except index49 in the special case n=51, where the finite ceiling supplies it.

## Exact pruning of the old 48-job suite

Delete these six jobs from the new mathematical route:

1. `certificate_ceiling40`: replace with the finite ANCHOR40/first-row base acceptance; discard its old tail integrity edge.
2. `integrity_ceiling45_composition`: replace with the finite base and the new scalar composition.
3. `certificate_left_binary47`: replaced by Schulz's first inequality.
4. `control_left_binary_independent`: no selected left-binomial numerical proposition remains.
5. `conditional_selector50`: replaced by `check_short_selector50.py` and the new least-failure proof.
6. `certificate_central_strip47`: redundant old 47-row exterior object. `certificate_central_support47` already reconstructs 1,080 radius cells and the 1,431 strip cells for the selected 45 canonical input rows.

The other 42 jobs can retain their arithmetic. Their scope annotations and integrity closures must be rebound for a standalone new release. In particular, the old global composition wrappers and coverage metadata may mention old tail/binary inputs; those references are not evidence of a dependency of the underlying geometric or arithmetic statement. The new DAG must distinguish source-code imports from mathematical theorem dependencies.

## What to retain from the 54-page foundation

The following is a conservative sufficient *analytic core*, identified by exact source sections, not a claim that its wording is shortest possible:

| Old source | Retain | Original printed pages |
|---|---|---|
| `sections/introduction.tex` | Definitions, branch orientation, the two finite moment-dependent caps, corrected all-p Schulz input | Parts of 1–3, rewritten in the new introduction |
| `sections/identity.tex` | A.1–A.4: fixed-index attainment including equality; contact; smooth Fourier remainder; exact defect/leakage identity | 5–8 |
| `sections/entry.tex` | B.1–B.7: gap decomposition; positive-measure moment estimates; shared charge; event construction; full finite Fourier transfer; uniform feedback and cell rules | 9–24, with boundaries on 8/25 |
| `sections/localization.tex` | The predecessor-contact inequality and the cited finite global Gaussian estimate only | Part of 26 |
| `sections/entry95.tex` | Generic E.1–E.4 improvements: conserved phase budget, signed moment restrictions, radius-dependent estimates, wider paired-domain conditions; omit fixed ENTRY95/INPUT95 results | Parts of 30–34 |
| `sections/computation.tex` | H.1–H.2: rational enclosures, Bernstein transform, continuous coverage semantics | Parts of 52–53 |

The apparent positive-skew condition in the older paired specialization must be replaced by the already proved Fourier-only orientation clarification; the contracted-radius use also needs its `R≥2g` gate. These are new retained delta lemmas, not silently altered old hypotheses.

Do **not** retain old numeric STOP180, the old anchors/propagation, index-95 support/entry/exterior/confinement/normalization/LOW tables, the old cutoff99 selector, or their result inventory. The generic actual-count and LOW derivations at old G.6–G.7 already appear in the new local block and should be stated once there. The new finite Gaussian series likewise replaces old C.2/F rather than requiring both proofs.

At the original pagination, the substantive core above lies in the 28-page union `{5,…,24,26,30,…,34,52,53}`; some of those pages also contain obsolete boundary text. Thus at least 26 of the 54 appended pages are removable without compressing the retained generic derivations, in addition to deleting the full appendix wrapper page. This is a page-coverage comparison, not a measured page count of the revised manuscript. Removing the whole 54-page appendix while restating its generic core is a genuine dependency reduction; merely moving it to another PDF would not be.

Further large savings come from consolidating duplicate parameterized local proofs, not from the scalar shortcut alone. The old whole-count argument is repeated both in pages56–62 and in the appended foundation. TINY, central MID and left MID share quartic, Poisson, Bennett and normalization proofs. The newly consolidated local manuscript handles these once; that separate revision is being reviewed.

## Evidence limits

This audit inspected the listed source statements and their all-index semantics, and ran a new independent rational scalar checker with eleven false controls. It did not rerun millions of local gates or independently re-prove Schulz's dissertation. Bindings identify the exact source bytes inspected; they do not convert source integrity into a mathematical proof. The new finite-base component and newly consolidated manuscript need their own final source-bound replays/reviews before release.
