# Cutoff 49: finite base and one induction

The selected statement is `C_n < C_E` for every integer `n >= 49`, for the
unrestricted iid Berry–Esseen constants defined in the manuscript, with
`C_E=(3+sqrt(10))/(6 sqrt(2 pi))`. This is a computer-assisted research proof
using the cited published/preprint inputs. It is not a Lean formalization
or an external referee's certification.

## The new idea

Keep the established local implication at every index at least47. Improve
one auxiliary ceiling, from `46(C46-C_E)<.7` to `<.54`. A putative failure at49
then forces three predecessor losses of more than`.19/n`, whose sum is
strictly larger than`.54/46`. The exact surplus is`35419/254251200`.
A least later failure supplies its own local hypotheses by smoothing.

The new single-index exclusion uses support`[-3.4,3.4]`, four signed-moment
covers and three probability covers. Exact acceptance ends with`D<-.0046`,
contradicting the nonnegativity of the defect. Its support premise is acquired
independently, without using the new entry conclusion.

## A repaired sign issue

The audit found an omitted condition in a paired phase estimate: a negative
signed third-moment lower bound cannot be multiplied by a lower Gaussian
density. The new calculation includes the missing negative-part correction.
The earlier acquisition is separately replayed with sign-aware curvature,
against the same targets and every previously exported survivor resource.
Later uses have a separate sign-premise audit. See the new repair note and
logs. The preserved baseline archive contains the historical formulas;
its affected acceptance interfaces are superseded in this selected proof.

## Contents

- `BE_cutoff49.pdf`: complete manuscript, with the main argument first.
- `paper/`, `paper_entry/`, `paper_local/`, `entry/barrier46_proof.tex`: TeX.
- `entry/`: fixed corrected single-index proof object and exact acceptor.
- `root/`: fixed support46 and scalar-composition checks.
- `audit/`: independent analytic and arithmetic audits.
- `legacy_phase/`: separately named sign repair, replay, and domain audits.
- `baseline/`: byte-preserved earlier source/evidence capsule. Its global50
  conclusion is not a premise of this proof.
- `evidence/`: newly recorded runs, source hashes, output streams, and PDF QA.
- `DEPENDENCY_MAP.md`, `VERIFICATION.json`: scope and evidence boundary.
- `MANIFEST.json`: file integrity, not mathematical correctness.

## Reproduction

Use ordinary, unoptimized Python3.12 or later. Do not use`-O` or`-OO`.
No nonstandard Python package is required for arithmetic acceptance.
From the extracted archive run:

```sh
python3 -B verify.py --quick --output /tmp/be49-quick-new
python3 -B verify.py --output /tmp/be49-full-new
```

The output directory must be new and outside the source archive. Quick mode
checks every source hash and the cheap scalar/support/sign controls; it does
not replay the 74,016-cell entry or the retained baseline component suite.
Full mode also runs the fixed new and repaired acceptance plus the retained
component checks. It can take substantial time. The selected job list omits
the two superseded uncorrected acquisition runs.

To compile the manuscript, run`latexmk -pdf main.tex` from`paper/` with a
standard TeX Live installation. All decimals in proof tables are exact
rationals. Arithmetic PASS is distinct from the validity of the analytic
reductions and the correctness of the interpreter and acceptance programs.
No general theorem for the unrestricted remaining indices below49 is claimed.
