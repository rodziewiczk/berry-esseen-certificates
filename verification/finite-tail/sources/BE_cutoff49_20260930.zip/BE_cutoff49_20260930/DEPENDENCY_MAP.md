# Selected cutoff49 dependency graph

This map supersedes the global composition and two affected phase-acquisition
interfaces in the preserved baseline. Every edge refers to the same actual
law within a fixed index; scalar constants at different indices may have
different extremizers.

| Claim | Mathematical status | Execution status |
|---|---|---|
| Shevtsova finite estimates; Schulz all-parameter Bernoulli theorem; He–Cheng contact and Gaussian formula | Cited external inputs at the manuscript's exact scope | Not claimed to be machine verified |
| Attainment, closed/left-limit discrepancies, support compactness, smoothing | Locally derived analytic reductions, inherited and re-exposed | Analytic review; scalar checks do not replace these proofs |
| Finite ceilings`a_j<1.5/j`40..45 and`a_j<.7/j`45..50 | Preserved restricted composition of exact finite exclusions | Previously fresh PASS, reused unchanged with source integrity |
| Uniform LOCAL47 | Same-law resource, support, confinement, and Bernoulli comparison | Preserved checks plus new phase-scope audit and repaired acquisition replay |
| Support46 under`a46>=.54/46` | Same finite contact theorem, new instance; separately rederived by interpolation | Fresh exact support/ray PASS, independent arithmetic and false-target controls |
| Supported barrier46 | New four signed and three probability passes; signed phase corrected | Fresh fixed rational acceptance, 74,016 closed cells, 17 malformed/false controls |
| Sharper ceiling`a46<.54/46` | Composition of the previous two edges and old finite ceilings | Fresh independently reviewed scalar seams |
| Cutoff49 and infinite tail | Three-loss contradiction, then least-failure induction | Fresh exact scalar obligations; conditional on the preceding analytic/certificate dependencies |

## Exact edges

1. Published finite caps plus fixed-index compactness give attained positive
   contact. The cubic contact tail gives bounded support before higher moments.
2. Four unchanged supported exclusions A40/P41/A45/P46, their support rows,
   and smoothing prove only the finite ceilings required through50. No
   previously proved large-index or eventual theorem enters this edge.
3. Assume `a46>=.54/46`. The old ceilings give
   `delta46<46(.7)/45-.54=79/450` and`C46<.42496`. The all-threshold support
   row gives`|X|<3.4`. The fixed corrected barrier46 then contradicts`D>=0`.
4. LOCAL47 has the exact hypotheses
   `n>=47`, `0<=a_n<=.7/n`, `delta_n<=.19`, `C_n<.4247`, and
   `C_(n-1),C_(n-2)<.4253`. The acquired83-panel cover plus local comparison
   contradicts these premises, including zero-noise Bernoulli laws.
   PREP and complementary acquisition use new sign-aware acceptance.
   Later phase calls retain the original formula only with proved sign premises.
5. If `a49>=0`, the finite ceilings supply every cap for LOCAL47 at49,48,47.
   Hence `a46>.19(1/49+1/48+1/47)>.54/46`; the exact difference is
   `35419/254251200`. This contradicts3.
6. A least failure`n>=50` after49 has`delta_n=0`. Smoothing gives
   `n*a_n<50691940857/175000000000<.29`, using
   `sqrt(n/(n-1))<1.011` and`sqrt(n-1)>=7`. At50, the second predecessor48
   uses the finite ceiling; thereafter both predecessors are below`C_E`.
   All LOCAL47 premises follow, giving the contradiction for the whole tail.

## Evidence boundary

The old component sources/evidence remain unchanged. Their selected arithmetic
was freshly reproduced in the preceding cutoff50 delivery; unchanged components
are not falsely described as rerun in this improvement. The two uncorrected
phase-acquisition interfaces are replaced by a fresh corrected replay with the
same original targets, including every stored complement survivor bound.
The new support, barrier, sign audit, composition, and archive validation have
separate logs. Discovery experiments, including unsuccessful attempts at48,
are not premises. Source hashes establish integrity only. No Lean or
external-referee claim is made.
