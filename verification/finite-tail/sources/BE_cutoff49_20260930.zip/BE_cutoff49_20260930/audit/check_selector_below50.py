"""Exact independent scalar seams for proposed cutoff49/48 routes.

The improved a46 ceiling or stronger local tradeoff is a hypothesis.
This script cannot acquire either by arithmetic on the scalar constants.
"""
from fractions import Fraction as F
import json
import sys
assert __debug__ and not sys.flags.optimize

def need(v, s):
    if not v: raise ValueError(s)

def threshold(target, decrement=F(19,100)):
    need(target in (48,49), 'fixed candidate index')
    return 46*decrement*sum((F(1,j) for j in range(47,target+1)), F(0))

def ceiling_suffices(target, b):
    need(0 <= b <= threshold(target), 'too weak a46 ceiling')

def linear_suffices(target, eta):
    need(eta >= 0, 'positive tradeoff slope')
    bound = 46*F(19,100)*sum(((1+eta)**(j-47)/j for j in range(47,target+1)), F(0))
    need(bound >= F(7,10), 'tradeoff below required predecessor loss')
    return bound

def main():
    need(len(sys.argv)==1, 'fixed scalar obligations')
    gates={}
    def gate(name, value):
        need(value > 0, name);gates[name]=str(value)
    gate('49_ceiling_054_reserve', threshold(49)-F(27,50))
    gate('48_ceiling_036_reserve', threshold(48)-F(9,25))
    need(threshold(49)==F(3020107,5527200), '49 exact threshold')
    need(threshold(48)==F(8303,22560), '48 exact threshold')
    q=46*F(7,10)/45-F(27,50)
    need(q==F(79,450), 'new46 decrement from old45 ceiling')
    gate('current46_cap', F('.42496')-(F('.40974')+F('.7')/46))
    for j in (47,48,49):
        gate(f'own_cap_{j}',F('.4247')-F('.40974')-F('.7')/j)
        gate(f'deleted_cap_{j}',F('.4253')-F('.40974')-F('.7')/(j-2))
    gate('linear_tradeoff_eta027', linear_suffices(49,F(27,100))-F(7,10))
    # First failure after base49 or48: all positive recurrence bounds decrease.
    s=F(1011,1000)
    gate('sqrt49over48',s*s-F(49,48))
    gate('sqrt48_lower69over10',F(48)-F(69,10)**2)
    gate('scale_difference', F(51,100)-s*s/(s+1))
    tail = F('.40974')*F('.51')+s**3*(F(1,15)+F('.08')/F('6.9'))
    gate('first_failure_tail_below029',F('.29')-tail)
    gate('first_failure_own_cap',F('.4247')-F('.40974')-F('.29')/49)
    gate('base48_second_predecessor47',F('.4253')-F('.40974')-F('.7')/47)
    gate('base49_second_predecessor48',F('.4253')-F('.40974')-F('.7')/48)
    negatives=[]
    trials=[('49_ceiling055',lambda:ceiling_suffices(49,F('.55'))),
            ('48_ceiling037',lambda:ceiling_suffices(48,F('.37'))),
            ('49_loss024_with_old_ceiling',lambda:need(threshold(49,F('.24'))>=F('.7'),'loss too small')),
            ('reuse_old46_slow',lambda:need(q<=F('.7')/45,'new barrier has larger predecessor decrement')),
            ('reuse_old_sqrt101_at50',lambda:need(F('1.01')**2>F(50,49),'false square-root upper')),
            ('linear_tradeoff_eta026',lambda:linear_suffices(49,F('.26')))]
    for name,trial in trials:
        try:trial()
        except ValueError:negatives.append(name)
        else:raise AssertionError('false scalar claim accepted: '+name)
    print(json.dumps(dict(status='PASS_CONDITIONAL_SELECTORS49_48',
        mathematical_status='Proved conditional compositions; no new lower ceiling or stronger local inequality is acquired here.',
        execution_status='Fresh rational scalar gates and false-claim rejection controls.',
        a46_scaled_thresholds={str(j):str(threshold(j))for j in(48,49)},
        first_failure_na_upper=str(tail),positive_gates=gates,negative_controls=negatives),indent=2))

if __name__=='__main__': main()
