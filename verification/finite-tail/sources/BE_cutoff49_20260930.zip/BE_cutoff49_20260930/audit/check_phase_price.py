"""Independent exact checks for the signed density-product correction.

These finite controls supplement the complete two-case proof in the note;
they do not purport to establish a continuous assertion by sampling.
"""
from fractions import Fraction as F
import json, sys

def corrected(L,U,rho,D):
    return L*(F(79,25)*rho-3-D)-(U-L)*max(F(0),D-F(4,25))

def main():
    assert __debug__ and not sys.flags.optimize
    assert len(sys.argv)==1
    counts=dict(product=0,monotone_lower=0,excess_price=0)
    for L in (F(0),F(3,10),F(3675683260869565,10**16),F(2,5)):
      U=F(2,5)
      assert 0<=L<=U
      for rho in (F(1),F(101,100),F(11,10),F(3,2)):
       for D in (F(0),F(4,25),F(2371,10000),F(7,10)):
        g=F(79,25)*rho-3-D
        exact=min(L*g,U*g)
        assert corrected(L,U,rho,D)<=exact
        counts['monotone_lower']+=1
        for ph in (L,(2*L+U)/3,(L+2*U)/3,U):
         for gain in (F(0),F(1,10),F(1)):
          assert ph*(g+gain)>=corrected(L,U,rho,D)
          counts['product']+=1
    # An explicit false sign replacement is rejected.
    assert F(2,5)*F(-1,10)<F(3,10)*F(-1,10)
    # Price implication, including C below the available upper CE bracket.
    U=F(20487,50000); K=F(27,50); N=46
    for ce in (F(819,2000),U):
     for n in (N,47,99,1000):
      for C in (ce+K/n,ce+K/n+F(1,1000),ce+K/n+F(1,10)):
       assert n*(C-ce)>=max(K,N*(C-U))
       counts['excess_price']+=1
    # A full density gap is necessary at negative gamma in the sharp product.
    L=F(3,10);U=F(2,5);g=F(-1,10)
    assert U*g < L*g-(U-L)*(-g)/2
    print(json.dumps(dict(status='PASS_CONDITIONAL_PHASE_PRICE',counts=counts,
        negative_controls=['bare negative-gamma lower-density replacement',
                           'half-sized negative-product correction'],
        mathematical_status='Two-case product proof and separate convexity argument in phase_price_audit.tex.',
        execution_status='Fresh exact rational controls; no entry or cutoff theorem acquired.'),indent=2))

if __name__=='__main__':main()
