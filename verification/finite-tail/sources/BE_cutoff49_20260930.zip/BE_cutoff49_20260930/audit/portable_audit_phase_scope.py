"""Fixed all-job phase dependency map and later-call analytical licenses.

No imported entry arithmetic is used. The same actual law remains inside
its acquired input domain throughout every later refinement iteration.
The broad PREP/complement passes require their separately named corrected
replay; this checker does not supply that replay.
"""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import hashlib,json,sys

HERE=Path(__file__).resolve().parent
if (HERE.parent/'baseline/certificates/work/below50_20260929').is_dir():
    ROOT=HERE.parent/'baseline/certificates'
    JOBS=HERE.parent/'baseline/jobs.json'
else:
    ROOT=HERE.parents[2]
    JOBS=ROOT/'work/short50_20260930/jobs.json'
EXPECTED_MANIFEST='8ffe67c53fb9a689f62e71f48727a9fea785321b4739c92075a3cc5856504617'
_manifest=(HERE/'legacy_phase_scope_inputs.json').read_bytes()
assert hashlib.sha256(_manifest).hexdigest()==EXPECTED_MANIFEST
EXPECTED=json.loads(_manifest)
OLD=ROOT/'work/below50_20260929'
ENTRY=OLD/'entry'
INPUTS={}
def logical(p):
    return 'work/short50_20260930/jobs.json' if p.resolve()==JOBS.resolve() else str(p.resolve().relative_to(ROOT.resolve()))
def bind(p):
    p=p.resolve();name=logical(p);h=hashlib.sha256(p.read_bytes()).hexdigest()
    assert EXPECTED.get(name)==h,('fixed input source',name)
    INPUTS[name]=h
def load(p):
    bind(p);return json.loads(p.read_bytes())
def sqrt_bounds(x):
    assert x>=0
    scale=10**12;n=isqrt(x.numerator*scale*scale//x.denominator)
    lo,hi=F(n,scale),F(n+1,scale)
    assert lo*lo<=x<hi*hi
    return lo,hi
def license_row(label,index,l,u,d,t,radius):
    assert 0<l<u<F(1,2) and 0<=t<1 and 0<d<2 and 0<radius<=F(96,25)
    gc=sqrt_bounds((1-t)**3*(1-2*u)**2/(u*(1-u)))[0]-(F(96,25)+2*sqrt_bounds(u/(1-u))[1])*t
    # For u<1/2 the displayed gamma lower bound decreases with theta.
    # The acquired input moments of the actual law remain true throughout.
    assert gc>F(12,125),(label,index,str(gc),str(d),str(t))
    return dict(component=label,index=index,p=[str(l),str(u)],D=str(d),theta=str(t),radius=str(radius),
                license='nonnegative_actual_gamma',gamma_lower=str(gc))

def main():
    assert __debug__ and not sys.flags.optimize and len(sys.argv)==1
    jobs=load(JOBS);assert len(jobs)==43
    needs_replay={'certificate_central_prep47','certificate_complement47'}
    later={'certificate_central_input47','certificate_confined_feedback47','certificate_sperner_feedback47',
           'certificate_left_input47','certificate_signed_resource47','certificate_left270_input47'}
    mapping=[]
    for j in jobs:
        p=ROOT/j['cwd']/j['argv'][0];bind(p)
        category='corrected_phase_replay_required'if j['name']in needs_replay else'later_phase_license'if j['name']in later else'no_paired_phase_envelope_in_selected_calculation'
        mapping.append(dict(name=j['name'],entrypoint=str(p.relative_to(ROOT)),category=category))
    assert sum(x['category']=='corrected_phase_replay_required'for x in mapping)==2
    assert sum(x['category']=='later_phase_license'for x in mapping)==6
    records=[]
    prep=load(ENTRY/'central47_prep_proof.json');canonical=load(OLD/'local/conditional_input47.json')
    for j,target in enumerate(canonical['panels']):
        old=prep['rows'][j//5];l,u=map(F,target['p'])
        records.append(license_row('central_input47',j,l,u,F(old['D']),F(old['theta']),F('2.5')))
    confined=load(ENTRY/'confined_feedback47_table.json')
    for j,(old,target)in enumerate(zip(canonical['panels'],confined['panels'])):
        l,u=map(F,old['p']);records.append(license_row('confined_feedback47',j,l,u,F(old['D']),F(old['theta']),F(target['actual_radius'])))
    sperner=load(ENTRY/'sperner_feedback47_table.json')
    for j,(old,target)in enumerate(zip(confined['panels'],sperner['panels'])):
        l,u=map(F,old['p']);records.append(license_row('sperner_feedback47',j,l,u,F(old['D']),F(old['theta']),F(target['actual_radius'])))
    complement=load(ENTRY/'complement47_accepted.json')
    for old in complement['surviving_cells']:
        records.append(license_row('left_input47',old['index'],F(old['pl']),F(old['pu']),F(old['D']),F(old['theta']),F(3)))
    left=load(ENTRY/'left_input47_table.json')
    for name,source in [('left',left),('central',sperner)]:
      for j,old in enumerate(source['panels']):
        l,u=map(F,old['p']);radius=F(source['support_radius'])if'support_radius'in source else F(old['actual_radius'])
        records.append(license_row('signed_resource47_'+name,j,l,u,F(old['D']),F(old['theta']),radius))
    resource=load(ENTRY/'signed_resource47_table.json')
    for old in resource['panels']:
      if old['source']=='left_input47_table.json':
        l,u=map(F,old['p']);records.append(license_row('left270_input47',old['index'],l,u,F(old['D']),F(old['theta']),F('2.7')))
    for name in ('local_panel_core.py','contracted_panel_core.py','sperner_panel_core.py','coupled_panel_core.py',
                 'kernel.py','contracted_kernel.py','paired_conditional_gamma47.py','signed_variance_resource.py'):
        bind(ENTRY/name)
    assert len(records)==302
    # These are independent algebraic controls for the sign condition.
    assert F(2,5)*F(-1,10)<F(3,10)*F(-1,10)
    assert F('3.16')-3-F('.16')==0
    assert INPUTS==EXPECTED,'complete fixed input binding'
    result=dict(status='PASS_PORTABLE_LATER_PAIRED_PHASE_SCOPE',mathematical_status='The same actual law retains its acquired input moment licenses. Two broad components still require the separately named corrected replay.',
        execution_status='Fresh exact rational input-row licenses, with independent integer square-root enclosures.',
        jobs=mapping,licensed_input_rows=len(records),licenses={k:sum(z['license']==k for z in records)for k in ('small_defect','nonnegative_actual_gamma')},records=records,source_sha256=INPUTS)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
