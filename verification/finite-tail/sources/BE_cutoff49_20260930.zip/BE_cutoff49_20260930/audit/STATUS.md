# Below-50 independent audit checkpoint

## Proved reductions

- With existing LOCAL47, a new ceiling `46 a46 < .54` suffices for cutoff49. The exact largest sufficient ceiling is `3020107/5527200`.
- Cutoff48 analogously requires `46 a46 <= 8303/22560`; `.36` is a convenient sufficient target.
- A hypothetical local tradeoff `delta <= .19 + .27 n a_n` at47--49 also suffices for49 with the old `.7/46` ceiling. The positive-excess subtraction is algebraically valid but the tradeoff itself is not acquired.
- Either finite base48 or49 extends to every larger index by the old all-index LOCAL47 and a corrected smoothing enclosure. The old `sqrt(n/(n-1))<1.01` must not be reused at50; the new proof uses1.011 and obtains `n a_n<.29` for every least failure `n>=49`.

Mathematical status: independent complete conditional derivations in `selectors49_48.tex`. Execution status: fresh17 positive rational scalar gates and6 false-claim controls, logged under `runs/below50_push_20260930/audit/independent01/selectors`.

## Independently verified support46 row

At actual index46, attained positive maximum, excess at least`.54/46` and decrement at most`79/450`, the unchanged finite contact/heat theorem gives actual support inside`(-3.4,3.4)`. The decrement comes from the already proved predecessor ceiling at45. Current score is below`.42496` by the independent old ceiling at46.

Execution status: fresh independent exact verification using no imported arithmetic kernel:22 closed support intervals, degree11 Bernstein coefficients recovered through rational interpolation,1856 positive interval/ray gates and3 false-target controls. All endpoint interpolation data are reconstructed. Log: `runs/below50_push_20260930/audit/independent01/support46`. The polynomial degree bound follows directly from the displayed finite heat formulas.

This support row does not acquire the new ceiling. A new supported entry exclusion at46 remains necessary. The old `.7` object's final negative defect cannot be transplanted, since its barrier participates in its moment cover and all intermediate budget deductions.

## Additional analytic reviews

`root/finite_contact.py` is valid at a fixed actual integer index`n=N`: whole `C Q` is maximized at the same score endpoint, both signs and Gaussian-density endpoints are retained, and the signed finite remainder is priced with its correct sign. Since it retains negative Gaussian coefficient maxima, its N must not silently become a lower-index floor. Conditional hypotheses still require acquisition.

`tradeoff/positive_panel_core.py` correctly subtracts `K rho` from the phase budget before maximizing corners, leaving the raw upper bound unchanged. Clipping `A-K rho` upward to zero in the phase-root enclosure is safe. Its improved moment/phase outputs require the explicit premise`n(C-C_E)>=K`; no conclusion under merely`C>=C_E` is licensed.

## Layout and remaining work

The two-page selector note compiled without warnings; both full rendered pages were inspected and are clean. No cutoff below50 is claimed at this checkpoint. Await a fixed accepted supported entry exclusion, then bind its source and the resulting unconditional composition.

## Signed phase scope audit (subsequent finding)

The new exploratory index46 probability bridge exposed an omitted sign
condition in the paired phase curvature. A negative signed gamma lower bound
cannot be multiplied by a lower Gaussian density. The separately named
corrected bridge subtracts `(.4-phi_lower)*(D-.16)_+/2` before both raw and
resource square completions, and still reaches `D<-.0046` in exact discovery.
The corrected core, acceptor, object and proof have now been read in full;
see `BARRIER46_REVIEW.md` and `phase_price_audit.tex`. The corrected fixed
acceptance is pending. The new note compiles to two clean, visually inspected
pages; its 856 exact rational controls and two false algebraic claims pass
under `runs/below50_push_20260930/audit/phase_price01`.

The same inherited paired formula is being traced in the older LOCAL47
acquisition. Thirteen calls are not immediately licensed by `D<=.16` or the
simple conditional-moment proof of nonnegative actual gamma. A sign-aware
corner-envelope review/replay is required; no old result is silently assumed
unaffected. The new global cutoff49 composition remains conditional on this
scope resolution as well as its new supported exclusion.

## Final resolution

The corrected supported barrier46 replay is fresh PASS: seven covers,
74016 cells,17 rejection controls, final `D<-.0046`. The selected source
and pre-run/live hash equality are bound in `BARRIER46_BINDING.json`.

The legacy phase issue is closed by separately named corrected PREP and
complement replay V3 (same10+125 cells and all45 selected survivors) and
the independent exact proof `gamma>.096` on all302 later acquired input
domains. `PHASE_SCOPE_FINAL_REVIEW.md` gives the complete analytic/code
conclusion. `portable_audit_phase_scope.py` verifies all57 fixed input hashes
and the302 bounds in both the workspace and a capsule-shaped layout.
The older generic phase formula is not asserted without its sign premise.

The complete new composition now proves `C_n<C_E` for every `n>=49`, using
the preserved reviewed finite foundation, repaired LOCAL47, the new ceiling
at46, three predecessor losses, and the support-free least-failure induction.
`FINAL49_BINDING.json` (SHA256
`0177cd6b7be6cdc2eadb5453b9d9ce72a8cd403a9e001bde8f6231bf080f522a`)
binds114 files and the11-file integrated TeX closure. The final56-page PDF
hash is `acae228ac396263485218d7d92d99be145981f031070eceff35119b8fe63f212`.
All assigned pages29--42 were inspected individually and are clean;
their pixels agree exactly with the final render. No unrestricted result
for indices below49 is claimed. Packaging/portable final-capsule validation
remains with the coordinating agent.
