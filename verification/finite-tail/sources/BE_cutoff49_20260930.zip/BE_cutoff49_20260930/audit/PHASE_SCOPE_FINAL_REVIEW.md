# Signed phase scope: independent final review

## Outcome

The omitted sign condition is repaired. The separately named corrected
PREP/complement replay passes with all target resources needed by the selected
downstream proof unchanged. The six later paired jobs are licensed directly:
on each of their 302 acquired input domains the actual signed third moment
is greater than `.096`. Thus the old numerical target tables remain usable
with these explicit new dependencies. The generic uncorrected formula is not
asserted without its sign premise.

Mathematical status: independently derived and source-reviewed. Execution
status: fresh exact corrected replay V3 and independent 302-domain check PASS.
This is a repair to a proof step; no counterexample to the Berry--Esseen
assertion was found.

## Analytic argument

For gamma at least `g0=3.16*rho-3-D` and Gaussian density in `[L,.4]`, use
`q_signed=C*rho+min(L*g0,.4*g0)/2`. This is a valid lower curvature for every
sign of gamma. For fixed C it is concave in rho; for fixed rho it is affine
in C. Before completing squares, `A+f*abs(H)-q_signed*H^2` is therefore
separately convex. Four corners suffice, including after adding the affine
conserved-resource phase price. Positive corner divisors imply positive
divisors throughout. Every returned q, raw value and subsequent threshold
calculation uses the corrected tuple.

For the later input domains write `B=1_{X>0}`, `V=E(X|B)`, and `W=X-V`.
The support bound implies `W>=-R-V`. Conditional centering gives
`gamma>=E(V^3)+2E(V W^2)-R*theta`, hence the explicit bound in
`legacy_phase_repair.tex`. Its worst value on the acquired domain is bounded
at the upper p and theta endpoints. This concerns the same actual law and
does not depend on the numerical iteration's chosen theta field. It also
covers zero atoms in the nonpositive class.

## Code and coverage

The final selected replacement is `accept_phase_corrected_v3.py` with
`corrected_phase_callback_v2.py`. I read both files, their copied original
PREP/complement acceptors, the complete panel iteration and export code, and
the direct malformed-return/sign controls. V3 binds its fixed input manifest;
the callback checks four five-field corners and checks the old exact q formula
before replacing it. It does not obtain its target from the proof object.

All 10 PREP target cells and all 125 complementary cells are replayed. The
complete exclusion set and all 45 stored survivor identities are checked.
Every bound consumed by the selected later jobs is checked in its correct
direction: upper bounds for raw, defect, variance, rho, absolute beta, H,
lambda and inward gap; lower bounds for the inner endpoints and signed beta.
The final replay also runs 12 inherited rejection controls, three direct
positive controls and six direct rejection controls. Diagnostic unused
quadratic fields in the complement JSON are not an additional downstream
premise and are not claimed as independently compared by V3.

I independently reconstructed the six later input families directly from
their source tables, using a separate exact integer-square-root enclosure
implementation and no imported entry arithmetic. The common support radius
3.84 proves gamma>.096 for all 302 domains. The portable checker fixes and
checks all 57 source/input hashes. It passes both in the workspace and in a
minimal capsule-shaped copy.

The 43-job mapping consists of two broad paired jobs requiring V3, six later
paired jobs licensed by the actual-gamma check, and 35 jobs whose selected
arithmetic does not use the paired phase envelope. This classification does
not remove transitive dependencies: local confinement and comparison still
consume the now repaired resource tables. Initial and finite-barrier signed
kernels use their own sign-aware density endpoint minima; auxiliary HIGH,
support, normalization and actual-law controls do not invoke this paired
curvature. The exact map and source hashes are emitted by the independent
checker.

The exceptional-call diagnostic additionally finds identical corrected and
old raw/resource maxima on the 13 initially unlicensed calls. This is useful
corroboration, but the complete V3 replay, not that diagnostic, is the selected
proof of preservation.

## Composition conclusion

Together with the separately reviewed supported index46 exclusion and its
independent support check, the repaired all-index LOCAL47 input licenses
the three-loss argument for `C49<CE`. The support-free least-failure
recurrence then excludes every larger index. No unresolved analytic issue
remains in the new phase repair or the reviewed global composition. This
review is mathematical and executable-proof review, not Lean formalization
or external refereeing.
