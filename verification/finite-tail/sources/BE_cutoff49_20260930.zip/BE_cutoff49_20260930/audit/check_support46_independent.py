"""Independent exact interpolation certificate for the single-index R=3.4 row.

No inherited kernel is imported. Polynomial signs use degree-eleven
Bernstein interpolation at rational nodes, not the inherited power-basis
transform. Mathematical scope is conditional support exclusion only.
"""
from fractions import Fraction as F
from math import comb, isqrt
from hashlib import sha256
import json
import sys

assert __debug__ and not sys.flags.optimize
DEG = 11
N = 46
K = F(27, 50)
RADIUS = F(17, 5)
SLOW = F(79, 450)
def need(b, text):
    if not b: raise ValueError(text)

def inverse(a):
    n = len(a)
    z = [list(row) + [F(i == j) for j in range(n)] for i, row in enumerate(a)]
    for i in range(n):
        p = next(j for j in range(i, n) if z[j][i])
        z[i], z[p] = z[p], z[i]
        pivot = z[i][i]
        z[i] = [v / pivot for v in z[i]]
        for j in range(n):
            if j != i:
                t = z[j][i]
                z[j] = [a - t*b for a, b in zip(z[j], z[i])]
    need(all(z[i][j] == F(i == j) for i in range(n) for j in range(n)), 'inverse identity')
    return [row[n:] for row in z]

nodes = [F(j, DEG) for j in range(DEG+1)]
matrix = [[comb(DEG, k)*x**k*(1-x)**(DEG-k) for k in range(DEG+1)] for x in nodes]
inv = inverse(matrix)
need(all(sum(inv[i][k]*matrix[k][j] for k in range(DEG+1)) == F(i == j)
         for i in range(DEG+1) for j in range(DEG+1)), 'independent inverse multiplication')

def bernstein_by_values(values):
    return [sum(a*b for a, b in zip(row, values)) for row in inv]

def sqrt_interval(x):
    d = 10**12
    k = isqrt(x.numerator*d*d // x.denominator)
    lo, hi = F(k, d), F(k+1, d)
    need(lo*lo <= x < hi*hi, 'square-root enclosure')
    return lo, hi

def fixed_constants(beta=None):
    c = F('.4095') + K/N
    rho = min(F('.3031')*F('.646')/(c-F('.3031')),
              F('.3322')*F('.429')/(c-F('.3322')))
    b = F(8837908849, 15625000000) if beta is None else beta
    need(0 < b < 1 and (1+b*b)**2 > rho*rho*(1-b*b), 'signed second-moment cap')
    ell = sqrt_interval(F(N-1))[0]
    scale = sqrt_interval(F(N, N-1))[1]
    x = F(1, N); ec = F(48, 125)
    need((2*ec-F(3,4))-(ec+F(1,4))*x+(ec*ec-ec)*x*x-ec*ec*x**3 > 0, 'scale correction')
    return c, rho, b, ell, scale

def point_gates(u, slow, constants):
    c, rho, beta, ell, scale = constants
    v = N-1
    a = (u**3-3*u)/6
    h4 = u**4-6*u*u+3
    j5 = u**5-15*u
    # N=L=46: the favorable and adverse fifth-order endpoints coincide.
    fifth = j5/(120*v)
    w = a-F(15,2)*fifth
    e = F(51,14400*v)*u**6/ell + F(51,960*v)*(3*u*u-2)/ell + u/(8*v*v)
    numerator = (a-3*fifth)*w + h4*h4/(256*v)
    domination = (a/2-6*fifth-h4/(12*ell))*w + h4*h4/(256*v)
    q = -u**3+F(3,2)*rho*u*u+3*beta*u+F(48,125)*rho/N
    contact = F(2,5)*scale**3*numerator + scale**3*e*w + (c*q+rho*scale*slow)*w
    return (a, h4, j5, w, domination, -q, -contact)

def verify(slow=SLOW, radius=RADIUS):
    need(slow >= 0 and F('2.5') <= radius < F('4.5'), 'support domain')
    constants = fixed_constants()
    all_gates = []
    l = radius
    while l < F('4.5'):
        h = min(l+F(1,20), F('4.5'))
        rows = [point_gates(l+(h-l)*x, slow, constants) for x in nodes]
        for name, values in zip(('A','H4','J5','W','domination','negative_C','contact'), zip(*rows)):
            coeff = bernstein_by_values(values)
            need(min(coeff) > 0, f'{name} on {l},{h}')
            # Recover all interpolation data by the independently checked basis matrix.
            need(all(sum(a*b for a,b in zip(row,coeff)) == value for row,value in zip(matrix,values)), 'interpolation reconstruction')
            all_gates.extend((str(l), name, str(x)) for x in coeff)
        l = h
    c, rho, beta, ell, scale = constants
    # Each ray polynomial is cubic; signs of all endpoint derivatives prove the whole ray.
    u = F('4.5')
    q = (-u**3+F(3,2)*rho*u*u+3*beta*u+F(48,125)*rho/N,
         -3*u*u+3*rho*u+3*beta, -6*u+3*rho, F(-6))
    ray = (c*q[0]+u**3/15+u/5+F(1,2)+rho*scale*slow,
           c*q[1]+u*u/5+F(1,5), c*q[2]+2*u/5, c*q[3]+F(2,5))
    need(all(t < 0 for t in q+ray), 'all endpoint ray derivatives')
    all_gates += [('ray',str(i),str(-t)) for i,t in enumerate(q+ray)]
    return dict(closed_intervals=int((F('4.5')-radius)/F(1,20)),
                degree=DEG, gates=len(all_gates),
                minimum_contact=str(min(F(z) for _,name,z in all_gates if name=='contact')),
                gate_sha256=sha256(json.dumps(all_gates,separators=(',',':')).encode()).hexdigest(),
                constants=[str(v) for v in constants])

def main():
    need(len(sys.argv)==1, 'fixed row only')
    result = verify()
    negatives=[]
    for name, trial in [('false_moment_cap',lambda:fixed_constants(F('.5'))),
                        ('false_slow_target',lambda:verify(F(1))),
                        ('false_radius_target',lambda:verify(radius=F(3)) )]:
        try: trial()
        except ValueError: negatives.append(name)
        else: raise AssertionError('false target accepted: '+name)
    print(json.dumps(dict(status='PASS_SUPPORT46_INDEPENDENT_INTERPOLATION',
        mathematical_status='Conditional all-threshold actual-support theorem at n=46, barrier .54, decrement<=79/450; inherited finite contact/Gaussian lemma required.',
        execution_status='Fresh independent exact interpolation and ray verification; no imported certificate kernel.',
        row=dict(n=N,barrier=str(K),radius=str(RADIUS),slow=str(SLOW)),
        result=result,negative_controls=negatives),indent=2))

if __name__=='__main__': main()
