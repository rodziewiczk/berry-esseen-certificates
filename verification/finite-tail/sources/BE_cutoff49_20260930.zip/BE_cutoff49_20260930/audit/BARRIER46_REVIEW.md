# Independent review of the corrected supported index-46 exclusion

## Mathematical scope

The reviewed component excludes an attained, positively oriented maximizing
pair at the actual integer index 46 with support in `[-3.4,3.4]`, score at most
`.42496`, and `46(C46-CE)>=.54`. This is a supported exclusion. Its combination
with an earlier finite ceiling and the separate support implication is needed
to prove the new ceiling. Its combination with LOCAL47 is needed for cutoff49.

The four initial signed-moment passes use byte-identical copies of the earlier
signed kernel and HIGH refinement. The three new passes cover the complete
probability interval derived from the preceding actual defect bound, with
96 closed adjacent cells. General estimates always apply; paired estimates
are optional and require the explicit probability, moment, Pearson, binary
moment, and coefficient-ordering premises.

## Independent derivation

The barrier price `K*rho` is subtracted from the conserved-resource envelope
before maximizing the actual score and moment corners. The unshifted raw
remainder remains a separate invariant. The additional phase price consumes
only the previously acquired raw and defect bounds. Its positivity is checked
before division. The pair of complete general and paired maxima may safely
be intersected.

The original exploratory paired phase expression was not valid under its
stated general signed-moment scope. Its old lower curvature used a lower
Gaussian density with a potentially negative signed gamma bound. The new
`barrier46_corrected_core.py` explicitly subtracts
`(.4-phi_lower)*(D_upper-.16)_+/2` from both curvatures before completing
squares. The full two-case proof is in `phase_price_audit.tex`. The auxiliary
Fourier reflection does not alter the signed gamma in the actual phase
identity, and is not used as a repair.

The subtraction is constant on a probability cell; the prior phase price is
affine in rho. Thus the established separate score/rho convexity and the four
corners remain valid. The code checks all four corrected divisors and the
prior resource price. The paired lower score `.4095` relaxes the stronger
barrier lower score and is valid.

## Source and acceptance review

I read the entire corrected core, fixed acceptor, proof object, and explanatory
TeX. The acceptor fixes the scope and seven-operation order, rejects duplicate
JSON keys and noncanonical rationals, recomputes every cover, checks exact
incidence counts and strict invariant targets, and checks its deliberately
false arithmetic targets. Caching in the negative controls reuses arithmetic
that is independent of the claimed proof-object targets.

The seven target rows have strict positive raw bounds. Only the last defect
target is negative, so a negative invariant is never fed into another
calculation. Retaining an unchanged earlier raw/defect target is allowed only
when the other invariant strictly improves; that is a valid intersection of
already established invariants. The actual object strictly improves both at
every step. Its last target is `D<-.0046`, contradicting the nonnegative
actual defect.

The copies of `signed_core.py`, `kernel.py`, `high_refinement.py`, and
`high_window_core.py` are byte-identical to the preserved below50 working
sources. No old source or theorem was silently rewritten.

## Global composition

Independently read the new global manuscript route. The finite ceiling at
45 and 46 supplies the new support premise with decrement `79/450` and
own score below `.42496`. At a putative nonnegative score at49, LOCAL47 forces
three strictly positive predecessor losses. Their excess over `.54/46` is
exactly `35419/254251200>0`. A least later failure has zero decrement and,
by the support-free recurrence, excess `n*a_n<.29`; its two predecessor
caps come from minimality except for index48 at the first possible failure50,
where the already proved finite ceiling applies. No monotonicity of `C_n`
or shared extremizer across indices is assumed.

## Status at this writing

Mathematical status: corrected supported component and conditional global
composition independently derived and source-reviewed. The older LOCAL47
paired calls are undergoing a separate phase-scope audit; this review does
not silently license those calls. Execution status: corrected discovery PASS;
the fixed corrected replay is running. Final source/log binding follows its
completion. No new global cutoff is claimed by this file alone.
