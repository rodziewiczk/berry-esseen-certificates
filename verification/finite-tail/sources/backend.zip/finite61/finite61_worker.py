"""One fresh native action or LOW row in an isolated interpreter."""
from pathlib import Path
import hashlib
import importlib
import json
import os
import runpy
import sys


def need(value, message):
    if not value: raise ValueError(message)


def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    need(__debug__ and not sys.flags.optimize and len(sys.argv) == 2, "Fixed unoptimized child invocation")
    request_file = Path(sys.argv[1]).resolve()
    request = json.loads(request_file.read_bytes())
    task = request_file.parent
    capsule = task / "capsule"
    for name, pin in request["inputs"].items():
        path = capsule / name
        need(path.is_file() and not path.is_symlink() and digest(path) == pin, "Pinned source/data before import: " + name)
    cwd = (capsule / request["definition"]["cwd"]).resolve()
    need(cwd.is_relative_to(capsule), "Contained original numerical cwd")
    os.chdir(cwd)
    sys.dont_write_bytecode = True
    sys.pycache_prefix = str(task / "never-native-bytecode")
    runtime = tuple(Path(value).resolve() for value in {sys.prefix, sys.base_prefix})
    reads = set(); unexpected = set(); writes = set()
    active = True

    def audit(event, args):
        if not active or event != "open" or not args or isinstance(args[0], int): return
        try:
            path = Path(args[0]).resolve()
        except (TypeError, ValueError, OSError): return
        mode = args[1] if len(args) > 1 else None
        flags = args[2] if len(args) > 2 and type(args[2]) is int else 0
        writing = (type(mode) is str and any(value in mode for value in "wa+")) or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT))
        if writing:
            writes.add(str(path))
            need(path.is_relative_to(task), "Numerical child write outside private task")
            need(not path.is_relative_to(capsule) or path.relative_to(capsule).as_posix() not in request["inputs"],
                 "Numerical source/witness inputs are immutable")
        elif path.is_file():
            if path.is_relative_to(capsule):
                name = path.relative_to(capsule).as_posix()
                reads.add(name)
                if name not in request["inputs"]: unexpected.add(str(path))
            elif not any(path.is_relative_to(root) for root in runtime):
                unexpected.add(str(path))

    sys.addaudithook(audit)
    try:
        definition = request["definition"]
        if definition["kind"] == "native":
            script = (capsule / definition["script"]).resolve()
            sys.path[0] = str(script.parent)
            sys.argv = [str(script), *definition["arguments"]]
            runpy.run_path(str(script), run_name="__main__")
        elif definition["kind"] == "low-row":
            sys.path[0] = str(cwd)
            contract = importlib.import_module("central42_contract")
            kernel = importlib.import_module("central42_kernel")
            selected = [row for row in contract.read() if row["index"] == definition["index"]]
            need(len(selected) == 1, "One actual source target row")
            cfg = contract.selected(selected[0], definition["sign"], definition["H_cells"], definition["outer_phase_cells"])
            proof, report = kernel.evaluate(cfg)
            need(proof["contract"]["N"] == 42, "Actual contract index42; descriptive LOW47 is not scope")
            packet = dict(index=definition["index"], sign=definition["sign"], proof=proof, report=report)
            raw = (json.dumps(packet, indent=2) + "\n").encode("utf-8")
            with (task / "LOW-ROW.json").open("xb") as stream: stream.write(raw)
            print(json.dumps(dict(status="FRESH_LOW_ROW_PRODUCED_NOT_ACCEPTED", index=definition["index"],
                                  sign=definition["sign"], gates=report["gates"], row_sha256=hashlib.sha256(raw).hexdigest())), flush=True)
        else:
            raise ValueError("Unsupported native child mode")
    finally:
        active = False
        trace = dict(schema="be.finite61-child-read-trace/1", reads=sorted(reads),
                     unexpected_reads=sorted(unexpected), writes=sorted(writes),
                     source_inputs_immutable=True, original_numerical_code_unchanged=True)
        (task / "SOURCE-READ-TRACE.json").write_bytes(json.dumps(trace, sort_keys=True, separators=(",", ":")).encode())


if __name__ == "__main__": main()
