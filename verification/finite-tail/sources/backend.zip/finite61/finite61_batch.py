"""Source-only61:31 original native actions,152 fresh LOW rows,2 blocked joins.

This port reuses the frozen COUNT supervisor/CAS guards. It implements no
scheduler and never promotes conditional arithmetic to an all-law provider.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import sys
import count69_batch as common

HERE = Path(__file__).resolve().parent
MANIFEST_SHA = "c8d6228d6a1abd0b25a2f69ed35ae78f1e719a58e27e4fedf5af28e942469cdf"
COMMON_SHA = "abb1b2e93aae8ccd65b3597c60dc4c5cfe7c04545684077202960e83d6dd821b"
MAX_INPUT = 32 * common.MIB
ROW_FIELDS = {"index", "sign", "proof", "report"}
IMPORTED_DRIVER_SHA = common.sha(common.regular(Path(__file__)))


def identity(kind, value):
    return common.sha(("BEFRESHFINITE61/1\n" + kind + "\n").encode() + common.encoded(value))


def manifest(cache=None):
    cache = HERE if cache is None else Path(cache)
    raw = common.regular(cache / "MANIFEST.json", MAX_INPUT)
    common.need(common.sha(raw) == MANIFEST_SHA, "source_manifest", "Complete frozen finite61 source/data/task registry")
    return common.parsed(raw)


def definition(task_id, cache=None):
    data = manifest(cache)
    found = [row for key in ("actions", "low_rows", "collectors") for row in data[key] if row["task_id"] == task_id]
    common.need(len(found) == 1, "finite61_task", "One explicitly enumerated complete task")
    return found[0]


def tasks(cache=None):
    data = manifest(cache)
    return tuple(row["task_id"] for key in ("actions", "low_rows", "collectors") for row in data[key])


def _path(root, name):
    common.need(type(name) is str and not PurePosixPath(name).is_absolute() and "\\" not in name and ":" not in name
                and all(part not in ("", ".", "..") for part in name.split("/")), "source_path", "Contained original POSIX path")
    return root.joinpath(*PurePosixPath(name).parts)


def implementation():
    common.need(common.sha(common.regular(Path(__file__))) == IMPORTED_DRIVER_SHA,
                "adapter_changed", "No finite61 adapter mutation after interpreter import")
    common.need(common.sha(common.regular(HERE / "count69_batch.py")) == COMMON_SHA, "shared_guard", "Frozen common source/supervision guards")
    return {name: common.sha(common.regular(HERE / name)) for name in ("finite61_batch.py", "finite61_worker.py", "count69_batch.py")}


def _row_imports(data, row, paths, task, inputs, campaign_id):
    family = next(f for f in data["low_families"] if f["family"] == row["low_family"])
    expected = [r for r in data["low_rows"] if r["family"] == family["family"]]
    common.need(type(paths) is dict and set(paths) == {r["task_id"] for r in expected}, "complete_low_rows", "All and only the fresh signed row tasks")
    index = []
    for child in expected:
        origin = Path(paths[child["task_id"]]).resolve()
        result = common.parsed(common.regular(origin / "TASK-COMPLETED.json", MAX_INPUT))
        request = common.parsed(common.regular(origin / "SOURCE-REQUEST.json", MAX_INPUT))
        common.need(result.get("task_id") == child["task_id"] and result.get("campaign_id") == campaign_id
                    and result.get("source_manifest_sha256") == MANIFEST_SHA and result.get("outcome") == "FRESH_LOW_ROW_COMPUTED_NOT_ACCEPTED"
                    and common.encoded(request.get("definition")) == common.encoded(child) and result.get("implementation") == implementation(),
                    "fresh_low_binding", "Current matching source-bound producer task; coordinator must authenticate its execution receipt")
        raw = common.regular(origin / "LOW-ROW.json", MAX_INPUT)
        common.need(common.sha(raw) == result.get("row_sha256"), "fresh_low_bytes", "Whole actual new producer bytes")
        packet = common.parsed(raw)
        common.need(set(packet) == ROW_FIELDS and type(packet["index"]) is int and type(packet["sign"]) is int
                    and (packet["index"], packet["sign"]) == (child["index"], child["sign"]), "low_row_labels", "Strict same signed row")
        name = row["cwd"] + "/low_rows/" + child["file"]
        destination = _path(task / "capsule", name); destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw); inputs[name] = common.sha(raw)
        index.append(dict(index=child["index"], sign=child["sign"], file=child["file"], sha256=common.sha(raw)))
    raw = (json.dumps(dict(schema=family["index_schema"], rows=index), indent=2) + "\n").encode("utf-8")
    # The original unchanged binder explicitly requires its frozen index hash.
    # This equality follows only after all new row bytes have been generated.
    common.need(common.sha(raw) == family["reference_index_sha256"], "fresh_low_index", "New canonical complete index meets the original unchanged binder contract")
    name = row["cwd"] + "/" + family["index_name"]
    _path(task / "capsule", name).write_bytes(raw); inputs[name] = common.sha(raw)


def prepare(task_id, cache, task, *, campaign_id, rows=None):
    data = manifest(cache); row = dict(definition(task_id, cache))
    common.need(row["kind"] != "collector", "collector_blocked", "Final61 joins need current parents and an explicit new capture/source epoch adapter")
    common.need(type(campaign_id) is str and bool(campaign_id), "campaign_id", "Explicit current fresh campaign")
    task = Path(task).resolve(); common.need(not task.exists(), "fresh_task", "Exclusive complete finite61 task")
    (task / "capsule").mkdir(parents=True)
    inputs = {}
    for name, meta in data["files"].items():
        if row["kind"] == "low-row" and not name.startswith(row["cwd"] + "/"): continue
        if row["kind"] == "native" and name not in row["input_files"]: continue
        raw = common.regular(Path(cache) / "blobs" / meta["sha256"], MAX_INPUT)
        common.need(len(raw) == meta["bytes"] and common.sha(raw) == meta["sha256"], "source_blob", "Pinned original source or untrusted mathematical input")
        destination = _path(task / "capsule", name); destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw); inputs[name] = meta["sha256"]
    if row["kind"] == "native" and Path(row["script"]).name == "bind_low42.py":
        row["low_family"] = "central42_v2" if "central42_v2" in row["cwd"] else "left42_final"
        _row_imports(data, row, rows, task, inputs, campaign_id)
    packet = dict(schema="be.finite61-job-inputs/1", task_id=task_id, campaign_id=campaign_id,
                  definition=row, source_manifest_sha256=MANIFEST_SHA, implementation=implementation(), inputs=inputs,
                  historical_captures_staged=False, historical_low_outputs_staged=False,
                  current_parent_licenses_required=True, full_proof_pass=False)
    (task / "SOURCE-REQUEST.json").write_bytes(common.encoded(packet))
    guard(task)
    return packet


def guard(task):
    task = Path(task).resolve()
    request = common.parsed(common.regular(task / "SOURCE-REQUEST.json", MAX_INPUT))
    common.need(set(request) == {"schema", "task_id", "campaign_id", "definition", "source_manifest_sha256", "implementation", "inputs",
                                 "historical_captures_staged", "historical_low_outputs_staged", "current_parent_licenses_required", "full_proof_pass"}
                and request["schema"] == "be.finite61-job-inputs/1" and type(request["campaign_id"]) is str and bool(request["campaign_id"])
                and request["historical_captures_staged"] is False and request["historical_low_outputs_staged"] is False
                and request["current_parent_licenses_required"] is True and request["full_proof_pass"] is False,
                "request_schema", "Closed current finite61 request and honest conditional scope")
    common.need(request.get("implementation") == implementation() and request.get("source_manifest_sha256") == MANIFEST_SHA,
                "implementation_binding", "Exact finite61 adapter, child worker and frozen common guard")
    expected = dict(definition(request["task_id"]))
    if expected["kind"] == "native" and Path(expected["script"]).name == "bind_low42.py":
        expected["low_family"] = "central42_v2" if "central42_v2" in expected["cwd"] else "left42_final"
    common.need(common.encoded(request["definition"]) == common.encoded(expected), "definition_binding", "Exact frozen task scope, source code and controls")
    data = manifest()
    static = {name: meta["sha256"] for name, meta in data["files"].items()
              if (expected["kind"] == "low-row" and name.startswith(expected["cwd"] + "/"))
              or (expected["kind"] == "native" and name in expected["input_files"])}
    common.need(all(request["inputs"].get(name) == pin for name, pin in static.items()),
                "frozen_input_binding", "Request cannot replace any original code or frozen mathematical context")
    extra = set(request["inputs"]) - set(static)
    if "low_family" in expected:
        family = next(row for row in data["low_families"] if row["family"] == expected["low_family"])
        low = [row for row in data["low_rows"] if row["family"] == family["family"]]
        required = {expected["cwd"] + "/low_rows/" + row["file"] for row in low}
        index = expected["cwd"] + "/" + family["index_name"]
        required.add(index)
        common.need(extra == required and request["inputs"][index] == family["reference_index_sha256"],
                    "low_input_cover", "Only all exact newly generated signed rows and complete canonical index")
    else:
        common.need(not extra, "extra_input", "No undeclared numerical inputs")
    common.need(all(not path.is_symlink() for path in (task / "capsule").rglob("*")), "source_link", "Private source closure contains no links")
    actual = {path.relative_to(task / "capsule").as_posix() for path in (task / "capsule").rglob("*") if path.is_file()}
    common.need(actual == set(request["inputs"]), "source_inventory", "Only immutable inputs and explicitly imported new LOW bytes")
    for name, pin in request["inputs"].items():
        common.need(common.sha(common.regular(_path(task / "capsule", name), MAX_INPUT)) == pin,
                    "source_changed", "Every whole source/context/row byte unchanged")
    return request


def _stdout(text, rule):
    if rule["kind"] == "exact_terminal":
        common.need(text.strip().splitlines()[-1] == rule["terminal"], "native_terminal", "Complete source-exact final control/cell protocol")
        return {"terminal": rule["terminal"]}
    decoder = json.JSONDecoder(object_pairs_hook=common.unique)
    possible = []
    for index, char in enumerate(text):
        if char != "{": continue
        try: value, end = decoder.raw_decode(text, index)
        except (ValueError, json.JSONDecodeError): continue
        if not text[end:].strip(): possible.append(value)
    common.need(len(possible) == 1 and common.encoded(possible[0]) == common.encoded(rule["expected"]),
                "native_complete_output", "Every original numerical/profile/source field and negative control, not just a PASS string")
    return possible[0]


def execute(task_id, task, *, runtime_profile_digest, timeout=43200, supervisor=None):
    task = Path(task).resolve(); request = guard(task)
    common.need(request["task_id"] == task_id and type(timeout) is int and 1 <= timeout <= 82800,
                "execution_request", "One admitted exact task and outer remaining campaign wall budget")
    common.need(type(runtime_profile_digest) is str and len(runtime_profile_digest) == 64
                and all(char in "0123456789abcdef" for char in runtime_profile_digest), "runtime_profile", "Campaign pre/post runtime seal reference")
    common.need(not (task / "TASK-COMPLETED.json").exists() and not (task / "execution.log").exists(), "fresh_execution", "No historical completion/log")
    row = request["definition"]
    command = [sys.executable, "-E", "-B", "-S", str(HERE / "finite61_worker.py"), str(task / "SOURCE-REQUEST.json")]
    metadata = (supervisor or common._default_supervisor)(command, task / "capsule" / row["cwd"], task / "execution.log", timeout)
    common.need(type(metadata) is dict and type(metadata.get("returncode")) is int and metadata["returncode"] == 0
                and metadata.get("reason") == "completed" and metadata.get("tree_cleanup_complete") is True,
                "native_failure", "Successful complete child termination and cleanup, including limit/exit races")
    log_raw = common.regular(task / "execution.log", common.MAX_LOG)
    process = {"command": command, "supervisor": metadata, "log_sha256": common.sha(log_raw)}
    guard(task)
    trace = common.parsed(common.regular(task / "SOURCE-READ-TRACE.json", MAX_INPUT))
    common.need(trace.get("unexpected_reads") == [] and set(trace.get("reads", [])) <= set(request["inputs"]),
                "unqualified_runtime_read", "All actual source/data reads lie in the frozen private closure; runtime is separately sealed")
    text = common.regular(task / "execution.log", common.MAX_LOG).decode("utf-8")
    result = dict(schema="be.finite61-completed/1", task_id=task_id, campaign_id=request["campaign_id"],
                  implementation=implementation(), source_manifest_sha256=MANIFEST_SHA,
                  input_statement_digest=identity("task-inputs", request), runtime_profile_digest=runtime_profile_digest,
                  campaign_runtime_seal_required=True, coordinator_execution_authentication_required=True,
                  process=process, source_read_trace_sha256=common.sha(common.encoded(trace)),
                  current_parent_licenses_required=True, all_law_provider_populated=False, full_proof_pass=False)
    if row["kind"] == "native":
        result.update(outcome="CONDITIONAL_FINITE61_NATIVE_REPLAY_COMPLETED", native_report=_stdout(text, row["stdout_rule"]),
                      original_mathematical_program_unchanged=True,
                      original_semantic_argv=["python", "-B", row["script"], *row["arguments"]])
    else:
        raw = common.regular(task / "LOW-ROW.json", MAX_INPUT); packet = common.parsed(raw)
        common.need(set(packet) == ROW_FIELDS and type(packet["index"]) is int and type(packet["sign"]) is int
                    and (packet["index"], packet["sign"]) == (row["index"], row["sign"])
                    and packet["proof"]["contract"]["N"] == 42, "low_row_scope", "Actual selected signed index42 row")
        result.update(outcome="FRESH_LOW_ROW_COMPUTED_NOT_ACCEPTED", row_sha256=common.sha(raw),
                      full_original_binder_replay_still_required=True, gates=packet["report"]["gates"])
    (task / "TASK-COMPLETED.json").write_bytes(common.encoded(result))
    return result


def run(task_id, cache, task, *, campaign_id, runtime_profile_digest, rows=None, timeout=43200, supervisor=None):
    prepare(task_id, cache, task, campaign_id=campaign_id, rows=rows)
    return execute(task_id, task, runtime_profile_digest=runtime_profile_digest, timeout=timeout, supervisor=supervisor)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-id", required=True); parser.add_argument("--cache", type=Path, default=HERE)
    parser.add_argument("--task", type=Path, required=True); parser.add_argument("--campaign-id", required=True)
    parser.add_argument("--runtime-profile-digest", required=True); parser.add_argument("--rows", type=Path)
    parser.add_argument("--timeout", type=int, default=43200)
    args = parser.parse_args()
    rows = common.parsed(common.regular(args.rows, MAX_INPUT)) if args.rows else None
    result = run(args.task_id, args.cache, args.task, campaign_id=args.campaign_id,
                 runtime_profile_digest=args.runtime_profile_digest, rows=rows, timeout=args.timeout)
    print(common.encoded({"task_id": args.task_id, "outcome": result["outcome"], "full_proof_pass": False}).decode())


if __name__ == "__main__": main()
