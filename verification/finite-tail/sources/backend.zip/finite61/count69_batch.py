"""Fresh source-only finite6--9 COUNT batch: 284 independent complete forests.

No archived forest or old numerical acceptance is staged. Exact original
construct/accept programs run in separate private processes. The current
runtime profile is supplied by a campaign-level pre/post seal, not rehashed
thousands of times. Numerical replay stays conditional on resource acquisition.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from functools import lru_cache
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from typing import Callable
import zipfile

HERE = Path(__file__).resolve().parent
SNAPSHOT = HERE / "snapshot"
CATALOG = SNAPSHOT / "proof/finite69_sources_catalog.json"
CATALOG_SHA = "2a0575f59f9d6c8e95c53f68767b1cbae28b1ed2f5cd72c27a240b50d1367232"
MIB = 1024**2
MAX_SOURCE = MIB
MAX_FOREST = 64*MIB
MAX_LOG = 16*MIB
MAX_NODES = 1000000
MAX_DEPTH = 128
PROTOCOL = "be.fresh-count69/1"
TRUST = "native-python-source-replay-conditional-campaign-runtime-seal-v1"
NativeSupervisor = Callable[[list[str], Path, Path, int], dict]


class BatchError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def need(condition, code, message):
    if not condition:
        raise BatchError(code, message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")


def identity(kind, value):
    return sha(("BEFRESHCOUNT69/1\n"+kind+"\n").encode("ascii")+encoded(value))


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate_key", "No duplicate JSON keys")
        result[key] = value
    return result


def parsed(raw):
    try:
        return json.loads(raw, object_pairs_hook=unique,
                          parse_constant=lambda _: (_ for _ in ()).throw(BatchError("nonfinite_json", "Finite JSON only")))
    except (json.JSONDecodeError, UnicodeError, RecursionError) as error:
        raise BatchError("invalid_json", str(error)) from error


def regular(path, limit=MAX_SOURCE):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "regular_file", str(path))
    need(path.stat().st_size <= limit, "input_limit", str(path))
    with path.open("rb") as stream:
        raw = stream.read(limit+1)
    need(len(raw) <= limit, "input_limit", str(path))
    return raw


def file_sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(MIB):
            digest.update(block)
    return digest.hexdigest()


@lru_cache(maxsize=1)
def catalog():
    raw = regular(CATALOG, 32*MIB)
    need(sha(raw) == CATALOG_SHA, "catalog_pin", "Exact source-selected finite69 catalog")
    data = parsed(raw)
    need(data["schema"] == "FINITE69_SELECTED_SOURCE_CATALOG_V1"
         and len(data["jobs"]) == 284 and len({r["job_id"] for r in data["jobs"]}) == 284,
         "catalog_scope", "All 284 unique conditional COUNT obligations")
    return data


def jobs():
    return catalog()["jobs"]


def job(job_id):
    result = [row for row in jobs() if row["job_id"] == job_id]
    need(len(result) == 1, "job_id", "One exact selected finite69 COUNT job")
    return result[0]


def sources(row):
    """Flat exact original source closure, explicitly excluding old candidates."""
    prefix = row["selection"]["capsule"]+"/"
    result = {}
    for name, digest in row["source_files_sha256"].items():
        need(name.startswith(prefix), "source_scope", "One original native source directory")
        flat = name[len(prefix):]
        need(flat and "/" not in flat and "\\" not in flat and ":" not in flat,
             "flat_source", "Flat original source name")
        if flat == row["selection"]["forest_name"]:
            continue
        need(flat != row["selection"]["receipt_name"] and not flat.startswith("accepted_"),
             "no_historical_receipt", "Acceptance receipts are never source inputs")
        meta = catalog()["source_files"][name]
        need(meta["sha256"] == digest and meta["bytes"] <= MAX_SOURCE, "source_design", "Exact bounded source pin")
        result[flat] = meta
    need({"count_protocol.py", "contract.json", "KERNEL_COPY_MANIFEST.json"} <= set(result),
         "source_closure", "Actual checker, fixed contract and complete kernel")
    return result


def source_epoch(row):
    return identity("source-epoch", {"catalog": CATALOG_SHA, "job_id": row["job_id"],
                    "sources": {k: v["sha256"] for k, v in sources(row).items()}})


def prepare_source_cache(archives: dict[str, Path], output: Path):
    """606 unique source blobs (~3.75MB), no historical numerical outputs."""
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output/"blobs").mkdir(exist_ok=True)
    definitions = {}
    for row in jobs():
        for meta in sources(row).values():
            definitions.setdefault(meta["sha256"], meta)
    opened = {}
    indices = {}
    try:
        used = {meta["archive"] for meta in definitions.values()}
        for asset in catalog()["assets"]:
            if asset["name"] not in used:
                continue
            path = Path(archives[asset["name"]])
            need(path.is_file() and not path.is_symlink() and path.stat().st_size == asset["bytes"]
                 and file_sha(path) == asset["sha256"], "archive_pin", "Exact source archive: "+asset["name"])
            opened[asset["name"]] = zipfile.ZipFile(path)
            index = {}
            for info in opened[asset["name"]].infolist():
                index.setdefault(info.filename, []).append(info)
            indices[asset["name"]] = index
        for digest, meta in sorted(definitions.items()):
            dest = output/"blobs"/digest
            if dest.exists():
                raw = regular(dest)
            else:
                archive = opened[meta["archive"]]
                matches = indices[meta["archive"]].get(meta["member"], [])
                need(len(matches) == 1 and matches[0].file_size == meta["bytes"], "member_identity", "Unique exact source member")
                with archive.open(matches[0]) as stream:
                    raw = stream.read(MAX_SOURCE+1)
                need(len(raw) == meta["bytes"] and sha(raw) == digest, "member_pin", "Source member size/SHA")
                with dest.open("xb") as target:
                    target.write(raw)
            need(len(raw) == meta["bytes"] and sha(raw) == digest, "source_blob", "Source CAS byte integrity")
        index = {"schema": PROTOCOL, "kind": "source-cache", "catalog_sha256": CATALOG_SHA,
                 "source_blobs": {k: {"bytes": v["bytes"], "sha256": k} for k, v in definitions.items()},
                 "historical_forests_staged": False, "historical_acceptances_staged": False}
        raw = encoded(index)
        marker = output/"SOURCE-CACHE.json"
        if marker.exists():
            need(regular(marker) == raw, "source_cache_epoch", "Exact source-only cache epoch")
        else:
            marker.write_bytes(raw)
        return {"source_blobs": len(definitions), "bytes": sum(v["bytes"] for v in definitions.values()),
                "source_cache_sha256": sha(raw)}
    finally:
        for archive in opened.values():
            archive.close()


def read_sources(row, cache):
    result = {}
    for name, meta in sources(row).items():
        raw = regular(Path(cache)/"blobs"/meta["sha256"])
        need(len(raw) == meta["bytes"] and sha(raw) == meta["sha256"], "source_blob", "Source CAS pin: "+name)
        result[name] = raw
    return result


def validate_directory(row, directory):
    blobs = {}
    for name, meta in sources(row).items():
        raw = regular(Path(directory)/name)
        need(len(raw) == meta["bytes"] and sha(raw) == meta["sha256"], "source_pin", "Exact native source: "+name)
        blobs[name] = raw
    return blobs


def prepare(job_id: str, cache: Path, task: Path):
    row = job(job_id)
    need(not Path(task).exists(), "fresh_task", "Fresh private job task")
    task = Path(task).resolve()
    task.mkdir(parents=True)
    for role in ("produce", "verify"):
        directory = task/role
        directory.mkdir()
        for name, raw in read_sources(row, cache).items():
            with (directory/name).open("xb") as stream:
                stream.write(raw)
        need(not (directory/row["selection"]["forest_name"]).exists()
             and not (directory/row["selection"]["receipt_name"]).exists(),
             "source_only", "No old candidate or acceptance in execution directories")
    request = {"schema": PROTOCOL, "job_id": job_id, "catalog_sha256": CATALOG_SHA,
               "source_epoch_digest": source_epoch(row), "fresh_construct_required": True,
               "source_files": {k: v["sha256"] for k, v in sources(row).items()},
               "parent_acquisitions_verified": False, "all_index_conclusion_verified": False}
    (task/"TASK.json").write_bytes(encoded(request))
    return request


def _default_supervisor(command, cwd, log, timeout):
    started = time.monotonic()
    with Path(log).open("xb") as output:
        process = subprocess.Popen(command, cwd=cwd, stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=subprocess.STDOUT, shell=False)
        try:
            while process.poll() is None:
                need(time.monotonic()-started <= timeout, "wall_timeout", "Native wall deadline")
                need(Path(log).stat().st_size <= MAX_LOG, "log_limit", "Native log size")
                time.sleep(.05)
        except BaseException:
            process.kill()
            process.wait()
            raise
    return {"returncode": process.returncode, "elapsed_seconds": time.monotonic()-started,
            "reason": "completed", "tree_cleanup_complete": True}


def _run(row, directory, action, *, timeout, supervisor=None):
    need(type(timeout) is int and 1 <= timeout <= 54000, "timeout", "Explicit bounded per-action wall limit")
    before = validate_directory(row, directory)
    output = row["selection"]["forest_name"] if action == "construct" else row["selection"]["receipt_name"]
    need(not (directory/output).exists(), "fresh_native_output", "Native output cannot preexist")
    log = directory/(action+".log")
    need(not log.exists(), "fresh_log", "Native log cannot preexist")
    command = [sys.executable, "-E", "-B", "-S", str(directory/"count_protocol.py"), action]
    metadata = (supervisor or _default_supervisor)(command, directory, log, timeout)
    need(type(metadata) is dict and type(metadata.get("returncode")) is int and metadata["returncode"] == 0
         and metadata.get("reason") == "completed" and metadata.get("tree_cleanup_complete") is True,
         "native_failure", "Native execution, termination reason or process cleanup was not complete: "+str(log))
    log_raw = regular(log, MAX_LOG)
    need(before == validate_directory(row, directory), "source_changed", "Frozen native source after execution")
    return {"command": ["python", "-E", "-B", "-S", "count_protocol.py", action],
            "supervisor": metadata, "log_sha256": sha(log_raw)}


def literal_header(code):
    tree = ast.parse(code)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "header"]
    need(len(functions) == 1 and len(functions[0].body) == 1, "header_shape", "Reviewed literal native header function")
    call = functions[0].body[0].value
    need(isinstance(call, ast.Call) and isinstance(call.func, ast.Name) and call.func.id == "dict", "header_shape", "Native dict header")
    fields = {entry.arg: entry.value for entry in call.keywords}
    return {key: ast.literal_eval(fields[key]) for key in ("schema", "n", "index")}


def forest_census(row, raw, directory):
    need(len(raw) <= MAX_FOREST, "forest_limit", "Bounded complete native forest")
    obj = parsed(raw)
    blobs = validate_directory(row, directory)
    selection = row["selection"]
    header = literal_header(blobs["count_protocol.py"])
    header.update(target=selection["target"], contract_sha256=selection["contract_pin"],
                  checker_sha256=sha(blobs["count_protocol.py"]),
                  kernel_sha256=parsed(blobs["KERNEL_COPY_MANIFEST.json"])["files"])
    need(type(obj) is dict and set(obj) == set(header)|{"roots"}, "forest_schema", "Exact native header and roots")
    for key, value in header.items():
        need(type(obj[key]) is type(value) and obj[key] == value, "forest_header", "Native header binding: "+key)
    n = selection["n"]
    roots = obj["roots"]
    need(type(roots) is list and len(roots) == n+1, "complete_roots", "All original n+1 nearest counts")
    cfg = parsed(blobs["contract.json"])["rows"][0]
    start = [[Fraction(t) for t in cfg["p"]], [Fraction(0), Fraction(cfg["Lambda"])],
             [Fraction(0), Fraction(1)], [Fraction(-1,2), Fraction(1,2)],
             [Fraction(0), Fraction(cfg["d0"])]]
    nodes = leaves = depthmax = 0
    statuses = Counter()
    maximum = Fraction(0)
    for k, root in enumerate(roots):
        need(type(root) is dict and set(root) == {"k", "tree"}
             and type(root["k"]) is int and root["k"] == k, "root_order", "Exactly ordered count roots")
        todo = [(root["tree"], start, 0)]
        while todo:
            node, box, depth = todo.pop()
            nodes += 1
            depthmax = max(depthmax, depth)
            need(nodes <= MAX_NODES and depth <= MAX_DEPTH, "forest_budget", "Finite full tree budget")
            need(type(node) is dict, "tree_node", "Native tree node object")
            if node.get("kind") == "split":
                need(set(node) == {"kind", "axis", "cut", "left", "right"}
                     and type(node["axis"]) is int and 0 <= node["axis"] < 5
                     and type(node["cut"]) is str and len(node["cut"]) <= 2048,
                     "complete_split", "Exact axis, cut and both children")
                axis, cut = node["axis"], Fraction(node["cut"])
                need(box[axis][0] < cut < box[axis][1], "strict_cut", "Strict interior rational cut")
                left, right = ([p[:] for p in box] for _ in range(2))
                left[axis][1], right[axis][0] = cut, cut
                todo.extend(((node["right"], right, depth+1), (node["left"], left, depth+1)))
                continue
            need(node.get("kind") == "leaf" and set(node) == {"kind", "box", "decision", "result"},
                 "leaf_schema", "Complete leaf with no success shortcut")
            need(node["box"] == [[str(a),str(b)] for a,b in box] and type(node["decision"]) is str
                 and type(node["result"]) is dict, "original_leaf_box", "Reconstructed original closed box")
            leaves += 1
            statuses[node["decision"]] += 1
            if node["decision"] == "PASS_TARGET":
                maximum = max(maximum, Fraction(node["result"]["score_upper"]))
    return {"roots": n+1, "nodes": nodes, "leaves": leaves, "maximum_depth": depthmax,
            "closed_statuses": dict(statuses), "maximum_score": str(maximum)}


def construct(job_id: str, task: Path, *, timeout=300, supervisor: NativeSupervisor|None=None):
    adapter_pin = sha(regular(Path(__file__)))
    row = job(job_id)
    directory = Path(task).resolve()/"produce"
    process = _run(row, directory, "construct", timeout=timeout, supervisor=supervisor)
    raw = regular(directory/row["selection"]["forest_name"], MAX_FOREST)
    census = forest_census(row, raw, directory)
    need(sha(regular(Path(__file__))) == adapter_pin, "adapter_changed", "Unchanged batch adapter during construction")
    result = {"schema": PROTOCOL, "job_id": job_id, "operation": "construct",
              "source_epoch_digest": source_epoch(row), "candidate_sha256": sha(raw),
              "candidate": str(directory/row["selection"]["forest_name"]),
              "fresh_census": census, "process": process, "accepted": False}
    (Path(task)/"CONSTRUCTED.json").write_bytes(encoded(result))
    return result


def accept(job_id: str, task: Path, *, runtime_profile_digest: str, timeout=54000,
           supervisor: NativeSupervisor|None=None):
    adapter_pin = sha(regular(Path(__file__)))
    need(type(runtime_profile_digest) is str and re.fullmatch(r"[a-f0-9]{64}", runtime_profile_digest),
         "runtime_profile", "Campaign runtime pre/post seal digest required")
    row = job(job_id)
    task = Path(task).resolve()
    producer, verifier = task/"produce", task/"verify"
    forest_name = row["selection"]["forest_name"]
    raw = regular(producer/forest_name, MAX_FOREST)
    census = forest_census(row, raw, producer)
    need(not (verifier/forest_name).exists(), "fresh_verifier_candidate", "No old or preexisting verifier forest")
    with (verifier/forest_name).open("xb") as stream:
        stream.write(raw)
    process = _run(row, verifier, "accept", timeout=timeout, supervisor=supervisor)
    receipt_raw = regular(verifier/row["selection"]["receipt_name"], MAX_FOREST)
    receipt = parsed(receipt_raw)
    schema = row["native_schema"]
    need(type(receipt) is dict and set(receipt) == set(schema["fields"]), "receipt_schema", "Whole native receipt field set")
    for key in ("status", "scope", "n", "index"):
        need(type(receipt[key]) is type(schema[key]) and receipt[key] == schema[key], "receipt_scope", "Native receipt scope: "+key)
    blobs = validate_directory(row, verifier)
    for key, expected in (("forest_sha256",sha(raw)), ("contract_sha256",sha(blobs["contract.json"])),
                          ("checker_sha256",sha(blobs["count_protocol.py"]))):
        need(receipt[key] == expected, "receipt_binding", "Fresh receipt digest: "+key)
    kernel = parsed(blobs["KERNEL_COPY_MANIFEST.json"])["files"]
    need(receipt["kernel_sha256"] == kernel, "kernel_binding", "Entire exact numerical kernel")
    need(receipt["statistics"] == {k:v for k,v in census.items() if k != "roots"}, "fresh_statistics", "Dynamic full newly constructed census")
    need(type(receipt["fresh_leaf_evaluations"]) is int and receipt["fresh_leaf_evaluations"] == census["leaves"],
         "fresh_leaf_count", "All newly produced leaves re-evaluated")
    need(receipt["negative_controls"] == schema["controls"] and len(schema["controls"]) == 24,
         "native_controls", "All original 24 named corruption controls")
    need(Fraction(census["maximum_score"]) < Fraction(row["selection"]["target"]), "strict_target", "Strict ordinary COUNT bound")
    need(sha(regular(verifier/forest_name, MAX_FOREST)) == sha(raw), "candidate_changed", "Immutable candidate through replay")
    need(sha(regular(Path(__file__))) == adapter_pin, "adapter_changed", "Unchanged batch adapter during replay")
    key = identity("verification", {"catalog": CATALOG_SHA, "job_id": job_id, "source_epoch": source_epoch(row),
                  "candidate_sha256": sha(raw), "checker_sha256": receipt["checker_sha256"],
                  "adapter_sha256": sha(regular(Path(__file__))), "runtime_profile_digest": runtime_profile_digest,
                  "trust_profile": TRUST})
    result = {"schema": PROTOCOL, "job_id": job_id, "outcome": "SCOPED_COUNT_REPLAY_COMPLETED",
              "verification_key": key, "candidate_sha256": sha(raw), "native_receipt_sha256": sha(receipt_raw),
              "native_receipt": str(verifier/row["selection"]["receipt_name"]), "fresh_census": census,
              "source_epoch_digest": source_epoch(row), "runtime_profile_digest": runtime_profile_digest,
              "campaign_runtime_seal_required": True, "trust_profile": TRUST,
              "negative_controls": receipt["negative_controls"], "process": process,
              "parent_acquisitions_verified": False, "all_law_C6_9_verified": False, "full_proof_pass": False}
    (task/"REPLAY-COMPLETED.json").write_bytes(encoded(result))
    return result


def qualify_cache(cache: Path):
    """Static source qualification, no mathematical native imports/execution."""
    rows = []
    for row in jobs():
        blobs = read_sources(row, cache)
        code = ast.parse(blobs["count_protocol.py"])
        functions = {node.name for node in code.body if isinstance(node, ast.FunctionDef)}
        need({"construct", "accept", "replay", "children", "rootbox"} <= functions,
             "fresh_generator", "Complete source-backed generator and independent acceptor")
        header = literal_header(blobs["count_protocol.py"])
        need(header["n"] == row["selection"]["n"] and header["index"] == row["selection"]["index"],
             "literal_job", "Actual sample index/panel header")
        rows.append({"job_id":row["job_id"], "n":header["n"], "index":header["index"],
                     "band":row["selection"]["band"], "source_epoch_digest":source_epoch(row),
                     "native_checker_sha256":sha(blobs["count_protocol.py"]),
                     "contract_sha256":sha(blobs["contract.json"]), "source_files":len(blobs),
                     "construct_argv":["python","-E","-B","-S","count_protocol.py","construct"],
                     "accept_argv":["python","-E","-B","-S","count_protocol.py","accept"],
                     "cpu_slots":1, "memory_bytes":2*1024**3,
                     "historical_leaf_count_scheduling_hint_only":row["candidate_census"]["leaves"],
                     "historical_data_may_close_obligation":False,
                     "acceptance":"new forest digest/census + full native replay +24 controls + campaign runtime seal",
                     "mathematical_parent_license":"same-law source-exact contract acquisition required separately"})
    return {"schema":PROTOCOL, "kind":"qualified-source-task-catalog", "catalog_sha256":CATALOG_SHA,
            "tasks":rows, "count":len(rows), "per_n":dict(Counter(r["n"]for r in rows)),
            "independent_conditional_count_tasks":True, "fresh_construct_required":True,
            "runtime_profile_policy":"one full profile before batch; verify unchanged before final publication",
            "cache_policy":"only authenticated stages from the same fresh campaign may resume",
            "full_proof_pass":False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest="action",required=True)
    prep=sub.add_parser("source-cache")
    prep.add_argument("--archives",type=Path,required=True)
    prep.add_argument("--cache",type=Path,required=True)
    qualify=sub.add_parser("qualify")
    qualify.add_argument("--cache",type=Path,required=True)
    qualify.add_argument("--output",type=Path,required=True)
    run=sub.add_parser("job")
    run.add_argument("--job-id",required=True)
    run.add_argument("--cache",type=Path,required=True)
    run.add_argument("--task",type=Path,required=True)
    run.add_argument("--runtime-profile-digest",required=True)
    run.add_argument("--construct-timeout",type=int,default=300)
    run.add_argument("--accept-timeout",type=int,default=54000)
    args=parser.parse_args()
    need(__debug__ and not sys.flags.optimize,"optimization_forbidden","Ordinary exact Python required")
    if args.action=="source-cache":
        assets={row["name"]:args.archives/row["name"]for row in catalog()["assets"]}
        print(encoded(prepare_source_cache(assets,args.cache)).decode())
    elif args.action=="qualify":
        result=qualify_cache(args.cache)
        args.output.write_bytes(encoded(result))
        print(encoded({"qualified":result["count"],"per_n":result["per_n"],"output":str(args.output)}).decode())
    else:
        prepare(args.job_id,args.cache,args.task)
        produced=construct(args.job_id,args.task,timeout=args.construct_timeout)
        print(encoded({"stage":"construct","job_id":args.job_id,"census":produced["fresh_census"]}).decode(),flush=True)
        result=accept(args.job_id,args.task,runtime_profile_digest=args.runtime_profile_digest,timeout=args.accept_timeout)
        print(encoded(result).decode(),flush=True)


if __name__=="__main__":
    main()
